# **Plugin de calcul des écarts entre deux schémas de données**
Ce Plugin est composé de deux parties, Analyse des écarts entre deux livrables, Découpage d'un livrable à la ZSRO.
## ***Analyse des écarts entre deux livrables :***
- ### ***Objectif :***
Ce module permet de comparer deux livrables déjà stockés en base de données, et d'identifier leurs différences.
- ### ***Données d’entrée :***
    L’utilisateur sélectionne à l'aide des listes déroulantes les livrables qu'il souhaite comparer, si ces derniers sont à l'echelle d'une ZSRO, il sélectionne egalement le ZSRO concerné. 
- ### ***Variables demandés :***
    - #### Nom du Schema Départ
    - #### Nom du Schema Arrivé
- ### ***Résultats :***
    L'analyse est stocké en base de données dans schéma cible, et se présente sous la forme de table:
    - #### res_entites_ajoutees, entité présente dans le schéma cible mais absente dans le schéma source,
    - #### res_entites_supprimees, entité présente dans le schéma source mais absente dans le schéma cible,
    - #### res_compare_geom, entité dont la géométrie est différente entre les deux schémas.
    Il y a deux méthodes utilisées pour le controle de la géométrie: 
    - #### La géométrie exacte (attribut 'diff_distance_01')
    - #### La géometrie avec une tolérance de 1cm (attribut 'difference_egal').
- ### ***Contraintes :***
    Toutes les données d'entrée doivent etre conformes et toutes les variables doivent etre renseignées.  
    La comparaison est basée sur les attributs de type « etiquette » pour les cables. Les tables 't_znro', 't_position','t_organisme', 't_reference', 't_baie', 't_ltech', 't_sitetech' et 't_tiroir' ne sont pas decoupée à l'echelle de la ZSRO. 
- ### ***Mode opératoire :***
    ![Erreur Image](assets/app_analyse_ecart.png)
## ***Découpage d'un livrable à la ZSRO :***
- ### ***Objectif :***
    Ce module permet de découper à l'echelle d'une ZSRO toutes les tables d'un schéma donné à l'echelle d'une PR,  en fonction de la table t_zsro de ce dernier.
- ### ***Données d’entrée :***
    Les données d'entrée correspondent à trois noms de schémas (schema_depart, schema_arrivé et schema_decoupe) d’un même « PR ». Par exemple, pour le PR 3_4, le schéma de départ est : « pr_3_4_exe_v_20191024 », le et le schéma d'arrivé est : « pr_3_4_exe_v_20191024 » et le schéma de découpe est : « decoupe_depart ».
- ### ***Variables demandés :***
    - #### Nom du Schema Départ
    - #### Nom du Schema Arrivé
    - #### Nom du Schema Decoupe à créer
- ### ***Résultats :***
    Les résultats correspondent à une création du schema  « decoupe_depart » avec la creation de toutes les tables par rapport au schéma de départ.
- ### ***Contraintes :***
    Il faut que la table t_zsro du schéma arrivé soit dans la meme zone que celles des données de toutes les tables dans du schéma départ. La maniére de découpage est géométrique.
- ### ***Mode opératoire :***
    ![Erreur Image](assets/app_decoupe.png)