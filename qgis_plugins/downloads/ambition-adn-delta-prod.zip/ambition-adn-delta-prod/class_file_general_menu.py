from qgis.PyQt.QtWidgets import QMessageBox, QWidget
from .class_file_global_menu import var_class_init_custom_menu_bar, ambition_menu
from .vidange_cache_qgis import function_delete_cache_qgis
from .forms.check_decoupe_delta_form import class_checkDecoupeDelta_dialog
from .forms.check_delta_form import class_checkDelta_dialog

name_menu_projet = var_class_init_custom_menu_bar.funct_add_submenu_projet_to_global(ambition_menu, 'ADN')
name_menu_groupe = "A.3. Contrôle ECART"


class ClassGeneraleMenu:
    def __init__(self, iface):
        self.iface = iface

    def initGui(self):
        # DELTA Submenu
        res_vidange = function_delete_cache_qgis()
        if res_vidange[1] is False:
            QMessageBox.warning(QWidget(), "Message dexecution de requete", 'Le cache nest pas vide ... ' + str(res_vidange))
        self.delta_menu = var_class_init_custom_menu_bar.func_add_submenu_group_to_projet(name_menu_projet, name_menu_groupe)
        var_class_init_custom_menu_bar.func_add_action_menu(self.delta_menu,
                                                            "A.3.1. Découpage d'un livrable à la ZSRO",
                                                            self.exe_class_checkDecoupeDelta_dialog)
        var_class_init_custom_menu_bar.func_add_action_menu(self.delta_menu,
                                                            "A.3.2. Analyse des écarts entre deux livrables",
                                                            self.exe_class_checkDelta_dialog)

    def unload(self):
        self.iface.removePluginMenu(name_menu_groupe, self.delta_menu.menuAction())

    def exe_class_checkDecoupeDelta_dialog(self):
        self.execheckdecoupedelta = class_checkDecoupeDelta_dialog(self.iface)
        self.execheckdecoupedelta.exec_()

    def exe_class_checkDelta_dialog(self):
        self.execheckdelta = class_checkDelta_dialog(self.iface)
        self.execheckdelta.exec_()
