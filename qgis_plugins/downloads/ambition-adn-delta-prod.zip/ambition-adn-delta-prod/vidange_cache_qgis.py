from qgis.core import QgsApplication
from qgis.utils import iface
from qgis.PyQt.QtWidgets import QMessageBox, QWidget
import sys
# # {
# # Initialize QGIS Application
# app = QgsApplication([], False)
# QgsApplication.setPrefixPath("C:\QGIS 3.22.13\apps\qgis-ltr", True)
# QgsApplication.initQgis()

def function_delete_cache_qgis():
    import os
    import shutil
    path = os.getenv('APPDATA')
    path_qgis = f"{path}\QGIS\QGIS3\profiles\default\cache"
    try:
        list_folder_deleted = []
        is_exist_path_qgis = os.path.exists(path_qgis)
        if is_exist_path_qgis:
            for file_object in os.listdir(path_qgis):
                file_object_path = os.path.join(path_qgis, file_object)
                if os.path.isfile(file_object_path) or os.path.islink(file_object_path):
                    list_folder_deleted.append(file_object_path)
                    os.unlink(file_object_path)
                else:
                    list_folder_deleted.append(file_object_path)
                    shutil.rmtree(file_object_path)
        return list_folder_deleted, True
    except Exception as error:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        QMessageBox.warning(QWidget(), "Message dexecution de requete", 'Le cache nest pas vide ... ' + str(exc_tb.tb_lineno))
        return str(path_qgis) + str(error), False