# **Plugin de Contrôle des données sur le projet Orange BTHD pour la distribution**
Ce Plugin est composé de deux parties, l'import des données dans la base de données et le Contrôle de ces données s'il agit des données de distribution. Le Contrôle de données se fait par un lancement d'une serie de traitements qui seront décrits ci-dessous. Pour avoir plus de détails sur les Contrôles, reportez vous sur le [Fichier Spec des Contrôles](./assets/docs_spec/DICO_POINTS_CONTROLEvPIEPOM.xlsx).
## ***Import des données***
- ### ***Objectif :***
Consiste à importer des données dans la base de données dont le format est celui de GraceTHD. La base de données est celle configurée dans le projet : bthd.
- ### ***Variables demandés :***
    - ###### Code déploiement+departement sous la forme suivante : 'T2-29' 
    - ###### Code affaire sous la forme : '01109' 
    - ###### Choix de la date 
    - ###### Trigramme NRO sous la forme : 'CRO' 
    - ###### INSEE NRO sous la forme : '29042' 
    - ###### Code armoire MEGALIS sous la forme : 'S029'
    - ###### Choix du dossier contenant les données 
- ### ***Résultats :***
    Le résultat est que les données seront importées dans la base de données sans message d'erreur. On aura un aperçu des checks sur le format de données : tables manquantes, attributs en plus/manquants, erreur de clés étrangères, erreur de topologie etc. Les données peuvent être consultés sous Qgis tout en choisissant le nom de la base et le schéma concerné ou bien faire l'objet d'un traitement.
- ### ***Contraintes :***
    Le format de données à importer est celui de GraceTHD à savoir des fichiers au format CSV et SHP. Il faut aussi renseigner toutes les variables demandées
- ### ***Mode opératoire :***
    ![Erreur Image](assets/import_data.png)
    ![Erreur Image](assets/import_message.png)

## ***Contrôle des données de distribution***
- ### ***Objectif :***
    Il est de réaliser soixante-trois contrôles qui sont :
    - ###### Contrôle RNRO.001 sur t_sitetech; Descripton: Shelter = Megalis NRA/bâtiment = Orange"
    - ###### Contrôle RNRO.00 sur t_znro; Descripton: Toujours NRO-PON-PTP
    - ###### Contrôle RNRO.003 sur t_sitetech; Descripton: SHELTER OU BATIMENT
    - ###### Contrôle RNRO.004 sur t_noeud; Descripton: Format, erreur de typo
    - ###### Contrôle RNRO.005 sur t_sitetech; Descripton: Si transport en cours = EXISTANT > cf.  st_avct Si distri en cours = DEPLOYE > cf. zn_etat, EN SERVICE pour les elements construit EXISTANT pour la location"
    - ###### Contrôle RSRO.00 sur t_sitetech; Descripton: Toujours MEGALIS
    - ###### Contrôle RSRO.003 sur t_sitetech; Descripton: Toujours ADR
    - ###### Contrôle RSRO.004 sur t_sitetech; Descripton: Toujours SRO
    - ###### Contrôle RSRO.006 sur t_noeud; Descripton: Format, erreur de typo > BLOCAGE JUSQU'AU NOM DE RUE"
    - ###### Contrôle RSRO.007 sur t_zsro; Descripton: Toujours PM400 ou PM700, comparer à la référence IPON et câlage > Source IPON ? Nombre de tete? > lié à la reference de modele, lié à la hauteur de la baie (x) > contrôle du cable, des tetes dans OGRE"
    - ###### Contrôle RSRO.009 sur t_sitetech; Descripton: Si transport en cours = EXISTANT Si distri en cours = DEPLOYE == Service ou pas > pas ?"
    - ###### Contrôle RSRO.01 sur t_noeud; Descripton: Vérifier tranche de déploiement + département
    - ###### Contrôle RSRO.013 sur t_noeud; Descripton: Vérifier code affaire
    - ###### Contrôle RSRO.014 sur t_noeud; Descripton: Nœud Megalis Bretagne + trigramme NRO
    - ###### Contrôle RSRO.015 sur t_noeud; Descripton: Nœud Megalis Bretagne + trigramme NRO + code armoire MEGALIS > ou trouver le code armoire MEGALIS"
    - ###### Contrôle RSRO.018 sur SRO; Descripton:  Contrôler la longueur des liens NRO vers PM  (max 14km)
    - ###### Contrôle REBP.001 sur BOITIER; Descripton: Si 'PA' :  ""MB"";bp_code;zn_r3_code;PT xxxxx (PA);insee /NRO Sinon : ""MB"";bp_code;zn_r3_code;PT xxxxx ;insee /NRO > Export IPON (où trouver l'information PA)? > Export GFI?"
    - ###### Contrôle REBP.00 sur BOITIER; Descripton: Toujours MEGALIS
    - ###### Contrôle REBP.003 sur BOITIER; Descripton: Toujours MEGALIS
    - ###### Contrôle REBP.004 sur BOITIER; Descripton: Toujours EXISTANT pour les contrôles en cours ?"
    - ###### Contrôle REBP.008 sur BOITIER; Descripton: Comparer avec la référence OGRE > comment extraire la donnée ?"
    - ###### Contrôle REBP.01 sur BOITIER; Descripton: Pas de chevauchement + suf
    - ###### Contrôle REBP.013 sur BOITIER; Descripton: Contrôler la longueur des liens NRO vers PBO  (max 19km)
    - ###### Contrôle REBP.014 sur BOITIER; Descripton: Contrôler que toutes les fibres du cable entrant du boitier sont modelisées dans le boitier ( compter nombre de t_position dans le boitier, comparer avec le nombre cb_capa_fo  du cable entrant)
    - ###### Contrôle REBP.015 sur BOITIER; Descripton: ZPBO incluse dans ZDEP
    - ###### Contrôle RCAB.001 sur CABLE; Descripton: MEGALIS BRETAGNE + CAPACITE + FONCTION + DATE DE POSE + cb_code + nd_r3_code + cb_rf_code + cb_codeext
    - ###### Contrôle RCAB.00 sur CABLE; Descripton: Vérifier tranche de déploiement + département
    - ###### Contrôle RCAB.003 sur CABLE; Descripton: Vérifier code affaire
    - ###### Contrôle RCAB.004 sur CABLE; Descripton: Toujours MEGALIS
    - ###### Contrôle RCAB.005 sur CABLE; Descripton: Toujours MEGALIS
    - ###### Contrôle RCAB.006 sur CABLE; Descripton: Toujours REC
    - ###### Contrôle RCAB.007 sur CABLE; Descripton: Toujours EXISTANT pour les contrôles en cours
    - ###### Contrôle RCAB.008 sur CABLE; Descripton: Toujours C 
    - ###### Contrôle RCAB.009 sur CABLE; Descripton: Toujours DI en distri, TR pour le transport
    - ###### Contrôle RCAB.010 sur CABLE; Descripton: Contrôle OGRE
    - ###### Contrôle RCAB.011 sur CABLE; Descripton: Comparer avec les dimensions validées THDB
    - ###### Contrôle RCAB.01 sur CABLE; Descripton: Contrôle OGRE
    - ###### Contrôle RCAB.013 sur CABLE; Descripton: Toujours 1 en transport / M6 DISTRI
    - ###### Contrôle RCAB.014 sur CABLE; Descripton: RI à connaître par rapport référence câble
    - ###### Contrôle RCAB.015 sur CABLE; Descripton: 15% cb_long + calclul distance NRO-PB =< 15km > respect du sens du cable OK > de facon attributaire"
    - ###### Contrôle RCAB.016 sur CABLE; Descripton: Calcul automatique
    - ###### Contrôle RPTE.001 sur POINT TECHNIQUE; Descripton: Vérifier identification du propriétaire
    - ###### Contrôle RPTE.00 sur POINT TECHNIQUE; Descripton: Vérifier identification du gestionnaire
    - ###### Contrôle RPTE.003 sur POINT TECHNIQUE; Descripton: Vérifier la conformité par rapport au pt_prop MB > CST SINON LOC"
    - ###### Contrôle RPTE.004 sur POINT TECHNIQUE; Descripton: Vérifier par rapport au pt_prop (cas par cas)
    - ###### Contrôle RPTE.005 sur POINT TECHNIQUE; Descripton: Type de site support (C = chambre, A = appui, I = immeuble)
    - ###### Contrôle RPTE.006 sur POINT TECHNIQUE; Descripton: Tirage ou Raccordement
    - ###### Contrôle RPTE.007 sur POINT TECHNIQUE; Descripton: Nature du site support 
    - ###### Contrôle RPTE.008 sur POINT TECHNIQUE; Descripton: Vérifier tranche de déploiement + département
    - ###### Contrôle RPTE.009 sur POINT TECHNIQUE; Descripton: Vérifier code affaire
    - ###### Contrôle RPTE.010 sur POINT TECHNIQUE; Descripton: Format, erreur de typo
    - ###### Contrôle RPTE.011 sur POINT TECHNIQUE; Descripton: Toujours PT
    - ###### Contrôle RCHE.001 sur CHEMINEMENT; Descripton: Vérifier tranche de déploiement + département
    - ###### Contrôle RCHE.00 sur CHEMINEMENT; Descripton: Vérifier code affaire
    - ###### Contrôle RCHE.003 sur CHEMINEMENT; Descripton: Vérifier par rapport au pt_prop (cas par cas)
    - ###### Contrôle RCHE.004 sur CHEMINEMENT; Descripton: Vérifier par rapport au pt_prop (cas par cas)
    - ###### Contrôle RCHE.005 sur CHEMINEMENT; Descripton: Vérifier par rapport à livraison (Transport, distri ou les deux)> fonction des cables, geom > TR , TD, DI"
    - ###### Contrôle RCHE.006 sur CHEMINEMENT; Descripton: Toujours TEL
    - ###### Contrôle RCHE.007 sur CHEMINEMENT; Descripton: 15% cb_long + ne doit pas dépasser km
    - ###### Contrôle RCHE.008 sur CHEMINEMENT; Descripton: Calcul automatique
    - ###### Contrôle RCHE.009 sur CHEMINEMENT; Descripton: Vérifier au cheminement
    - ###### Contrôle RADR.001 sur IMMEUBLE; Descripton: si collectif (PLUS DE 3 SUF, ab_nblab / nblpro),  Si organisme = 1 Si pas d'organisme = f ou 0 pour tous les imb > pav à 0"
    - ###### Contrôle RADR.00 sur IMMEUBLE; Descripton: si ad_iaccgst = 1 (Correlé avec ad_iaccgst)
- ### ***Variables demandés :***
    Nous rappelons que le schéma étude est le meme que celui d'Ogre.  
    - ###### Nom du schéma d'étude à sélectionner
    - ###### Code du déploiement + Département
    - ###### Code Affaire
    - ###### Code Trigramme NRO
    - ###### Code INSEE NRO
    - ###### Code Armoire
    - ###### Code NRO ou SRO du départ de parcours
- ### ***Résultats :***
    Les résultats sont dans la table: t_Contrôle_VariableCodeArmoire dans le schema étude declaré de l'interface
- ### ***Contraintes :***
    Toutes les variables de l'interface doivent etre renseignées et correspondantes aux données. 
- ### ***Mode opératoire :***
    ![Erreur Image](assets/ctrl_distri.png)
    ![Erreur Image](assets/ctrl_distri_message.png)