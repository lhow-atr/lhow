SET search_path TO schemacheck, gracethd, public;

Create OR Replace Function create_v_ct_unit()
	returns void
	as $$
	Declare 
		var_req text := '';
		row record;
	Begin
		For row in 
			select ct_pgs_code, ct_pgs_script FROM t_ct_code_pgs
		loop
		var_req := 'CREATE OR REPLACE VIEW v_ct_unit_' || row.ct_pgs_code || ' AS ' || replace(row.ct_pgs_script, '&', '');
		var_req := replace(var_req, 'ad.ad_nblhab + ad.ad_nblpro','ad.ad_nblhab::int + ad.ad_nblpro::int');
		var_req := replace(var_req, 'ad.ad_nbprhab + ad.ad_nbprpro','ad.ad_nbprhab::int + ad.ad_nbprpro::int');
		var_req := replace(var_req, 'cb.cb_capafo > cast(conf.capamax as integer)','cb.cb_capafo::int > cast(conf.capamax as integer)');
		var_req := replace(var_req, 'cb.cb_capafo <','cb.cb_capafo::int < ');
		--RAISE NOTICE '%' , var_req;
		EXECUTE var_req;
		end loop;
	end;
	$$
	LANGUAGE plpgsql;

select * from create_v_ct_unit()