SET search_path TO schemacheck, gracethd, public;

/*VIEWS*/

DROP VIEW IF EXISTS "v_ct_exe" CASCADE;
CREATE VIEW v_ct_exe AS
SELECT * FROM t_ct_exe_pgs
ORDER BY ct_code