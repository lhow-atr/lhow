# -*- coding: utf-8 -*-
import csv
import os
import psycopg2.extras
from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtWidgets import QWidget, QProgressDialog, QMessageBox
from qgis.core import QgsDataSourceUri, QgsVectorLayer, Qgis
from qgis.utils import iface
from osgeo import ogr
import json

import sys
from pathlib import Path

folder_plugin = str(Path(__file__).parent.parent)
sys.path.append(folder_plugin)
# {folder_plugin = r'C:\Users\babacar.fassa\Documents\GitHub\orange-thdb-rec-distri'
from bdd_bthd.params_connexion import function_connexion, DB, user, MP, host, port


# Class pour les fonctions generales
class GeneralFunctions:
    w = QWidget()

    # Function pour la progession bar1
    @staticmethod
    def progress_bar(name_etape):
        prog = QProgressDialog(name_etape + ' : Veillez Patienter', 'Cancel', 0, 100)
        prog.setWindowModality(Qt.WindowModal)
        prog.setMinimumDuration(1)
        return prog

    # Function pour la progession bar2
    @staticmethod
    def progress_processing(index, count_entite, progress_dialog):
        f = int(index + 1)
        pcnt = int(f / count_entite * 100 / 1)
        progress_dialog.setValue(pcnt)

    # Function pour executer une requete sql dans la base
    def function_execute_requete(self, requete_execute, req_fetch, connection):
        curs = connection.cursor()
        try:
            curs.execute(requete_execute)
            if req_fetch:
                data_req = [row for row in curs.fetchall()]
                if data_req:
                    return data_req
        except(Exception, psycopg2.DatabaseError) as error:
            connection.commit()
            curs.close()
            QMessageBox.warning(self.w, "Message dexecution de requete", 'Requete Non Executer : ' + str(error) + ' ; ' + str(requete_execute))

    # Function pour  Get layer dans la BD
    def function_getlayer_bdd(self, schema, table_name, key, rename_table, column_geom):
        uri = QgsDataSourceUri()
        uri.setConnection(host, port, DB, user, MP)
        uri.setDataSource(schema, table_name, column_geom, '', key)
        layer = QgsVectorLayer(uri.uri(False), rename_table, "postgres")
        if layer.isValid():
            return layer
        else:
            return QMessageBox.warning(self.w, "Message", 'Erreur de recuperation de la table : ' + str(table_name))

    # Function Get file Sql
    @staticmethod
    def get_file_content_sql_gracethd(pathandfilename, var_replace_schemagra, schema_namegra,
                             var_replace_schemagra_in_check, schema_namegra_in_check):
        with open(pathandfilename, 'r', encoding="utf-8-sig") as theFile:
            data = theFile.read().replace(var_replace_schemagra, schema_namegra).replace(var_replace_schemagra_in_check,
                                                                                         schema_namegra_in_check)
            theFile.close()
            return data

    # Function Get file Sql
    @staticmethod
    def get_file_content_sql(path_and_file_name, schema_name):
        with open(path_and_file_name, 'r') as theFile:
            data = theFile.read().replace('var_schema', schema_name)
            theFile.close()
            return data


# Class pour importer des csv et shp dans BDD
class ImportMultiplesFilesCsvShp(GeneralFunctions):
    # Function initialisation
    def __init__(self, var_connection, var_schema, var_folder_data):
        self.connection = var_connection
        self.schema = var_schema
        self.folder_data = var_folder_data
        self.files_import = []
        self.list_error_traitement = []
        self.db_cursor = self.connection.cursor()
        self.function_import_mutiples_files()  # Execution des imports a linitialisation de la classe

    # Function pour Importer des fichiers csv dans une BDD
    def function_insert_csv_bdd(self, var_file):
        try:
            # https://stackoverflow.com/questions/48085319/python-reading-and-writing-csv-files-with-utf-8-encoding
            with open(var_file, encoding="utf-8-sig") as f:
                reader_file = csv.reader(f, delimiter=';')
                header = next(reader_file)
                file_name = '"' + os.path.basename(var_file).split('.')[0].replace(' ', '_').replace('-', '_').lower() + '"'
                # Creation de la table
                list_column = [str(key).replace("'", '').replace('"', '').replace(' ', '_').replace('-', '_')
                               for key in header]  # ';'.join(header).split(';')
                list_column_text = [str(key) + ' text' for key in list_column]
                req_create_table = f"DROP TABLE IF EXISTS {self.schema}.{file_name} cascade;" \
                                   f"CREATE TABLE {self.schema}.{file_name}({','.join(list_column_text)})"
                self.db_cursor.execute(req_create_table)
                # Insertion des elements dans la table creee
                list_all_feature_insert = []
                for index in reader_file:
                    list_tuple = tuple(index)
                    list_replace_carac = [str(key).replace("'", '').replace('"', '') for key in list_tuple]
                    values_features = str(tuple(list_replace_carac))
                    list_all_feature_insert.append(values_features)
                if list_all_feature_insert:
                    var_req_insert = f"INSERT INTO {self.schema}.{file_name}({','.join(list_column)})" \
                                     f"values{','.join(list_all_feature_insert)}"
                    self.db_cursor.execute(var_req_insert)
                    # {print(var_req_insert)
                # db_cursor.copy_from(f, var_schema + """.""" + file_name, sep=';')
                # logging.info(f"Partie Import CSV: Le CSV {var_file} est bien importe dans le schema {self.schema}")
        except Exception as error:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            self.list_error_traitement.append(['function_insert_csv_bdd', var_file, f"{error} ... {exc_tb.tb_lineno}"])

    # Function pour Importer des fichiers shp dans une BDD
    def function_insert_shp_bdd(self, var_shp):
        try:
            file_open = ogr.Open(var_shp, 0)
            if file_open is None:
                QMessageBox.information(self.w, "Message-Execution-Plugin",
                                        f"Partie Import SHP: Probleme Import SHP...Le Shape {var_shp} "
                                        f"ne peut pas etre ouvert")
            else:
                shape_feature = file_open.GetLayer(0)
                var_file_name = '"' + os.path.basename(var_shp).split('.')[0].\
                    replace(' ', '_').replace('-', '_').lower() + '"'
                dict_convert_type_field = {'String': 'character varying', 'Date': 'text',
                                           'Integer': 'Integer', 'Real': 'real', 'Integer64': 'Integer'}
                # Column_name et type
                list_column = []
                list_column_text = []
                for field in shape_feature.schema:
                    field_name = str(field.name).replace(' ', '_').replace('-', '_')
                    field_type_name = str(dict_convert_type_field[field.GetTypeName()])
                    field_width = str(field.GetWidth())
                    if field.GetTypeName() == 'String':
                        field_name_prepare = f"{field_name} {field_type_name}({str(field_width)})"
                    else:
                        field_name_prepare = f"{field_name} {field_type_name}"
                    list_column.append(field_name)
                    list_column_text.append(field_name_prepare)
                # Ajout de la colonne geometry
                list_column.append('geom')
                list_column_text.append('geom geometry')
                # Creation de la table
                req_create_table = f"DROP TABLE IF EXISTS {self.schema}.{var_file_name} cascade;" \
                                   f"CREATE TABLE {self.schema}.{var_file_name}({','.join(list_column_text)})"
                # Execution de la creation de la table
                self.db_cursor.execute(req_create_table)
                # Parcours du shape plus prepapration des donnees a inserer
                list_all_feature_insert = []
                for n in range(shape_feature.GetFeatureCount()):
                    feature_shp = shape_feature.GetFeature(n)
                    feature_json = json.loads(feature_shp.ExportToJson())
                    # {geaom_feature = f"ST_GeomFromText('{str(feature_shp.geometry())}')"
                    geaom_feature = f"ST_GeomFromText('{str(feature_shp.geometry())}',2154)"
                    list_values_attributs = list(feature_json['properties'].values())
                    list_appen_geom_feature = [None if field is None else str(field).replace("'", '')
                                               for field in list_values_attributs]
                    list_appen_geom_feature.append(geaom_feature)
                    tuple_appen_geom_feature = str(tuple(list_appen_geom_feature)).replace('"', '')
                    list_all_feature_insert.append(tuple_appen_geom_feature)
                # Insertion des elements dans la table
                if list_all_feature_insert:
                    var_req_insert = f"INSERT INTO {self.schema}.{var_file_name}({','.join(list_column)}) " \
                                     f"values{','.join(list_all_feature_insert)}".replace('None', 'NULL')
                    self.db_cursor.execute(var_req_insert)
                    # print(var_req_insert)

                # logging.info(f"Partie Import SHP: Le Shape {var_shp} est bien importe dans le schema {self.schema}")
        except Exception as error:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            self.list_error_traitement.append(['function_insert_shp_bdd', var_shp, f"{error} ... {exc_tb.tb_lineno}"])

    # Function Execution en masse des Imports des fichiers CSV/SHP dans une BDD
    def function_import_mutiples_files(self):
        try:
            if self.folder_data:
                # Creation du schema import
                self.db_cursor.execute(f"CREATE SCHEMA IF NOT EXISTS {self.schema}")
                folder_iterate = os.listdir(self.folder_data)
                bar_progress = self.progress_bar('Partie Import en Masse des donnees')
                for index_char_qgis, file_etude in enumerate(folder_iterate):
                    chemin = self.folder_data
                    name, ext = os.path.splitext(file_etude)
                    chem_etude = f"{chemin}/{file_etude}"
                    if ext == ".shp":
                        self.function_insert_shp_bdd(chem_etude)
                        self.connection.commit()
                        self.files_import.append(file_etude)
                    elif ext == ".csv":
                        self.function_insert_csv_bdd(chem_etude)
                        self.connection.commit()
                        self.files_import.append(file_etude)
                    elif ext in (".dbf", ".cpg", ".prj", ".shx", ".log", ".sbn", ".sbx", ".qgz", ".qpj", ".qml"):
                        continue
                    else:
                        self.list_error_traitement.append(
                            ['function_import_mutiples_files', f"{name}_{ext}",
                             f"Partie Import chaque table: Le fichier {name}_{ext} ne sera "
                             f"pas importe puisse quil nest pas un csv ni un shape"])
                    self.progress_processing(index_char_qgis, len(folder_iterate), bar_progress)
                    if bar_progress.wasCanceled():
                        iface.messageBar().pushMessage('Info', 'Action Cancelled', level=Qgis.Info)
                        break
                # self.connection.commit()
                self.db_cursor.close()
                self.connection.close()
                return self.files_import, self.list_error_traitement
            else:
                self.list_error_traitement.append(['function_import_mutiples_files', self.folder_data,
                                                   f"Partie Import en masse: Probleme choix repertoire des donnees..."
                                                   f"{self.folder_data}"])
        except Exception as error:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            self.list_error_traitement.append(['function_import_mutiples_files', 'function_import_mutiples_files', f"{error} ... {exc_tb.tb_lineno}"])


# Class pour model GraceTHD
class CreateModeleGraceTHD(GeneralFunctions):
    def __init__(self, var_connection, var_name_gracethd_file_sql, var_schema_gracethd_mod,
                 var_name_gracethdcheck_file_sql, var_schema_gracethd_che, var_path_folder_gracethd,
                 var_path_folder_gracethdcheck):
        self.connection = var_connection
        self.db_cursor = self.connection.cursor()

        self.schema_gracethd_replace = var_name_gracethd_file_sql  # NAme schema in the files sql
        self.schema_gracethd = var_schema_gracethd_mod  # NAme schema To replace in the files sql

        self.schema_gracethdcheck_replace = var_name_gracethdcheck_file_sql  # NAme schema in the files sql
        self.schema_gracethdcheck = var_schema_gracethd_che  # NAme schema To replace in the files sql

        self.path_folder_gracethd = var_path_folder_gracethd
        self.path_folder_gracethdcheck = var_path_folder_gracethdcheck

        self.list_error_traitement = []
        self.w = QWidget()

    # Function Creation du Schema GraceTHD
    def function_create_schemagrace_thd(self):
        try:
            if self.path_folder_gracethd:
                bar_progress = self.progress_bar('Partie Creation model GraceTHD')
                folder_iterate = os.listdir(self.path_folder_gracethd)
                for index_gracethd, file_gracethd_sql in enumerate(folder_iterate):
                    chemin = self.path_folder_gracethd
                    name, ext = os.path.splitext(file_gracethd_sql)
                    chem_file_gracethd_sql = chemin + '/' + file_gracethd_sql
                    try:
                        if ext == ".sql":
                            text_sql_file = self.get_file_content_sql_gracethd(chem_file_gracethd_sql, self.schema_gracethd_replace,
                                                                 self.schema_gracethd, '', '')
                            self.db_cursor.execute(text_sql_file)
                    except Exception as error:
                        self.list_error_traitement.append(['function_create_schemagrace_thd',
                                                           f"Partie Execution File Sql Gracethd: Le fichier sql {name} "
                                                           f"Nest Pas bien execute{error}"])
                    self.progress_processing(index_gracethd, len(folder_iterate), bar_progress)
                    if bar_progress.wasCanceled():
                        iface.messageBar().pushMessage('Info', 'Action Cancelled', level=Qgis.Info)
                        break
            else:
                QMessageBox.warning(self.w, "Message Execution", f'Erreur: {self.path_folder_gracethd}')
        except Exception as error:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            self.list_error_traitement.append(['function_create_schemagrace_thd',
                                               f"Partie Creation Schema Gracethd: Le schema Gracethd nest "
                                               f"pas creee...{error} ... {exc_tb.tb_lineno}"])

    # Function Creation du Schema GraceTHDCHECK
    def function_create_schemagracethdcheck(self):
        try:
            if self.path_folder_gracethdcheck:
                folder_iteratec = os.listdir(self.path_folder_gracethdcheck)
                list_sql_file_gracethdcheck = ['gracethdcheck_10_lists', 'gracethdcheck_30_tables',
                                               'gracethdcheck_20_insert',
                                               'gracethdcheck_31_filltab_insert', 'gracethdcheck_32_fillatt_insert',
                                               'gracethdcheck_32_fillatt_update',
                                               'gracethdcheck_33_conf_insert', 'gracethdcheck_34_cat_insert',
                                               'gracethdcheck_35_code_pgs_insert',
                                               'gracethdcheck_37_exe_pgs_fillatt_to_exe', 'gracethdcheck_50_index',
                                               'gracethdcheck_60_views',
                                               'f_recreate_v_ct_units', 'f_recreate_v_ct_anom',
                                               'gracethdcheck_62_views_anom_statut']
                bar_progress = self.progress_bar('Partie Create Model GraceTHDCHECK')
                for index_file, file_sql in enumerate(list_sql_file_gracethdcheck):
                    for index_gracethdc, file_gracethdc_sql in enumerate(folder_iteratec):
                        chemin = self.path_folder_gracethdcheck
                        name, ext = os.path.splitext(file_gracethdc_sql)
                        chem_file_gracethdc_sql = chemin + '/' + file_gracethdc_sql
                        try:
                            if file_sql == name and ext == ".sql":
                                text_sql_file = self.get_file_content_sql_gracethd(chem_file_gracethdc_sql,
                                                                     self.schema_gracethd_replace,
                                                                     self.schema_gracethd,
                                                                     self.schema_gracethdcheck_replace,
                                                                     self.schema_gracethdcheck)
                                if text_sql_file:
                                    self.db_cursor.execute(text_sql_file)
                        except Exception as error:
                            self.list_error_traitement.append(['function_create_schemagracethdcheck',
                                                               f"Partie Execution File Sql GracethdCheck: "
                                                               f"Le fichier sql {name} Nest Pas bien execute..."
                                                               f"{error}"])
                    self.progress_processing(index_file, len(list_sql_file_gracethdcheck), bar_progress)
                    if bar_progress.wasCanceled():
                        iface.messageBar().pushMessage('Info', 'Action Cancelled', level=Qgis.Info)
                        break
            else:
                QMessageBox.warning(self.w, "Message Execution", f'Erreur: {self.path_folder_gracethdcheck}')
        except Exception as error:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            self.list_error_traitement.append(['function_create_schemagracethdcheck',
                                               f"Partie Creation Schema GracethdCheck: Le schema GracethdCheck "
                                               f"nest pas creee...{error} ... {exc_tb.tb_lineno}"])


# Class Check
class ClassCheckMcd(GeneralFunctions):
    # Constructeur des variables qui change
    def __init__(self, var_connection, var_name_gracethd_file_sql, var_schema_gracethd_mod, var_schema_gracethd_input,
                 var_path_folder_gracethd, var_path_folder_gracethdcheck,
                 var_name_gracethdcheck_file_sql, var_schema_gracethd_che, var_name_phase):

        self.connection = var_connection
        self.db_cursor = self.connection.cursor()

        self.schema_gracethd_replace = var_name_gracethd_file_sql  # NAme schema in the files sql
        self.schema_gracethd = var_schema_gracethd_mod  # NAme schema To replace in the files sql
        self.schema_input_etude = var_schema_gracethd_input
        self.path_folder_gracethd = var_path_folder_gracethd
        self.path_folder_gracethdcheck = var_path_folder_gracethdcheck
        self.schema_gracethdcheck_replace = var_name_gracethdcheck_file_sql  # NAme schema in the files sql
        self.schema_gracethdcheck = var_schema_gracethd_che
        self.name_phase = var_name_phase
        self.list_error_traitement_check = []
        # connection.commit()

    # Function Creation du Schema GraceTHD
    def function_create_vues(self):
        try:
            path_folder_gracethd = self.path_folder_gracethd
            if path_folder_gracethd:
                folder_iterate = os.listdir(path_folder_gracethd)
                bar_progress = self.progress_bar('Partie Creation des Vues')
                for index_gracethd, file_gracethd_sql in enumerate(folder_iterate):
                    chemin = path_folder_gracethd
                    name, ext = os.path.splitext(file_gracethd_sql)
                    chem_file_gracethd_sql = chemin + '/' + file_gracethd_sql
                    try:
                        if ext == ".sql" and name in ('gracethd_61_vues_elem', 'gracethd_61_vues_elem_vmat'):
                            text_sql_file = self.get_file_content_sql_gracethd(chem_file_gracethd_sql, self.schema_gracethd_replace,
                                                                 self.schema_input_etude, '', '')
                            if text_sql_file:
                                self.db_cursor.execute(text_sql_file)
                    except Exception as error:
                        self.list_error_traitement_check.append(['function_create_vues',
                                                           f"Partie Creation Vues Gracethd: Le fichier sql {name} "
                                         f"Nest Pas bien execute...{error}"])
                    self.progress_processing(index_gracethd, len(folder_iterate), bar_progress)
                    if bar_progress.wasCanceled():
                        iface.messageBar().pushMessage('Info', 'Action Cancelled', level=Qgis.Info)
                        break
        except Exception as error:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            self.list_error_traitement_check.append(['function_create_vues',
                                                     f"Partie Creation Vues Gracethd: Les schema Vues Gracethd ne "
                                                     f"sont pas creees...{error} ... {exc_tb.tb_lineno}"])

    # Function Verfication de la structure de la donnee par rapport au format GraceTHD
    def function_check_erreur_mcd(self):
        try:
            path_folder_gracethdcheck = self.path_folder_gracethdcheck
            schema_mcd_mod = 'schema_mcd_mod'
            schema_etude_input = 'schema_etude_input'
            if path_folder_gracethdcheck:
                folder_iterate = os.listdir(path_folder_gracethdcheck)
                bar_progress = self.progress_bar('Partie Check des erreurs de format MCD')
                for index_gracethd, file_gracethd_sql in enumerate(folder_iterate):
                    chemin = path_folder_gracethdcheck
                    name, ext = os.path.splitext(file_gracethd_sql)
                    chem_file_gracethd_sql = chemin + '/' + file_gracethd_sql
                    try:
                        if ext == ".sql" and name == 'check_erreur_mcd':
                            text_sql_file = self.get_file_content_sql_gracethd(chem_file_gracethd_sql,
                                                                               schema_etude_input,
                                                                               self.schema_input_etude,
                                                                               schema_mcd_mod, self.schema_gracethd)
                            if text_sql_file:
                                self.db_cursor.execute(text_sql_file)
                    except Exception as error:
                        self.list_error_traitement_check.append(['function_check_erreur_mcd',
                                                                 f"Partie Check Format Gracethd: Le fichier sql "
                                                                 f"{name} Nest Pas bien execute...{error}"])
                    self.progress_processing(index_gracethd, len(folder_iterate), bar_progress)
                    if bar_progress.wasCanceled():
                        iface.messageBar().pushMessage('Info', 'Action Cancelled', level=Qgis.Info)
                        break
        except Exception as error:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            self.list_error_traitement_check.append(['function_check_erreur_mcd',
                                                     f"Partie Check Format Gracethd: Les Check Format Gracethd ne "
                                                     f"sont pas creees...{error} ... {exc_tb.tb_lineno}"])

    # Function Check des erreurs de GraceTHDCHECK selon le status
    def function_erreur_gracethdcheck_statut(self):
        try:
            string_query_rec = "select erreur_resCheck_statut('select requete as ct_code from " \
                               "synt_erreur_statut_check(''v_ct_anom_8_rec'')','erreur_gracethd_rec');"
            string_query_pro = "select erreur_resCheck_statut('select requete as ct_code from " \
                               "synt_erreur_statut_check(''v_ct_anom_4_pro'')','erreur_gracethd_pro');"
            string_query_exe = "select erreur_resCheck_statut('select requete as ct_code from " \
                               "synt_erreur_statut_check(''v_ct_anom_6_exe'')','erreur_gracethd_exe');"
            string_query_avp = "select erreur_resCheck_statut('select requete as ct_code from " \
                               "synt_erreur_statut_check(''v_ct_anom_3_avp'')','erreur_gracethd_avp');"
            list_function_statut = [string_query_avp, string_query_pro, string_query_rec, string_query_exe]
            list_statut = ['AVP', 'PRO', 'REC', 'DEO']
            zipb_obj = zip(list_statut, list_function_statut)
            dict_statut_check = dict(zipb_obj)
            bar_progress = self.progress_bar('Partie Check Erreur Selon statut')
            if self.path_folder_gracethdcheck:
                folder_iteratec = os.listdir(self.path_folder_gracethdcheck)
                for index_gracethdc, file_gracethdc_sql in enumerate(folder_iteratec):
                    chemin = self.path_folder_gracethdcheck
                    name, ext = os.path.splitext(file_gracethdc_sql)
                    chem_file_gracethdcs_sql = chemin + '/' + file_gracethdc_sql
                    try:
                        if ext == ".sql" and name == 'check_erreur_graceth_statut':
                            text_sql_file = self.get_file_content_sql_gracethd(chem_file_gracethdcs_sql,
                                                                 self.schema_gracethd_replace,
                                                                 self.schema_gracethd,
                                                                 self.schema_gracethdcheck_replace,
                                                                 self.schema_gracethdcheck)
                            if text_sql_file:
                                self.db_cursor.execute(text_sql_file)
                    except Exception as error:
                        self.list_error_traitement_check.append(['function_erreur_gracethdcheck_statut',
                                                                 f"Partie Check Statut Gracethd: Le fichier sql {name} "
                                         f"Nest Pas bien execute...{error}"])
                    self.progress_processing(index_gracethdc, len(folder_iteratec), bar_progress)
                    if bar_progress.wasCanceled():
                        iface.messageBar().pushMessage('Info', 'Action Cancelled', level=Qgis.Info)
                        break
            for index_gracethdc, (key, value) in enumerate(dict_statut_check.items()):
                reqexec = f"""SET search_path TO {self.schema_gracethd}, {self.schema_gracethdcheck}, public;{value}"""
                try:
                    if str(key).lower() == str(self.name_phase).lower():
                        self.db_cursor.execute(reqexec)
                except Exception as error:
                    self.list_error_traitement_check.append(['function_erreur_gracethdcheck_statut',
                                                             f"Partie Check Statut Gracethd: La requete {reqexec} "
                                     f"Nest Pas bien execute...{error}"])
                self.progress_processing(index_gracethdc, len(dict_statut_check), bar_progress)
                if bar_progress.wasCanceled():
                    iface.messageBar().pushMessage('Info', 'Action Cancelled', level=Qgis.Info)
                    break
        except Exception as error:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            self.list_error_traitement_check.append(['function_erreur_gracethdcheck_statut',
                                                     f"Partie Check Statut Gracethd: Les Check Statut Gracethd ne "
                                                     f"sont pas creees...{error} ... {exc_tb.tb_lineno}"])

    # Function pour creer des tables annexes ainsi que des droits
    def function_table_annexe(self, file_sql_annexe):
        name_schema_in_file = 'schema_name'
        text_sql_file = self.get_file_content_sql_gracethd(file_sql_annexe, name_schema_in_file, self.schema_input_etude, '', '')
        try:
            if text_sql_file:
                self.db_cursor.execute(text_sql_file)
        except Exception as error:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            self.list_error_traitement_check.append(['function_table_annexe',
                                                     f"Partie Check Statut Gracethd: La requete {text_sql_file} "
                                                     f"Nest Pas bien execute...{error} ... {exc_tb.tb_lineno}"])


# Function execute class import ou export
def function_execute_import_export(var_schema, var_folder_data, var_type_execute):
    w = QWidget()
    try:
        # Connexion a la base
        connection = psycopg2.connect(user=user, password=MP, host=host, port=port, database=DB)
        if var_type_execute == 'import':
            res_import = ImportMultiplesFilesCsvShp(connection, var_schema, var_folder_data)
            connection.close()
            return True, res_import.files_import, res_import.list_error_traitement
    except Exception as error:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        QMessageBox.information(w, "Message-Execution-Plugin", f"Partie Execution Import en masse: "
                                                               f"Probleme dexecution des imports en masse...{error} ... {exc_tb.tb_lineno}")
        return False, error, error


def function_execute_class_check_data(schema_input_etude, var_name_phase):
    w = QWidget()
    # {
    # folder_plugin = r'C:\Users\babacar.fassa\Documents\GitHub\orange-thdb-rec-distri'

    try:
        path_folder_gracethd = f'{folder_plugin}/file_sql/create_schema_gracethd'
        path_folder_gracethdcheck = f'{folder_plugin}/file_sql/create_schema_ckeck'
        # file_sql_annexe = f'{folder_plugin}/files_sql/autre_gracethd.sql'
        # Connexion a la base
        try:
            connection = psycopg2.connect(user=user, password=MP, host=host, port=port, database=DB)
            message_connexion = True
        except(Exception, psycopg2.DatabaseError) as error:
            QMessageBox.warning(w, "Message de connexion de la base", f'Erreur de Execution: {error}')
            return False, error

        if message_connexion is True:
            # print(folder_plugin, '\n', path_folder_gracethd, '\n', path_folder_gracethdcheck)
            schema_gracethd_replace = 'gracethd'  # NAme schema in the files sql
            schema_gracethdcheck_replace = 'schemacheck'  # NAme schema in the files sql
            schema_gracethdcheck = 'gracethd_check'  # NAme schema To replace in the files sql
            schema_gracethd = 'gracethd_mod'  # NAme schema To replace in the files sql

            # Suppression des schemas si existant
            var_schema_mod_drop = """DROP SCHEMA IF EXISTS """ + schema_gracethd + """ CASCADE;"""
            var_schema_check_drop = """DROP SCHEMA IF EXISTS """ + schema_input_etude + """_check""" + """ CASCADE;"""
            curs = connection.cursor()
            curs.execute(var_schema_mod_drop + var_schema_check_drop)
            curs.close()

            # Declaration des folders path_folder_gracethd,path_folder_gracethdcheck
            # Initialisation Class CreateModelGraceTHD
            class_schema_gracethd = CreateModeleGraceTHD(connection, schema_gracethd_replace, schema_gracethd,
                                                         schema_gracethdcheck_replace, schema_gracethdcheck,
                                                         path_folder_gracethd, path_folder_gracethdcheck)
            # Creation du Schema GraceTHD
            class_schema_gracethd.function_create_schemagrace_thd()

            # Initialisation Class ClassCheckMcd
            class_check_mcd_format = ClassCheckMcd(connection, schema_gracethd_replace, schema_gracethd,
                                                   schema_input_etude, path_folder_gracethd, path_folder_gracethdcheck,
                                                   schema_gracethdcheck_replace, schema_gracethdcheck, var_name_phase)
            class_check_mcd_format.function_check_erreur_mcd()  # Check Format MCD
            class_check_mcd_format.function_create_vues()  # Generation des vues

            # Reaffectation des variables pour un replacement dans la Class Create Model GraceTHD
            class_schema_gracethd.schema_gracethd = schema_input_etude
            schema_gracethdcheck = class_schema_gracethd.schema_gracethdcheck = schema_input_etude + '_check'

            # Reaffectation des variables pour un replacement dans la class Check
            class_check_mcd_format.schema_gracethd = schema_input_etude
            schema_gracethdcheck = class_check_mcd_format.schema_gracethdcheck = schema_input_etude + '_check'

            # Creation du Schema GraceTHDCHECK
            class_schema_gracethd.function_create_schemagracethdcheck()
            connection.commit()

            # Creation des Erreurs GraceTHD et GraceTHDCHECK
            class_check_mcd_format.function_erreur_gracethdcheck_statut()
            connection.commit()

            req_droit = f"""SET search_path TO {schema_input_etude}, public;
            ---DROP ROLE IF EXISTS bthd_ing cascade;
            ---CREATE ROLE bthd_ing WITH LOGIN PASSWORD 'bthd_ing' NOSUPERUSER INHERIT NOCREATEDB NOCREATEROLE NOREPLICATION;
            GRANT ALL ON SCHEMA {schema_input_etude} TO bthd_ing;
            GRANT SELECT, INSERT, Update ON ALL TABLES IN SCHEMA {schema_input_etude} TO bthd_ing;
            ALTER DEFAULT PRIVILEGES IN SCHEMA {schema_input_etude} GRANT SELECT, INSERT, UPDATE  ON TABLES TO bthd_ing;"""
            class_schema_gracethd.db_cursor.execute(req_droit)

            var_schema_mod = """DROP SCHEMA IF EXISTS """ + schema_gracethd + """ CASCADE"""
            var_schema_check = """DROP SCHEMA IF EXISTS """ + schema_gracethdcheck + """ CASCADE"""
            class_schema_gracethd.db_cursor.execute(var_schema_mod)
            class_schema_gracethd.db_cursor.execute(var_schema_check)
            connection.commit()
            connection.close()

            # QMessageBox.information(w, "Message de connexion de la base",
            #                     f"Erreur Create Model:  {','.join(class_schema_gracethd.list_error_traitement)} "
            #                         f"{len(class_schema_gracethd.list_error_traitement)}\n"
            #                     f"Erreur Check: {','.join(class_check_mcd_format.list_error_traitement_check)} "
            #                         f"{len(class_check_mcd_format.list_error_traitement_check)}")
            return class_schema_gracethd.list_error_traitement, class_check_mcd_format.list_error_traitement_check
        else:
            QMessageBox.warning(w, "Message de connexion de la base", f'Erreur de Execution: {message_connexion}')
    except Exception as error:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        QMessageBox.information(w, "Message-Execution-Plugin", f"Partie Execution All Check: Les Checks Ne sont "
                                                               f"Pas bien executes... {error} ... {exc_tb.tb_lineno}")
        return False, error


# {
# var_schema = 'schema_test'  # schema_test  gracethd  pr_1_17_deo_v_20200819
# var_folder_data = r'C:\data_all'
# var_folder_export = r'C:\Users\babacar.fassa\Desktop\export_test'
# res_import = function_execute_import_export(var_schema, var_folder_data, 'import')
# res_check = function_execute_class_check_data(var_schema, 'REC')
#
# QMessageBox.information(QWidget(), "Message-Execution-Plugin", f"Tables importees: {len(res_import[1])}\n"
#                                             f"Error Import: {' '.join(map(str, res_import[2]))}\n"
#                                             f"Error Create GraceTHD: {' '.join(map(str, res_check[0]))}\n"
#                                             f"Error Create GraceTHDChck: {' '.join(map(str, res_check[1]))}")
