from qgis.PyQt import QtWidgets
from qgis.utils import iface


class CustomMenuBar:
    # Partie I Pour la creation du La barre Menu Global
    @staticmethod
    def func_create_menu_global(name_menu_globagl):
        ambition_menu = iface.mainWindow().findChild(QtWidgets.QMenu, name_menu_globagl)
        if not ambition_menu:
            ambition_menu = QtWidgets.QMenu(name_menu_globagl, iface.mainWindow().menuBar())
            ambition_menu.setObjectName(name_menu_globagl)
            actions = iface.mainWindow().menuBar().actions()
            last_action = actions[-1]
            iface.mainWindow().menuBar().insertMenu(last_action, ambition_menu)
        return ambition_menu

    # Partie II Pour la creation du SousMenu Projet dans le Menu Global Cree en partie I
    @staticmethod
    def funct_add_submenu_projet_to_global(name_menu_globagl, submenu_projet_name):
        name_adn_menu = QtWidgets.QMenu(submenu_projet_name)
        name_adn_menu.setObjectName(submenu_projet_name)
        submenus = []
        for item in name_menu_globagl.actions():
            submenus.append(item)
        # Check submenu action list to see if 'MySubMenu' exists
        submenu_list = [x for x in submenus if x.text() == submenu_projet_name]  #
        # If 'MySubMenu' is not in above list (i.e. does not exist), create it
        if not submenu_list:
            name_menu_globagl.addMenu(name_adn_menu)  # submenu_projet_object
            return name_adn_menu  # submenu_projet_object
        return submenu_list[0].menu()

    # Partie III Pour la creation du SousSousMenu Group dans le SousMenu Projet Cree en partie II
    @staticmethod
    def func_add_submenu_group_to_projet(submenu_projet, submenu_projet_group):
        check_menu_design = [x for x in submenu_projet.actions() if x.text() == submenu_projet_group]
        if check_menu_design:
            for item in check_menu_design:
                if item.text() == submenu_projet_group:
                    submenu_projet.removeAction(item)
                    menu_group = submenu_projet.addMenu(submenu_projet_group)
                    return menu_group
        else:
            menu_group = submenu_projet.addMenu(submenu_projet_group)
            return menu_group

    # Partie IV Pour la creation dune action pour le SousSousMenu Group Cree en partie III
    @staticmethod
    def func_add_action_menu(func_ajout_menu_in_projet, submenu_projet_group_name_title_action, name_function_action):
        name_action = QtWidgets.QAction(submenu_projet_group_name_title_action, iface.mainWindow())
        name_action.triggered.connect(name_function_action)
        func_ajout_menu_in_projet.addAction(name_action)
        # return name_action


var_class_init_custom_menu_bar = CustomMenuBar()
ambition_menu = var_class_init_custom_menu_bar.func_create_menu_global('AMBITION_DEV')
# ambition_menu = var_class_init_custom_menu_bar.func_create_menu_global('AMBITION_PROD')
