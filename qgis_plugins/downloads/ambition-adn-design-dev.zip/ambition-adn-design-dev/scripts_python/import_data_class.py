import csv
import os
import re
import sys
import psycopg2
import psycopg2.extras
from osgeo import ogr, osr
import json

from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtWidgets import QApplication, QProgressDialog, QMessageBox, QWidget

from bdd.params_connexion import function_connexion

# app = QApplication(sys.argv)

# Class pour importer des csv et shp dans BDD
class ImportMultiplesFilesCsvShp:
    """
     [Cette Class permet d'importer des fichiers de format csv et shp dans une base de donnee]

    Returns:
        [type] -- [Il retourne 
            la liste des fichiers importes, 
            la liste des erreurs de traitements
            ]
    """    
    # Function initialisation
    def __init__(self, var_schema, var_folder_data):
        self.connection = function_connexion()
        self.schema = var_schema
        self.folder_data = var_folder_data
        self.files_import = []
        self.list_error = []
        self.db_cursor = self.connection.cursor()
        self.function_import_mutiples_files()  # Execution des imports a linitialisation de la classe
        self.connection.close()
        self.var_widget = QWidget()
        if self.list_error:
            QMessageBox.warning(self.var_widget, "Message Information: Cliquer sur Ok pour Continuer le traitement", f"Erreur de Traitement sur {','.join([f'{i[0]}__{i[1]}' for i in self.list_error])}")
    # Function pour la progression bar1
    @staticmethod
    def progress_bar(name_etape):
        prog = QProgressDialog(name_etape + ' : Veillez Patienter', 'Cancel', 0, 100)
        prog.setWindowModality(Qt.WindowModal)#
        prog.setMinimumDuration(1)
        return prog

    # Function pour la progession bar2
    @staticmethod
    def progress_processing(index, count_entite, progress_dialog):
        f = int(index + 1)
        pcnt = int(f / count_entite * 100 / 1)
        progress_dialog.setValue(pcnt)

    # Function Rename doublons name column
    @staticmethod
    def function_rename_column_name(var_list_column):
        dups = {}
        for i, val in enumerate(var_list_column):
            if val not in dups:
                # Store index of first occurrence and occurrence value
                dups[val] = [i, 1]
            else:
                # Special case for first occurrence
                if dups[val][1] == 1:
                    var_list_column[dups[val][0]] += str(dups[val][1])
                # Increment occurrence value, index value doesn't matter anymore
                dups[val][1] += 1
                # Use stored occurrence value
                var_list_column[i] += str(dups[val][1])
        return var_list_column

    # Function pour Importer des fichiers csv dans une BDD
    def function_insert_csv_bdd(self, var_file):
        """
        function_insert_csv_bdd [Cette fonction permet dimporter un fichier csv dans une BDD]

        Arguments:
            var_file {[type]: string} -- [Il prend comme argument le chemin du fichier a importer dans la BDD. Sont type est du string]
        """        
        try:
            # https://stackoverflow.com/questions/48085319/python-reading-and-writing-csv-files-with-utf-8-encoding
            with open(var_file, encoding="utf-8-sig", errors='ignore') as f:
                reader_file = csv.reader(f, delimiter=';')
                header = next(reader_file)
                file_name = '"' + os.path.basename(var_file).split('.')[0].replace(' ', '_').replace('-', '_').lower() + '"'
                # Creation de la table
                list_column = ["nan" if key == '' else re.sub('[^a-zA-Z]', '_', str(key)) for key in header]
                list_column_rename = self.function_rename_column_name(list_column)
                list_column_text = [str(key) + ' text' for key in list_column_rename]
                req_create_table = f"DROP TABLE IF EXISTS {self.schema}.{file_name};" \
                                   f"CREATE TABLE {self.schema}.{file_name}({','.join(list_column_text)})"
                self.db_cursor.execute(req_create_table)
                # Insertion des elements dans la table creee
                list_all_feature_insert = []
                for index in reader_file:
                    list_tuple = tuple(index)
                    list_replace_carac = [str(key).replace("'", '').replace('"', '') for key in list_tuple]
                    values_features = str(tuple(list_replace_carac))
                    list_all_feature_insert.append(values_features)
                if list_all_feature_insert:
                    var_req_insert = f"INSERT INTO {self.schema}.{file_name}({','.join(list_column_rename)}) " \
                                 f"values{','.join(list_all_feature_insert)}" \
                                 f";CREATE INDEX index_geom_{file_name} ON {self.schema}.{file_name} " \
                                 f"USING btree ({list_column_rename[0]});".replace('None', 'NULL').replace('"', '')

                    self.db_cursor.execute(var_req_insert)
        except OSError:
            self.list_error.append(['function_insert_csv_bdd', f"Partie Import SHP: Probleme Import SHP...Le CSV {var_file} nest pas importe...{OSError}"])

    # Function pour Importer des fichiers shp dans une BDD
    def function_insert_shp_bdd(self, var_shp):
        """
        function_insert_shp_bdd [Cette fonction permet dimporter un fichier shapefile dans une BDD]

        Arguments:
            var_shp {[type]: string} -- [Il prend comme argument le chemin du fichier a importer dans la BDD. Sont type est du string]
        """        
        try:
            file_fichier = ogr.Open(var_shp, 0)
            if file_fichier is None:
                self.list_error.append(['function_insert_shp_bdd', f"Partie Import SHP: Probleme Import SHP...Le Shape {var_shp} ne peut pas etre ouvert"])
            else:
                shape_feature = file_fichier.GetLayer(0)
                var_file_name = '"' + os.path.basename(var_shp).split('.')[0].replace(' ', '_').replace('-', '_').lower() + '"'
                dict_convert_type_field = {'String': 'character varying', 'Date': 'text',
                                           'Integer': 'Integer', 'Real': 'real', 'Integer64': 'Integer',
										   'OFTString': 'text', 'OFTDate': 'text', 'OFTDateTime': 'text',
											'OFTTime': 'text', 'OFTInteger': 'Integer', 'OFTReal': 'real', 
											'OFTInteger64': 'Integer'}
                # Column_name et type
                list_column = []
                list_column_text = []
                for field in shape_feature.schema:
                    # print(field.name, ';', field.GetTypeName(), ';', field.GetType(), ';', field.GetWidth(), ';',
                    #       field.GetPrecision())
                    field_name = str(field.name).replace(' ', '_').replace('-', '_')
                    field_type_name = str(dict_convert_type_field[field.GetTypeName()])
                    field_width = str(field.GetWidth())
                    if field.GetTypeName() == 'String':
                        field_name_prepare = f"{field_name} {field_type_name}({str(field_width)})"
                    else:
                        field_name_prepare = f"{field_name} {field_type_name}"
                    list_column.append(field_name)
                    list_column_text.append(field_name_prepare)
                # Ajout de la colonne geometry
                list_column.append('geom')
                list_column_text.append('geom geometry')
                # Creation de la table
                req_create_table = f"DROP TABLE IF EXISTS {self.schema}.{var_file_name};" \
                                   f"CREATE TABLE {self.schema}.{var_file_name}({','.join(list_column_text)})"
                # Execution de la creation de la table
                self.db_cursor.execute(req_create_table)
                # Parcours du shape plus prepapration des donnees a inserer
                list_all_feature_insert = []
                for n in range(shape_feature.GetFeatureCount()):
                    feature_shp = shape_feature.GetFeature(n)
                    feature_json = json.loads(feature_shp.ExportToJson())
                    # Ne peut importer les geometries null
                    if feature_shp.geometry():
                        geaom_feature = f"ST_GeomFromText('{str(feature_shp.geometry())}',2154)"
                        list_values_attributs = list(feature_json['properties'].values())
                        list_appen_geom_feature = [None if field is None else str(field).replace("'", '')
                                                for field in list_values_attributs]
                        list_appen_geom_feature.append(geaom_feature)
                        tuple_appen_geom_feature = str(tuple(list_appen_geom_feature)).replace('"', '')
                        list_all_feature_insert.append(tuple_appen_geom_feature)
                    else:
                        self.list_error.append(['function_insert_shp_bdd', f"Partie Import SHP: Cette Entite {feature_shp[0]} a une geometrie Null dans le shape: {var_file_name}"])

                # Insertion des elements dans la table
                if list_all_feature_insert:
                    var_req_insert = f"INSERT INTO {self.schema}.{var_file_name}({','.join(list_column)}) " \
                                 f"values{','.join(list_all_feature_insert)}" \
                                 f";CREATE INDEX index_geom_{var_file_name} ON {self.schema}.{var_file_name} " \
                                 f"USING gist (geom);".replace('None', 'NULL').replace('"', '')
                    self.db_cursor.execute(var_req_insert)
        except OSError: 
            self.list_error.append(['function_insert_shp_bdd', f"Partie Import SHP: Probleme Import SHP...Le Shape {var_shp} nest pas importe...{OSError}"])

    # Function Execution en masse des Imports des fichiers CSV/SHP dans une BDD
    def function_import_mutiples_files(self):
        """
        function_import_mutiples_files [Cette fonction permet dimporter plusieurs fichiers csv et shapefiles dans une BDD]

        Returns:
            [type] -- [Il retourne la liste des fichiers importer]
        """        
        try:
            if self.folder_data:
                # Creation du schema import
                self.db_cursor.execute(f"DROP SCHEMA IF EXISTS {self.schema} Cascade;"
                                       f"CREATE SCHEMA IF NOT EXISTS {self.schema};")
                folder_iterate = os.listdir(self.folder_data)
                bar_progress = self.progress_bar('Insertion des donnees en masse dans la BDD')
                for index_char_qgis, file_etude in enumerate(folder_iterate):
                    chemin = self.folder_data
                    name, ext = os.path.splitext(file_etude)
                    chem_etude = f"{chemin}/{file_etude}"
                    if ext == ".shp":
                        self.function_insert_shp_bdd(chem_etude)
                        self.files_import.append(file_etude)
                    elif ext == ".csv" and name[:2] != 'l_':
                        self.function_insert_csv_bdd(chem_etude)
                        self.files_import.append(file_etude)
                    elif ext in (".dbf", ".cpg", ".prj", ".shx", ".log", ".sbn", ".sbx", ".qgz", ".qpj", ".qml"):
                        continue
                    else:
                        continue
                    self.progress_processing(index_char_qgis, len(folder_iterate), bar_progress)
                    if bar_progress.wasCanceled():
                        iface.messageBar().pushMessage('Info', 'Action Cancelled', level=Qgis.Info)
                        break
                self.connection.commit()
                self.db_cursor.close()
                self.connection.close()
                return self.files_import
            else:
                self.list_error.append(['function_import_mutiples_files',
                                        f"Partie Import en masse: Probleme choix repertoire des donnees..."
                                        f"{self.folder_data}"])
        except OSError:
            self.list_error.append(['function_import_mutiples_files',
                                    f"Partie Import en masse: Probleme dexecution des imports en masse...{OSError}"])





# ImportMultiplesFilesCsvShp('pr_baba_test_import_exe_v_20211013', r'C:\Users\babacar.fassa.AMBITION\Desktop\test_import')