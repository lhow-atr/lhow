# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'Dialog_IMPORT_BDD2.ui'
#
# Created by: PyQt5 UI code generator 5.11.3
#
# WARNING! All changes made in this file will be lost!
import sys
from pathlib import Path

from qgis.PyQt import QtCore, QtWidgets
from qgis.gui import QgsCheckableComboBox

folder_plugin = str(Path(__file__).parent.parent)

sys.path.append(folder_plugin)

from scripts_python.dimensionnement_cables import *


class Ui_create_model(object):
    def setupUi(self, create_model):
        create_model.setObjectName("create_model")
        create_model.setWindowModality(QtCore.Qt.ApplicationModal)
        create_model.setEnabled(True)
        create_model.resize(800, 800)  # 1305, 882
        create_model.setMouseTracking(False)

        self.verticalLayoutWidget = QtWidgets.QWidget(create_model)
        self.verticalLayoutWidget.setGeometry(QtCore.QRect(30, 30, 700, 700))  # 1161, 731
        self.verticalLayoutWidget.setObjectName("verticalLayoutWidget")

        self.verticalLayout = QtWidgets.QVBoxLayout(self.verticalLayoutWidget)
        self.verticalLayout.setContentsMargins(0, 0, 0, 0)
        self.verticalLayout.setObjectName("verticalLayout")

        self.gridLayout = QtWidgets.QGridLayout()
        self.gridLayout.setObjectName("gridLayout")

        self.label_12 = QtWidgets.QLabel(self.verticalLayoutWidget)
        self.label_12.setObjectName("label_12")
        self.gridLayout.addWidget(self.label_12, 0, 0, 1, 1)

        self.label_2 = QtWidgets.QLabel(self.verticalLayoutWidget)
        self.label_2.setObjectName("label_2")
        self.gridLayout.addWidget(self.label_2, 0, 1, 1, 1)

        self.name_pr = QgsCheckableComboBox(self.verticalLayoutWidget)
        self.name_pr.setMinimumSize(QtCore.QSize(106, 0))
        self.name_pr.setObjectName("name_pr")
        self.gridLayout.addWidget(self.name_pr, 1, 0, 1, 1)

        self.list_st_typephy = QgsCheckableComboBox(self.verticalLayoutWidget)
        self.list_st_typephy.setMinimumSize(QtCore.QSize(106, 0))
        self.list_st_typephy.setObjectName("list_st_typephy")
        self.list_st_typephy.addItem("NRO+SROL")
        self.list_st_typephy.addItem("NRO")
        self.list_st_typephy.addItem("SRO")
        self.list_st_typephy.addItem("SROL")
        self.gridLayout.addWidget(self.list_st_typephy, 1, 1, 1, 1)

        self.verticalLayout.addLayout(self.gridLayout)

        self.textBrowser = QtWidgets.QTextBrowser(self.verticalLayoutWidget)
        self.textBrowser.setObjectName("textBrowser")
        self.verticalLayout.addWidget(self.textBrowser)

        self.button_box = QtWidgets.QDialogButtonBox(self.verticalLayoutWidget)
        self.button_box.setOrientation(QtCore.Qt.Horizontal)
        self.button_box.setStandardButtons(QtWidgets.QDialogButtonBox.Cancel | QtWidgets.QDialogButtonBox.Ok)
        self.button_box.setObjectName("button_box")
        self.verticalLayout.addWidget(self.button_box)

        self.retranslateUi(create_model)
        self.button_box.accepted.connect(create_model.accept)
        self.button_box.rejected.connect(create_model.reject)
        QtCore.QMetaObject.connectSlotsByName(create_model)

    def retranslateUi(self, create_model):
        _translate = QtCore.QCoreApplication.translate
        create_model.setWindowTitle(
            _translate("create_model", "DESIGN v0.01 - Importation des donnees dans la BDD"))
        self.label_12.setText(_translate("create_model", "Nom du pr"))
        self.label_2.setText(_translate("create_model", "Nom du St_typephy"))
        self.textBrowser.setHtml(_translate("create_model",
                                            "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
                                            "<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
                                            "p, li { white-space: pre-wrap; }\n"
                                            "p { margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:8pt }\n"
                                            "</style></head><body style=\" font-family:\'MS Shell Dlg 2\'; font-size:8.25pt; font-weight:400; font-style:normal;\">\n"
                                            "<h2>Objectifs: </h2>\n"
                                            "<div > Ce module permet de Modeliser un reseau. </div>\n"
                                            "<h2>Données en entrée: </h2>\n"
                                            "<div > L’utilisateur sélectionne dans la liste déroulante le livrable qu'il souhaite modéliser </div>\n"
                                            "<div> 1 - Correction accrochage des extrémités/origines des lignes par rapport aux points dans un buffer de 0.1 m</div>\n"
                                            "<div> 2 - Correction du sens des lignes (du point de départ jusqu'à la fin)</div>\n"
                                            "<div> 3 - Suppression des doublons de geometrie ayant un meme parcours</div>\n"
                                            "<div> 4 - Detection des origines et des extrémites des lignes par rapport aux points</div>\n"
                                            "<div> 5 - Vérification de la detection des origines et extrémités</div>\n"
                                            "<div> 6 - Calcul du nombre de prises, de fibre, de fibre jusqu'au point de départ</div>\n"
                                            "<div> 7 - Calcul du nombre fibre de dérivations des les boites</div>\n"
                                            "<div> 8 - Calcul de la capacité optimisée, utile et de la longueur des sections</div>\n"
                                            "<h2 >Résultat: </h2>\n"
                                            "<div> Les résultats sont dans de nouveaux attributs : nbresuf, nbreFo, nbreFoSum, capaOpt, capaUtile, Seclen, cb_deriv, ca_deriv, fo_deriv</div>\n"
                                            "<h2 >Contraintes: </h2>\n"
                                            "<div > La topologie du livrable doit être cohérente, les règles d'accrochage entre les objets doivent respectées </div>\n"
                                            "</body></html>"))


class class_general_dialog(QtWidgets.QDialog):
    def __init__(self, iface, var_connection):
        QtWidgets.QDialog.__init__(self)
        self.iface = iface
        self.connection = var_connection

    # Function pour executer une requete sql dans la base
    def function_execute_requete(self, requete_execute, req_fetch):
        curs = self.connection.cursor()
        try:
            curs.execute(requete_execute)
            if req_fetch:
                data_req = [row for row in curs.fetchall()]
                if data_req:
                    return data_req
        except(Exception, psycopg2.DatabaseError) as error:
            QMessageBox.critical(self.iface.mainWindow(), "Message dexecution de requete",
                                 'Requete Non Executer : ' + str(error) + ' ; ' + str(requete_execute))
        # print("Message dexecution de requete", 'Requete Non Executer : '+str(error)+' ; '+str(requete_execute))
        curs.close()

    def get_all_schema_name(self, list_widget):
        req_get_schema = """select 
        schema_name
        from information_schema.schemata
        where schema_name like 'pr%' order by schema_name;"""
        list_schema_name = self.function_execute_requete(req_get_schema, 'bab')
        for index, name_schema in enumerate(list_schema_name):
            if name_schema:
                list_widget.addItem("")
                list_widget.setItemText(index, name_schema[0])

    def get_version_plugin(self):
        # folder_plugin = os.path.dirname(os.path.abspath(__file__))
        folder_metada = open(
            folder_plugin + "\metadata.txt")  # open(folder_plugin.replace("forms\design", "\metadata.txt"))
        for line in folder_metada:
            if str(line)[:7] == 'version':
                get_version = line.split('=')[1]
                return get_version
        folder_metada.close()


class class_create_mode_dialog(class_general_dialog, Ui_create_model):
    def __init__(self, iface):
        self.var_connection = function_connexion()
        class_general_dialog.__init__(self, iface, self.var_connection)
        self.setupUi(self)
        self.get_all_schema_name(self.name_pr)
        self.setWindowTitle("DESIGN " + str(self.get_version_plugin()) + " - Modelisation du Reseau")
        self.var_connection.close()
        self.button_box.button(QtWidgets.QDialogButtonBox.Ok).clicked.connect(self.run)

    def run(self):
        list_st_typephy = self.list_st_typephy
        text_list_st_typephy = [x for x in list_st_typephy.currentText().split(',') if x]
        list_namePR = self.name_pr
        text_namePR = [x for x in list_namePR.currentText().split(',') if x]
        if len(text_list_st_typephy) != 1 or len(text_namePR) != 1:  # len(text_titulaire) != 1 or  un seul MOE et
            QMessageBox.critical(self.iface.mainWindow(), "Message Du Choix",
                                 'Veillez cocher un seul SRO et un seul PR')
        else:
            nom_pr = "".join(text_namePR)
            nom_sro = str("".join(text_list_st_typephy)).upper()
            schema = nom_pr
            # Declaration des variables
            var_schema = schema
            var_type_sitetech_depart = nom_sro
            var_t_noeud = 't_noeud'
            var_vs_elem_cl_cb = 'vs_elem_cl_cb'
            var_vs_elem_st_nd = 'vs_elem_st_nd'
            var_vs_elem_pt_nd = 'vs_elem_pt_nd'
            var_t_cheminement = 't_cheminement'
            var_name_boites = 'vs_elem_bp_pt_nd'
            var_atr_bpcode = 'bp_code'
            var_st_typelog = 'st_typelog'
            var_st_nom = 'st_nom'
            var_nd_code = 'nd_code'
            var_cb_code = 'cb_code'
            var_geom = 'geom'
            var_vs_elem_sf_nd = 'vs_elem_sf_nd'
            var_sfndcode = 'sf_nd_code'
            var_cbcapafo = 'cb_capafo'
            var_cbtypelog = 'cb_typelog'
            var_sfcode = 'sf_code'
            var_ptcode = 'pt_code'
            var_distance_buffer = 0.1
            var_list_shape_cable = []
            var_listshape_noeud = []

            # Declaration Class Principale
            Class_Modelisation_Reseau = Modelisation_Reseau(var_schema, var_type_sitetech_depart, var_t_noeud,
                                                            var_vs_elem_cl_cb, var_vs_elem_st_nd,
                                                            var_st_typelog, var_nd_code, var_cb_code, var_geom,
                                                            var_distance_buffer, var_st_nom,
                                                            var_list_shape_cable, var_listshape_noeud,
                                                            var_vs_elem_sf_nd, var_sfndcode, var_cbcapafo,
                                                            var_cbtypelog, var_sfcode,
                                                            var_ptcode, var_vs_elem_pt_nd, var_t_cheminement,
                                                            var_name_boites, var_atr_bpcode)
            shape_erreur_detection = Class_Modelisation_Reseau.function_check_detection()[0]
            shape_erreur_detection_length = shape_erreur_detection.featureCount()
            if shape_erreur_detection_length <= 0:
                Class_Modelisation_Reseau.function_count_suf()
                Class_Modelisation_Reseau.function_ajout_calcul_Derivation()
                QMessageBox.information(self.iface.mainWindow(), "Message dexecution de requete", 'Execution Terminee')
                self.function_close_requete_cache()
            else:
                QMessageBox.information(self.iface.mainWindow(), "Message dexecution de requete",
                                        'Multitudes de noeux en extrémité')
