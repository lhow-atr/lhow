# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'Dialog_IMPORT_BDD2.ui'
#
# Created by: PyQt5 UI code generator 5.11.3
#
# WARNING! All changes made in this file will be lost!
import sys
from pathlib import Path

from qgis.PyQt import QtCore, QtWidgets
from qgis.gui import QgsCheckableComboBox

folder_plugin = str(Path(__file__).parent.parent)

sys.path.append(folder_plugin)

from scripts_python.dimensionnement_cables import *


class Ui_impor_bbd_shp(object):
    def setupUi(self, impor_bbd_shp):
        impor_bbd_shp.setObjectName("impor_bbd_shp")
        impor_bbd_shp.setWindowModality(QtCore.Qt.ApplicationModal)
        impor_bbd_shp.setEnabled(True)
        impor_bbd_shp.resize(800, 800)  # 1305, 882
        impor_bbd_shp.setMouseTracking(False)

        self.verticalLayoutWidget = QtWidgets.QWidget(impor_bbd_shp)
        self.verticalLayoutWidget.setGeometry(QtCore.QRect(30, 30, 700, 700))  # 1161, 731
        self.verticalLayoutWidget.setObjectName("verticalLayoutWidget")

        self.verticalLayout = QtWidgets.QVBoxLayout(self.verticalLayoutWidget)
        self.verticalLayout.setContentsMargins(0, 0, 0, 0)
        self.verticalLayout.setObjectName("verticalLayout")

        self.gridLayout = QtWidgets.QGridLayout()
        self.gridLayout.setObjectName("gridLayout")

        self.label_12 = QtWidgets.QLabel(self.verticalLayoutWidget)
        self.label_12.setObjectName("label_12")
        self.gridLayout.addWidget(self.label_12, 0, 0)

        self.name_pr = QgsCheckableComboBox(self.verticalLayoutWidget)
        self.name_pr.setMinimumSize(QtCore.QSize(106, 0))
        self.name_pr.setObjectName("name_pr")
        self.gridLayout.addWidget(self.name_pr, 1, 0)

        self.verticalLayout.addLayout(self.gridLayout)

        self.textBrowser = QtWidgets.QTextBrowser(self.verticalLayoutWidget)
        self.textBrowser.setObjectName("textBrowser")
        self.verticalLayout.addWidget(self.textBrowser)

        self.button_box = QtWidgets.QDialogButtonBox(self.verticalLayoutWidget)
        self.button_box.setOrientation(QtCore.Qt.Horizontal)
        self.button_box.setStandardButtons(QtWidgets.QDialogButtonBox.Cancel | QtWidgets.QDialogButtonBox.Ok)
        self.button_box.setObjectName("button_box")
        self.verticalLayout.addWidget(self.button_box)

        self.retranslateUi(impor_bbd_shp)
        self.button_box.accepted.connect(impor_bbd_shp.accept)
        self.button_box.rejected.connect(impor_bbd_shp.reject)
        QtCore.QMetaObject.connectSlotsByName(impor_bbd_shp)

    def retranslateUi(self, impor_bbd_shp):
        _translate = QtCore.QCoreApplication.translate
        impor_bbd_shp.setWindowTitle(
            _translate("impor_bbd_shp", "DESIGN v0.01 - Importation des donnees dans la BDD"))
        self.label_12.setText(_translate("impor_bbd_shp", "Nom du pr"))
        self.textBrowser.setHtml(_translate("impor_bbd_shp",
                                            "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
                                            "<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
                                            "p, li { white-space: pre-wrap; }\n"
                                            "p { margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:8pt }\n"
                                            "</style></head><body style=\" font-family:\'MS Shell Dlg 2\'; font-size:8.25pt; font-weight:400; font-style:normal;\">\n"
                                            "<h2>Objectifs: </h2>\n"
                                            "<div > Ce module permet de Modeliser un reseau. </div>\n"
                                            "<h2>Données en entrée: </h2>\n"
                                            "<div > Les shapefiles chargés dans Qgis seront tous importés dans la BDD dans le schema choisi par l’utilisateur sélectionne dans la liste déroulante le livrable qu'il souhaite modéliser </div>\n"
                                            "<h2 >Contraintes: </h2>\n"
                                            "<div > Il faut que les shapefiles soient chargés dans Qgis</div>\n"
                                            "</body></html>"))


class class_general_dialog(QtWidgets.QDialog):
    def __init__(self, iface, var_connection):
        QtWidgets.QDialog.__init__(self)
        self.iface = iface
        self.connection = var_connection

    # Function pour executer une requete sql dans la base
    def function_execute_requete(self, requete_execute, req_fetch):
        curs = self.connection.cursor()
        try:
            curs.execute(requete_execute)
            if req_fetch:
                data_req = [row for row in curs.fetchall()]
                if data_req:
                    return data_req
        except(Exception, psycopg2.DatabaseError) as error:
            QMessageBox.critical(self.iface.mainWindow(), "Message dexecution de requete",
                                 'Requete Non Executer : ' + str(error) + ' ; ' + str(requete_execute))
        curs.close()

    def get_all_schema_name(self, list_widget):
        req_get_schema = """select 
            schema_name
        from information_schema.schemata
        where schema_name like 'pr%' order by schema_name;"""

        list_schema_name = self.function_execute_requete(req_get_schema, 'bab')

        for index, name_schema in enumerate(list_schema_name):
            if name_schema:
                list_widget.addItem("")
                list_widget.setItemText(index, name_schema[0])

    def get_version_plugin(self):
        # folder_plugin = os.path.dirname(os.path.abspath(__file__))
        folder_metada = open(
            folder_plugin + "\metadata.txt")  # open(folder_plugin.replace("forms\design", "\metadata.txt"))
        for line in folder_metada:
            if str(line)[:7] == 'version':
                get_version = line.split('=')[1]
                return get_version
        folder_metada.close()


class class_impor_bbd_shp_dialog(class_general_dialog, Ui_impor_bbd_shp):
    def __init__(self, iface):
        self.var_connection = function_connexion()
        class_general_dialog.__init__(self, iface, self.var_connection)
        self.setupUi(self)
        self.get_all_schema_name(self.name_pr)
        self.setWindowTitle("DESIGN " + str(self.get_version_plugin()) + " - Importation des shapefiles dans le BDD")
        self.var_connection.close()
        self.button_box.button(QtWidgets.QDialogButtonBox.Ok).clicked.connect(self.run)

    def run(self):
        list_namePR = self.name_pr
        text_namePR = [x for x in list_namePR.currentText().split(',') if x]
        if len(text_namePR) != 1:  # len(text_titulaire) != 1 or  un seul MOE et
            QMessageBox.critical(self.iface.mainWindow(), "Message Du Choix", 'Veillez cocher un seul PR')
        else:
            nom_pr = "".join(text_namePR)
            # Declaration des variables
            function_execute_import_bdd(nom_pr, '', '_ext')
