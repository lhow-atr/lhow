# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'Dialog_IMPORT_BDD2.ui'
#
# Created by: PyQt5 UI code generator 5.11.3
#
# WARNING! All changes made in this file will be lost!
import sys
from pathlib import Path

from qgis.PyQt import QtCore, QtWidgets
from qgis.gui import QgsCheckableComboBox

folder_plugin = str(Path(__file__).parent.parent)

sys.path.append(folder_plugin)

from scripts_python.controle_formalisme_mcd import *


class Ui_class_checkformalisme_dialog(object):
    def setupUi(self, class_checkformalisme_dialog):
        class_checkformalisme_dialog.setObjectName("class_checkformalisme_dialog")
        class_checkformalisme_dialog.resize(800, 800)

        self.verticalLayoutWidget = QtWidgets.QWidget(class_checkformalisme_dialog)
        self.verticalLayoutWidget.setGeometry(QtCore.QRect(30, 30, 700, 700))
        self.verticalLayoutWidget.setObjectName("verticalLayoutWidget")

        self.verticalLayout = QtWidgets.QVBoxLayout(self.verticalLayoutWidget)
        self.verticalLayout.setContentsMargins(0, 0, 0, 0)
        self.verticalLayout.setObjectName("verticalLayout")

        self.gridLayout = QtWidgets.QGridLayout()
        self.gridLayout.setObjectName("gridLayout")

        self.name_pr = QgsCheckableComboBox(self.verticalLayoutWidget)
        self.name_pr.setMinimumSize(QtCore.QSize(106, 0))
        self.name_pr.setObjectName("name_pr")
        self.gridLayout.addWidget(self.name_pr, 1, 0, 1, 1)

        self.label_2 = QtWidgets.QLabel(self.verticalLayoutWidget)
        self.label_2.setObjectName("label_2")
        self.gridLayout.addWidget(self.label_2, 0, 1, 1, 1)

        self.label = QtWidgets.QLabel(self.verticalLayoutWidget)
        self.label.setObjectName("label")
        self.gridLayout.addWidget(self.label, 0, 2, 1, 1)

        self.label_st_typephy = QtWidgets.QLabel(self.verticalLayoutWidget)
        self.label_st_typephy.setObjectName("label_st_typephy")
        self.gridLayout.addWidget(self.label_st_typephy, 0, 3, 1, 1)

        self.name_statut = QgsCheckableComboBox(self.verticalLayoutWidget)
        self.name_statut.setMinimumSize(QtCore.QSize(106, 0))
        self.name_statut.setObjectName("name_statut")
        self.name_statut.addItem("")
        self.name_statut.addItem("")
        self.name_statut.addItem("")
        self.name_statut.addItem("")
        self.name_statut.addItem("")
        self.name_statut.addItem("")
        self.name_statut.addItem("")
        self.name_statut.addItem("")
        self.name_statut.addItem("")
        self.gridLayout.addWidget(self.name_statut, 1, 1, 1, 1)

        self.name_titulaire = QgsCheckableComboBox(self.verticalLayoutWidget)
        self.name_titulaire.setMinimumSize(QtCore.QSize(106, 0))
        self.name_titulaire.setObjectName("name_titulaire")
        self.name_titulaire.addItem("")
        self.name_titulaire.addItem("")
        self.name_titulaire.addItem("")
        self.name_titulaire.addItem("")
        self.name_titulaire.addItem("")
        self.name_titulaire.addItem("")
        self.name_titulaire.addItem("")
        self.name_titulaire.addItem("")
        self.name_titulaire.addItem("")
        self.name_titulaire.addItem("")
        self.name_titulaire.addItem("")
        self.name_titulaire.addItem("")
        self.name_titulaire.addItem("")
        self.name_titulaire.addItem("")
        self.gridLayout.addWidget(self.name_titulaire, 1, 2, 1, 1)

        self.list_st_typephy = QgsCheckableComboBox(self.verticalLayoutWidget)
        self.list_st_typephy.setMinimumSize(QtCore.QSize(106, 0))
        self.list_st_typephy.setObjectName("list_st_typephy")
        self.list_st_typephy.addItem("NRO+SROL")
        self.list_st_typephy.addItem("NRO")
        self.list_st_typephy.addItem("SRO")
        self.list_st_typephy.addItem("SROL")
        self.gridLayout.addWidget(self.list_st_typephy, 1, 3, 1, 1)

        self.label_12 = QtWidgets.QLabel(self.verticalLayoutWidget)
        self.label_12.setObjectName("label_12")
        self.gridLayout.addWidget(self.label_12, 0, 0, 1, 1)
        self.verticalLayout.addLayout(self.gridLayout)

        self.gridLayout_2 = QtWidgets.QGridLayout()
        self.gridLayout_2.setObjectName("gridLayout_2")
        self.label_21 = QtWidgets.QLabel(self.verticalLayoutWidget)
        self.label_21.setObjectName("label_21")
        self.gridLayout_2.addWidget(self.label_21, 0, 4, 1, 1)
        self.label_3 = QtWidgets.QLabel(self.verticalLayoutWidget)
        self.label_3.setObjectName("label_3")
        self.gridLayout_2.addWidget(self.label_3, 0, 0, 1, 1)
        self.name_col_table = QtWidgets.QLineEdit(self.verticalLayoutWidget)
        self.name_col_table.setObjectName("name_col_table")
        self.gridLayout_2.addWidget(self.name_col_table, 1, 4, 1, 1)
        self.sheet_attribut = QtWidgets.QLineEdit(self.verticalLayoutWidget)
        self.sheet_attribut.setObjectName("sheet_attribut")
        self.gridLayout_2.addWidget(self.sheet_attribut, 1, 1, 1, 1)
        self.label_18 = QtWidgets.QLabel(self.verticalLayoutWidget)
        self.label_18.setObjectName("label_18")
        self.gridLayout_2.addWidget(self.label_18, 0, 1, 1, 1)
        self.sheet_table = QtWidgets.QLineEdit(self.verticalLayoutWidget)
        self.sheet_table.setObjectName("sheet_table")
        self.gridLayout_2.addWidget(self.sheet_table, 1, 2, 1, 1)
        self.name_col_attribut = QtWidgets.QLineEdit(self.verticalLayoutWidget)
        self.name_col_attribut.setObjectName("name_col_attribut")
        self.gridLayout_2.addWidget(self.name_col_attribut, 1, 3, 1, 1)
        self.name_grille = QgsCheckableComboBox(self.verticalLayoutWidget)
        self.name_grille.setMinimumSize(QtCore.QSize(106, 0))
        self.name_grille.setObjectName("name_grille")
        self.name_grille.addItem("")
        self.name_grille.addItem("")
        self.name_grille.addItem("")
        self.name_grille.addItem("")
        self.name_grille.addItem("")
        self.gridLayout_2.addWidget(self.name_grille, 1, 0, 1, 1)
        self.label_19 = QtWidgets.QLabel(self.verticalLayoutWidget)
        self.label_19.setObjectName("label_19")
        self.gridLayout_2.addWidget(self.label_19, 0, 2, 1, 1)
        self.label_20 = QtWidgets.QLabel(self.verticalLayoutWidget)
        self.label_20.setObjectName("label_20")
        self.gridLayout_2.addWidget(self.label_20, 0, 3, 1, 1)
        self.verticalLayout.addLayout(self.gridLayout_2)
        self.textBrowser = QtWidgets.QTextBrowser(self.verticalLayoutWidget)
        self.textBrowser.setObjectName("textBrowser")
        self.verticalLayout.addWidget(self.textBrowser)
        self.button_box = QtWidgets.QDialogButtonBox(self.verticalLayoutWidget)
        self.button_box.setOrientation(QtCore.Qt.Horizontal)
        self.button_box.setStandardButtons(QtWidgets.QDialogButtonBox.Cancel | QtWidgets.QDialogButtonBox.Ok)
        self.button_box.setObjectName("button_box")
        self.verticalLayout.addWidget(self.button_box)

        self.retranslateUi(class_checkformalisme_dialog)
        self.button_box.accepted.connect(class_checkformalisme_dialog.accept)
        self.button_box.rejected.connect(class_checkformalisme_dialog.reject)
        QtCore.QMetaObject.connectSlotsByName(class_checkformalisme_dialog)

    def retranslateUi(self, class_checkformalisme_dialog):
        _translate = QtCore.QCoreApplication.translate
        class_checkformalisme_dialog.setWindowTitle(
            _translate("class_checkformalisme_dialog", "DESIGN v0.01 - Controles du Formalisme du MCD"))
        # self.name_pr.setText(_translate("class_checkformalisme_dialog", "pr_baba"))
        self.label_2.setText(_translate("class_checkformalisme_dialog", "STATUT"))
        self.label.setText(_translate("class_checkformalisme_dialog", "TITULAIRE"))
        self.name_statut.setItemText(0, _translate("class_checkformalisme_dialog", "AOR"))
        self.name_statut.setItemText(1, _translate("class_checkformalisme_dialog", "DEO"))
        self.name_statut.setItemText(2, _translate("class_checkformalisme_dialog", "DEP"))
        self.name_statut.setItemText(3, _translate("class_checkformalisme_dialog", "DIU"))
        self.name_statut.setItemText(4, _translate("class_checkformalisme_dialog", "DOE"))
        self.name_statut.setItemText(5, _translate("class_checkformalisme_dialog", "DET"))
        self.name_statut.setItemText(6, _translate("class_checkformalisme_dialog", "EXE"))
        self.name_statut.setItemText(7, _translate("class_checkformalisme_dialog", "MCO"))
        self.name_statut.setItemText(8, _translate("class_checkformalisme_dialog", "PRO"))
        self.name_titulaire.setItemText(0, _translate("class_checkformalisme_dialog", "ADTIM FTTH"))
        self.name_titulaire.setItemText(1, _translate("class_checkformalisme_dialog", "ADN"))
        self.name_titulaire.setItemText(2, _translate("class_checkformalisme_dialog", "AMO"))
        self.name_titulaire.setItemText(3, _translate("class_checkformalisme_dialog", "CSPS"))
        self.name_titulaire.setItemText(4, _translate("class_checkformalisme_dialog", "ATR"))
        self.name_titulaire.setItemText(5, _translate("class_checkformalisme_dialog", "EIFFAGE"))
        self.name_titulaire.setItemText(6, _translate("class_checkformalisme_dialog", "INEO"))
        self.name_titulaire.setItemText(7, _translate("class_checkformalisme_dialog", "SOBECA"))
        self.name_titulaire.setItemText(8, _translate("class_checkformalisme_dialog", "IMOPTEL"))
        self.name_titulaire.setItemText(9, _translate("class_checkformalisme_dialog", "SERFIM TIC"))
        self.name_titulaire.setItemText(10, _translate("class_checkformalisme_dialog", "AXIONE"))
        self.name_titulaire.setItemText(11, _translate("class_checkformalisme_dialog", "BETREC"))
        self.name_titulaire.setItemText(12, _translate("class_checkformalisme_dialog", "IBSE"))
        self.name_titulaire.setItemText(13, _translate("class_checkformalisme_dialog", "COORDINATION"))
        # self.list_st_typephy.setItemText(13, _translate("class_checkformalisme_dialog", "COORDINATION"))
        self.label_st_typephy.setText(_translate("class_checkformalisme_dialog", "Nom du St_typephy"))
        self.label_12.setText(_translate("class_checkformalisme_dialog", "Nom du pr"))
        self.label_21.setText(_translate("class_checkformalisme_dialog", "Nom de la colonne des tables"))
        self.label_3.setText(_translate("class_checkformalisme_dialog", "Grille_STATUT"))
        self.name_col_table.setText(_translate("class_checkformalisme_dialog", "Nom de la table"))
        self.sheet_attribut.setText(_translate("class_checkformalisme_dialog", "MCD_Attributs"))
        self.label_18.setText(_translate("class_checkformalisme_dialog", "Nom Feuille MCD_ATTRIBUT"))
        self.sheet_table.setText(_translate("class_checkformalisme_dialog", "MCD_Classes"))
        self.name_col_attribut.setText(_translate("class_checkformalisme_dialog", "Nom court de lattribut"))
        self.name_grille.setItemText(0, _translate("class_checkformalisme_dialog", "DEO"))
        self.name_grille.setItemText(1, _translate("class_checkformalisme_dialog", "DPRO"))
        self.name_grille.setItemText(2, _translate("class_checkformalisme_dialog", "DEXE"))
        self.name_grille.setItemText(3, _translate("class_checkformalisme_dialog", "PREDOE/DOE"))
        self.name_grille.setItemText(4, _translate("class_checkformalisme_dialog", "MCO"))
        self.label_19.setText(_translate("class_checkformalisme_dialog", "Nom Feuille MCD_Classes"))
        self.label_20.setText(_translate("class_checkformalisme_dialog", "Nom de la colonne des attributs"))
        self.textBrowser.setHtml(_translate("class_checkformalisme_dialog",
                                            "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
                                            "<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
                                            "p, li { white-space: pre-wrap; }\n"
                                            "</style></head><body style=\" font-family:\'MS Shell Dlg 2\'; font-size:8.25pt; font-weight:400; font-style:normal;\">\n"
                                            "<h2 >Objectif:</h2>\n"
                                            "<div >L’utilisateur sélectionne dans la liste déroulante le livrable qu\'il souhaite contrôler sur les points suivants, </div>\n"
                                            "<div >S01 - Fourniture de données SIG conformes au MCD du Syndicat ADN,</div>\n"
                                            "<div >S02 - Nommage des éléments de la table t_adresse,</div>\n"
                                            "<div >S03 - Nommage des éléments de la table t_ptech,</div>\n"
                                            "<div >S04 - Nommage des éléments de la table t_ebp</div>\n"
                                            "<div >S05 - Nommage des éléments de la table t_cheminement</div>\n"
                                            "<div >S06 - Nommage des éléments de la table t_zdep</div>\n"
                                            "<div >S07 - Nommage des éléments de la table t_cable (Collecte),</div>\n"
                                            "<div >S08 - Nommage des éléments de la table t_cable (autre que Collecte),</div>\n"
                                            "<div >S09 - Caracteristiques des éléments de la table t_fibre,</div>\n"
                                            "<div >S10 - Nommage des éléments de la table t_sitetech</div>\n"
                                            "<div >S11 - Nommage des éléments de la table t_ltech,</div>\n"
                                            "<div >S12 - Coherence de la table t_znro,</div>\n"
                                            "<div >S13 - Coherence de la table t_zsro,</div>\n"
                                            "<div >S14 - Coherence de la table t_zpbo,</div>\n"
                                            "<div >S15 - Identification des SUF (Résidentiels, Professionnel, Technique),</div>\n"
                                            "<div >S16 - Identification des zones de PLU (t_zdep),</div>\n"
                                            "<div >S17 - Calcul du nombre de SUF par ZPBO,</div>\n"
                                            "<div >S18 - Présence de toutes les fiches de chambre,</div>\n"
                                            "<div >S19 - Présence d\'une etude pour tous les appuis mobilisés,</div>\n"
                                            "<div >S20 - Présence des autorisations pour le deploiement en facade,</div>\n"
                                            "<div >S21 - Découpe ZAPM de 300SUF minimum.</div>\n"
                                            "<h2 >Données en entrée: </h2>\n"
                                            "<div >L’utilisateur doit choisir le bon nom de schéma pour que les contrôles soient appliqués sur les données qu’il a importé dans la base de données. Sinon ça sera dans le schéma par default (pr_baba_exe_v_20251231). </div>\n"
                                            "<h2 >Contraintes: </h2>\n"
                                            "<div >Il faut que les noms des feuilles et des colonnes soient bien respectés. Les noms des colonnes doivent etre sans accent.</div>\n"
                                            "<div >Les noms des clients référencés dans la grille sont :</div>\n"
                                            "<div >ADTIM FTTH</div>\n"
                                            "<div >EIFFAGE</div>\n"
                                            "<div >INEO</div>\n"
                                            "<div >SOBECA</div>\n"
                                            "<div >IMOPTEL</div>\n"
                                            "<div >SERFIM TIC</div>\n"
                                            "<div >ADN</div>\n"
                                            "<div >Si un client figure pas dans cette liste il necessite a etre intégrer avec tous ces parametres de  Nommages</div>\n"
                                            "<h2 >Résultats:</h2>\n"
                                            "<div >Les résultats sont intégrés dans la table &quot;t_echange&quot; qui se trouve dans la base de donnée</div></body></html>"))


class class_general_dialog(QtWidgets.QDialog):
    def __init__(self, iface, var_connection):
        QtWidgets.QDialog.__init__(self)
        self.iface = iface
        self.connection = var_connection

    # Function pour executer une requete sql dans la base
    def function_execute_requete(self, requete_execute, req_fetch):
        curs = self.connection.cursor()
        try:
            curs.execute(requete_execute)
            if req_fetch:
                data_req = [row for row in curs.fetchall()]
                if data_req:
                    return data_req
        except(Exception, psycopg2.DatabaseError) as error:
            QMessageBox.critical(self.iface.mainWindow(), "Message dexecution de requete",
                                 'Requete Non Executer : ' + str(error) + ' ; ' + str(requete_execute))
        # print("Message dexecution de requete", 'Requete Non Executer : '+str(error)+' ; '+str(requete_execute))
        curs.close()

    def get_all_schema_name(self, list_widget):
        req_get_schema = """select 
			schema_name
		from information_schema.schemata
		where schema_name like 'pr%' order by schema_name;"""

        list_schema_name = self.function_execute_requete(req_get_schema, 'bab')

        for index, name_schema in enumerate(list_schema_name):
            if name_schema:
                list_widget.addItem("")
                list_widget.setItemText(index, name_schema[0])

    def get_version_plugin(self):
        # folder_plugin = os.path.dirname(os.path.abspath(__file__))
        folder_metada = open(
            folder_plugin + "\metadata.txt")  # open(folder_plugin.replace("forms\design", "\metadata.txt"))
        for line in folder_metada:
            if str(line)[:7] == 'version':
                get_version = line.split('=')[1]
                return get_version
        folder_metada.close()


class class_checkformalisme_dialog(class_general_dialog, Ui_class_checkformalisme_dialog):
    def __init__(self, iface):
        self.var_connection = function_connexion()
        class_general_dialog.__init__(self, iface, self.var_connection)
        self.setupUi(self)
        self.get_all_schema_name(self.name_pr)
        self.setWindowTitle("DESIGN " + str(self.get_version_plugin()) + " - Contrôle du formalisme des données")
        self.var_connection.close()
        self.button_box.button(QtWidgets.QDialogButtonBox.Ok).clicked.connect(self.run)

    def run(self):
        list_titulaire = self.name_titulaire
        text_titulaire = [x for x in list_titulaire.currentText().split(',') if x]

        list_statut = self.name_statut
        text_statut = [x for x in list_statut.currentText().split(',') if x]

        list_namePR = self.name_pr
        text_namePR = [x for x in list_namePR.currentText().split(',') if x]

        list_statut_grille = self.name_grille
        text_statut_grille = [x for x in list_statut_grille.currentText().split(',') if x]

        list_list_st_typephy = self.list_st_typephy
        text_list_st_typephy = [x for x in list_list_st_typephy.currentText().split(',') if x]

        if len(text_titulaire) != 1 or len(text_statut) != 1 or len(text_namePR) != 1 or len(
                text_statut_grille) != 1 or len(text_list_st_typephy) != 1:
            QMessageBox.critical(self.iface.mainWindow(), "Message Du Choix",
                                 'Veillez cocher un seul MOE et un seul STATUT et un seul PR et un seul statut Grille et un seul de st_typelogique')
        else:
            nom_moe = "".join(text_titulaire)
            nom_pr = "".join(text_namePR)
            nom_phase = str("".join(text_statut)).upper()
            schema = nom_pr
            nom_st_typelog = "".join(text_list_st_typephy)

            sheet_mcd_attribut = self.sheet_attribut.text()
            sheet_mcd_table = self.sheet_table.text()
            sheet_mcd_attribut_column_name_attribut = self.name_col_attribut.text()
            sheet_mcd_table_column_name_table = self.name_col_table.text()
            sheet_mcd_attribut_column_name_status = "".join(text_statut_grille)

            function_formalisme_mcd(schema, nom_moe, nom_phase,
                                    sheet_mcd_attribut,
                                    sheet_mcd_table,
                                    sheet_mcd_attribut_column_name_attribut,
                                    sheet_mcd_table_column_name_table,
                                    sheet_mcd_attribut_column_name_status, nom_pr, nom_st_typelog)
