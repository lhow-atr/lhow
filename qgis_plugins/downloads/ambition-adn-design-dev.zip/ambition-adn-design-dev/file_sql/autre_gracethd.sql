GRANT USAGE ON SCHEMA schema_name to adn_ing;
GRANT CREATE ON SCHEMA schema_name to adn_ing;
--GRANT SELECT, INSERT ON ALL TABLES IN SCHEMA schema_name TO adn_ing;
-- GRANT ALL ON TABLE contre_releve TO adn_ing;

SET search_path to schema_name, public;
CREATE OR REPLACE VIEW schema_name.vs_dep_znro AS
with Q1 AS
		(Select DZN.*
		FROM dep_.znro DZN, t_znro ZN
		where DZN.nro_ref  = ZN.zn_r2_code),
	Q2 AS (
		  SELECT znro.*
			FROM dep_.znro , q1
			WHERE ST_Intersects(Q1.geom, znro.geom)
			)
select *
from q2;
-- ALTER TABLE vs_dep_znro OWNER TO postgres;


CREATE OR REPLACE VIEW schema_name.vs_resopt_noeuds AS
SELECT resopt_noeuds.gid,
	id_reseau ,
	id_element ,
	rang_opt ,
	niveau ,
	etat_racco ,
	supp_racco ,
	support ,
	nom ,
	cle_ext ,
	sites ,
	prises ,
	equip ,
	cout ,
	id_nod_pri ,
	l_nod_pri ,
	id_nod_sup ,
	l_nod_sup ,
	l_pto_min ,
	l_pto_max ,
	l_pto_tot ,
	c_noeud ,
	c_reseau ,
	c_prise ,
	nom_nro ,
	ancien_nom ,
	resopt_noeuds.geom
FROM dep_.resopt_noeuds, schema_name.vs_dep_znro
WHERE st_within(resopt_noeuds.geom, vs_dep_znro.geom);
-- ALTER TABLE schema_name.vs_resopt_noeuds OWNER TO postgres;


CREATE OR REPLACE VIEW schema_name.vs_suf_majic AS
SELECT suf_majic.gid,
	ccodep ,
	code_insee ,
	nb_indiv ,
	nb_collect ,
	nb_prof ,
	suf_majic.nb_total ,
	nb_propri ,
	suf_majic.geom
FROM dep_.suf_majic, schema_name.vs_dep_znro
WHERE st_within(suf_majic.geom, vs_dep_znro.geom);
-- ALTER TABLE schema_name.vs_resopt_noeuds OWNER TO postgres;


CREATE OR REPLACE VIEW schema_name.vs_resopt_lienstransport AS
SELECT resopt_lienstransport.gid,
	id_reseau,
	id_element ,
	rang_opt ,
	niveau ,
	segment ,
	support ,
	nom ,
	cle_ext ,
	sites ,
	prises ,
	fibres ,
	fibres_p2p ,
	fibres_pon ,
	fibres_res ,
	cables ,
	longueur ,
	cout ,
	id_nod_pri ,
	id_nod_sup ,
	nom_nro ,
	ancien_nom ,
	resopt_lienstransport.geom
FROM dep_.resopt_lienstransport, schema_name.vs_dep_znro
WHERE st_within(resopt_lienstransport.geom, vs_dep_znro.geom);
-- ALTER TABLE schema_name.vs_resopt_lienstransport OWNER TO postgres;


CREATE OR REPLACE VIEW schema_name.vs_resopt_lienstransport AS
SELECT resopt_lienstransport.gid,
	id_reseau,
	id_element ,
	rang_opt ,
	niveau ,
	segment ,
	support ,
	nom ,
	cle_ext ,
	sites ,
	prises ,
	fibres ,
	fibres_p2p ,
	fibres_pon ,
	fibres_res ,
	cables ,
	longueur ,
	cout ,
	id_nod_pri ,
	id_nod_sup ,
	nom_nro ,
	ancien_nom ,
	resopt_lienstransport.geom
FROM dep_.resopt_lienstransport, schema_name.vs_dep_znro
WHERE st_within(resopt_lienstransport.geom, vs_dep_znro.geom);
-- ALTER TABLE schema_name.vs_resopt_lienstransport OWNER TO postgres;


CREATE OR REPLACE VIEW schema_name.vs_resopt_liens AS
SELECT resopt_liens.gid,
	id_reseau,
	id_element ,
	rang_opt ,
	niveau ,
	segment ,
	support ,
	nom ,
	cle_ext ,
	sites ,
	prises ,
	fibres ,
	fibres_p2p ,
	fibres_pon ,
	fibres_res ,
	cables ,
	longueur ,
	cout ,
	id_nod_pri ,
	id_nod_sup ,
	nom_nro ,
	ancien_nom ,
	resopt_liens.geom
FROM dep_.resopt_liens, schema_name.vs_dep_znro
WHERE st_within(resopt_liens.geom, vs_dep_znro.geom);
-- ALTER TABLE schema_name.vs_resopt_liens OWNER TO postgres;

--Creation des routes a lechelle du projet
create table schema_name."troncon_rff" as
select
	tvf.*
from troncon_lineaire."TRONCON_VOIE_FERREE_07-26" as tvf
	join t_znro as zn on ST_DWithin(zn.geom,tvf.geom, 0.1);
	
create table schema_name."troncon_enedis" as
select
	tvf.*
from troncon_lineaire."TRONCON_ENEDIS_07-26" as tvf
	join t_znro as zn on ST_DWithin(zn.geom,tvf.geom, 0.1);

create table schema_name."troncon_route" as
select
	tvf.*
from troncon_lineaire."TRONCON_ROUTE_07-26" as tvf
	join t_znro as zn on ST_DWithin(zn.geom,tvf.geom, 0.1);

create table schema_name."troncon_pr" as
select
	tvf.*
from troncon_lineaire."bornage_pr_shp_l93_201807" as tvf
	join t_znro as zn on ST_DWithin(zn.geom,tvf.geom, 0.1);
	
create table schema_name."appui_orange" as
select
	tvf.*
from troncon_lineaire."appui_orange_07_26" as tvf
	join t_znro as zn on ST_DWithin(zn.geom,tvf.geom, 0.1);
	
create table schema_name."chambre_adn" as
select
	tvf.*
from troncon_lineaire."chambre_adn_rip1_07_26" as tvf
	join t_znro as zn on ST_DWithin(zn.geom,tvf.geom, 0.1);
	
create table schema_name."chambre_orange" as
select
	tvf.*
from troncon_lineaire."chambre_orange_07_26" as tvf
	join t_znro as zn on ST_DWithin(zn.geom,tvf.geom, 0.1);

create table schema_name."pk_07_26" as
select
	tvf.*
from troncon_lineaire."pk_07_26" as tvf
	join t_znro as zn on ST_DWithin(zn.geom,tvf.geom, 0.1);

create table schema_name."troncon_adn" as
select
	tvf.*
from troncon_lineaire."troncon_adn_rip1_07_26" as tvf
	join t_znro as zn on ST_DWithin(zn.geom,tvf.geom, 0.1);


create table schema_name."troncon_orange" as
select
	tvf.*
from troncon_lineaire."troncon_orange_07_26" as tvf
	join t_znro as zn on ST_DWithin(zn.geom,tvf.geom, 0.1);
	
create table schema_name."zone_pr_adn" as
select
	tvf.*
from troncon_lineaire."zone_pr_adn_rip2_07_26" as tvf
	join t_znro as zn on ST_DWithin(zn.geom,tvf.geom, 0.1);
	
	
	
-- Create vue parcelle
CREATE OR REPLACE VIEW vs_parcelles_znro AS
	 SELECT cadastre_domanialite.id_par,
		cadastre_domanialite.id_com,
		cadastre_domanialite.parcelle,
		cadastre_domanialite.dvoilib,
		cadastre_domanialite.nat_droit,
		cadastre_domanialite.pers_moral,
		cadastre_domanialite.geom
	   FROM parcelles.cadastre_domanialite,
		t_znro
	  WHERE st_Within(cadastre_domanialite.geom, t_znro.geom);
	ALTER TABLE vs_parcelles_znro OWNER TO postgres;

-- Create t_refboite
CREATE TABLE t_refboite
	(
		rb_code text NOT NULL,
		rb_rf_code text ,
		rb_etat text ,
		rb_ca_nbmax text ,
		rb_volume text ,
		rb_pressu text ,
		rb_creadat text ,
		rb_majdate text ,
		rb_majsrc text ,
		rb_abddate text ,
		rb_abdsrc text   ,
		CONSTRAINT t_refboite_pkey PRIMARY KEY (rb_code)
	) ;

INSERT INTO schema_name."t_refboite" ("rb_code", "rb_rf_code", "rb_etat", "rb_ca_nbmax", "rb_volume", "rb_pressu", "rb_creadat", "rb_majdate", "rb_majsrc", "rb_abddate", "rb_abdsrc") VALUES ('RB000000000034', 'RF000000000096', 'A', '1', NULL, 'FAUX', 'oct 30, 2017 12:00:00 AM', NULL, NULL, NULL, NULL);
INSERT INTO schema_name."t_refboite" ("rb_code", "rb_rf_code", "rb_etat", "rb_ca_nbmax", "rb_volume", "rb_pressu", "rb_creadat", "rb_majdate", "rb_majsrc", "rb_abddate", "rb_abdsrc") VALUES ('RB000000000036', 'RF000000000099', 'A', '3', NULL, 'FAUX', 'mai 27, 2019 12:00:00 AM', NULL, NULL, NULL, NULL);
INSERT INTO schema_name."t_refboite" ("rb_code", "rb_rf_code", "rb_etat", "rb_ca_nbmax", "rb_volume", "rb_pressu", "rb_creadat", "rb_majdate", "rb_majsrc", "rb_abddate", "rb_abdsrc") VALUES ('RB000000000037', 'RF000000000100', 'A', '4', NULL, 'FAUX', 'mai 27, 2019 12:00:00 AM', NULL, NULL, NULL, NULL);
INSERT INTO schema_name."t_refboite" ("rb_code", "rb_rf_code", "rb_etat", "rb_ca_nbmax", "rb_volume", "rb_pressu", "rb_creadat", "rb_majdate", "rb_majsrc", "rb_abddate", "rb_abdsrc") VALUES ('RB000000000041', 'RF000000000092', 'N', NULL, NULL, 'VRAI', 'oct 30, 2017 12:00:00 AM', NULL, NULL, 'oct 01, 2018', NULL);
INSERT INTO schema_name."t_refboite" ("rb_code", "rb_rf_code", "rb_etat", "rb_ca_nbmax", "rb_volume", "rb_pressu", "rb_creadat", "rb_majdate", "rb_majsrc", "rb_abddate", "rb_abdsrc") VALUES ('RB000000000042', 'RF000000000098', 'N', NULL, NULL, 'VRAI', 'oct 30, 2017 12:00:00 AM', NULL, NULL, 'oct 01, 2018', NULL);
INSERT INTO schema_name."t_refboite" ("rb_code", "rb_rf_code", "rb_etat", "rb_ca_nbmax", "rb_volume", "rb_pressu", "rb_creadat", "rb_majdate", "rb_majsrc", "rb_abddate", "rb_abdsrc") VALUES ('RB000000000003', 'RF000000000054', 'N', NULL, NULL, 'VRAI', 'oct 30, 2017 12:00:00 AM', NULL, NULL, 'oct 01, 2018', 'Ancienne reference');
INSERT INTO schema_name."t_refboite" ("rb_code", "rb_rf_code", "rb_etat", "rb_ca_nbmax", "rb_volume", "rb_pressu", "rb_creadat", "rb_majdate", "rb_majsrc", "rb_abddate", "rb_abdsrc") VALUES ('RB000000000004', 'RF000000000055', 'N', NULL, NULL, 'VRAI', 'oct 30, 2017 12:00:00 AM', NULL, NULL, 'oct 01, 2018', 'Ancienne reference');
INSERT INTO schema_name."t_refboite" ("rb_code", "rb_rf_code", "rb_etat", "rb_ca_nbmax", "rb_volume", "rb_pressu", "rb_creadat", "rb_majdate", "rb_majsrc", "rb_abddate", "rb_abdsrc") VALUES ('RB000000000013', 'RF000000000064', 'N', '1', NULL, 'VRAI', 'oct 30, 2017 12:00:00 AM', NULL, NULL, 'janv 08, 2019', 'Suppression reference cable traversant');
INSERT INTO schema_name."t_refboite" ("rb_code", "rb_rf_code", "rb_etat", "rb_ca_nbmax", "rb_volume", "rb_pressu", "rb_creadat", "rb_majdate", "rb_majsrc", "rb_abddate", "rb_abdsrc") VALUES ('RB000000000017', 'RF000000000068', 'N', NULL, NULL, 'FAUX', 'oct 30, 2017 12:00:00 AM', NULL, NULL, 'janv 08, 2019', 'Ancienne reference');
INSERT INTO schema_name."t_refboite" ("rb_code", "rb_rf_code", "rb_etat", "rb_ca_nbmax", "rb_volume", "rb_pressu", "rb_creadat", "rb_majdate", "rb_majsrc", "rb_abddate", "rb_abdsrc") VALUES ('RB000000000032', 'RF000000000083', 'N', NULL, '57.9', 'VRAI', 'oct 30, 2017 12:00:00 AM', NULL, NULL, 'oct 01, 2018', NULL);
INSERT INTO schema_name."t_refboite" ("rb_code", "rb_rf_code", "rb_etat", "rb_ca_nbmax", "rb_volume", "rb_pressu", "rb_creadat", "rb_majdate", "rb_majsrc", "rb_abddate", "rb_abdsrc") VALUES ('RB000000000033', 'RF000000000084', 'N', '2', '1', 'VRAI', 'oct 30, 2017 12:00:00 AM', NULL, NULL, 'oct 01, 2018', NULL);
INSERT INTO schema_name."t_refboite" ("rb_code", "rb_rf_code", "rb_etat", "rb_ca_nbmax", "rb_volume", "rb_pressu", "rb_creadat", "rb_majdate", "rb_majsrc", "rb_abddate", "rb_abdsrc") VALUES ('RB000000000040', 'RF000000000125', 'A', '12', '5.6', 'VRAI', 'mai 27, 2019 12:00:00 AM', NULL, NULL, NULL, NULL);
INSERT INTO schema_name."t_refboite" ("rb_code", "rb_rf_code", "rb_etat", "rb_ca_nbmax", "rb_volume", "rb_pressu", "rb_creadat", "rb_majdate", "rb_majsrc", "rb_abddate", "rb_abdsrc") VALUES ('RB000000000001', 'RF000000000052', 'A', '1', NULL, 'FAUX', 'oct 30, 2017 12:00:00 AM', NULL, NULL, NULL, NULL);
INSERT INTO schema_name."t_refboite" ("rb_code", "rb_rf_code", "rb_etat", "rb_ca_nbmax", "rb_volume", "rb_pressu", "rb_creadat", "rb_majdate", "rb_majsrc", "rb_abddate", "rb_abdsrc") VALUES ('RB000000000002', 'RF000000000053', 'A', '2', NULL, 'FAUX', 'oct 30, 2017 12:00:00 AM', NULL, NULL, NULL, NULL);
INSERT INTO schema_name."t_refboite" ("rb_code", "rb_rf_code", "rb_etat", "rb_ca_nbmax", "rb_volume", "rb_pressu", "rb_creadat", "rb_majdate", "rb_majsrc", "rb_abddate", "rb_abdsrc") VALUES ('RB000000000005', 'RF000000000056', 'A', '24', '9.9', 'VRAI', 'oct 30, 2017 12:00:00 AM', NULL, NULL, NULL, NULL);
INSERT INTO schema_name."t_refboite" ("rb_code", "rb_rf_code", "rb_etat", "rb_ca_nbmax", "rb_volume", "rb_pressu", "rb_creadat", "rb_majdate", "rb_majsrc", "rb_abddate", "rb_abdsrc") VALUES ('RB000000000006', 'RF000000000057', 'A', '56', '15.65', 'VRAI', 'oct 30, 2017 12:00:00 AM', NULL, NULL, NULL, NULL);
INSERT INTO schema_name."t_refboite" ("rb_code", "rb_rf_code", "rb_etat", "rb_ca_nbmax", "rb_volume", "rb_pressu", "rb_creadat", "rb_majdate", "rb_majsrc", "rb_abddate", "rb_abdsrc") VALUES ('RB000000000007', 'RF000000000058', 'A', '56', '15.65', 'VRAI', 'oct 30, 2017 12:00:00 AM', NULL, NULL, NULL, NULL);
INSERT INTO schema_name."t_refboite" ("rb_code", "rb_rf_code", "rb_etat", "rb_ca_nbmax", "rb_volume", "rb_pressu", "rb_creadat", "rb_majdate", "rb_majsrc", "rb_abddate", "rb_abdsrc") VALUES ('RB000000000008', 'RF000000000059', 'A', '80', '19.05', 'VRAI', 'oct 30, 2017 12:00:00 AM', NULL, NULL, NULL, NULL);
INSERT INTO schema_name."t_refboite" ("rb_code", "rb_rf_code", "rb_etat", "rb_ca_nbmax", "rb_volume", "rb_pressu", "rb_creadat", "rb_majdate", "rb_majsrc", "rb_abddate", "rb_abdsrc") VALUES ('RB000000000009', 'RF000000000060', 'A', '80', '19.05', 'VRAI', 'oct 30, 2017 12:00:00 AM', NULL, NULL, NULL, NULL);
INSERT INTO schema_name."t_refboite" ("rb_code", "rb_rf_code", "rb_etat", "rb_ca_nbmax", "rb_volume", "rb_pressu", "rb_creadat", "rb_majdate", "rb_majsrc", "rb_abddate", "rb_abdsrc") VALUES ('RB000000000010', 'RF000000000061', 'A', '112', '22.3', 'VRAI', 'oct 30, 2017 12:00:00 AM', NULL, NULL, NULL, NULL);
INSERT INTO schema_name."t_refboite" ("rb_code", "rb_rf_code", "rb_etat", "rb_ca_nbmax", "rb_volume", "rb_pressu", "rb_creadat", "rb_majdate", "rb_majsrc", "rb_abddate", "rb_abdsrc") VALUES ('RB000000000011', 'RF000000000062', 'A', '112', '22.3', 'VRAI', 'oct 30, 2017 12:00:00 AM', NULL, NULL, NULL, NULL);
INSERT INTO schema_name."t_refboite" ("rb_code", "rb_rf_code", "rb_etat", "rb_ca_nbmax", "rb_volume", "rb_pressu", "rb_creadat", "rb_majdate", "rb_majsrc", "rb_abddate", "rb_abdsrc") VALUES ('RB000000000012', 'RF000000000063', 'A', '12', '5.95', 'VRAI', 'oct 30, 2017 12:00:00 AM', NULL, NULL, NULL, NULL);
INSERT INTO schema_name."t_refboite" ("rb_code", "rb_rf_code", "rb_etat", "rb_ca_nbmax", "rb_volume", "rb_pressu", "rb_creadat", "rb_majdate", "rb_majsrc", "rb_abddate", "rb_abdsrc") VALUES ('RB000000000014', 'RF000000000065', 'A', '4', NULL, 'FAUX', 'oct 30, 2017 12:00:00 AM', NULL, NULL, NULL, NULL);
INSERT INTO schema_name."t_refboite" ("rb_code", "rb_rf_code", "rb_etat", "rb_ca_nbmax", "rb_volume", "rb_pressu", "rb_creadat", "rb_majdate", "rb_majsrc", "rb_abddate", "rb_abdsrc") VALUES ('RB000000000015', 'RF000000000066', 'A', '12', NULL, 'FAUX', 'oct 30, 2017 12:00:00 AM', NULL, NULL, NULL, NULL);
INSERT INTO schema_name."t_refboite" ("rb_code", "rb_rf_code", "rb_etat", "rb_ca_nbmax", "rb_volume", "rb_pressu", "rb_creadat", "rb_majdate", "rb_majsrc", "rb_abddate", "rb_abdsrc") VALUES ('RB000000000016', 'RF000000000067', 'A', '3', NULL, 'FAUX', 'oct 30, 2017 12:00:00 AM', NULL, NULL, NULL, NULL);
INSERT INTO schema_name."t_refboite" ("rb_code", "rb_rf_code", "rb_etat", "rb_ca_nbmax", "rb_volume", "rb_pressu", "rb_creadat", "rb_majdate", "rb_majsrc", "rb_abddate", "rb_abdsrc") VALUES ('RB000000000018', 'RF000000000069', 'A', '4', '2', 'VRAI', 'oct 30, 2017 12:00:00 AM', NULL, NULL, NULL, NULL);
INSERT INTO schema_name."t_refboite" ("rb_code", "rb_rf_code", "rb_etat", "rb_ca_nbmax", "rb_volume", "rb_pressu", "rb_creadat", "rb_majdate", "rb_majsrc", "rb_abddate", "rb_abdsrc") VALUES ('RB000000000019', 'RF000000000070', 'A', '12', '4.8', 'VRAI', 'oct 30, 2017 12:00:00 AM', NULL, NULL, NULL, NULL);
INSERT INTO schema_name."t_refboite" ("rb_code", "rb_rf_code", "rb_etat", "rb_ca_nbmax", "rb_volume", "rb_pressu", "rb_creadat", "rb_majdate", "rb_majsrc", "rb_abddate", "rb_abdsrc") VALUES ('RB000000000020', 'RF000000000071', 'A', '12', '4.8', 'VRAI', 'oct 30, 2017 12:00:00 AM', NULL, NULL, NULL, NULL);
INSERT INTO schema_name."t_refboite" ("rb_code", "rb_rf_code", "rb_etat", "rb_ca_nbmax", "rb_volume", "rb_pressu", "rb_creadat", "rb_majdate", "rb_majsrc", "rb_abddate", "rb_abdsrc") VALUES ('RB000000000021', 'RF000000000072', 'A', '12', '4.8', 'VRAI', 'oct 30, 2017 12:00:00 AM', NULL, NULL, NULL, NULL);
INSERT INTO schema_name."t_refboite" ("rb_code", "rb_rf_code", "rb_etat", "rb_ca_nbmax", "rb_volume", "rb_pressu", "rb_creadat", "rb_majdate", "rb_majsrc", "rb_abddate", "rb_abdsrc") VALUES ('RB000000000022', 'RF000000000073', 'A', '12', '4.8', 'VRAI', 'oct 30, 2017 12:00:00 AM', NULL, NULL, NULL, NULL);
INSERT INTO schema_name."t_refboite" ("rb_code", "rb_rf_code", "rb_etat", "rb_ca_nbmax", "rb_volume", "rb_pressu", "rb_creadat", "rb_majdate", "rb_majsrc", "rb_abddate", "rb_abdsrc") VALUES ('RB000000000023', 'RF000000000074', 'A', '12', '4.8', 'VRAI', 'oct 30, 2017 12:00:00 AM', NULL, NULL, NULL, NULL);
INSERT INTO schema_name."t_refboite" ("rb_code", "rb_rf_code", "rb_etat", "rb_ca_nbmax", "rb_volume", "rb_pressu", "rb_creadat", "rb_majdate", "rb_majsrc", "rb_abddate", "rb_abdsrc") VALUES ('RB000000000024', 'RF000000000075', 'A', '12', '5.6', 'VRAI', 'oct 30, 2017 12:00:00 AM', NULL, NULL, NULL, NULL);
INSERT INTO schema_name."t_refboite" ("rb_code", "rb_rf_code", "rb_etat", "rb_ca_nbmax", "rb_volume", "rb_pressu", "rb_creadat", "rb_majdate", "rb_majsrc", "rb_abddate", "rb_abdsrc") VALUES ('RB000000000025', 'RF000000000076', 'A', '12', '5.6', 'VRAI', 'oct 30, 2017 12:00:00 AM', NULL, NULL, NULL, NULL);
INSERT INTO schema_name."t_refboite" ("rb_code", "rb_rf_code", "rb_etat", "rb_ca_nbmax", "rb_volume", "rb_pressu", "rb_creadat", "rb_majdate", "rb_majsrc", "rb_abddate", "rb_abdsrc") VALUES ('RB000000000026', 'RF000000000077', 'A', '28', '17.3', 'VRAI', 'oct 30, 2017 12:00:00 AM', NULL, NULL, NULL, NULL);
INSERT INTO schema_name."t_refboite" ("rb_code", "rb_rf_code", "rb_etat", "rb_ca_nbmax", "rb_volume", "rb_pressu", "rb_creadat", "rb_majdate", "rb_majsrc", "rb_abddate", "rb_abdsrc") VALUES ('RB000000000027', 'RF000000000078', 'A', '28', '17.3', 'VRAI', 'oct 30, 2017 12:00:00 AM', NULL, NULL, NULL, NULL);
INSERT INTO schema_name."t_refboite" ("rb_code", "rb_rf_code", "rb_etat", "rb_ca_nbmax", "rb_volume", "rb_pressu", "rb_creadat", "rb_majdate", "rb_majsrc", "rb_abddate", "rb_abdsrc") VALUES ('RB000000000028', 'RF000000000079', 'A', '28', '17.3', 'VRAI', 'oct 30, 2017 12:00:00 AM', NULL, NULL, NULL, NULL);
INSERT INTO schema_name."t_refboite" ("rb_code", "rb_rf_code", "rb_etat", "rb_ca_nbmax", "rb_volume", "rb_pressu", "rb_creadat", "rb_majdate", "rb_majsrc", "rb_abddate", "rb_abdsrc") VALUES ('RB000000000029', 'RF000000000080', 'A', '48', '23.8', 'VRAI', 'oct 30, 2017 12:00:00 AM', NULL, NULL, NULL, NULL);
INSERT INTO schema_name."t_refboite" ("rb_code", "rb_rf_code", "rb_etat", "rb_ca_nbmax", "rb_volume", "rb_pressu", "rb_creadat", "rb_majdate", "rb_majsrc", "rb_abddate", "rb_abdsrc") VALUES ('RB000000000030', 'RF000000000081', 'A', '48', '23.8', 'VRAI', 'oct 30, 2017 12:00:00 AM', NULL, NULL, NULL, NULL);
INSERT INTO schema_name."t_refboite" ("rb_code", "rb_rf_code", "rb_etat", "rb_ca_nbmax", "rb_volume", "rb_pressu", "rb_creadat", "rb_majdate", "rb_majsrc", "rb_abddate", "rb_abdsrc") VALUES ('RB000000000031', 'RF000000000082', 'A', '48', '23.8', 'VRAI', 'oct 30, 2017 12:00:00 AM', NULL, NULL, NULL, NULL);
INSERT INTO schema_name."t_refboite" ("rb_code", "rb_rf_code", "rb_etat", "rb_ca_nbmax", "rb_volume", "rb_pressu", "rb_creadat", "rb_majdate", "rb_majsrc", "rb_abddate", "rb_abdsrc") VALUES ('RB000000000035', 'RF000000000091', 'A', '28', '9.9', 'VRAI', 'mai 27, 2019 12:00:00 AM', NULL, NULL, NULL, NULL);
INSERT INTO schema_name."t_refboite" ("rb_code", "rb_rf_code", "rb_etat", "rb_ca_nbmax", "rb_volume", "rb_pressu", "rb_creadat", "rb_majdate", "rb_majsrc", "rb_abddate", "rb_abdsrc") VALUES ('RB000000000038', 'RF000000000123', 'A', '4', '2', 'VRAI', 'mai 27, 2019 12:00:00 AM', NULL, NULL, NULL, NULL);
INSERT INTO schema_name."t_refboite" ("rb_code", "rb_rf_code", "rb_etat", "rb_ca_nbmax", "rb_volume", "rb_pressu", "rb_creadat", "rb_majdate", "rb_majsrc", "rb_abddate", "rb_abdsrc") VALUES ('RB000000000039', 'RF000000000124', 'A', '12', '4.8', 'VRAI', 'mai 27, 2019 12:00:00 AM', NULL, NULL, NULL, NULL);


-- Create t_refcable
CREATE TABLE t_refcable
	(
		rc_code text NOT NULL,
		rc_rf_code text ,
		rc_etat text ,
		rc_capafo text ,
		rc_modulo text ,
		rc_diam text ,
		rc_typpose text,
		rc_portee text ,
		rc_norm text ,
		rc_rfcomac text ,
		rc_ancref text ,
		rc_creadat text,
		rc_majdate	text,
		rc_majsrc	text,
		rc_abddate	text,
		rc_abdsrc	text,

		CONSTRAINT t_refcable_pkey PRIMARY KEY (rc_code)
	) ;

INSERT INTO schema_name."t_refcable" ("rc_code", "rc_rf_code", "rc_etat", "rc_capafo", "rc_modulo", "rc_diam", "rc_typpose", "rc_portee", "rc_norm", "rc_rfcomac", "rc_ancref", "rc_creadat", "rc_majdate", "rc_majsrc", "rc_abddate", "rc_abdsrc") VALUES ('RC000000000001', 'RF000000000009', 'A', '12', '12', '6', 'C', NULL, 'G.657A2', NULL, 'TF103G', 'oct 30, 2017 12:00:00 AM', NULL, NULL, NULL, NULL);
INSERT INTO schema_name."t_refcable" ("rc_code", "rc_rf_code", "rc_etat", "rc_capafo", "rc_modulo", "rc_diam", "rc_typpose", "rc_portee", "rc_norm", "rc_rfcomac", "rc_ancref", "rc_creadat", "rc_majdate", "rc_majsrc", "rc_abddate", "rc_abdsrc") VALUES ('RC000000000002', 'RF000000000009', 'A', '48', '12', '8', 'C', NULL, 'G.657A2', NULL, 'TF103G', 'oct 30, 2017 12:00:00 AM', NULL, NULL, NULL, NULL);
INSERT INTO schema_name."t_refcable" ("rc_code", "rc_rf_code", "rc_etat", "rc_capafo", "rc_modulo", "rc_diam", "rc_typpose", "rc_portee", "rc_norm", "rc_rfcomac", "rc_ancref", "rc_creadat", "rc_majdate", "rc_majsrc", "rc_abddate", "rc_abdsrc") VALUES ('RC000000000003', 'RF000000000009', 'A', '72', '12', '10', 'C', NULL, 'G.657A2', NULL, 'TF103G', 'oct 30, 2017 12:00:00 AM', NULL, NULL, NULL, NULL);
INSERT INTO schema_name."t_refcable" ("rc_code", "rc_rf_code", "rc_etat", "rc_capafo", "rc_modulo", "rc_diam", "rc_typpose", "rc_portee", "rc_norm", "rc_rfcomac", "rc_ancref", "rc_creadat", "rc_majdate", "rc_majsrc", "rc_abddate", "rc_abdsrc") VALUES ('RC000000000004', 'RF000000000009', 'A', '96', '12', '11.2', 'C', NULL, 'G.657A2', NULL, 'TF103G', 'oct 30, 2017 12:00:00 AM', NULL, NULL, NULL, NULL);
INSERT INTO schema_name."t_refcable" ("rc_code", "rc_rf_code", "rc_etat", "rc_capafo", "rc_modulo", "rc_diam", "rc_typpose", "rc_portee", "rc_norm", "rc_rfcomac", "rc_ancref", "rc_creadat", "rc_majdate", "rc_majsrc", "rc_abddate", "rc_abdsrc") VALUES ('RC000000000005', 'RF000000000009', 'A', '144', '12', '11.5', 'C', NULL, 'G.657A2', NULL, 'TF103G', 'oct 30, 2017 12:00:00 AM', NULL, NULL, NULL, NULL);
INSERT INTO schema_name."t_refcable" ("rc_code", "rc_rf_code", "rc_etat", "rc_capafo", "rc_modulo", "rc_diam", "rc_typpose", "rc_portee", "rc_norm", "rc_rfcomac", "rc_ancref", "rc_creadat", "rc_majdate", "rc_majsrc", "rc_abddate", "rc_abdsrc") VALUES ('RC000000000006', 'RF000000000009', 'A', '216', '12', '12.8', 'C', NULL, 'G.657A2', NULL, 'TF103G', 'oct 30, 2017 12:00:00 AM', NULL, NULL, NULL, NULL);
INSERT INTO schema_name."t_refcable" ("rc_code", "rc_rf_code", "rc_etat", "rc_capafo", "rc_modulo", "rc_diam", "rc_typpose", "rc_portee", "rc_norm", "rc_rfcomac", "rc_ancref", "rc_creadat", "rc_majdate", "rc_majsrc", "rc_abddate", "rc_abdsrc") VALUES ('RC000000000007', 'RF000000000009', 'A', '288', '12', '13.8', 'C', NULL, 'G.657A2', NULL, 'TF103G', 'oct 30, 2017 12:00:00 AM', NULL, NULL, NULL, NULL);
INSERT INTO schema_name."t_refcable" ("rc_code", "rc_rf_code", "rc_etat", "rc_capafo", "rc_modulo", "rc_diam", "rc_typpose", "rc_portee", "rc_norm", "rc_rfcomac", "rc_ancref", "rc_creadat", "rc_majdate", "rc_majsrc", "rc_abddate", "rc_abdsrc") VALUES ('RC000000000008', 'RF000000000010', 'A', '360', '12', '14.5', 'C', NULL, 'G.657A2', NULL, 'TF104G', 'oct 30, 2017 12:00:00 AM', NULL, NULL, NULL, NULL);
INSERT INTO schema_name."t_refcable" ("rc_code", "rc_rf_code", "rc_etat", "rc_capafo", "rc_modulo", "rc_diam", "rc_typpose", "rc_portee", "rc_norm", "rc_rfcomac", "rc_ancref", "rc_creadat", "rc_majdate", "rc_majsrc", "rc_abddate", "rc_abdsrc") VALUES ('RC000000000009', 'RF000000000010', 'A', '432', '12', '15.2', 'C', NULL, 'G.657A2', NULL, 'TF104G', 'oct 30, 2017 12:00:00 AM', NULL, NULL, NULL, NULL);
INSERT INTO schema_name."t_refcable" ("rc_code", "rc_rf_code", "rc_etat", "rc_capafo", "rc_modulo", "rc_diam", "rc_typpose", "rc_portee", "rc_norm", "rc_rfcomac", "rc_ancref", "rc_creadat", "rc_majdate", "rc_majsrc", "rc_abddate", "rc_abdsrc") VALUES ('RC000000000010', 'RF000000000010', 'A', '576', '12', '16.7', 'C', NULL, 'G.657A2', NULL, 'TF104G', 'oct 30, 2017 12:00:00 AM', NULL, NULL, NULL, NULL);
INSERT INTO schema_name."t_refcable" ("rc_code", "rc_rf_code", "rc_etat", "rc_capafo", "rc_modulo", "rc_diam", "rc_typpose", "rc_portee", "rc_norm", "rc_rfcomac", "rc_ancref", "rc_creadat", "rc_majdate", "rc_majsrc", "rc_abddate", "rc_abdsrc") VALUES ('RC000000000011', 'RF000000000010', 'A', '720', '12', '18', 'C', NULL, 'G.657A2', NULL, 'TF104G', 'oct 30, 2017 12:00:00 AM', NULL, NULL, NULL, NULL);
INSERT INTO schema_name."t_refcable" ("rc_code", "rc_rf_code", "rc_etat", "rc_capafo", "rc_modulo", "rc_diam", "rc_typpose", "rc_portee", "rc_norm", "rc_rfcomac", "rc_ancref", "rc_creadat", "rc_majdate", "rc_majsrc", "rc_abddate", "rc_abdsrc") VALUES ('RC000000000012', 'RF000000000010', 'A', '864', '12', '19.2', 'C', NULL, 'G.657A2', NULL, 'TF104G', 'oct 30, 2017 12:00:00 AM', NULL, NULL, NULL, NULL);
INSERT INTO schema_name."t_refcable" ("rc_code", "rc_rf_code", "rc_etat", "rc_capafo", "rc_modulo", "rc_diam", "rc_typpose", "rc_portee", "rc_norm", "rc_rfcomac", "rc_ancref", "rc_creadat", "rc_majdate", "rc_majsrc", "rc_abddate", "rc_abdsrc") VALUES ('RC000000000013', 'RF000000000011', 'A', '12', '12', '6', 'M', '80', 'G.657A2', 'P-TF303G-12F-80', 'TF303G', 'oct 30, 2017 12:00:00 AM', NULL, NULL, NULL, NULL);
INSERT INTO schema_name."t_refcable" ("rc_code", "rc_rf_code", "rc_etat", "rc_capafo", "rc_modulo", "rc_diam", "rc_typpose", "rc_portee", "rc_norm", "rc_rfcomac", "rc_ancref", "rc_creadat", "rc_majdate", "rc_majsrc", "rc_abddate", "rc_abdsrc") VALUES ('RC000000000014', 'RF000000000011', 'A', '24', '12', '8', 'M', '80', 'G.657A2', 'P-TF303G-24F-80', 'TF303G', 'oct 30, 2017 12:00:00 AM', NULL, NULL, NULL, NULL);
INSERT INTO schema_name."t_refcable" ("rc_code", "rc_rf_code", "rc_etat", "rc_capafo", "rc_modulo", "rc_diam", "rc_typpose", "rc_portee", "rc_norm", "rc_rfcomac", "rc_ancref", "rc_creadat", "rc_majdate", "rc_majsrc", "rc_abddate", "rc_abdsrc") VALUES ('RC000000000015', 'RF000000000011', 'A', '36', '12', '8', 'M', '80', 'G.657A2', 'P-TF303G-36F-80', 'TF303G', 'oct 30, 2017 12:00:00 AM', NULL, NULL, NULL, NULL);
INSERT INTO schema_name."t_refcable" ("rc_code", "rc_rf_code", "rc_etat", "rc_capafo", "rc_modulo", "rc_diam", "rc_typpose", "rc_portee", "rc_norm", "rc_rfcomac", "rc_ancref", "rc_creadat", "rc_majdate", "rc_majsrc", "rc_abddate", "rc_abdsrc") VALUES ('RC000000000016', 'RF000000000011', 'A', '48', '12', '10', 'M', '80', 'G.657A2', 'P-TF303G-48F-80', 'TF303G', 'oct 30, 2017 12:00:00 AM', NULL, NULL, NULL, NULL);
INSERT INTO schema_name."t_refcable" ("rc_code", "rc_rf_code", "rc_etat", "rc_capafo", "rc_modulo", "rc_diam", "rc_typpose", "rc_portee", "rc_norm", "rc_rfcomac", "rc_ancref", "rc_creadat", "rc_majdate", "rc_majsrc", "rc_abddate", "rc_abdsrc") VALUES ('RC000000000017', 'RF000000000011', 'A', '72', '12', '11.3', 'M', '80', 'G.657A2', 'P-TF303G-72F-80', 'TF303G', 'oct 30, 2017 12:00:00 AM', NULL, NULL, NULL, NULL);
INSERT INTO schema_name."t_refcable" ("rc_code", "rc_rf_code", "rc_etat", "rc_capafo", "rc_modulo", "rc_diam", "rc_typpose", "rc_portee", "rc_norm", "rc_rfcomac", "rc_ancref", "rc_creadat", "rc_majdate", "rc_majsrc", "rc_abddate", "rc_abdsrc") VALUES ('RC000000000018', 'RF000000000011', 'A', '96', '12', '12.4', 'M', '80', 'G.657A2', 'P-TF303G-96F-80', 'TF303G', 'oct 30, 2017 12:00:00 AM', NULL, NULL, NULL, NULL);
INSERT INTO schema_name."t_refcable" ("rc_code", "rc_rf_code", "rc_etat", "rc_capafo", "rc_modulo", "rc_diam", "rc_typpose", "rc_portee", "rc_norm", "rc_rfcomac", "rc_ancref", "rc_creadat", "rc_majdate", "rc_majsrc", "rc_abddate", "rc_abdsrc") VALUES ('RC000000000019', 'RF000000000011', 'A', '144', '12', '13.3', 'M', '80', 'G.657A2', 'P-TF303G-144F-80', 'TF303G', 'oct 30, 2017 12:00:00 AM', NULL, NULL, NULL, NULL);
INSERT INTO schema_name."t_refcable" ("rc_code", "rc_rf_code", "rc_etat", "rc_capafo", "rc_modulo", "rc_diam", "rc_typpose", "rc_portee", "rc_norm", "rc_rfcomac", "rc_ancref", "rc_creadat", "rc_majdate", "rc_majsrc", "rc_abddate", "rc_abdsrc") VALUES ('RC000000000062', 'RF000000000093', 'A', '2', '2', '6', 'M', '70', 'G.657A2', NULL, NULL, 'oct 30, 2017 12:00:00 AM', NULL, NULL, NULL, NULL);
INSERT INTO schema_name."t_refcable" ("rc_code", "rc_rf_code", "rc_etat", "rc_capafo", "rc_modulo", "rc_diam", "rc_typpose", "rc_portee", "rc_norm", "rc_rfcomac", "rc_ancref", "rc_creadat", "rc_majdate", "rc_majsrc", "rc_abddate", "rc_abdsrc") VALUES ('RC000000000021', 'RF000000000011', 'A', '288', '12', '15.5', 'M', '80', 'G.657A2', 'P-TF303G-288F-80', 'TF303G', 'oct 30, 2017 12:00:00 AM', NULL, NULL, NULL, NULL);
INSERT INTO schema_name."t_refcable" ("rc_code", "rc_rf_code", "rc_etat", "rc_capafo", "rc_modulo", "rc_diam", "rc_typpose", "rc_portee", "rc_norm", "rc_rfcomac", "rc_ancref", "rc_creadat", "rc_majdate", "rc_majsrc", "rc_abddate", "rc_abdsrc") VALUES ('RC000000000023', 'RF000000000013', 'A', '12', '12', '5.5', 'M', '60', 'G.657A2', 'S817A12-12F-60', NULL, 'oct 30, 2017 12:00:00 AM', NULL, NULL, NULL, NULL);
INSERT INTO schema_name."t_refcable" ("rc_code", "rc_rf_code", "rc_etat", "rc_capafo", "rc_modulo", "rc_diam", "rc_typpose", "rc_portee", "rc_norm", "rc_rfcomac", "rc_ancref", "rc_creadat", "rc_majdate", "rc_majsrc", "rc_abddate", "rc_abdsrc") VALUES ('RC000000000022', 'RF000000000012', 'A', '12', '12', '7', 'M', '60', 'G.657A2', NULL, NULL, 'oct 30, 2017 12:00:00 AM', NULL, NULL, NULL, NULL);
INSERT INTO schema_name."t_refcable" ("rc_code", "rc_rf_code", "rc_etat", "rc_capafo", "rc_modulo", "rc_diam", "rc_typpose", "rc_portee", "rc_norm", "rc_rfcomac", "rc_ancref", "rc_creadat", "rc_majdate", "rc_majsrc", "rc_abddate", "rc_abdsrc") VALUES ('RC000000000024', 'RF000000000014', 'A', '24', '12', '7', 'M', '60', 'G.657A2', 'S817A24-24F-60', NULL, 'oct 30, 2017 12:00:00 AM', NULL, NULL, NULL, NULL);
INSERT INTO schema_name."t_refcable" ("rc_code", "rc_rf_code", "rc_etat", "rc_capafo", "rc_modulo", "rc_diam", "rc_typpose", "rc_portee", "rc_norm", "rc_rfcomac", "rc_ancref", "rc_creadat", "rc_majdate", "rc_majsrc", "rc_abddate", "rc_abdsrc") VALUES ('RC000000000025', 'RF000000000015', 'A', '48', '12', '8', 'M', '60', 'G.657A2', 'S817A48-48F-50', NULL, 'oct 30, 2017 12:00:00 AM', NULL, NULL, NULL, NULL);
INSERT INTO schema_name."t_refcable" ("rc_code", "rc_rf_code", "rc_etat", "rc_capafo", "rc_modulo", "rc_diam", "rc_typpose", "rc_portee", "rc_norm", "rc_rfcomac", "rc_ancref", "rc_creadat", "rc_majdate", "rc_majsrc", "rc_abddate", "rc_abdsrc") VALUES ('RC000000000026', 'RF000000000016', 'A', '72', '12', '9.6', 'M', '60', 'G.657A2', 'S817A72-72F-50', NULL, 'oct 30, 2017 12:00:00 AM', NULL, NULL, NULL, NULL);
INSERT INTO schema_name."t_refcable" ("rc_code", "rc_rf_code", "rc_etat", "rc_capafo", "rc_modulo", "rc_diam", "rc_typpose", "rc_portee", "rc_norm", "rc_rfcomac", "rc_ancref", "rc_creadat", "rc_majdate", "rc_majsrc", "rc_abddate", "rc_abdsrc") VALUES ('RC000000000027', 'RF000000000017', 'A', '96', '12', '11.5', 'M', '60', 'G.657A2', 'S817A96-96F-50', NULL, 'oct 30, 2017 12:00:00 AM', NULL, NULL, NULL, NULL);
INSERT INTO schema_name."t_refcable" ("rc_code", "rc_rf_code", "rc_etat", "rc_capafo", "rc_modulo", "rc_diam", "rc_typpose", "rc_portee", "rc_norm", "rc_rfcomac", "rc_ancref", "rc_creadat", "rc_majdate", "rc_majsrc", "rc_abddate", "rc_abdsrc") VALUES ('RC000000000028', 'RF000000000018', 'A', '144', '12', '11.5', 'M', '60', 'G.657A2', NULL, NULL, 'oct 30, 2017 12:00:00 AM', NULL, NULL, NULL, NULL);
INSERT INTO schema_name."t_refcable" ("rc_code", "rc_rf_code", "rc_etat", "rc_capafo", "rc_modulo", "rc_diam", "rc_typpose", "rc_portee", "rc_norm", "rc_rfcomac", "rc_ancref", "rc_creadat", "rc_majdate", "rc_majsrc", "rc_abddate", "rc_abdsrc") VALUES ('RC000000000029', 'RF000000000019', 'A', '288', '12', '16', 'M', '60', 'G.657A2', NULL, NULL, 'oct 30, 2017 12:00:00 AM', NULL, NULL, NULL, NULL);
INSERT INTO schema_name."t_refcable" ("rc_code", "rc_rf_code", "rc_etat", "rc_capafo", "rc_modulo", "rc_diam", "rc_typpose", "rc_portee", "rc_norm", "rc_rfcomac", "rc_ancref", "rc_creadat", "rc_majdate", "rc_majsrc", "rc_abddate", "rc_abdsrc") VALUES ('RC000000000030', 'RF000000000020', 'A', '12', '12', '6', 'C', NULL, 'G.657A2', NULL, NULL, 'oct 30, 2017 12:00:00 AM', NULL, NULL, NULL, NULL);
INSERT INTO schema_name."t_refcable" ("rc_code", "rc_rf_code", "rc_etat", "rc_capafo", "rc_modulo", "rc_diam", "rc_typpose", "rc_portee", "rc_norm", "rc_rfcomac", "rc_ancref", "rc_creadat", "rc_majdate", "rc_majsrc", "rc_abddate", "rc_abdsrc") VALUES ('RC000000000031', 'RF000000000021', 'A', '24', '12', '6', 'C', NULL, 'G.657A2', NULL, NULL, 'oct 30, 2017 12:00:00 AM', NULL, NULL, NULL, NULL);
INSERT INTO schema_name."t_refcable" ("rc_code", "rc_rf_code", "rc_etat", "rc_capafo", "rc_modulo", "rc_diam", "rc_typpose", "rc_portee", "rc_norm", "rc_rfcomac", "rc_ancref", "rc_creadat", "rc_majdate", "rc_majsrc", "rc_abddate", "rc_abdsrc") VALUES ('RC000000000032', 'RF000000000022', 'A', '36', '12', '6', 'C', NULL, 'G.657A2', NULL, NULL, 'oct 30, 2017 12:00:00 AM', NULL, NULL, NULL, NULL);
INSERT INTO schema_name."t_refcable" ("rc_code", "rc_rf_code", "rc_etat", "rc_capafo", "rc_modulo", "rc_diam", "rc_typpose", "rc_portee", "rc_norm", "rc_rfcomac", "rc_ancref", "rc_creadat", "rc_majdate", "rc_majsrc", "rc_abddate", "rc_abdsrc") VALUES ('RC000000000033', 'RF000000000023', 'A', '48', '12', '6', 'C', NULL, 'G.657A2', NULL, NULL, 'oct 30, 2017 12:00:00 AM', NULL, NULL, NULL, NULL);
INSERT INTO schema_name."t_refcable" ("rc_code", "rc_rf_code", "rc_etat", "rc_capafo", "rc_modulo", "rc_diam", "rc_typpose", "rc_portee", "rc_norm", "rc_rfcomac", "rc_ancref", "rc_creadat", "rc_majdate", "rc_majsrc", "rc_abddate", "rc_abdsrc") VALUES ('RC000000000034', 'RF000000000024', 'A', '72', '12', '8', 'C', NULL, 'G.657A2', NULL, NULL, 'oct 30, 2017 12:00:00 AM', NULL, NULL, NULL, NULL);
INSERT INTO schema_name."t_refcable" ("rc_code", "rc_rf_code", "rc_etat", "rc_capafo", "rc_modulo", "rc_diam", "rc_typpose", "rc_portee", "rc_norm", "rc_rfcomac", "rc_ancref", "rc_creadat", "rc_majdate", "rc_majsrc", "rc_abddate", "rc_abdsrc") VALUES ('RC000000000035', 'RF000000000025', 'A', '96', '12', '8', 'C', NULL, 'G.657A2', NULL, NULL, 'oct 30, 2017 12:00:00 AM', NULL, NULL, NULL, NULL);
INSERT INTO schema_name."t_refcable" ("rc_code", "rc_rf_code", "rc_etat", "rc_capafo", "rc_modulo", "rc_diam", "rc_typpose", "rc_portee", "rc_norm", "rc_rfcomac", "rc_ancref", "rc_creadat", "rc_majdate", "rc_majsrc", "rc_abddate", "rc_abdsrc") VALUES ('RC000000000036', 'RF000000000026', 'A', '144', '12', '9.5', 'C', NULL, 'G.657A2', NULL, NULL, 'oct 30, 2017 12:00:00 AM', NULL, NULL, NULL, NULL);
INSERT INTO schema_name."t_refcable" ("rc_code", "rc_rf_code", "rc_etat", "rc_capafo", "rc_modulo", "rc_diam", "rc_typpose", "rc_portee", "rc_norm", "rc_rfcomac", "rc_ancref", "rc_creadat", "rc_majdate", "rc_majsrc", "rc_abddate", "rc_abdsrc") VALUES ('RC000000000037', 'RF000000000027', 'A', '432', '12', '12', 'C', NULL, 'G.657A2', NULL, NULL, 'oct 30, 2017 12:00:00 AM', NULL, NULL, NULL, NULL);
INSERT INTO schema_name."t_refcable" ("rc_code", "rc_rf_code", "rc_etat", "rc_capafo", "rc_modulo", "rc_diam", "rc_typpose", "rc_portee", "rc_norm", "rc_rfcomac", "rc_ancref", "rc_creadat", "rc_majdate", "rc_majsrc", "rc_abddate", "rc_abdsrc") VALUES ('RC000000000038', 'RF000000000028', 'A', '576', '12', '17', 'C', NULL, 'G.657A2', NULL, NULL, 'oct 30, 2017 12:00:00 AM', NULL, NULL, NULL, NULL);
INSERT INTO schema_name."t_refcable" ("rc_code", "rc_rf_code", "rc_etat", "rc_capafo", "rc_modulo", "rc_diam", "rc_typpose", "rc_portee", "rc_norm", "rc_rfcomac", "rc_ancref", "rc_creadat", "rc_majdate", "rc_majsrc", "rc_abddate", "rc_abdsrc") VALUES ('RC000000000039', 'RF000000000029', 'A', '720', '12', '17', 'C', NULL, 'G.657A2', NULL, NULL, 'oct 30, 2017 12:00:00 AM', NULL, NULL, NULL, NULL);
INSERT INTO schema_name."t_refcable" ("rc_code", "rc_rf_code", "rc_etat", "rc_capafo", "rc_modulo", "rc_diam", "rc_typpose", "rc_portee", "rc_norm", "rc_rfcomac", "rc_ancref", "rc_creadat", "rc_majdate", "rc_majsrc", "rc_abddate", "rc_abdsrc") VALUES ('RC000000000040', 'RF000000000030', 'A', '864', '12', '19', 'C', NULL, 'G.657A2', NULL, NULL, 'oct 30, 2017 12:00:00 AM', NULL, NULL, NULL, NULL);
INSERT INTO schema_name."t_refcable" ("rc_code", "rc_rf_code", "rc_etat", "rc_capafo", "rc_modulo", "rc_diam", "rc_typpose", "rc_portee", "rc_norm", "rc_rfcomac", "rc_ancref", "rc_creadat", "rc_majdate", "rc_majsrc", "rc_abddate", "rc_abdsrc") VALUES ('RC000000000041', 'RF000000000031', 'A', '288', '12', '12', 'C', NULL, 'G.657A2', NULL, NULL, 'oct 30, 2017 12:00:00 AM', NULL, NULL, NULL, NULL);
INSERT INTO schema_name."t_refcable" ("rc_code", "rc_rf_code", "rc_etat", "rc_capafo", "rc_modulo", "rc_diam", "rc_typpose", "rc_portee", "rc_norm", "rc_rfcomac", "rc_ancref", "rc_creadat", "rc_majdate", "rc_majsrc", "rc_abddate", "rc_abdsrc") VALUES ('RC000000000042', 'RF000000000032', 'A', '12', '12', '6.1', 'C', NULL, 'G.657A2', NULL, NULL, 'oct 30, 2017 12:00:00 AM', NULL, NULL, NULL, NULL);
INSERT INTO schema_name."t_refcable" ("rc_code", "rc_rf_code", "rc_etat", "rc_capafo", "rc_modulo", "rc_diam", "rc_typpose", "rc_portee", "rc_norm", "rc_rfcomac", "rc_ancref", "rc_creadat", "rc_majdate", "rc_majsrc", "rc_abddate", "rc_abdsrc") VALUES ('RC000000000043', 'RF000000000033', 'A', '24', '12', '8.4', 'C', NULL, 'G.657A2', NULL, NULL, 'oct 30, 2017 12:00:00 AM', NULL, NULL, NULL, NULL);
INSERT INTO schema_name."t_refcable" ("rc_code", "rc_rf_code", "rc_etat", "rc_capafo", "rc_modulo", "rc_diam", "rc_typpose", "rc_portee", "rc_norm", "rc_rfcomac", "rc_ancref", "rc_creadat", "rc_majdate", "rc_majsrc", "rc_abddate", "rc_abdsrc") VALUES ('RC000000000044', 'RF000000000034', 'A', '36', '12', '8.4', 'C', NULL, 'G.657A2', NULL, NULL, 'oct 30, 2017 12:00:00 AM', NULL, NULL, NULL, NULL);
INSERT INTO schema_name."t_refcable" ("rc_code", "rc_rf_code", "rc_etat", "rc_capafo", "rc_modulo", "rc_diam", "rc_typpose", "rc_portee", "rc_norm", "rc_rfcomac", "rc_ancref", "rc_creadat", "rc_majdate", "rc_majsrc", "rc_abddate", "rc_abdsrc") VALUES ('RC000000000045', 'RF000000000035', 'A', '48', '12', '8.4', 'C', NULL, 'G.657A2', NULL, NULL, 'oct 30, 2017 12:00:00 AM', NULL, NULL, NULL, NULL);
INSERT INTO schema_name."t_refcable" ("rc_code", "rc_rf_code", "rc_etat", "rc_capafo", "rc_modulo", "rc_diam", "rc_typpose", "rc_portee", "rc_norm", "rc_rfcomac", "rc_ancref", "rc_creadat", "rc_majdate", "rc_majsrc", "rc_abddate", "rc_abdsrc") VALUES ('RC000000000046', 'RF000000000036', 'A', '48', '12', '8.4', 'C', NULL, 'G.652D', NULL, NULL, 'oct 30, 2017 12:00:00 AM', NULL, NULL, NULL, NULL);
INSERT INTO schema_name."t_refcable" ("rc_code", "rc_rf_code", "rc_etat", "rc_capafo", "rc_modulo", "rc_diam", "rc_typpose", "rc_portee", "rc_norm", "rc_rfcomac", "rc_ancref", "rc_creadat", "rc_majdate", "rc_majsrc", "rc_abddate", "rc_abdsrc") VALUES ('RC000000000047', 'RF000000000037', 'A', '72', '12', '10.2', 'C', NULL, 'G.657A2', NULL, NULL, 'oct 30, 2017 12:00:00 AM', NULL, NULL, NULL, NULL);
INSERT INTO schema_name."t_refcable" ("rc_code", "rc_rf_code", "rc_etat", "rc_capafo", "rc_modulo", "rc_diam", "rc_typpose", "rc_portee", "rc_norm", "rc_rfcomac", "rc_ancref", "rc_creadat", "rc_majdate", "rc_majsrc", "rc_abddate", "rc_abdsrc") VALUES ('RC000000000048', 'RF000000000038', 'A', '96', '12', '12', 'C', NULL, 'G.657A2', NULL, NULL, 'oct 30, 2017 12:00:00 AM', NULL, NULL, NULL, NULL);
INSERT INTO schema_name."t_refcable" ("rc_code", "rc_rf_code", "rc_etat", "rc_capafo", "rc_modulo", "rc_diam", "rc_typpose", "rc_portee", "rc_norm", "rc_rfcomac", "rc_ancref", "rc_creadat", "rc_majdate", "rc_majsrc", "rc_abddate", "rc_abdsrc") VALUES ('RC000000000049', 'RF000000000039', 'A', '144', '12', '12', 'C', NULL, 'G.657A2', NULL, NULL, 'oct 30, 2017 12:00:00 AM', NULL, NULL, NULL, NULL);
INSERT INTO schema_name."t_refcable" ("rc_code", "rc_rf_code", "rc_etat", "rc_capafo", "rc_modulo", "rc_diam", "rc_typpose", "rc_portee", "rc_norm", "rc_rfcomac", "rc_ancref", "rc_creadat", "rc_majdate", "rc_majsrc", "rc_abddate", "rc_abdsrc") VALUES ('RC000000000050', 'RF000000000040', 'A', '288', '12', '13.2', 'C', NULL, 'G.657A2', NULL, NULL, 'oct 30, 2017 12:00:00 AM', NULL, NULL, NULL, NULL);
INSERT INTO schema_name."t_refcable" ("rc_code", "rc_rf_code", "rc_etat", "rc_capafo", "rc_modulo", "rc_diam", "rc_typpose", "rc_portee", "rc_norm", "rc_rfcomac", "rc_ancref", "rc_creadat", "rc_majdate", "rc_majsrc", "rc_abddate", "rc_abdsrc") VALUES ('RC000000000051', 'RF000000000041', 'A', '432', '12', '16.5', 'C', NULL, 'G.657A2', NULL, NULL, 'oct 30, 2017 12:00:00 AM', NULL, NULL, NULL, NULL);
INSERT INTO schema_name."t_refcable" ("rc_code", "rc_rf_code", "rc_etat", "rc_capafo", "rc_modulo", "rc_diam", "rc_typpose", "rc_portee", "rc_norm", "rc_rfcomac", "rc_ancref", "rc_creadat", "rc_majdate", "rc_majsrc", "rc_abddate", "rc_abdsrc") VALUES ('RC000000000052', 'RF000000000042', 'A', '576', '12', '18', 'C', NULL, 'G.657A2', NULL, NULL, 'oct 30, 2017 12:00:00 AM', NULL, NULL, NULL, NULL);
INSERT INTO schema_name."t_refcable" ("rc_code", "rc_rf_code", "rc_etat", "rc_capafo", "rc_modulo", "rc_diam", "rc_typpose", "rc_portee", "rc_norm", "rc_rfcomac", "rc_ancref", "rc_creadat", "rc_majdate", "rc_majsrc", "rc_abddate", "rc_abdsrc") VALUES ('RC000000000053', 'RF000000000043', 'A', '720', '12', '18.5', 'C', NULL, 'G.657A2', NULL, NULL, 'oct 30, 2017 12:00:00 AM', NULL, NULL, NULL, NULL);
INSERT INTO schema_name."t_refcable" ("rc_code", "rc_rf_code", "rc_etat", "rc_capafo", "rc_modulo", "rc_diam", "rc_typpose", "rc_portee", "rc_norm", "rc_rfcomac", "rc_ancref", "rc_creadat", "rc_majdate", "rc_majsrc", "rc_abddate", "rc_abdsrc") VALUES ('RC000000000054', 'RF000000000044', 'A', '864', '12', '19.5', 'C', NULL, 'G.657A2', NULL, NULL, 'oct 30, 2017 12:00:00 AM', NULL, NULL, NULL, NULL);
INSERT INTO schema_name."t_refcable" ("rc_code", "rc_rf_code", "rc_etat", "rc_capafo", "rc_modulo", "rc_diam", "rc_typpose", "rc_portee", "rc_norm", "rc_rfcomac", "rc_ancref", "rc_creadat", "rc_majdate", "rc_majsrc", "rc_abddate", "rc_abdsrc") VALUES ('RC000000000055', 'RF000000000045', 'A', '12', '12', '6.1', 'M', '70', 'G.657A2', 'A-N7841A-12F-70', NULL, 'oct 30, 2017 12:00:00 AM', NULL, NULL, NULL, NULL);
INSERT INTO schema_name."t_refcable" ("rc_code", "rc_rf_code", "rc_etat", "rc_capafo", "rc_modulo", "rc_diam", "rc_typpose", "rc_portee", "rc_norm", "rc_rfcomac", "rc_ancref", "rc_creadat", "rc_majdate", "rc_majsrc", "rc_abddate", "rc_abdsrc") VALUES ('RC000000000056', 'RF000000000046', 'A', '24', '12', '8.3', 'M', '70', 'G.657A2', 'A-N8227A-24F-70', NULL, 'oct 30, 2017 12:00:00 AM', NULL, NULL, NULL, NULL);
INSERT INTO schema_name."t_refcable" ("rc_code", "rc_rf_code", "rc_etat", "rc_capafo", "rc_modulo", "rc_diam", "rc_typpose", "rc_portee", "rc_norm", "rc_rfcomac", "rc_ancref", "rc_creadat", "rc_majdate", "rc_majsrc", "rc_abddate", "rc_abdsrc") VALUES ('RC000000000057', 'RF000000000047', 'A', '48', '12', '9.4', 'M', '70', 'G.657A2', 'A-N9273A-48F-70', NULL, 'oct 30, 2017 12:00:00 AM', NULL, NULL, NULL, NULL);
INSERT INTO schema_name."t_refcable" ("rc_code", "rc_rf_code", "rc_etat", "rc_capafo", "rc_modulo", "rc_diam", "rc_typpose", "rc_portee", "rc_norm", "rc_rfcomac", "rc_ancref", "rc_creadat", "rc_majdate", "rc_majsrc", "rc_abddate", "rc_abdsrc") VALUES ('RC000000000058', 'RF000000000048', 'A', '72', '12', '10.7', 'M', '70', 'G.657A2', 'A-N9270A-72F-70', NULL, 'oct 30, 2017 12:00:00 AM', NULL, NULL, NULL, NULL);
INSERT INTO schema_name."t_refcable" ("rc_code", "rc_rf_code", "rc_etat", "rc_capafo", "rc_modulo", "rc_diam", "rc_typpose", "rc_portee", "rc_norm", "rc_rfcomac", "rc_ancref", "rc_creadat", "rc_majdate", "rc_majsrc", "rc_abddate", "rc_abdsrc") VALUES ('RC000000000059', 'RF000000000049', 'A', '96', '12', '11.3', 'M', '70', 'G.657A2', 'A-N9271A-96F-70', NULL, 'oct 30, 2017 12:00:00 AM', NULL, NULL, NULL, NULL);
INSERT INTO schema_name."t_refcable" ("rc_code", "rc_rf_code", "rc_etat", "rc_capafo", "rc_modulo", "rc_diam", "rc_typpose", "rc_portee", "rc_norm", "rc_rfcomac", "rc_ancref", "rc_creadat", "rc_majdate", "rc_majsrc", "rc_abddate", "rc_abdsrc") VALUES ('RC000000000060', 'RF000000000050', 'A', '144', '12', '11.3', 'M', '70', 'G.657A2', 'A-N9272A-144F-70', NULL, 'oct 30, 2017 12:00:00 AM', NULL, NULL, NULL, NULL);
INSERT INTO schema_name."t_refcable" ("rc_code", "rc_rf_code", "rc_etat", "rc_capafo", "rc_modulo", "rc_diam", "rc_typpose", "rc_portee", "rc_norm", "rc_rfcomac", "rc_ancref", "rc_creadat", "rc_majdate", "rc_majsrc", "rc_abddate", "rc_abdsrc") VALUES ('RC000000000061', 'RF000000000051', 'A', '288', '12', '14.6', 'M', '70', 'G.657A2', NULL, NULL, 'oct 30, 2017 12:00:00 AM', NULL, NULL, NULL, NULL);
INSERT INTO schema_name."t_refcable" ("rc_code", "rc_rf_code", "rc_etat", "rc_capafo", "rc_modulo", "rc_diam", "rc_typpose", "rc_portee", "rc_norm", "rc_rfcomac", "rc_ancref", "rc_creadat", "rc_majdate", "rc_majsrc", "rc_abddate", "rc_abdsrc") VALUES ('RC000000000063', 'RF000000000094', 'A', '36', '12', '7', 'M', '60', 'G.657A2', 'S917A36-36F-60', NULL, 'oct 30, 2017 12:00:00 AM', NULL, NULL, NULL, NULL);
INSERT INTO schema_name."t_refcable" ("rc_code", "rc_rf_code", "rc_etat", "rc_capafo", "rc_modulo", "rc_diam", "rc_typpose", "rc_portee", "rc_norm", "rc_rfcomac", "rc_ancref", "rc_creadat", "rc_majdate", "rc_majsrc", "rc_abddate", "rc_abdsrc") VALUES ('RC000000000064', 'RF000000000095', 'A', '36', '12', '8.3', 'M', '70', 'G.657A2', 'A-N8228A-36F-70', NULL, 'oct 30, 2017 12:00:00 AM', NULL, NULL, NULL, NULL);
INSERT INTO schema_name."t_refcable" ("rc_code", "rc_rf_code", "rc_etat", "rc_capafo", "rc_modulo", "rc_diam", "rc_typpose", "rc_portee", "rc_norm", "rc_rfcomac", "rc_ancref", "rc_creadat", "rc_majdate", "rc_majsrc", "rc_abddate", "rc_abdsrc") VALUES ('RC000000000065', 'RF000000000009', 'A', '24', '12', '8', 'C', NULL, 'G.657A2', NULL, 'TF103G', 'oct 30, 2017 12:00:00 AM', NULL, NULL, NULL, NULL);
INSERT INTO schema_name."t_refcable" ("rc_code", "rc_rf_code", "rc_etat", "rc_capafo", "rc_modulo", "rc_diam", "rc_typpose", "rc_portee", "rc_norm", "rc_rfcomac", "rc_ancref", "rc_creadat", "rc_majdate", "rc_majsrc", "rc_abddate", "rc_abdsrc") VALUES ('RC000000000066', 'RF000000000009', 'A', '36', '12', '8', 'C', NULL, 'G.657A2', NULL, 'TF103G', 'oct 30, 2017 12:00:00 AM', NULL, NULL, NULL, NULL);
INSERT INTO schema_name."t_refcable" ("rc_code", "rc_rf_code", "rc_etat", "rc_capafo", "rc_modulo", "rc_diam", "rc_typpose", "rc_portee", "rc_norm", "rc_rfcomac", "rc_ancref", "rc_creadat", "rc_majdate", "rc_majsrc", "rc_abddate", "rc_abdsrc") VALUES ('RC000000000067', 'RF000000000101', 'A', '96', '12', NULL, 'M', '50', 'G.657A2', NULL, NULL, 'juil 20, 2018 12:00:00 AM', NULL, NULL, NULL, NULL);
INSERT INTO schema_name."t_refcable" ("rc_code", "rc_rf_code", "rc_etat", "rc_capafo", "rc_modulo", "rc_diam", "rc_typpose", "rc_portee", "rc_norm", "rc_rfcomac", "rc_ancref", "rc_creadat", "rc_majdate", "rc_majsrc", "rc_abddate", "rc_abdsrc") VALUES ('RC000000000068', 'RF000000000102', 'A', '144', '12', NULL, 'M', '50', 'G.657A2', NULL, NULL, 'juil 20, 2018 12:00:00 AM', NULL, NULL, NULL, NULL);
INSERT INTO schema_name."t_refcable" ("rc_code", "rc_rf_code", "rc_etat", "rc_capafo", "rc_modulo", "rc_diam", "rc_typpose", "rc_portee", "rc_norm", "rc_rfcomac", "rc_ancref", "rc_creadat", "rc_majdate", "rc_majsrc", "rc_abddate", "rc_abdsrc") VALUES ('RC000000000069', 'RF000000000103', 'A', '288', '12', NULL, 'M', '50', 'G.657A2', NULL, NULL, 'juil 20, 2018 12:00:00 AM', NULL, NULL, NULL, NULL);
INSERT INTO schema_name."t_refcable" ("rc_code", "rc_rf_code", "rc_etat", "rc_capafo", "rc_modulo", "rc_diam", "rc_typpose", "rc_portee", "rc_norm", "rc_rfcomac", "rc_ancref", "rc_creadat", "rc_majdate", "rc_majsrc", "rc_abddate", "rc_abdsrc") VALUES ('RC000000000070', 'RF000000000104', 'A', '432', '12', NULL, 'M', '50', 'G.657A2', NULL, NULL, 'juil 20, 2018 12:00:00 AM', NULL, NULL, NULL, NULL);
INSERT INTO schema_name."t_refcable" ("rc_code", "rc_rf_code", "rc_etat", "rc_capafo", "rc_modulo", "rc_diam", "rc_typpose", "rc_portee", "rc_norm", "rc_rfcomac", "rc_ancref", "rc_creadat", "rc_majdate", "rc_majsrc", "rc_abddate", "rc_abdsrc") VALUES ('RC000000000071', 'RF000000000105', 'A', '720', '12', NULL, 'M', '50', 'G.657A2', NULL, NULL, 'juil 20, 2018 12:00:00 AM', NULL, NULL, NULL, NULL);
INSERT INTO schema_name."t_refcable" ("rc_code", "rc_rf_code", "rc_etat", "rc_capafo", "rc_modulo", "rc_diam", "rc_typpose", "rc_portee", "rc_norm", "rc_rfcomac", "rc_ancref", "rc_creadat", "rc_majdate", "rc_majsrc", "rc_abddate", "rc_abdsrc") VALUES ('RC000000000072', 'RF000000000106', 'A', '96', '12', '10.3', 'M', '50', 'G.657A2', NULL, NULL, 'juil 20, 2018 12:00:00 AM', NULL, NULL, NULL, NULL);
INSERT INTO schema_name."t_refcable" ("rc_code", "rc_rf_code", "rc_etat", "rc_capafo", "rc_modulo", "rc_diam", "rc_typpose", "rc_portee", "rc_norm", "rc_rfcomac", "rc_ancref", "rc_creadat", "rc_majdate", "rc_majsrc", "rc_abddate", "rc_abdsrc") VALUES ('RC000000000073', 'RF000000000107', 'A', '144', '12', '11.5', 'M', '45', 'G.657A2', NULL, NULL, 'juil 20, 2018 12:00:00 AM', NULL, NULL, NULL, NULL);
INSERT INTO schema_name."t_refcable" ("rc_code", "rc_rf_code", "rc_etat", "rc_capafo", "rc_modulo", "rc_diam", "rc_typpose", "rc_portee", "rc_norm", "rc_rfcomac", "rc_ancref", "rc_creadat", "rc_majdate", "rc_majsrc", "rc_abddate", "rc_abdsrc") VALUES ('RC000000000074', 'RF000000000108', 'A', '288', '12', '13', 'M', '35', 'G.657A2', NULL, NULL, 'juil 20, 2018 12:00:00 AM', NULL, NULL, NULL, NULL);
INSERT INTO schema_name."t_refcable" ("rc_code", "rc_rf_code", "rc_etat", "rc_capafo", "rc_modulo", "rc_diam", "rc_typpose", "rc_portee", "rc_norm", "rc_rfcomac", "rc_ancref", "rc_creadat", "rc_majdate", "rc_majsrc", "rc_abddate", "rc_abdsrc") VALUES ('RC000000000075', 'RF000000000109', 'A', '12', '12', '6', 'C', '55', 'G.657A2', NULL, NULL, 'juil 20, 2018 12:00:00 AM', NULL, NULL, NULL, NULL);
INSERT INTO schema_name."t_refcable" ("rc_code", "rc_rf_code", "rc_etat", "rc_capafo", "rc_modulo", "rc_diam", "rc_typpose", "rc_portee", "rc_norm", "rc_rfcomac", "rc_ancref", "rc_creadat", "rc_majdate", "rc_majsrc", "rc_abddate", "rc_abdsrc") VALUES ('RC000000000076', 'RF000000000110', 'A', '24', '12', '7.7', 'C', '55', 'G.657A2', NULL, NULL, 'juil 20, 2018 12:00:00 AM', NULL, NULL, NULL, NULL);
INSERT INTO schema_name."t_refcable" ("rc_code", "rc_rf_code", "rc_etat", "rc_capafo", "rc_modulo", "rc_diam", "rc_typpose", "rc_portee", "rc_norm", "rc_rfcomac", "rc_ancref", "rc_creadat", "rc_majdate", "rc_majsrc", "rc_abddate", "rc_abdsrc") VALUES ('RC000000000077', 'RF000000000111', 'A', '36', '12', '8.4', 'C', '55', 'G.657A2', NULL, NULL, 'juil 20, 2018 12:00:00 AM', NULL, NULL, NULL, NULL);
INSERT INTO schema_name."t_refcable" ("rc_code", "rc_rf_code", "rc_etat", "rc_capafo", "rc_modulo", "rc_diam", "rc_typpose", "rc_portee", "rc_norm", "rc_rfcomac", "rc_ancref", "rc_creadat", "rc_majdate", "rc_majsrc", "rc_abddate", "rc_abdsrc") VALUES ('RC000000000078', 'RF000000000112', 'A', '48', '12', '8.4', 'C', '55', 'G.657A2', NULL, NULL, 'juil 20, 2018 12:00:00 AM', NULL, NULL, NULL, NULL);
INSERT INTO schema_name."t_refcable" ("rc_code", "rc_rf_code", "rc_etat", "rc_capafo", "rc_modulo", "rc_diam", "rc_typpose", "rc_portee", "rc_norm", "rc_rfcomac", "rc_ancref", "rc_creadat", "rc_majdate", "rc_majsrc", "rc_abddate", "rc_abdsrc") VALUES ('RC000000000079', 'RF000000000113', 'A', '72', '12', '9', 'M', '55', 'G.657A2', NULL, NULL, 'juil 20, 2018 12:00:00 AM', NULL, NULL, NULL, NULL);
INSERT INTO schema_name."t_refcable" ("rc_code", "rc_rf_code", "rc_etat", "rc_capafo", "rc_modulo", "rc_diam", "rc_typpose", "rc_portee", "rc_norm", "rc_rfcomac", "rc_ancref", "rc_creadat", "rc_majdate", "rc_majsrc", "rc_abddate", "rc_abdsrc") VALUES ('RC000000000080', 'RF000000000114', 'A', '48', '12', NULL, 'C', NULL, 'G.652D', NULL, NULL, 'juil 20, 2018 12:00:00 AM', NULL, NULL, NULL, NULL);

-- Ajout attribut ADN
ALTER TABLE t_zdep ADD COLUMN IF NOT EXISTS zd_r5_code text;
--Drop table if exists "TRONCON_VOIE_FERREE_07-26";
--Drop table if exists "TRONCON_ROUTE_07-26";

-- FUNCTION pour Convertir les multilinesstring to linestring
DROP FUNCTION if exists convert_multlines_to_lines(text);
Create or replace Function convert_multlines_to_lines(var_schema_name text) Returns void as $$
    DECLARE
        -----Declaration des variables drop et create
        var_req_execute record;
    begin
			FOR var_req_execute in
					select
			'UPDATE '||f_table_name||' cl1 SET geom = ST_SetSRID(cl2.linemerge, 2154)
				from ('||
				'select '||'ST_LineMerge(ST_Force2D(geom)) as linemerge, *'||' from '||f_table_schema||'.'||f_table_name||' where ST_GeometryType(geom) != ''ST_LineString'''
				||') as cl2
			WHERE '||
			case
				when f_table_name = 't_cableline' then 'cl1.cl_code=cl2.cl_code'
				when f_table_name = 't_cheminement' then 'cl1.cm_code=cl2.cm_code'
			end as req_convert, f_table_name
					from geometry_columns
					where f_table_schema  = $1 and f_table_name  in ('t_cableline','t_cheminement')--,

					LOOP
							IF var_req_execute.req_convert is not null THEN
			EXECUTE var_req_execute.req_convert;
							END IF;
					END LOOP;
    end;
$$ language plpgsql;
select * from convert_multlines_to_lines('schema_name');

--Ajout des droit

--GRANT INSERT, SELECT ON TABLE vs_dep_znro TO adn_ing;
--GRANT ALL ON TABLE vs_dep_znro TO postgres;
--
--GRANT INSERT, SELECT ON TABLE vs_resopt_noeuds TO adn_ing;
--GRANT ALL ON TABLE vs_resopt_noeuds TO postgres;
--
--GRANT INSERT, SELECT ON TABLE vs_suf_majic TO adn_ing;
--GRANT ALL ON TABLE vs_suf_majic TO postgres;
--
--GRANT INSERT, SELECT ON TABLE vs_resopt_lienstransport TO adn_ing;
--GRANT ALL ON TABLE vs_resopt_lienstransport TO postgres;
--
--GRANT INSERT, SELECT ON TABLE vs_resopt_lienstransport TO adn_ing;
--GRANT ALL ON TABLE vs_resopt_lienstransport TO postgres;
--
--GRANT INSERT, SELECT ON TABLE vs_resopt_liens TO adn_ing;
--GRANT ALL ON TABLE vs_resopt_liens TO postgres;
--
--GRANT INSERT, SELECT ON TABLE troncon_voie_ferree TO adn_ing;
--GRANT ALL ON TABLE troncon_voie_ferree TO postgres;
--
--GRANT INSERT, SELECT ON TABLE troncon_route TO adn_ing;
--GRANT ALL ON TABLE troncon_route TO postgres;
--
--GRANT INSERT, SELECT ON TABLE vs_parcelles_znro TO adn_ing;
--GRANT ALL ON TABLE vs_parcelles_znro TO postgres;
--
--GRANT INSERT, SELECT ON TABLE t_refboite TO adn_ing;
--GRANT ALL ON TABLE t_refboite TO postgres;
--
--GRANT INSERT, SELECT ON TABLE t_refcable TO adn_ing;
--GRANT ALL ON TABLE t_refcable TO postgres;

GRANT SELECT, INSERT, Update ON ALL TABLES IN SCHEMA schema_name TO adn_ing;
ALTER DEFAULT PRIVILEGES IN SCHEMA schema_name GRANT SELECT, INSERT, UPDATE  ON TABLES TO adn_ing;


--GRANT ALL ON TABLE check_attribut_cles_etrangeres TO adn_ing;
--GRANT ALL ON TABLE check_attribut_duplique TO adn_ing;
--GRANT ALL ON TABLE check_attribut_not_null TO adn_ing;
--GRANT ALL ON TABLE check_attribut_moins TO adn_ing;
--GRANT ALL ON TABLE check_attribut_plus TO adn_ing;
--GRANT ALL ON TABLE check_table_manquante TO adn_ing;
--GRANT ALL ON TABLE check_erreur_statut_mcd TO adn_ing;

