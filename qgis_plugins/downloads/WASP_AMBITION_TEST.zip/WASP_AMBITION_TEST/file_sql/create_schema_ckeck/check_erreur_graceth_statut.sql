SET search_path TO gracethd, schemacheck, public;
---Partie pour recuperer le nom de la vue selon le statut detude
---DROP FUNCTION return_query_v_ct_anom_statut(text);
CREATE OR REPLACE FUNCTION return_query_v_ct_anom_statut(text) RETURNS table (ct_code text,ct_view text,attribut text,ct_def text[]) AS
$$

BEGIN

RETURN QUERY EXECUTE 

	'select * from (
		SELECT 
			ct_code::text,
			''v_ct_unit_''||ct_code as ct_view, 
			left(SUBSTRING (ct_code,1),2) as attribut,
			array_agg(ct_def::text) ct_def ---gracethd.delete_accent
		from '||$1||
		' where ct_code != ''dm_creadat_1_r00484'' and ct_code != ''cc_creadat_1_r00554'' 
		group by ct_code ) as t';

END;

$$ LANGUAGE plpgsql;


---Partie pour recuperer la requete dynamique selon le statut detude
CREATE OR REPLACE FUNCTION synt_erreur_statut_check(text)
 RETURNS TABLE(requete text) AS
$BODY$

with all_anom_metier_pro_ou_act as (

	select * from return_query_v_ct_anom_statut($1) ),---'v_ct_anom_8_rec', 
	
	join_anom as (
	select  * 
	from pg_views
		join all_anom_metier_pro_ou_act on viewname=all_anom_metier_pro_ou_act.ct_view),
	View_Synth_Anom as (
	select 
		'select'||
		' ct_code, '||
		quote_literal(replace(array_to_string(ARRAY[join_anom.ct_def], '.'),quote_literal(e'\''),''))||
		' as ct_def, '||
			case when attribut in ('mq','lv','rt') 
				then attribut ||'_id::text '
			else attribut ||'_code::text as ad_code ' end || 'from '||schemaname||'.'||viewname as requete 
	from join_anom 
	order by ct_def),
	
	res_requete as (
	select 
		requete ---as res---||' union all ' as res  ---into View_Synth_Anom 
	from View_Synth_Anom )

	select 
		requete
	from res_requete

$BODY$
  LANGUAGE sql VOLATILE;


---Partie pour la synthese des res en fonction du statut
CREATE OR REPLACE FUNCTION erreur_resCheck_statut(text,text) RETURNS void 
AS
$$
DECLARE

    -----Declaration du variable text
    qry varchar := '';
    -----Declaration du variable cursor
    row record;
    -----Declaration du variable cursor
    chemin_export text;
    ---Declaration du variable 
    query_pro text := $1;----select requete as ct_code from gracethd.synt_erreur_statut_check('v_ct_anom_8_rec')
BEGIN

	
    ---select genid_chemin_erreur_gracethd($2) into chemin_export;
    FOR row IN EXECUTE query_pro
		
    LOOP
	    IF length(qry) > 0 THEN
		  qry := qry|| ' UNION ALL ';
		END IF;
	    qry := qry || row.ct_code;
		 
    END LOOP;

	qry :=  'SELECT * FROM (' || qry || ') AS A ';
	---EXECUTE qry;
	IF FOUND THEN 
	RAISE NOTICE '%' , qry;
	---EXECUTE 'copy (' || qry || ' ) to '|| chemin_export;
	EXECUTE 'DROP TABLE IF EXISTS check_erreur_statut_mcd; CREATE TABLE check_erreur_statut_mcd as ' || qry ||'; CREATE INDEX inde_check_erreur_gracethd  ON check_erreur_statut_mcd  USING btree (ad_code COLLATE pg_catalog."default");';
	END IF;
	
END;
$$
LANGUAGE plpgsql;

---Execution de la fonction erreur_resCheck_statut pour les quatre statut
---select erreur_resCheck_statut('select requete as ct_code from synt_erreur_statut_check(''v_ct_anom_3_avp'')','erreur_gracethd_rec');