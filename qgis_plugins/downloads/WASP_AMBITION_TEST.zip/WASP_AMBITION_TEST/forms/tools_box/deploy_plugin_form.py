# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'Dialog_IMPORT_BDD2.ui'
#
# Created by: PyQt5 UI code generator 5.11.3
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets
import datetime
from pathlib import Path

folder_plugin = str(Path(__file__).parent.parent.parent)

class Ui_deploy_plugin_dialog(object):
	def setupUi(self, deploy_plugin_dialog):
		deploy_plugin_dialog.setObjectName("deploy_plugin_dialog")
		deploy_plugin_dialog.setWindowModality(QtCore.Qt.ApplicationModal)
		deploy_plugin_dialog.setEnabled(True)
		deploy_plugin_dialog.resize(800, 800)#1305, 882
		deploy_plugin_dialog.setMouseTracking(False)

		self.verticalLayoutWidget = QtWidgets.QWidget(deploy_plugin_dialog)
		self.verticalLayoutWidget.setGeometry(QtCore.QRect(30, 30, 700, 700))#1161, 731
		self.verticalLayoutWidget.setObjectName("verticalLayoutWidget")

		self.verticalLayout = QtWidgets.QVBoxLayout(self.verticalLayoutWidget)
		self.verticalLayout.setContentsMargins(0, 0, 0, 0)
		self.verticalLayout.setObjectName("verticalLayout")

		# self.gridLayout = QtWidgets.QGridLayout()
		# self.gridLayout.setObjectName("gridLayout")
		#
		# self.label_12 = QtWidgets.QLabel(self.verticalLayoutWidget)
		# self.label_12.setObjectName("label_12")
		# self.gridLayout.addWidget(self.label_12, 0, 0, 1, 1)
		#
		# self.name_pr = QgsCheckableComboBox(self.verticalLayoutWidget)
		# self.name_pr.setMinimumSize(QtCore.QSize(106, 0))
		# self.name_pr.setObjectName("name_pr")
		# self.gridLayout.addWidget(self.name_pr, 1, 0, 1, 1)
		#
		# self.verticalLayout.addLayout(self.gridLayout)

		self.textBrowser = QtWidgets.QTextBrowser(self.verticalLayoutWidget)
		self.textBrowser.setObjectName("textBrowser")
		self.verticalLayout.addWidget(self.textBrowser)

		self.button_box = QtWidgets.QDialogButtonBox(self.verticalLayoutWidget)
		self.button_box.setOrientation(QtCore.Qt.Horizontal)
		self.button_box.setStandardButtons(QtWidgets.QDialogButtonBox.Cancel|QtWidgets.QDialogButtonBox.Ok)
		self.button_box.setObjectName("button_box")
		self.verticalLayout.addWidget(self.button_box)

		self.retranslateUi(deploy_plugin_dialog)
		self.button_box.accepted.connect(deploy_plugin_dialog.accept)
		self.button_box.rejected.connect(deploy_plugin_dialog.reject)
		QtCore.QMetaObject.connectSlotsByName(deploy_plugin_dialog)

	def retranslateUi(self, deploy_plugin_dialog):
		_translate = QtCore.QCoreApplication.translate
		deploy_plugin_dialog.setWindowTitle(_translate("deploy_plugin_dialog", "DESIGN v0.01 - Deploiement des Plugins dans le server de Depot"))
		# self.label_12.setText(_translate("deploy_plugin_dialog", "Nom du pr"))
		self.textBrowser.setHtml(_translate("deploy_plugin_dialog", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
	"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
	"p, li { white-space: pre-wrap; }\n"
	"p { margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:8pt }\n"
	"</style></head><body style=\" font-family:\'MS Shell Dlg 2\'; font-size:8.25pt; font-weight:400; font-style:normal;\">\n"
	"<h2>Objectifs: </h2>\n"
	"<div >Ce plugin permet de deployer des Plugins dans le Depot de ATR.</div>\n"
	"<h2>Données en entrée: </h2>\n"
	"<div > L'utilisateur selectionne le zip du Plugin à déployer pour lequel il souhaite générer les vues. </div>\n"
	"<h2 >Résultat: </h2>\n"
	"<div> Un message à la fin montrant que le depot c'est bien passé. </div>\n"
	"</body></html>"))

from qgscheckablecombobox import QgsCheckableComboBox
from qgsdatetimeedit import QgsDateTimeEdit


import os.path
from qgis.core import *
from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5.QtWidgets import *

	
import psycopg2
import datetime
import importlib	
import sys

from ...scripts_python.tools_box.deploy_script import *


# ------------------------------------------------------------------------------
#    class_general_dialog - base class for WASP dialogs containing utility functions
# ------------------------------------------------------------------------------

class class_general_dialog(QtWidgets.QDialog):
	def __init__(self, iface):
		QtWidgets.QDialog.__init__(self)
		self.iface = iface
	def get_version_plugin(self):
		# folder_plugin = os.path.dirname(os.path.abspath(__file__))
		folder_metada  = open(folder_plugin + "\metadata.txt")#open(folder_plugin.replace("forms\design", "\metadata.txt"))
		for line in folder_metada :
			if str(line)[:7] == 'version':
				get_version = line.split('=')[1]
				return get_version
		folder_metada .close()


class class_deploy_plugin_dialog(class_general_dialog, Ui_deploy_plugin_dialog):
	def __init__(self, iface):
		class_general_dialog.__init__(self, iface)
		self.setupUi(self)
		self.button_box.button(QtWidgets.QDialogButtonBox.Ok).clicked.connect(self.run)
		self.setWindowTitle("Deploy Des Plugins_" + str(self.get_version_plugin()))

	def run(self):
		function_deploy_server(server_prod)
