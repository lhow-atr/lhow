# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'Dialog_IMPORT_BDD2.ui'
#
# Created by: PyQt5 UI code generator 5.11.3
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets
from qgis import gui
from pathlib import Path

folder_plugin = str(Path(__file__).parent.parent.parent)

class Ui_import_data_dialog(object):
	def setupUi(self, import_data_dialog):
		import_data_dialog.setObjectName("import_data_dialog")
		import_data_dialog.setWindowModality(QtCore.Qt.ApplicationModal)
		import_data_dialog.setEnabled(True)
		import_data_dialog.resize(800, 800)#1305, 882
		import_data_dialog.setMouseTracking(False)

		self.verticalLayoutWidget = QtWidgets.QWidget(import_data_dialog)
		self.verticalLayoutWidget.setGeometry(QtCore.QRect(30, 30, 700, 700))#1161, 731
		self.verticalLayoutWidget.setObjectName("verticalLayoutWidget")

		self.verticalLayout = QtWidgets.QVBoxLayout(self.verticalLayoutWidget)
		self.verticalLayout.setContentsMargins(0, 0, 0, 0)
		self.verticalLayout.setObjectName("verticalLayout")

		self.gridLayout = QtWidgets.QGridLayout()
		self.gridLayout.setObjectName("gridLayout")

		# self.label_12 = QtWidgets.QLabel(self.verticalLayoutWidget)
		# self.label_12.setObjectName("label_12")
		# self.gridLayout.addWidget(self.label_12, 0, 0, 1, 1)

		self.label_2 = QtWidgets.QLabel(self.verticalLayoutWidget)
		self.label_2.setObjectName("label_2")
		self.gridLayout.addWidget(self.label_2, 0, 0, 1, 1)

		self.label = QtWidgets.QLabel(self.verticalLayoutWidget)
		self.label.setObjectName("label")
		self.gridLayout.addWidget(self.label, 0, 1, 1, 1)

		# self.name_schema = QtWidgets.QLineEdit(self.verticalLayoutWidget)
		# self.name_schema.setMinimumSize(QtCore.QSize(111, 0))
		# self.name_schema.setObjectName("name_schema")
		# self.gridLayout.addWidget(self.name_schema, 1, 0, 1, 1)

		self.name_za = QtWidgets.QLineEdit(self.verticalLayoutWidget)
		self.name_za.setMinimumSize(QtCore.QSize(111, 0))
		self.name_za.setObjectName("name_za")
		self.gridLayout.addWidget(self.name_za, 1, 0, 1, 1)

		self.data_directory = gui.QgsFileWidget(import_data_dialog)
		self.data_directory.setObjectName("data_directory")
		self.gridLayout.addWidget(self.data_directory, 1, 1, 1, 1)

		self.verticalLayout.addLayout(self.gridLayout)

		self.textBrowser = QtWidgets.QTextBrowser(self.verticalLayoutWidget)
		self.textBrowser.setObjectName("textBrowser")
		self.verticalLayout.addWidget(self.textBrowser)

		self.button_box = QtWidgets.QDialogButtonBox(self.verticalLayoutWidget)
		self.button_box.setOrientation(QtCore.Qt.Horizontal)
		self.button_box.setStandardButtons(QtWidgets.QDialogButtonBox.Cancel|QtWidgets.QDialogButtonBox.Ok)
		self.button_box.setObjectName("button_box")
		self.verticalLayout.addWidget(self.button_box)

		self.retranslateUi(import_data_dialog)
		self.button_box.accepted.connect(import_data_dialog.accept)
		self.button_box.rejected.connect(import_data_dialog.reject)
		QtCore.QMetaObject.connectSlotsByName(import_data_dialog)

	def retranslateUi(self, import_data_dialog):
		_translate = QtCore.QCoreApplication.translate
		import_data_dialog.setWindowTitle(_translate("import_data_dialog", "Importation des données dans la BDD"))
		# self.label_12.setText(_translate("import_data_dialog", "Nom du Schema APS"))
		self.label_2.setText(_translate("import_data_dialog", "Nom de la Zone arriére"))
		self.label.setText(_translate("import_data_dialog", "Dossier des shapes"))
		# self.name_schema.setText(_translate("import_data_dialog", "aps"))
		self.name_za.setText(_translate("import_data_dialog", "nro_50119_00001"))
		self.textBrowser.setHtml(_translate("import_data_dialog", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
		"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
		"p, li { white-space: pre-wrap; }\n"
		"p { margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:8pt }\n"
		"</style></head><body style=\" font-family:\'MS Shell Dlg 2\'; font-size:8.25pt; font-weight:400; font-style:normal;\">\n"
		"<h2>Objectifs: </h2>\n"
		"<div > Ce module permet d'importer des données dans la BDD ainsi que de la creation de certaines tables</div>\n"
		"<h2>Données en entrée: </h2>\n"
		"<div > Les données d'entrée correspondent à des shapes que l'utilisateur est sensé de renseigner ainsi que le nom du schema et le nom de la zone arriére </div>\n"
		"<h2 >Résultat: </h2>\n"
		"<div> Les résultats correspondent à une création du schema  fournit par l'utilisateur et tous les shapes sont importés dans la BDD dans le schema dont le nom est fourni par l'utilisateur</div>\n"
		"<h2 >Contraintes: </h2>\n"
		"<div > Le nom de la zone arriére doit etre en 15 digit: 3 premiers digits qui correspondent au nom de la ZA, 5 digits pour le code insee et 5 digits pour l'incrémentation. Pour les deux digits qui restent, se sont des undercore (tiret du 8); l'un entre le nom de la ZA et l'autre entre le code insee et l'incrémentation</div>\n"
		"</body></html>"))


from ...scripts_python.axione_echange.import_data import *


class class_general_dialog(QtWidgets.QDialog):
	
	def __init__(self, iface):
		QtWidgets.QDialog.__init__(self)
		self.iface = iface
	
	def get_version_plugin(self):
		# folder_plugin = os.path.dirname(os.path.abspath(__file__))
		folder_metada  = open(folder_plugin + "\metadata.txt")#open(folder_plugin.replace("forms\delta", "\metadata.txt"))
		for line in folder_metada :
			if str(line)[:7] == 'version':
				get_version = line.split('=')[1]
				return get_version
		folder_metada .close()

class class_import_data_axione_dialog(class_general_dialog, Ui_import_data_dialog):
	def __init__(self, iface):
		class_general_dialog.__init__(self, iface)
		self.setupUi(self)
		self.button_box.button(QtWidgets.QDialogButtonBox.Ok).clicked.connect(self.run)
		self.setWindowTitle("Axione " + str(self.get_version_plugin()) + " - Importation des données")
		self.data_directory.setStorageMode(gui.QgsFileWidget.GetDirectory)

	def run(self):
		name_schema = 'aps' #  self.name_schema.text()
		name_za = self.name_za.text()
		name_data_directory = str(self.data_directory.filePath())
		if len(name_data_directory) == 0:
			QMessageBox.critical(self.iface.mainWindow(), "Message Du Choix", 'Veillez choisir le dossier contenant les shapes à importer')
		elif len(name_za) != 15:  # nro_50119_00001
			QMessageBox.critical(self.iface.mainWindow(), "Message Du Choix", 'Le nom de ZA doit etre sous ce format: nro_50119_00001')
		# elif len(name_schema) == 0:  # name schema
		# 	QMessageBox.critical(self.iface.mainWindow(), "Message Du Choix", 'Veillez choisir un nom de schema')
		else:
			function_execute_class_import_shape_csv_bdd(name_schema, name_za, name_data_directory)
