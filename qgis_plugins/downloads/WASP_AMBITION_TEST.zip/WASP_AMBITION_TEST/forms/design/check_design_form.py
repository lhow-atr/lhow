# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'Dialog_IMPORT_BDD2.ui'
#
# Created by: PyQt5 UI code generator 5.11.3
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets
import datetime
from pathlib import Path
from ...params_connexion import *

folder_plugin = str(Path(__file__).parent.parent.parent)

class Ui_check_design_dialog(object):
	def setupUi(self, check_design_dialog):
		check_design_dialog.setObjectName("check_design_dialog")
		check_design_dialog.setWindowModality(QtCore.Qt.ApplicationModal)
		check_design_dialog.setEnabled(True)
		check_design_dialog.resize(800, 800)#1305, 882
		check_design_dialog.setMouseTracking(False)

		self.verticalLayoutWidget = QtWidgets.QWidget(check_design_dialog)
		self.verticalLayoutWidget.setGeometry(QtCore.QRect(30, 30, 700, 700))#1161, 731
		self.verticalLayoutWidget.setObjectName("verticalLayoutWidget")

		self.verticalLayout = QtWidgets.QVBoxLayout(self.verticalLayoutWidget)
		self.verticalLayout.setContentsMargins(0, 0, 0, 0)
		self.verticalLayout.setObjectName("verticalLayout")

		self.gridLayout = QtWidgets.QGridLayout()
		self.gridLayout.setObjectName("gridLayout")

		self.label_12 = QtWidgets.QLabel(self.verticalLayoutWidget)
		self.label_12.setObjectName("label_12")
		self.gridLayout.addWidget(self.label_12, 0, 0, 1, 1)

		self.label_2 = QtWidgets.QLabel(self.verticalLayoutWidget)
		self.label_2.setObjectName("label_2")
		self.gridLayout.addWidget(self.label_2, 0, 1, 1, 1)

		# self.label = QtWidgets.QLabel(self.verticalLayoutWidget)
		# self.label.setObjectName("label")
		# self.gridLayout.addWidget(self.label, 0, 2, 1, 1)

		self.name_pr = QgsCheckableComboBox(self.verticalLayoutWidget)
		self.name_pr.setMinimumSize(QtCore.QSize(106, 0))
		self.name_pr.setObjectName("name_pr")
		self.gridLayout.addWidget(self.name_pr, 1, 0, 1, 1)

		self.name_statut = QgsCheckableComboBox(self.verticalLayoutWidget)
		self.name_statut.setMinimumSize(QtCore.QSize(106, 0))
		self.name_statut.setObjectName("name_statut")
		self.name_statut.addItem("")
		self.name_statut.addItem("")
		self.name_statut.addItem("")
		self.name_statut.addItem("")
		self.name_statut.addItem("")
		self.name_statut.addItem("")
		self.name_statut.addItem("")
		self.name_statut.addItem("")
		self.name_statut.addItem("")
		self.gridLayout.addWidget(self.name_statut, 1, 1, 1, 1)

		# self.name_titulaire = QgsCheckableComboBox(self.verticalLayoutWidget)
		# self.name_titulaire.setMinimumSize(QtCore.QSize(106, 0))
		# self.name_titulaire.setObjectName("name_titulaire")
		# self.name_titulaire.addItem("")
		# self.name_titulaire.addItem("")
		# self.name_titulaire.addItem("")
		# self.name_titulaire.addItem("")
		# self.name_titulaire.addItem("")
		# self.name_titulaire.addItem("")
		# self.name_titulaire.addItem("")
		# self.name_titulaire.addItem("")
		# self.name_titulaire.addItem("")
		# self.name_titulaire.addItem("")
		# self.name_titulaire.addItem("")
		# self.name_titulaire.addItem("")
		# self.name_titulaire.addItem("")
		# self.name_titulaire.addItem("")
		# self.gridLayout.addWidget(self.name_titulaire, 1, 2, 1, 1)		

		self.verticalLayout.addLayout(self.gridLayout)

		self.textBrowser = QtWidgets.QTextBrowser(self.verticalLayoutWidget)
		self.textBrowser.setObjectName("textBrowser")
		self.verticalLayout.addWidget(self.textBrowser)

		self.button_box = QtWidgets.QDialogButtonBox(self.verticalLayoutWidget)
		self.button_box.setOrientation(QtCore.Qt.Horizontal)
		self.button_box.setStandardButtons(QtWidgets.QDialogButtonBox.Cancel|QtWidgets.QDialogButtonBox.Ok)
		self.button_box.setObjectName("button_box")
		self.verticalLayout.addWidget(self.button_box)

		self.retranslateUi(check_design_dialog)
		self.button_box.accepted.connect(check_design_dialog.accept)
		self.button_box.rejected.connect(check_design_dialog.reject)
		QtCore.QMetaObject.connectSlotsByName(check_design_dialog)

	def retranslateUi(self, check_design_dialog):
		_translate = QtCore.QCoreApplication.translate
		check_design_dialog.setWindowTitle(_translate("check_design_dialog", "DESIGN v0.01 - Importation des donnees dans la BDD"))
		self.label_12.setText(_translate("check_design_dialog", "Nom du pr"))
		self.label_2.setText(_translate("check_design_dialog", "STATUT"))
		self.name_statut.setItemText(0, _translate("check_design_dialog", "AOR"))
		self.name_statut.setItemText(1, _translate("check_design_dialog", "DEO"))
		self.name_statut.setItemText(2, _translate("check_design_dialog", "DEP"))
		self.name_statut.setItemText(3, _translate("check_design_dialog", "DIU"))
		self.name_statut.setItemText(4, _translate("check_design_dialog", "DOE"))
		self.name_statut.setItemText(5, _translate("check_design_dialog", "DET"))
		self.name_statut.setItemText(6, _translate("check_design_dialog", "EXE"))
		self.name_statut.setItemText(7, _translate("check_design_dialog", "MCO"))
		self.name_statut.setItemText(8, _translate("check_design_dialog", "PRO"))
		# self.label.setText(_translate("check_design_dialog", "TITULAIRE"))
		# self.name_titulaire.setItemText(0, _translate("check_design_dialog", "ADTIM FTTH"))
		# self.name_titulaire.setItemText(1, _translate("check_design_dialog", "ADN"))
		# self.name_titulaire.setItemText(2, _translate("check_design_dialog", "AMO"))
		# self.name_titulaire.setItemText(3, _translate("check_design_dialog", "CSPS"))
		# self.name_titulaire.setItemText(4, _translate("check_design_dialog", "ATR"))
		# self.name_titulaire.setItemText(5, _translate("check_design_dialog", "EIFFAGE"))
		# self.name_titulaire.setItemText(6, _translate("check_design_dialog", "INEO"))
		# self.name_titulaire.setItemText(7, _translate("check_design_dialog", "SOBECA"))
		# self.name_titulaire.setItemText(8, _translate("check_design_dialog", "IMOPTEL"))
		# self.name_titulaire.setItemText(9, _translate("check_design_dialog", "SERFIM TIC"))
		# self.name_titulaire.setItemText(10, _translate("check_design_dialog", "AXIONE"))
		# self.name_titulaire.setItemText(11, _translate("check_design_dialog", "BETREC"))
		# self.name_titulaire.setItemText(12, _translate("check_design_dialog", "IBSE"))
		# self.name_titulaire.setItemText(13, _translate("check_design_dialog", "COORDINATION"))
		self.textBrowser.setHtml(_translate("check_design_dialog", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
	"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
	"p, li { white-space: pre-wrap; }\n"
	"p { margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:8pt }\n"
	"</style></head><body style=\" font-family:\'MS Shell Dlg 2\'; font-size:8.25pt; font-weight:400; font-style:normal;\">\n"
	"<h2>Objectifs: </h2>\n"
	"<div >Ce module permet de contrôler le DESIGN d'un livrable existant en base de données. </div>\n"
	"<h2>Données en entrée: </h2>\n"
	"<div > L’utilisateur sélectionne dans la liste déroulante le livrable qu'il souhaite contrôler sur les points suivants:</div>\n"
	"<div> D01 - Présence de cheminement en parallèle,</div>\n"
	"<div> D02 - Présence de cheminement sans câble,</div>\n"
	"<div> D03 - Cohérence des tracés de l’infrastructure mobilisée,</div>\n"
	"<div> D04 - Implantation des PBO (optimisation, géométrie des ZPBO),</div>\n"
	"<div> D05 - Limite de cinq branchements par boitiers optiques,</div>\n"
	"<div> D06 - Limite de trois branchements en parallèle sur une portée,</div>\n"
	"<div> D07 - Limite de six branchements hors nappe,</div>\n"
	"<div> D08 - Longueur des raccordements ( >100m, >200m, >500m ),</div>\n"
	"<div> D09 - Présence de SUF non raccordé </div>\n"
	"<h2 >Résultat: </h2>\n"
	"<div> La liste des erreurs est remontée, au format de la couche echange, dans la couche audit du schéma sélectionné. </div>\n"
	"<h2 >Contraintes: </h2>\n"
	"<div >La topologie du livrable doit être cohérente, les règles d'accrochage entre les objets doivent respectées.</div>\n"
	"</body></html>"))

from qgscheckablecombobox import QgsCheckableComboBox
from qgsdatetimeedit import QgsDateTimeEdit


import os.path
from qgis.core import *
from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5.QtWidgets import *

	
import psycopg2
import datetime
import importlib	
import sys

from ...scripts_python.design.control_design import *

# ------------------------------------------------------------------------------
#    class_general_dialog - base class for WASP dialogs containing utility functions
# ------------------------------------------------------------------------------


class class_general_dialog(QtWidgets.QDialog):
	def __init__(self, iface, var_connection):
		QtWidgets.QDialog.__init__(self)
		self.iface = iface
		self.connection = var_connection

	# Function pour executer une requete sql dans la base
	def function_execute_requete(self, requete_execute, req_fetch):
		curs=self.connection.cursor()
		try:
			curs.execute(requete_execute)
			if req_fetch:
				data_req=[row for row in curs.fetchall()]
				if data_req:
					return data_req
		except(Exception, psycopg2.DatabaseError) as error:
			QMessageBox.critical(self.iface.mainWindow(), "Message dexecution de requete", 'Requete Non Executer : '+str(error)+' ; '+str(requete_execute))
			# print("Message dexecution de requete", 'Requete Non Executer : '+str(error)+' ; '+str(requete_execute))
		curs.close()

	# Function pour supprimer les requetes en caches dans la BDD
	def function_close_requete_cache(self):
		requete = """--- Function pour supprimer les requetes en caches dans la BDD
			create or replace function delete_req_cache(bdd_name text) returns void as $$
				declare
					var_req_execute record;
				begin
				FOR var_req_execute in 
					select 
						*, 'select pg_terminate_backend('||pid||');' as req_cache
					from pg_stat_activity 
					where (state like '%idle in transaction%' or state like '%idle%') and application_name = '' and datname = $1 and client_addr = (select inet_client_addr()) and datname = $1 order by xact_start
					LOOP
						if var_req_execute.req_cache is not null then
							EXECUTE var_req_execute.req_cache;
						end if;

					END LOOP;
				end;
			$$ language plpgsql volatile;
			select * from delete_req_cache('MCD_ADN_sans_ct');"""
		self.function_execute_requete(requete, '', self.connection)

	def get_all_schema_name(self, list_widget):
		req_get_schema = """select 
			schema_name
		from information_schema.schemata
		where schema_name like 'pr%' order by schema_name;"""
		list_schema_name = self.function_execute_requete(req_get_schema, 'bab')
		for index, name_schema in enumerate(list_schema_name):
			if name_schema:
				list_widget.addItem("")
				list_widget.setItemText(index, name_schema[0])

	def get_version_plugin(self):
		# folder_plugin = str(Path(__file__).parent.parent.parent)#os.path.dirname(os.path.abspath(__file__))
		folder_metada  = open(folder_plugin + "\metadata.txt")#open(folder_plugin.replace("forms\design", "\metadata.txt"))
		for line in folder_metada :
			if str(line)[:7] == 'version':
				get_version = line.split('=')[1]
				return get_version
		folder_metada .close()


class class_checkdesignD0_dialog(class_general_dialog, Ui_check_design_dialog):
	def __init__(self, iface):
		self.var_connection = function_connexion()
		class_general_dialog.__init__(self, iface, self.var_connection)
		self.setupUi(self)
		self.get_all_schema_name(self.name_pr)
		self.setWindowTitle("DESIGN " + str(self.get_version_plugin()) + " - Contrôle du design D0..")
		self.var_connection.close()
		self.button_box.button(QtWidgets.QDialogButtonBox.Ok).clicked.connect(self.run)

	def run(self):
		list_statut = self.name_statut
		text_statut = [x for x in list_statut.currentText().split(',') if x]
		list_namePR = self.name_pr
		text_namePR = [x for x in list_namePR.currentText().split(',') if x]

		if len(text_statut) != 1 or len(text_namePR) != 1:
			QMessageBox.critical(self.iface.mainWindow(), "Message Du Choix", 'Veillez cocher un seul STATUT et un seul PR')
		else :
			nom_moe = 'MOE'#"".join(text_titulaire)
			nom_pr = "".join(text_namePR)
			nom_phase = str("".join(text_statut)).upper()
			schema = nom_pr
			# folder_plugin = os.path.dirname(os.path.abspath(__file__))
			var_file_echange = str(folder_plugin) + "/file_sql/create_modele_echange.sql"#str(folder_plugin).replace("forms\design", "/file_sql/create_modele_echange.sql")
			function_controle_design(schema,var_file_echange,nom_moe,nom_pr,nom_phase)
			# self.function_close_requete_cache()
