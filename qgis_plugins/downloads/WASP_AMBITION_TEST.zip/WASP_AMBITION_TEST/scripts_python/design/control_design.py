# Classse Generale
import processing, xlrd
from qgis.PyQt.QtCore import *
from qgis.PyQt.QtGui import *
from qgis.core import * 
from qgis.utils import *
from qgis.PyQt.QtWidgets import *
import datetime
import psycopg2
from shapely.geometry import Point, LineString, MultiPoint
from collections import defaultdict

from ...params_connexion import *


# Class pour les fonctions generales
class GeneralFunctions:
	w = QWidget()

	# Function pour la progession bar1
	def progress_bar(self, name_etape):
		prog = QProgressDialog(name_etape + ' : Veillez Patienter', 'Cancel', 0, 100)
		prog.setWindowModality(Qt.WindowModal)
		prog.setMinimumDuration(1)
		return prog

	# Function pour la progession bar2
	def progress_processing(self, index, count_entite, progress_dialog):
		f = int(index + 1)
		pcnt = int(f / count_entite * 100 / 1)
		progress_dialog.setValue(pcnt)

	# Function pour executer une requete sql dans la base
	def function_execute_requete(self, requete_execute, req_fetch, connection):
		curs = connection.cursor()
		try:
			curs.execute(requete_execute)
			if req_fetch:
				data_req = [row for row in curs.fetchall()]
				if data_req:
					return data_req
		except(Exception, psycopg2.DatabaseError) as error:
			QMessageBox.warning(self.w, "Message dexecution de requete",
								'Requete Non Executer : ' + str(error) + ' ; ' + str(requete_execute))
		curs.close()

	# Function pour  Get layer dans la BD
	def function_getlayer_bdd(self, schema, table_name, key, rename_table, column_geom):
		# import qgis.core
		global DB, user, MP, host, port
		uri = QgsDataSourceUri()
		uri.setConnection(host, port, DB, user, MP)
		uri.setDataSource(schema, table_name, column_geom, '', key)
		layer = QgsVectorLayer(uri.uri(False), rename_table, "postgres")
		if layer.isValid():
			# QgsProject.instance().addMapLayer(layer)
			return layer
		else:
			QMessageBox.warning(self.w, "Message", 'Erreur de recuperation de la table : ' + str(table_name))

	# Function Get layer dans Qgis
	def function_getlayer_qgis(self, layer_name):
		layers = [tree_layer.layer() for tree_layer in QgsProject.instance().layerTreeRoot().findLayers()]
		for layer in layers:
			layerType = layer.type()
			if layerType == QgsMapLayer.VectorLayer:
				if layer.name() == layer_name:
					return layer


# Class pour decoupe des lignes sans suppression de doublons de geometrie
class ClassDecoupLinePoints(GeneralFunctions):
	# Couper les lignes par rapport aux Points
	def cut_line_at_points(self, line, points):
		# First coords of line
		coords = list(line.coords)
		# Keep list coords where to cut (cuts = 1)
		cuts = [0] * len(coords)
		cuts[0] = 1
		cuts[-1] = 1
		# Add the coords from the points
		coords += [list(p.coords)[0] for p in points]
		cuts += [1] * len(points)
		# Calculate the distance along the line for each point
		dists = [line.project(Point(p)) for p in coords]
		# sort the coords/cuts based on the distances
		# see http://stackoverflow.com/questions/6618515/sorting-list-based-on-values-from-another-list
		coords = [p for (d, p) in sorted(zip(dists, coords))]
		cuts = [p for (d, p) in sorted(zip(dists, cuts))]
		# generate the Lines
		# lines = [LineString([coords[i], coords[i+1]]) for i in range(len(coords)-1)]
		lines = []
		for i in range(len(coords) - 1):
			if cuts[i] == 1:
				# find next element in cuts == 1 starting from index i + 1
				try:
					# print(cuts, ';', i + 1)
					if cuts[-1] != 0:
						j = cuts.index(1, i + 1)
						lines.append(LineString(coords[i:j + 1]))
				except(Exception) as error:
					QMessageBox.warning(self.w, "Message dexecution de requete", 'Erreur dexecution :' + str(error))
					break
		return lines

	# Convertir les geometries multiparts to single part
	def multipart_to_singlepart(self, geom):

		multiGeom = QgsGeometry()
		geometries = []

		if geom != NULL or geom.isGeosValid():
			if geom.type() == QgsWkbTypes.LineGeometry:
				if geom.isMultipart():
					multiGeom = geom.asMultiPolyline()
					for i in multiGeom:
						geometries.append(QgsGeometry().fromPolylineXY(i))
				else:
					geometries.append(geom)

		return geometries

	# Execution de la function de conversion des geometries multiparts to single part
	def function_multipart_to_singlepart(self, layer_cable):

		if layer_cable.isValid():
			multiline_to_sigleline = QgsVectorLayer("LineString?crs=epsg:2154", "multiline_to_sigleline", "memory")
			multiline_to_sigleline_pr2 = multiline_to_sigleline.dataProvider()
			multiline_to_sigleline_attr2 = layer_cable.dataProvider().fields().toList()
			multiline_to_sigleline_pr2.addAttributes(multiline_to_sigleline_attr2)

			for feature_cab in layer_cable.getFeatures():
				geom_cable = feature_cab.geometry()

				if geom_cable != NULL or geom_cable.isGeosValid():
					geometries = self.multipart_to_singlepart(geom_cable)

					outFeat = QgsFeature()
					attrs = feature_cab.attributes()
					outFeat.setAttributes(attrs)

					for g in geometries:
						outFeat.setGeometry(g)
						multiline_to_sigleline_pr2.addFeatures([outFeat])

			multiline_to_sigleline.updateFields()
			multiline_to_sigleline.commitChanges()

			return multiline_to_sigleline
		else:
			QMessageBox.warning(self.w, "function_multipart_to_singlepart", 'Layer invalide')

	# Creation de la ligne de decoupe
	def function_create_ligne_decoupe(self, layer_cable, layer_ptech):
		if layer_cable.isValid() and layer_ptech.isValid():
			layer_cable = self.function_multipart_to_singlepart(layer_cable)
			bar_progress = self.progress_bar(
				'Creation de la couche decoupe des lignes / Detection Origine/Extremite')
			# Creation des shapefles des erreurs
			Infra_Createe = QgsVectorLayer("LineString?crs=EPSG:2154", "Infra_Createe", "memory")
			Infra_Createe_pr = Infra_Createe.dataProvider()
			Infra_Createe.startEditing()
			Infra_Createe_pr.addAttributes([QgsField('NOM', QVariant.String),
											QgsField('LG_REELLE', QVariant.Double, 'double', 200, 2)])
			Infra_Createe.updateFields()
			Infra_Createe.commitChanges()
			count = 0
			# Creation dictionnary pour recuperer les points a decouper pour chaque ligne
			linestring_dict_points = defaultdict(list)

			# Creation Index des Points Techniques
			feature_dict_pt = {f.id(): f for f in layer_ptech.getFeatures()}
			index_ptech = QgsSpatialIndex()
			for current, f in enumerate(feature_dict_pt.values()):
				geom_point = f.geometry()
				if geom_point != NULL or geom_point.isGeosValid():
					index_ptech.insertFeature(f)

			# Len Features
			len_features_cable = len([feature for feature in layer_cable.getFeatures()])
			for index, feature_cab in enumerate(layer_cable.getFeatures()):
				# if feature_cab['cb_typelog'] != 'RA':
				geom_cable = feature_cab.geometry()
				if geom_cable != NULL or geom_cable.isGeosValid():
					candidates = index_ptech.intersects(geom_cable.boundingBox())
					if candidates:
						for candidate_id in candidates:
							attr_feature_dict_pt = feature_dict_pt[candidate_id]
							geomptech = attr_feature_dict_pt.geometry()
							# geomptech = geoms_ptech[candidate_id]
							geom_ptech_wkt2 = Point(geomptech.asPoint())
							if geomptech.within(geom_cable.buffer(0.1, 0.1)):
								linestring_dict_points[geom_cable].append(geom_ptech_wkt2)
				self.progress_processing(index, len_features_cable, bar_progress)
				if bar_progress.wasCanceled():
					iface.messageBar().pushMessage('Info', 'Action Cancelled', level=Qgis.Info)
					break
			# Creation du shape de decoupe des lignes
			list_result_cut_linest = []
			for index, (key, value) in enumerate(linestring_dict_points.items()):
				geom_cable_wkt2 = LineString(key.asPolyline())
				# print(geom_cable_wkt2)
				result_cut_linest = self.cut_line_at_points(geom_cable_wkt2, value)
				list_result_cut_linest.append(result_cut_linest)
				for index, cut_line in enumerate(result_cut_linest):
					geom_inf_decoupe = QgsGeometry.fromWkt(unicode(cut_line).replace('LINESTRING', 'LineString'))
					count += 1
					if geom_inf_decoupe != NULL or geom_inf_decoupe.isGeosValid():
						feat = QgsFeature()
						feat.setGeometry(geom_inf_decoupe)
						longueur = geom_inf_decoupe.length()
						if str(longueur) != '0.0':
							attrs = ['Ligne_' + unicode(count), longueur]
							feat.setAttributes(attrs)
							Infra_Createe_pr.addFeatures([feat])
				self.progress_processing(index, len(linestring_dict_points), bar_progress)
				if bar_progress.wasCanceled():
					iface.messageBar().pushMessage('Info', 'Action Cancelled', level=Qgis.Info)
					break

			Infra_Createe.commitChanges()
			Infra_Createe.updateExtents()
			# QgsProject.instance().addMapLayer(features_cable)
			return Infra_Createe
		else:
			QMessageBox.warning(self.w, "function_create_ligne_decoupe", 'Layer invalide')

	# Fonction pour renommer les entites selon le troncon de decoupage
	def function_renomme_entite_troncon(self, layer_troncon, layer_ptech):
		layer_decoup = self.function_create_ligne_decoupe(layer_troncon, layer_ptech)
		if layer_decoup.isValid() and layer_troncon.isValid():
			bar_progress = self.progress_bar('Recuperation des codes du decoup par rapport a leur troncon')
			indexe_nom = layer_decoup.fields().indexFromName('NOM')
			# Creation Index des Points Techniques
			feature_dict_layer_troncon = {f.id(): f for f in layer_troncon.getFeatures()}
			index_layer_troncon = QgsSpatialIndex()
			for current, f in enumerate(feature_dict_layer_troncon.values()):
				geom_point = f.geometry()
				if geom_point != NULL or geom_point.isGeosValid():
					index_layer_troncon.insertFeature(f)
			len_layer_decoup = layer_decoup.featureCount()
			layer_decoup.startEditing()
			for index, feature_cab in enumerate(layer_decoup.getFeatures()):
				geom_cable = feature_cab.geometry()
				if geom_cable != NULL or geom_cable.isGeosValid():
					candidates = index_layer_troncon.intersects(geom_cable.boundingBox())
					if candidates:
						for candidate_id in candidates:
							attr_feature_dict_pt = feature_dict_layer_troncon[candidate_id]
							geomlayer_troncon = attr_feature_dict_pt.geometry()
							if geom_cable.within(geomlayer_troncon.buffer(0.1, 0.1)):
								layer_decoup.changeAttributeValue(feature_cab.id(), indexe_nom,
																  attr_feature_dict_pt['cb_code'])
				self.progress_processing(index, len_layer_decoup, bar_progress)
				if bar_progress.wasCanceled():
					iface.messageBar().pushMessage('Info', 'Action Cancelled', level=Qgis.Info)
					break
			layer_decoup.commitChanges()
			# QgsProject.instance().addMapLayer(layer_decoup)
			return layer_decoup
		else:
			return QMessageBox.warning(self.w, "function_renomme_entite_troncon", 'Layer invalide')


# Class pour les cheminements sans cables et inversement
class ClassCheminementSansCableEtInversement(ClassDecoupLinePoints):
	def function_cm_sans_cb_and_cb_sans_cm(self, layer_cable_name, layer_cheminement_name, listing_erreor_control_ADN,
										   layer_ptech):
		layer_CM = layer_cheminement_name  # self.function_getlayer_bdd(schema, layer_cheminement_name, '', layer_cheminement_name, 'geom')
		layer_CL = self.function_renomme_entite_troncon(layer_cable_name, layer_ptech)
		# QgsProject.instance().addMapLayer(layer_CM)
		if layer_CM.isValid() and layer_CL.isValid():
			features_CM = layer_CM.getFeatures()
			features_CL = layer_CL.getFeatures()
			len_features_cm = len([feature for feature in layer_CM.getFeatures()])
			len_features_cl = len([feature for feature in layer_CL.getFeatures()])
			# Cheminement sans Cable
			message_chem = 'D02_1'  # 'Presence Cheminement sans Cable'
			bar_progress_1 = self.progress_bar('Identification de la ' + message_chem)
			geoms = {}
			index = QgsSpatialIndex()
			for current, f in enumerate(features_CL):
				geom_cl = f.geometry()
				if geom_cl != NULL or geom_cl.isGeosValid():
					geoms[f.id()] = geom_cl
					index.insertFeature(f)  # index.addFeature(f) insertFeature

			for feature_id, geometry in enumerate(features_CM):
				geom_cm = geometry.geometry()
				res_layer_1 = 'KO'
				if geom_cm != NULL or geom_cm.isGeosValid():
					candidates = index.intersects(geom_cm.boundingBox())
					if candidates:
						for candidate_id in candidates:
							geomCL = geoms[candidate_id]
							if geomCL != NULL or geomCL.isGeosValid():
								if geometry.geometry().within(geomCL.buffer(0.1, 0.1)):
									res_layer_1 = 'OK'
					if res_layer_1 == 'KO':
						listing_erreor_control_ADN.append(
							[geometry[0], geometry.geometry().buffer(0.5, 0.5), message_chem])
				self.progress_processing(feature_id, len_features_cm, bar_progress_1)
				if bar_progress_1.wasCanceled():
					iface.messageBar().pushMessage('Info', 'Action Cancelled', level=Qgis.Info)
					break

			# Cable sans Cheminement
			message_cb = 'D03_1'  # 'Presence Cable sans Cheminement'
			bar_progress_2 = self.progress_bar('Identification de la ' + message_cb)
			geoms_cb = {}
			index_cb = QgsSpatialIndex()
			features_CM = layer_CM.getFeatures()
			features_CL = layer_CL.getFeatures()
			for current, f in enumerate(features_CM):
				geom_cl = f.geometry()
				if geom_cl != NULL or geom_cl.isGeosValid():
					geoms_cb[f.id()] = geom_cl
					index_cb.insertFeature(f)

			for feature_id, geometry in enumerate(features_CL):
				geom_cm = geometry.geometry()
				res_layer_1 = 'KO'
				if geom_cm != NULL or geom_cm.isGeosValid():
					buffer_CL = geom_cm.buffer(0.1, 0.1)
					candidates = index_cb.intersects(geom_cm.boundingBox())
					if candidates:
						for candidate_id in candidates:
							geomCL = geoms_cb[candidate_id]
							if geomCL.within(buffer_CL):
								res_layer_1 = 'OK'
					if res_layer_1 == 'KO':
						listing_erreor_control_ADN.append(
							[geometry[0], geometry.geometry().buffer(0.5, 0.5), message_cb])
				self.progress_processing(feature_id, len_features_cl, bar_progress_2)
				if bar_progress_2.wasCanceled():
					iface.messageBar().pushMessage('Info', 'Action Cancelled', level=Qgis.Info)
					break

			# # Creation des shapefles des erreurs
			# cable_decoupe = QgsVectorLayer("Polygon?crs=EPSG:2154", "cable_decoupe", "memory")
			# cable_decoupe_pr = cable_decoupe.dataProvider()
			# cable_decoupe.startEditing()
			# cable_decoupe_pr.addAttributes([QgsField('NOM', QVariant.String), QgsField('Message', QVariant.String)])
			# cable_decoupe.updateFields()
			# cable_decoupe.commitChanges()
			#
			# feat = QgsFeature()
			# for i in listing_erreor_control_ADN:
			# 	feat.setGeometry(i[1])
			# 	attrs = [i[0], i[2]]
			# 	feat.setAttributes(attrs)
			# 	cable_decoupe_pr.addFeatures([feat])
			# cable_decoupe.commitChanges()
			# cable_decoupe.updateExtents()
			# QgsProject.instance().addMapLayer(cable_decoupe)
			return listing_erreor_control_ADN
		else:
			QMessageBox.warning(self.w, "Cable sans cheminement", 'Layer invalide')


# Function to controle design
def function_controle_design(schema, var_file_echange, var_MOE, var_PR, var_phase):
	global DB, user, MP, host, port
	# Declaration des tables a utiliser
	table_cheminement='t_cheminement'
	table_cable='t_cableline'
	table_zpbo='t_zpbo'
	table_zsro='t_zsro'
	table_suf='vs_elem_sf_nd'
	# PK pour views
	sf_PrimaryKey = 'sf_code'

	table_parcelles_znro='vs_parcelles_znro'
	Parcel_PrimaryKey = "id_par"
	attribut_parcel_public='pers_moral'
	list_parcel_public=('1','2','3','4','9')
	table_cableline='vs_elem_cl_cb'
	cb_PrimaryKey = "cb_code"
	attribut_cb_typelog='cb_typelog'
	attribut_cb_etiquet='cb_etiquet'
	attribut_zp_r4_code='zp_r4_code'
	attribut_sf_zp_code='sf_zp_code'
	attribut_zs_refpm='zs_refpm'
	entite_cbRac='RA'
	entite_cbRacCFI='CFI'
	prefix_BFI='BFI'
	prefix_CFI='CFI'

	var_aud='AUD'
	# var_MOE = 'ADN'
	# var_PR = 'pr_2_1_deo'
	# var_phase = 'EXE'
	var_type = 'AUD'

	w = QWidget()

	# Connexion a la base
	try:
		connection = psycopg2.connect(user=user,password=MP,host=host,port=port,database=DB)
	except(Exception, psycopg2.DatabaseError) as error:
		QMessageBox.warning(w, "Message de connexion de la base", 'Erreur de connexion de la base')

	# Function pour executer une requete sql dans la base
	def function_execute_requete(requete_execute, req_fetch, connection):
		curs = connection.cursor()
		try:
			curs.execute(requete_execute)
			if req_fetch:
				data_req=[row for row in curs.fetchall()]
				if data_req:
					return data_req
		except(Exception, psycopg2.DatabaseError) as error:
			QMessageBox.warning(w, "Message dexecution de requete", 'Requete Non Executer : '+str(error)+' ; '+str(requete_execute))
		curs.close()

	# Function Get file Sql
	def getFileContentSql(pathAndFileName, schema_name):
		with open(pathAndFileName, 'r') as theFile:
			# Return a list of lines (strings)
			# data = theFile.read().split('\n')
			
			# Return as string without line breaks
			# data = theFile.read().replace('\n', '')
			
			# Return as string
			data = theFile.read().replace('var_schema', schema_name)
			return data
			theFile.close() 

	# Execution des requetes sql pour la creation des tables echange et code erreur
	var_CreateTabEchangeCodeErreur = getFileContentSql(var_file_echange, schema)
	function_execute_requete(var_CreateTabEchangeCodeErreur, '', connection)
	# connection.commit()


	listing_erreor_control_ADN=[]
	now = datetime.datetime.now()
	nowdate = str(now.year) + '-' + str(now.month).zfill(2) + '-' + str(now.day).zfill(2)

	def function_getlayer_name(layer_name):
		layers = [tree_layer.layer() for tree_layer in QgsProject.instance().layerTreeRoot().findLayers()]
		for layer in layers:
			layerType = layer.type()
			if layerType == QgsMapLayer.VectorLayer:
				# print (layer.name())
				# layer_list.append(layer.name())
				if layer.name() == layer_name:
					return layer

	# Function pour la progession bar
	def progress_bar(name_etape):
		prog = QProgressDialog(name_etape + ' : Veillez Patienter', 'Cancel', 0, 100)
		prog.setWindowModality(Qt.WindowModal)
		prog.setMinimumDuration(1)
		return prog
		
	def progress_processing(index,count_entite,progress_dialog):
		f = int(index + 1)
		pcnt = int(f/count_entite * 100/1)
		progress_dialog.setValue(pcnt)

	# Function for return layer objet
	def function_return_layer(base_name, user_name, password, host_name ,port_name, schema_name, table_name, key):
		try:
			uri = QgsDataSourceUri()
			DB = base_name  # "MCD_ADN_sans_ct"
			user = user_name  # "adn_ing"
			MP = password  # "password"
			host = host_name  # "192.168.30.218"
			port = port_name  # "5432"
			schema = schema_name  # "pr_4_3_deo"
			uri.setConnection(host, port, DB, user, MP)
			uri.setDataSource(schema, table_name, "geom", '',  key)  # t_cheminement
			layer = QgsVectorLayer(uri.uri(False), table_name, "postgres")
			# QgsProject.instance().addMapLayer(layer)
			if layer.isValid():
				# QgsProject.instance().addMapLayer(layer)
				return layer
		except (Exception, psycopg2.DatabaseError) as error:
			QMessageBox.warning(w, "Message de connexion de la base", 'Erreur de connexion de la base')

	def function_append_duplicates_geometry(layer_chem, listing_erreor_control_ADN):
		message_chem = 'D01_1'  # 'Presence Cheminement en paralléle non justifié'
		# bar_progress = progress_bar('Identification des geometries dupliquees')
		layer_features=function_return_layer(DB,user,MP,host,port,schema,layer_chem,'')
		if layer_features.isValid():
			# function_return_layer(DB,user,MP,host,port,schema,layer_chem)#table ds BDD
			# function_getlayer_name(layer_chem)#Shape
			features = layer_features.getFeatures(QgsFeatureRequest().setSubsetOfAttributes([]))#
			geoms = dict()
			null_geom_features = set()
			index = QgsSpatialIndex()
			liste_avec_doublon_geometry=[]
			
			for current, f in enumerate(features):
				if not f.hasGeometry():
					null_geom_features.add(f.id())
					continue
				geoms[f.id()] = f.geometry()
				index.addFeature(f)

			unique_features = dict(geoms)
			count = 0
			for feature_id, geometry in geoms.items():
				# if feature_id not in unique_features:
					# continue
				candidates = index.intersects(geometry.boundingBox())
				candidates.remove(feature_id)
				for candidate_id in candidates:
					# if candidate_id not in unique_features:
						# continue
					count = count + 1
					if geometry.isGeosEqual(geoms[candidate_id]):
						listing_erreor_control_ADN.append([count, unique_features[candidate_id].buffer(0.5, 0.5), message_chem])
						# del unique_features[candidate_id]
		else:
			QMessageBox.warning(w, "Doublons de cheminement", 'Layer invalide')	

	def function_CM_sans_CB_and_CB_sans_CM(table_cableline, table_cheminement, listing_erreor_control_ADN):
		# global GeneralFunctions
		var_classcheminementsanscableetinversement = ClassCheminementSansCableEtInversement()
		features_cable = var_classcheminementsanscableetinversement.function_getlayer_bdd(schema, table_cableline, 'cb_code', table_cableline,
																'geom')
		features_cheminement = var_classcheminementsanscableetinversement.function_getlayer_bdd(schema, table_cheminement, '', table_cheminement,
																	  'geom')
		features_noeud = var_classcheminementsanscableetinversement.function_getlayer_bdd(schema, 't_noeud', '', 't_noeud', 'geom')
		# var_classcheminementsanscableetinversement = ClassCheminementSansCableEtInversement()
		var_classcheminementsanscableetinversement.function_cm_sans_cb_and_cb_sans_cm(features_cable,
																					  features_cheminement,
																					  listing_erreor_control_ADN,
																					  features_noeud)

	def function_zpbo_sup_7_suf(table_zpbo,table_suf,attribut_zp_r4_code,prefix_BFI):

		layer_zpbo = function_return_layer(DB, user, MP, host, port, schema, table_zpbo, '')
		layer_suf = function_return_layer(DB, user, MP, host, port, schema, table_suf, sf_PrimaryKey)

		if layer_zpbo.isValid() and layer_suf.isValid():
			features_zpbo = layer_zpbo.getFeatures()
			features_suf = layer_suf.getFeatures()
			message_suf_zpbo = 'D05_1'  # 'Presence de plus de 7 prises dans la ZPBO/PBO'
			bar_progress = progress_bar('Identification de la '+ message_suf_zpbo)
			len_features_zpbo = len([feature for feature in layer_zpbo.getFeatures()])
			geoms_suf = {}
			index_suf = QgsSpatialIndex()
			for current, f in enumerate(features_suf):
				geom_suf=f.geometry()
				if geom_suf != NULL or geom_suf.isGeosValid():
					if str(f['nd_r4_code'])[:3] != prefix_BFI:  # Sauf les prises dont nd_r4_code est different de CFI
						geoms_suf[f.id()] = geom_suf
						index_suf.insertFeature(f)  # index.addFeature(f) insertFeature

			for feature_id, geometry in enumerate(features_zpbo):
				geom_zpbo = geometry.geometry()
				# res_layer_1='KO'
				if geom_zpbo != NULL or geom_zpbo.isGeosValid():
					count_suf_zpbo = 0
					candidates = index_suf.intersects(geom_zpbo.boundingBox())
					if candidates:
						for candidate_id in candidates:
							geomSuf = geoms_suf[candidate_id]
							if geomSuf.within(geom_zpbo):
								count_suf_zpbo += 1
					# Sauf les BFI dans zp_r4_code
					if count_suf_zpbo > 7 and (str(geometry[attribut_zp_r4_code])[:3] != prefix_BFI):
						listing_erreor_control_ADN.append([geometry[0],geom_zpbo.buffer(0.5, 0.5), message_suf_zpbo])
				progress_processing(feature_id, len_features_zpbo, bar_progress)
				if bar_progress.wasCanceled():
					iface.messageBar().pushMessage('Info', 'Action Cancelled', level=Qgis.Info)
					break
		else:
			QMessageBox.warning(w, "ZPBO/PBO avec plus de 7 prises", 'Layer invalide')
					
	def function_longueur_cb_rac(layer_cable_name, layer_parc_name, attribut_parcel_public, list_parcel_public,
								 attribut_cb_typelog, entite_cbRac, attribut_cb_etiquet, entite_cbRacCFI):

		layer_CL = function_return_layer(DB, user, MP, host, port, schema, layer_cable_name, cb_PrimaryKey)
		layer_parcelles = function_return_layer(DB, user, MP, host, port, schema, layer_parc_name, Parcel_PrimaryKey)
		if layer_CL != None and layer_parcelles != None:
			if layer_CL.isValid() and layer_parcelles.isValid():
				# I.Presence de cables de raccordement en domaine publique dont la longueur est supperieur a 120m
				features_CL = layer_CL.getFeatures()  # QgsFeatureRequest().setSubsetOfAttributes([])
				features_parcelles = layer_parcelles.getFeatures()  # QgsFeatureRequest().setSubsetOfAttributes([])

				message_cbRac_sup_120 = 'D08_1'  # 'Presence de cables de raccordement en domaine publique dont la longueur est supperieur a 120m'
				message_cbRac_sup_300 = 'D08_3'  # 'Presence de cables de raccordement dont la longueur est supperieur a 300m'

				bar_progress_1 = progress_bar('Identification de la ' + message_cbRac_sup_120)
				len_features_CL = len([feature for feature in layer_CL.getFeatures()])

				geoms_parcel = {}
				index_parcel = QgsSpatialIndex()
				for current, f in enumerate(features_parcelles):
					if f[attribut_parcel_public] in list_parcel_public:
						geom_parcel = f.geometry()
						if geom_parcel != NULL or geom_parcel.isGeosValid():
							geoms_parcel[f.id()] = geom_parcel
							index_parcel.insertFeature(f)  # index.addFeature(f) insertFeature

				for feature_id, geometry in enumerate(features_CL):
					if geometry[attribut_cb_typelog] == entite_cbRac:
						geom_cbRac = geometry.geometry()
						res_layer_1 = 'KO'
						res_layer_length = 'OK'
						if geom_cbRac != NULL or geom_cbRac.isGeosValid():
							candidates = index_parcel.intersects(geom_cbRac.boundingBox())
							if candidates:
								for candidate_id in candidates:
									geomParcel = geoms_parcel[candidate_id]
									if geomParcel.intersects(geom_cbRac):
										geomParcelCbRac = geomParcel.intersection(geom_cbRac)
										if geomParcelCbRac.length() > 120:
											res_layer_1 = 'OK'
							if geom_cbRac.length() > 300:  # Cable de raccordement sup a 300
								res_layer_length = 'KO'
						if res_layer_1 == 'OK':
							listing_erreor_control_ADN.append([geometry[0], geom_cbRac.buffer(0.5, 0.5), message_cbRac_sup_120])
						if res_layer_length == 'KO':
							listing_erreor_control_ADN.append([geometry[0], geom_cbRac.buffer(0.5, 0.5), message_cbRac_sup_300])

					progress_processing(feature_id, len_features_CL, bar_progress_1)
					if bar_progress_1.wasCanceled():
						iface.messageBar().pushMessage('Info', 'Action Cancelled', level=Qgis.Info)
						break

				# II.Presence de cables fictif en domaine publique dont la longueur est supperieur a 120m
				features_CL = layer_CL.getFeatures()  # QgsFeatureRequest().setSubsetOfAttributes([])
				features_parcelles = layer_parcelles.getFeatures()  # QgsFeatureRequest().setSubsetOfAttributes([])

				message_cbFICT_sup_120 = 'D08_2'  # 'Presence de cables fictif en domaine publique dont la longueur est supperieur a 120m'
				bar_progress_2 = progress_bar('Identification de la '+ message_cbFICT_sup_120)
				len_features_CL = len([feature for feature in layer_CL.getFeatures()])
				geoms_parcel = {}
				index_parcel = QgsSpatialIndex()
				for current, f in enumerate(features_parcelles):
					if f[attribut_parcel_public] in list_parcel_public:
						geom_parcel = f.geometry()
						if geom_parcel != NULL or geom_parcel.isGeosValid():
							geoms_parcel[f.id()] = geom_parcel
							index_parcel.insertFeature(f)  # index.addFeature(f) insertFeature

				for feature_id, geometry in enumerate(features_CL):
					if geometry[attribut_cb_etiquet] != NULL and geometry[attribut_cb_etiquet][:3] == entite_cbRacCFI:
						geom_cbRac = geometry.geometry()
						res_layer_1 = 'KO'
						if geom_cbRac != NULL or geom_cbRac.isGeosValid():
							candidates = index_parcel.intersects(geom_cbRac.boundingBox())
							if candidates:
								for candidate_id in candidates:
									geomParcel = geoms_parcel[candidate_id]
									if geomParcel.intersects(geom_cbRac):
										geomParcelCbRac = geomParcel.intersection(geom_cbRac)
										if geomParcelCbRac.length() > 120:
											res_layer_1 = 'OK'
						if res_layer_1 == 'OK':
							listing_erreor_control_ADN.append([geometry[0], geom_cbRac.buffer(0.5, 0.5), message_cbFICT_sup_120])
					progress_processing(feature_id, len_features_CL, bar_progress_2)
					if bar_progress_2.wasCanceled():
						iface.messageBar().pushMessage('Info', 'Action Cancelled', level=Qgis.Info)
						break

			else:
				QMessageBox.warning(w, "Longueur cable Raccordement", 'Layer invalide')
		else:
			print(layer_CL, ';', layer_parcelles)
			QMessageBox.warning(w, "Longueur cable Raccordement", 'Pas de couche')
					
	def function_cable_racc_sans_suf_inversement(layer_cable_name,layer_parc_name, attribut_cb_typelog , entite_cbRac,
												 attribut_sf_zp_code, attribut_cb_etiquet, prefix_BFI, prefix_CFI):

		layer_CL = function_return_layer(DB, user, MP, host, port, schema, layer_cable_name, cb_PrimaryKey)
		layer_suf = function_return_layer(DB, user, MP, host, port, schema, layer_parc_name, sf_PrimaryKey)

		if layer_CL.isValid() and layer_suf.isValid():
			# I.Presence de cables de raccordement non raccorde a une prise
			features_CL = layer_CL.getFeatures()  # QgsFeatureRequest().setSubsetOfAttributes([])
			features_suf = layer_suf.getFeatures()  # QgsFeatureRequest().setSubsetOfAttributes([])

			message_cbRac_sans_suf = 'D09_2'  # 'Presence de cables de raccordement non raccorde a une prise'
			
			bar_progress_1 = progress_bar('Identification de la ' + message_cbRac_sans_suf)
			len_features_CL = len([feature for feature in features_CL])
			
			geoms_suf = {}
			index_suf = QgsSpatialIndex()
			for current, f in enumerate(features_suf):
				geom_suf = f.geometry()
				if geom_suf != NULL or geom_suf.isGeosValid():
					geoms_suf[f.id()] = geom_suf
					index_suf.insertFeature(f)
						
			for feature_id, geometry in enumerate(features_CL):
				
				if geometry[attribut_cb_typelog] == entite_cbRac:
					geom_cbRac = geometry.geometry()
					
					if geom_cbRac != NULL or geom_cbRac.isGeosValid():
						
						if geom_cbRac.wkbType() == QgsWkbTypes.MultiLineString:
							geom_cable_type = geom_cbRac.asMultiPolyline()
							cable_origine = geom_cable_type[0][0]
							support_extremite = geom_cable_type[-1][-1]
						
						if geom_cbRac.wkbType() == QgsWkbTypes.LineString:
							geom_cable_type = geom_cbRac.asPolyline()
							cable_origine = geom_cable_type[0]
							support_extremite = geom_cable_type[-1]
						
						cable_origine_point = (QgsGeometry.fromPointXY(QgsPointXY(cable_origine)))  # .asPoint()
						cable_extremite_point = (QgsGeometry.fromPointXY(QgsPointXY(support_extremite)))  # .asPoint()
						
						if geom_cbRac.wkbType() in [QgsWkbTypes.MultiLineString, QgsWkbTypes.LineString]:
						
							res_layer_1 = 'KO'
							candidates = index_suf.intersects(geom_cbRac.boundingBox())
							if candidates:
								for candidate_id in candidates:
									geomSuf = geoms_suf[candidate_id]
									if cable_extremite_point.intersects(geomSuf.buffer(0.1, 0.1)):
											res_layer_1 = 'OK'
									
							if res_layer_1 == 'KO' and str(geometry[attribut_cb_etiquet])[:3] != prefix_CFI:
								listing_erreor_control_ADN.append([geometry[0], geom_cbRac.buffer(0.5, 0.5), message_cbRac_sans_suf])
				progress_processing(feature_id,len_features_CL,bar_progress_1)
				if bar_progress_1.wasCanceled():
					iface.messageBar().pushMessage('Info', 'Action Cancelled', level=Qgis.Info)
					break
						
			# II.Presence de prises non raccorde a un cable de raccordement
			features_CL = layer_CL.getFeatures()  # QgsFeatureRequest().setSubsetOfAttributes([])
			features_suf = layer_suf.getFeatures()  # QgsFeatureRequest().setSubsetOfAttributes([])

			message_suf_sans_cbRac = 'D09_1'  # 'Presence de prises non raccorde a un cable de raccordement'
			bar_progress_2 = progress_bar('Identification de la '+ message_suf_sans_cbRac)
			len_features_suf = len([feature for feature in layer_suf.getFeatures()])
			geoms_cbRac = {}
			index_cbRac = QgsSpatialIndex()
			for current, f in enumerate(features_CL):
				geom_cbRac = f.geometry()
				if f[attribut_cb_typelog] == entite_cbRac or (f['cb_typelog'] == 'DI' and f['cb_etiquet'][:3] == prefix_CFI):
					if geom_cbRac != NULL or geom_cbRac.isGeosValid():
						geoms_cbRac[f.id()] = geom_cbRac
						index_cbRac.insertFeature(f)
						
			for feature_id, geometry in enumerate(features_suf):
				geom_suf = geometry.geometry()
				if geom_suf != NULL or geom_suf.isGeosValid():
					res_layer_1 = 'KO'
					candidates = index_cbRac.intersects(geom_suf.boundingBox())
					if candidates:
						for candidate_id in candidates:
							geom_cbRac = geoms_cbRac[candidate_id]
							if geom_cbRac.wkbType() == QgsWkbTypes.MultiLineString:
								geom_cable_type = geom_cbRac.asMultiPolyline()
								cable_origine = geom_cable_type[0][0]
								support_extremite = geom_cable_type[-1][-1]
							
							if geom_cbRac.wkbType() == QgsWkbTypes.LineString:
								geom_cable_type = geom_cbRac.asPolyline()
								cable_origine = geom_cable_type[0]
								support_extremite = geom_cable_type[-1]
							
							cable_origine_point = (QgsGeometry.fromPointXY(QgsPointXY(cable_origine)))
							cable_extremite_point = (QgsGeometry.fromPointXY(QgsPointXY(support_extremite)))
							
							if geom_cbRac.wkbType() in [QgsWkbTypes.MultiLineString, QgsWkbTypes.LineString]:
								if geom_suf.intersects(geom_cbRac.buffer(0.1,0.1)):
										res_layer_1 = 'OK'
		#                            if cable_origine_point.within(geomSuf.buffer(0.1,0.1)):
		#                                res_layer_1='OK'#Cable racco dessinder dans le mauvais sens mais ayant un suf
							
					if res_layer_1 == 'KO' and str(geometry['nd_r4_code'])[:3] != prefix_BFI:
						# print (geometry['sf_zp_code'],';', str(geometry['sf_zp_code'])[:3])
						listing_erreor_control_ADN.append([geometry[0], geom_suf.buffer(0.5, 0.5), message_suf_sans_cbRac])
				progress_processing(feature_id, len_features_suf, bar_progress_2)
				if bar_progress_2.wasCanceled():
					iface.messageBar().pushMessage('Info', 'Action Cancelled', level=Qgis.Info)
					break
		else:
			QMessageBox.warning(w, "Cable Raccordement sans prises et inversement", 'Layer invalide')

	def function_create_tab_shape_erreur_control_design(DB, user, MP, host, port, schema, table_zsro, attribut_zs_refpm,
														var_aud, var_MOE, var_PR, var_phase, var_type):
		# shape_erreur_control_design,pr_shape_erreur_control_design,

		name_pr_techange = str(var_PR).upper()[0:-15].replace('_', '-')

		bar_progress = progress_bar('Insertion des erreurs dans la base sur schema correspondant')
		len_features_error = len([feature for feature in listing_erreor_control_ADN])

		req_tab_code_erreur = """select * from """ + schema + """.t_code_erreur"""
		table_code_erreur = function_execute_requete(req_tab_code_erreur, 'bab', connection)

		# export Shapefile erreur de control des designs
		layer_zsro = function_return_layer(DB, user, MP, host, port, schema, table_zsro, '')
		# features_zsro = layer_zsro.getFeatures()
		geoms_zsro = {}
		index_zsro = QgsSpatialIndex()
		for current, f in enumerate(layer_zsro.getFeatures()):
			geom_zsro = f.geometry()
			if geom_zsro != NULL or geom_zsro.isGeosValid():
				geoms_zsro[f.id()] = geom_zsro
				index_zsro.insertFeature(f)

		count = 0
		for feature_id, geom in enumerate(listing_erreor_control_ADN):
			geom_error = geom[1]
			Name_PM = 'Pas de Zone SRO en Intersection ou bien lattribut zs_refpm du shapefile t_zsro est vide'
			id_zsro = '-1'
			id_comment = geom[2]
			id_categorie = geom[2]
			id_criticite = ''
			id_type = ''
			candidates = index_zsro.intersects(geom_error.boundingBox())
			id_cles = var_aud + '_' + var_MOE + '_' + unicode(count).zfill(6)
			id_code_entite = geom[0]
			if candidates:
				for candidate_id in candidates:
					geom_zsro = geoms_zsro[candidate_id]
					if geom_error.intersects(geom_zsro.buffer(0.1, 0.1)):
						id_zsro = candidate_id

			if id_zsro != '-1':
				for current, f in enumerate(layer_zsro.getFeatures()):
					if id_zsro == f.id():
						Name_PM = f[attribut_zs_refpm]

			for current_code_erreur, var_code_erreur in enumerate(table_code_erreur):
				if var_code_erreur[0] == geom[2]:  # Code egale column 2
					id_comment = var_code_erreur[3]  # Comment egale column 3
					id_categorie = var_code_erreur[2]  # Categorie egale column 1
					id_criticite = var_code_erreur[4]  # Criticite egale column 4
					id_type = var_code_erreur[1]  # Criticite egale column 4


			feat = QgsFeature()
			feat.setGeometry(geom[1])
			geome_text = geom[1].asWkt()
			# id_code=prefix_id_error+now+'_'+unicode(count).zfill(3)
			# id_comment=geom[1]
			# attrs=[id_code,id_comment,Name_PM]#,''
			# feat.setAttributes(attrs)
			# pr_shape_erreur_control_design.addFeatures([feat])#ST_GeomFromText((ST_Dump(geom)).geom)

			# requete_insert_tab="""INSERT INTO """+schema+"""."""+shape_erreur_control_design.name()+"""(
			# id, commentaire, zapm, geom) VALUES ('"""+id_code+"""','"""+ id_comment+"""', '"""+Name_PM+"""',
			# ST_GeomFromText(st_astext(ST_Geometryn(ST_GeomFromText('""" + geome_text + """',2154),1)),2154)"""+""");"""
			if geome_text != '':
				count += 1
				requete_insert_tab_echange = """INSERT INTO """ + schema + """.""" + """t_echange""" + """(
						cle, ident, localisation, num_sro, phase, type_rem, support, 
						id, com_init, date_cr, criticite, actions, 
						destinataire, prise_en_compte, valid_derog, com_rep, date_rep, 
						lien_inter_rem, geom)
						VALUES ('""" + str(id_cles) + """','""" + str(var_MOE) + """','""" + str(
					name_pr_techange) + """','""" + str(Name_PM) + """','""" + str(var_phase) + """','""" + str(
					id_type) + """','""" + str(id_categorie) + """', 
								'""" + str(id_code_entite) + """','""" + str(id_comment) + """','""" + str(
					nowdate) + """','""" + str(id_criticite) + """', null, 
								null,null,null,null,null, 
								null,""" + """ST_GeomFromText(st_astext(ST_Geometryn(ST_GeomFromText('""" + str(
					geome_text) + """',2154),1)),2154)""" + """);"""

				# Execution de linsertion de la table erreur_control
				function_execute_requete(requete_insert_tab_echange, '', connection)

			progress_processing(feature_id, len_features_error, bar_progress)
			if bar_progress.wasCanceled():
				iface.messageBar().pushMessage('Info', 'Action Cancelled', level=Qgis.Info)
				break
	try:
		function_append_duplicates_geometry(table_cheminement, listing_erreor_control_ADN)
		function_CM_sans_CB_and_CB_sans_CM(table_cableline, table_cheminement, listing_erreor_control_ADN)
		function_zpbo_sup_7_suf(table_zpbo, table_suf, attribut_zp_r4_code, prefix_BFI)
		function_longueur_cb_rac(table_cableline, table_parcelles_znro, attribut_parcel_public, list_parcel_public, attribut_cb_typelog, entite_cbRac, attribut_cb_etiquet, entite_cbRacCFI)
		function_cable_racc_sans_suf_inversement(table_cableline, table_suf, attribut_cb_typelog, entite_cbRac, attribut_sf_zp_code, attribut_cb_etiquet, prefix_BFI, prefix_CFI)
		function_create_tab_shape_erreur_control_design(DB, user, MP, host, port, schema, table_zsro, attribut_zs_refpm,
		var_aud, var_MOE, var_PR, var_phase, var_type)  # shape_erreur_control_design,pr_shape_erreur_control_design,
		connection.commit()
		connection.close()
	except(Exception) as error:
		connection.close()
		return QMessageBox.warning(w, "Message dexecution de requete", 'Erreur dexecution des controls:' + str(error))

	QMessageBox.information(w, "Message-Execution-Plugin", 'Contrôle du design réalisé avec succès')