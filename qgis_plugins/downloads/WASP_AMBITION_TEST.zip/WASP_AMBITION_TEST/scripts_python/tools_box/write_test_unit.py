# -*- coding: utf-8 -*-
# https://openclassrooms.com/fr/courses/235344-apprenez-a-programmer-en-python/2235416-creez-des-tests-unitaires-avec-unittest
# https://docs.python.org/fr/3/library/unittest.html
# https://openclassrooms.com/fr/courses/4568526-developpez-des-applications-robustes-et-fiables/4814730-decouvrez-l-importance-des-tests-unitaires?__cf_chl_jschl_tk__=8f5d15dc95d1935ed00dd9370824faaefedc3f3d-1605687097-0-AQ1hOqOS6NH-6KQSCxp_WqdWMg5RADG_FEtXrGzRmzNHsKLWzSgEN_ETaBxTox0syt_OyReXNpOiDOmxLKpJ7pFKRkCpVjMk6RHaZSSX2u219o0vqhISNUVcISK19iyo9XK_Cp0GR2QlhMKgoQN6ahTFjkZyjalaEQxrpJRe37MMCV9meVSq4l6alD7F6NpFeTpiu6Xj3nnY5cduV6kZkRkNDIBe0lhLCvq02Bin0nHoXzbKJDlgmgKvRIVwBZJNL0V5KwoyRRl7BuhHb9GI1Uor34tiZv5xY9fGMhmmNcJB-BP5UfOMlKnESx3t83H828Ayxb_Dcu8r0STG55NyzleP02QWMgmrIb3ktT4uV9DxVLMk7FnENT2soPRQI87k_Qq9PYkgX6An3rYTbTPEcHaUHo3Iqpw7rpQpAg4SPNUS7zJ0DDPfOS59KxwHOgi0uapH4LjKnOybaDx-YahkkCM
# Ecuritures des Tests Unitaires
import random
import unittest


class RandomTest(unittest.TestCase):
    """Test case utilisé pour tester les fonctions du module 'random'."""
    def test_choice(self):
        liste = list(range(10))
        elt = random.choice(liste)
        extrait = random.sample(liste, 11)
        for element in extrait:
            self.assertIn(element, liste)

    def test_upper(self):
        self.assertEqual('foo'.upper(), 'FOO')

    @unittest.skip("demonstrating skipping")
    def test_isupper(self):
        self.assertTrue('FOO'.isupper())
        self.assertFalse('FOO'.isupper(), 'doit etre True')

    def test_split(self):
        s = 'hello world'
        self.assertEqual(s.split(), ['hello', 'world'])
        # check that s.split fails when the separator is not a string
        with self.assertRaises(TypeError):
            s.split(2)


# if __name__ == '__main__':
#     unittest.main(verbosity=2)
