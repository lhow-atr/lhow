# -*- coding: utf-8 -*-
import csv
import os
import psycopg2
import psycopg2.extras
from osgeo import ogr, osr
import json
import ctypes
import logging


# Server Test
DB = 'bthd'
user = 'admambigroup'
MP = 'secure'
host = '192.168.30.195'
port = '5432'

# DB = "MCD_ADN_sans_ct"
# user = 'admambigroup'
# MP = 'secure'
# host = '192.168.30.195'
# port = '5432'


# Class pour importer des csv et shp dans BDD
class ImportMultiplesFilesCsvShp:
    # Function initialisation
    def __init__(self, var_connection, var_schema, var_folder_data):
        self.connection = var_connection
        self.schema = var_schema
        self.folder_data = var_folder_data
        self.db_cursor = self.connection.cursor()
        self.function_import_mutiples_files()  # Execution des imports a linitialisation de la classe

    # Function pour Importer des fichiers csv dans une BDD
    def function_insert_csv_bdd(self, var_file):
        try:
            with open(var_file) as f:
                reader_file = csv.reader(f, delimiter=';')
                header = next(reader_file)
                file_name = os.path.basename(f.name.split('.')[0])
                # Creation de la table
                list_column = [str(key).replace("'", '').replace('"', '') for key in ';'.join(header).split(';')]
                list_column_text = [str(key) + ' text' for key in list_column]
                req_create_table = f"DROP TABLE IF EXISTS {self.schema}.{file_name};" \
                                   f"CREATE TABLE {self.schema}.{file_name}({','.join(list_column_text)})"
                self.db_cursor.execute(req_create_table)
                # Insertion des elements dans la table creee
                list_all_feature_insert = []
                for index in reader_file:
                    list_tuple = tuple(index)
                    list_replace_carac = [str(key).replace("'", '').replace('"', '') for key in list_tuple]
                    values_features = str(tuple(list_replace_carac))
                    list_all_feature_insert.append(values_features)
                if list_all_feature_insert:
                    var_req_insert = f"INSERT INTO {self.schema}.{file_name}({','.join(header)})" \
                                     f"values{','.join(list_all_feature_insert)}"
                    self.db_cursor.execute(var_req_insert)
                # db_cursor.copy_from(f, var_schema + """.""" + file_name, sep=';')
                logging.info(f"Partie Import CSV: Le CSV {var_file} est bien importe dans le schema {self.schema}")
        except OSError:
            logging.critical(f"Partie Import SHP: Probleme Import SHP...Le CSV {var_file} nest pas importe...{OSError}")
            ctypes.windll.user32.MessageBoxW(0, f"Probleme dimport sur ce fichier {var_file}.\nErreur : {OSError}",
                                             "Title Message", 1)

    # Function pour Importer des fichiers shp dans une BDD
    def function_insert_shp_bdd(self, var_shp):
        try:
            file = ogr.Open(var_shp, 0)
            if file is None:
                logging.critical(f"Partie Import SHP: Probleme Import SHP...Le Shape {var_shp} ne peut pas etre ouvert")
                ctypes.windll.user32.MessageBoxW(0, f"Le Shape {var_shp} ne peut pas etre ouvert", "Title Message", 1)
            else:
                shape_feature = file.GetLayer(0)
                var_file_name = os.path.basename(file.GetName().split('.')[0])
                dict_convert_type_field = {'String': 'character varying', 'Date': 'text',
                                           'Integer': 'Integer', 'Real': 'real'}
                # Column_name et type
                list_column = []
                list_column_text = []
                for field in shape_feature.schema:
                    # print(field.name, ';', field.GetTypeName(), ';', field.GetType(), ';', field.GetWidth(), ';',
                    #       field.GetPrecision())
                    field_name = str(field.name)
                    field_type_name = str(dict_convert_type_field[field.GetTypeName()])
                    field_width = str(field.GetWidth())
                    if field.GetTypeName() == 'String':
                        field_name_prepare = f"{field_name} {field_type_name}({str(field_width)})"
                    else:
                        field_name_prepare = f"{field_name} {field_type_name}"
                    list_column.append(field_name)
                    list_column_text.append(field_name_prepare)
                # Ajout de la colonne geometry
                list_column.append('geom')
                list_column_text.append('geom geometry')
                # Creation de la table
                req_create_table = f"DROP TABLE IF EXISTS {self.schema}.{var_file_name};" \
                                   f"CREATE TABLE {self.schema}.{var_file_name}({','.join(list_column_text)})"
                # Execution de la creation de la table
                self.db_cursor.execute(req_create_table)
                # Parcours du shape plus prepapration des donnees a inserer
                list_all_feature_insert = []
                for n in range(shape_feature.GetFeatureCount()):
                    feature_shp = shape_feature.GetFeature(n)
                    feature_json = json.loads(feature_shp.ExportToJson())
                    geaom_feature = f"ST_GeomFromText('{str(feature_shp.geometry())}')"
                    list_values_attributs = list(feature_json['properties'].values())
                    list_appen_geom_feature = ['' if field is None else str(field).replace("'", '')
                                               for field in list_values_attributs]
                    list_appen_geom_feature.append(geaom_feature)
                    tuple_appen_geom_feature = str(tuple(list_appen_geom_feature)).replace('"', '')
                    list_all_feature_insert.append(tuple_appen_geom_feature)
                # Insertion des elements dans la table
                if list_all_feature_insert:
                    var_req_insert = f"INSERT INTO {self.schema}.{var_file_name}({','.join(list_column)}) " \
                                     f"values{','.join(list_all_feature_insert)}"
                    self.db_cursor.execute(var_req_insert)
                logging.info(f"Partie Import SHP: Le Shape {var_shp} est bien importe dans le schema {self.schema}")
        except OSError:
            logging.critical(f"Partie Import SHP: Probleme Import SHP...Le Shape {var_shp} nest pas importe"
                             f"...{OSError}")
            ctypes.windll.user32.MessageBoxW(0, f"Probleme dimport sur ce fichier {var_shp}.\nErreur : {OSError}",
                                             "Title Message", 1)

    # Function Execution en masse des Imports des fichiers CSV/SHP dans une BDD
    def function_import_mutiples_files(self):
        try:
            if self.folder_data:
                folder_iterate = os.listdir(self.folder_data)
                for index_char_qgis, file_etude in enumerate(folder_iterate):
                    chemin = self.folder_data
                    name, ext = os.path.splitext(file_etude)
                    # chem_etude = chemin + '/' + file_etude
                    chem_etude = f"{chemin}\{file_etude}"
                    if ext == ".shp":
                        self.function_insert_shp_bdd(chem_etude)
                    elif ext == ".csv":
                        self.function_insert_csv_bdd(chem_etude)
                    elif ext in (".dbf", ".cpg", ".prj", ".shx", ".log"):
                        continue
                    else:
                        logging.warning(f"Partie Import chaque table: Le fichier {name}_{ext} ne sera pas importe "
                                        f"puisse quil nest pas un csv ni un shape")
                        ctypes.windll.user32.MessageBoxW(0,
                                                         f"Le fichier {name}_{ext} ne sera pas importer "
                                                         f"puisse quil nest pas un csv ni un shape",
                                                         "Title Message", 1)
                logging.info(f"Partie Import en masse: {self.folder_data}")
                ctypes.windll.user32.MessageBoxW(0, f'Fin du Traitement, les donnees sont importees dans '
                                                    f'le schema suivant: {self.schema} et '
                                                    f'le fichier Log est exporte dans le repertoire suivant: '
                                                    f'{self.folder_data}', "Title Message", 1)

                self.connection.commit()
                self.db_cursor.close()
                self.connection.close()
            else:
                logging.critical(f"Partie Import en masse: Probleme choix repertoire des donnees...{self.folder_data}")
                ctypes.windll.user32.MessageBoxW(0, f'Le repertoire {self.folder_data} qui est choissi, est incorrect',
                                                 "Title Message", 1)
        except OSError:
            logging.critical(f"Partie Import en masse: Probleme dexecution des imports en masse...{OSError}")
            ctypes.windll.user32.MessageBoxW(0, f"Probleme dexecution des imports en masse.\nErreur : {OSError}",
                                             "Title Message", 1)


# Class pour exporter des tables csv et shp dans bdd
class ExportMultiplesTablesCsvShp:
    # Function initialisation
    def __init__(self, var_connection, var_schema, var_folder_export_data):
        global host, DB, user, MP
        self.connection = var_connection
        self.schema = var_schema
        self.conn_string = f"PG: host={host} dbname={DB} user={user} password={MP} ACTIVE_SCHEMA={self.schema}"
        self.folder_export_data = var_folder_export_data
        self.name_column_geom = 'geom'
        self.name_srid = 2154
        self.db_cursor = self.connection.cursor()
        self.function_export_mutiples_tables()

    # Function Export all tables bdd dynamic
    def function_export_mutiples_tables(self):
        try:
            req_dynamic_table = f"""set search_path to {self.schema}, public;
                SELECT 
                    table_schema, 
                    table_name,
                    geom_table.f_table_schema,
                    geom_table.f_table_name,
                    geom_table.f_geometry_column,
                    geom_table.type
                FROM information_schema.tables 
                    left join (
                        select * from geometry_columns WHERE f_table_schema='{self.schema}'
                        ) as geom_table on geom_table.f_table_name = table_name
                WHERE table_schema='{self.schema}';"""
            self.db_cursor.execute(req_dynamic_table)
            res_req_dynamic_table = self.db_cursor.fetchall()
            for index_row in range(len(res_req_dynamic_table)):
                var_row = res_req_dynamic_table[index_row]
                var_table_name = var_row[1]
                var_column_geom = var_row[4]
                if str(var_column_geom) != str(self.name_column_geom):  # Uniquement les csv
                    self.function_export_csv_bdd(var_table_name)
                elif str(var_column_geom) == str(self.name_column_geom):  # Uniquement les shp
                    self.function_create_shp_from_bdd(var_table_name)
                else:
                    logging.warning(f"Partie Export en masse: {var_table_name}....{var_row}")
                    ctypes.windll.user32.MessageBoxW(0, f'Le nom {var_column_geom} nest pas dans la condition',
                                                     "Title Message", 1)
            logging.info(f"Partie Export en masse: {res_req_dynamic_table}")
            ctypes.windll.user32.MessageBoxW(0, f"Fin du Traitement, les donnees et le fichier Log sont exportees "
                                                f"dans le repertoire suivant: {self.folder_export_data}",
                                             "Title Message", 1)
        except OSError:
            logging.critical(f"Partie Export en masse: Probleme dexecution des exports en masse...{OSError}")
            ctypes.windll.user32.MessageBoxW(0, f"Probleme dexecution des exports en masse.\nErreur : {OSError}",
                                             "Title Message", 1)

    # Function Export CSV from BDD
    def function_export_csv_bdd(self, name_table):
        try:
            var_sql = f"COPY (SELECT * FROM {self.schema}.{name_table}) TO STDOUT WITH HEADER CSV DELIMITER ';'"
            with open(f"{self.folder_export_data}/{name_table}.csv", 'w') as var_file:
                self.db_cursor.copy_expert(var_sql, var_file)
            logging.info(f"Partie Export CSV: {name_table}...{var_sql}")
        except OSError:
            logging.critical(f"Partie Export CSV: Probleme dexecution des exports CSV...{OSError}")
            ctypes.windll.user32.MessageBoxW(0, f"Probleme dexport sur cette table: {name_table}.\nErreur : {OSError}",
                                             "Title Message", 1)

    # Recuperation du type de geometry de la table pour pouvoir creer le shape
    def function_get_geometry_type_from_pg(self, table_pg):
        try:
            # return the GeometryType from a Pg Table
            query = f"SELECT ST_AsText({self.name_column_geom})  FROM {self.schema}.{table_pg}"
            self.db_cursor.execute(query)
            res = self.db_cursor.fetchone()
            if res is None:  # Les tables vides sont converties en Polygon
                geometrytype = ogr.Geometry(ogr.wkbPolygon).GetGeometryType()
            else:
                # geometrytype = ogr.CreateGeometryFromWkb(bytes(res[0])).GetGeometryType() # Avec ST_AsEWKB
                geometrytype = ogr.CreateGeometryFromWkt(res[0]).GetGeometryType()
            logging.info(f"Partie Recuperation Type Geometry: {table_pg}...{geometrytype}")
            return geometrytype
        except OSError:
            logging.critical(f"Partie Recuperation Type Geometry: Probleme Recuperation Type Geometry...{OSError}")
            ctypes.windll.user32.MessageBoxW(0, f"Probleme de recuperation de la geometrie sur cette table: {table_pg}"
                                                f".\nErreur : {OSError}", "Title Message", 1)

    # Function pour recuperer tous les attributs, leur type, leur longueur ainsi que leur precision
    def function_get_pg_layerfield_types(self, table_pg):
        try:
            # return a Dictionary with Pg table field name and Ogr feature
            conn = ogr.Open(self.conn_string)
            layer = conn.GetLayer(table_pg)
            if layer is None:
                ctypes.windll.user32.MessageBoxW(0, f'Erreur Lecture de la table {table_pg}', "Title Message", 1)
            else:
                lyr_feature = layer.GetLayerDefn()
                pgtable_fields = {}
                for i in range(lyr_feature.GetFieldCount()):
                    field_name = lyr_feature.GetFieldDefn(i).GetName()
                    field_type_code = lyr_feature.GetFieldDefn(i).GetType()
                    field_width = lyr_feature.GetFieldDefn(i).GetWidth()
                    get_precision = lyr_feature.GetFieldDefn(i).GetPrecision()
                    if field_type_code == 11:
                        field_type_code = 9
                    pgtable_fields[field_name] = field_type_code, field_width, get_precision
                conn.Destroy()
                logging.info(f"Partie Recuperation Fields: {pgtable_fields}")
                return pgtable_fields
        except OSError:
            logging.critical(f"Partie Recuperation Fields: Probleme Recuperation Fields...{OSError}")
            ctypes.windll.user32.MessageBoxW(0, f"Probleme de recuperation des attributs sur cette table: {table_pg}"
                                                f".\nErreur : {OSError}", "Title Message", 1)

    # Function Conversion de table en dictionnaire
    def function_get_table_asdict(self, table_pg):
        try:
            # return a Pg table as a Dictionary and transform Geometry to WKB
            # http://wiki.postgresql.org/wiki/Using_psycopg2_with_PostgreSQL
            # http://stackoverflow.com/questions/6739355/dictcursor-doesnt-seem-to-work-under-psycopg2
            cur = self.connection.cursor(cursor_factory=psycopg2.extras.RealDictCursor)
            query = f"SELECT *, ST_AsText ({self.name_column_geom}) as geom_wkb   FROM {self.schema}.{table_pg}"
            cur.execute(query)
            res = cur.fetchall()
            logging.info(f"Partie Conversion Entites vers Dictionnaire: {res}")
            return res
        except OSError:
            logging.critical(f"Partie Conversion Entites vers Dictionnaire: "
                             f"Probleme Conversion Entites vers Dictionnaire...{OSError}")
            ctypes.windll.user32.MessageBoxW(0, f"Probleme de recuperation des entites en DICT "
                                                f"sur cette table: {table_pg}.\nErreur : {OSError}", "Title Message", 1)

    # Function Export Shapefile from BDD
    # https://github.com/francot/python-ogr-postgis-tools/blob/master/export_import_postgis_shp.py
    def function_create_shp_from_bdd(self, name_table):
        try:
            # using the above function, return a shpfile from Pg table
            # set up the shapefile driver
            driver = ogr.GetDriverByName("ESRI Shapefile")
            # create the data source
            data_source = driver.CreateDataSource(f"{self.folder_export_data}/{name_table}.shp")
            # create the spatial reference
            srs = osr.SpatialReference()
            srs.ImportFromEPSG(self.name_srid)
            # create the layer
            layer = data_source.CreateLayer(name_table, srs, self.function_get_geometry_type_from_pg(name_table))
            # Add the fields taking dictionary output from GetPGLayerFieldTypes function
            dic_field_name = self.function_get_pg_layerfield_types(name_table)
            for key, vals in dic_field_name.items():
                field_name = ogr.FieldDefn(key[:10], vals[0])  # Normalise le nom de field qui depasse 10 digit
                field_name.SetWidth(vals[1])
                layer.CreateField(field_name)
            # Process the output dictionary from PgTableAsDict function and add features to the shapefile
            table_convert_dict = self.function_get_table_asdict(name_table)
            for pg_table_row in table_convert_dict:
                # create the feature
                feature = ogr.Feature(layer.GetLayerDefn())
                for f in pg_table_row.keys():
                    if f == self.name_column_geom:
                        continue
                    elif f == 'geom_wkb':
                        geometrytype = ogr.CreateGeometryFromWkt(pg_table_row[f])
                        # Set the geometry attributes
                        feature.SetGeometry(geometrytype)
                    else:
                        # Set the attributes
                        val_feature = pg_table_row[f]
                        if pg_table_row[f]:
                            val_feature = str(pg_table_row[f])[:253]  # Limiter les entites a 254 digit
                        feature.SetField(f[:10], val_feature)
                layer.CreateFeature(feature)
                feature.Destroy()
            # Destroy the data source to free resources
            data_source.Destroy()
            logging.info(f"Partie Conversion Entites vers Dictionnaire: {name_table}")
        except OSError:
            logging.critical(f"Partie Export du shp depuis BDD: Probleme Export du shp depuis BDD...{OSError}")
            ctypes.windll.user32.MessageBoxW(0, f"Probleme dexport du shp sur cette table: {name_table}."
                                                f"\nErreur : {OSError}", "Title Message", 1)


# Function execute class import ou export
def function_execute_import_export(var_schema, var_folder_data, var_type_execute):
    global host, DB, user, MP
    try:
        log_filename = f"{var_folder_data}\logfile.log"
        if os.path.exists(log_filename):
            os.remove(log_filename)
        else:
            log_filename = log_filename
        logging.basicConfig(filename=log_filename, level=logging.DEBUG,
                            format='%(asctime)s | %(levelname)s | %(message)s')
        # Connexion a la base
        connection = psycopg2.connect(user=user, password=MP, host=host, port=port, database=DB)
        if var_type_execute == 'import':
            ImportMultiplesFilesCsvShp(connection, var_schema, var_folder_data)
        elif var_type_execute == 'export':
            ExportMultiplesTablesCsvShp(connection, var_schema, var_folder_data)
        else:
            ctypes.windll.user32.MessageBoxW(0, f'Veillez choisir import ou export et non {var_type_execute}',
                                             "Title Message", 1)
    except(Exception, psycopg2.DatabaseError) as error:
        ctypes.windll.user32.MessageBoxW(0, f'Erreur de connexion de la base {error}', "Title Message", 1)


# var_schema = 'schema_test'  # schema_test  gracethd  pr_1_17_deo_v_20200819
# var_folder_data = r'V:\SIG\ORANGE-BTHD\BDD\transport\01109_DLG_V4'
# var_folder_export = r'C:\Users\babacar.fassa\Desktop\export_test'
# function_execute_import_export(var_schema, var_folder_export, 'export')  # OU 'import' ou 'export'
