# import paramiko
import os
import sys
from pathlib import Path
from qgis.PyQt.QtWidgets import *
from qgis.PyQt.QtCore import *

# folder_plugin = str(Path(__file__).parent.parent.parent)
# def load_libraries():
#     import_path = os.path.join(folder_plugin, folder_plugin + '/librairie')
#     sys.path.insert(0, import_path)
#     import paramiko
#     return paramiko
# paramiko = load_libraries()

try:
    import paramiko
except(Exception, ) as error:
    import subprocess
    subprocess.check_call(['pip', 'install', 'paramiko'])
    import paramiko

server_prod = {'hostname': '192.168.30.242',
               'port': 22,
               'username': 'root',
               'password': 'azerty123+'
               }
# server_test = {'hostname': '192.168.30.195',
#                'port': 22,
#                'username': 'root',
#                'password': 'Azerty123+'
#                }


def function_deploy_server(server):
    # global paramiko
    # Declaration de la variable pour les messages derreur
    w = QWidget()

    source = QFileDialog.getOpenFileName(None, "Selectionner le fichier zip ", "", "zip files (*.zip)")
    path_dest = r'/var/www/html/qgis_plugins/downloads'

    if source[0]:
        url = QUrl.fromLocalFile(source[0])
        name_zip = url.fileName()
        dest = path_dest + '/' + str(name_zip)
        try:
            t = paramiko.Transport((server['hostname'], server['port']))
            t.connect(username=server['username'], password=server['password'])
            sftp = paramiko.SFTPClient.from_transport(t)
            sftp.put(source[0], dest)
        except OSError as err:
            QMessageBox.information(w, "Message de Deploiement", str(err))
            t.close()
        QMessageBox.information(w, "Message de Deploiement", 'Deploiement Terminee')

# function_deploy_server(server_prod)
