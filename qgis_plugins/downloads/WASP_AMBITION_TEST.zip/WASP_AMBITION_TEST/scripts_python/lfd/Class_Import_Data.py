# -*- coding: utf-8 -*-
# import processing
import psycopg2
import xlwt
from qgis.PyQt.QtCore import *
from qgis.PyQt.QtGui import *
from qgis.core import *
from qgis.utils import *
from qgis.PyQt.QtWidgets import *
import os.path


# from ...bdd.lfd.params_connexion import *


# Class pour les fonctions generales
class GeneralFunctions:
    w = QWidget()

    # Function pour la progession bar1
    def progress_bar(self, name_etape):
        prog = QProgressDialog(name_etape + ' : Veillez Patienter', 'Cancel', 0, 100)
        prog.setWindowModality(Qt.WindowModal)
        prog.setMinimumDuration(1)
        return prog

    # Function pour la progession bar2
    def progress_processing(self, index, count_entite, progress_dialog):
        f = int(index + 1)
        pcnt = int(f / count_entite * 100 / 1)
        progress_dialog.setValue(pcnt)

    # Function pour executer une requete sql dans la base
    def function_execute_requete(self, requete_execute, req_fetch, connection):
        curs = connection.cursor()
        try:
            curs.execute(requete_execute)
            if req_fetch:
                data_req = [row for row in curs.fetchall()]
                if data_req:
                    return data_req
        except(Exception, psycopg2.DatabaseError) as error:
            connection.close()
            QMessageBox.warning(self.w, "Message dexecution de requete",
                                'Requete Non Executer : ' + str(error) + ' ; ' + str(requete_execute))
        curs.close()

    # Function pour  Get layer dans la BD
    def function_getLayer_bdd(self, schema, table_name, key, rename_table, column_geom):
        uri = QgsDataSourceUri()
        uri.setConnection(host, port, DB, user, MP)
        uri.setDataSource(schema, table_name, column_geom, '', key)
        layer = QgsVectorLayer(uri.uri(False), rename_table, "postgres")
        if layer.isValid():
            # QgsProject.instance().addMapLayer(layer)
            return layer
        else:
            QMessageBox.warning(self.w, "Message", 'Erreur de recuperation de la table : ' + str(table_name))

    # Function Get layer dans Qgis
    def function_getlayer_QGis(self, layer_name):
        layers = [tree_layer.layer() for tree_layer in QgsProject.instance().layerTreeRoot().findLayers()]  # Pyqgis3
        for layer in layers:
            layerType = layer.type()
            if layerType == QgsMapLayer.VectorLayer:
                if layer.name() == layer_name:
                    return layer

    # Function pour ajouter les tables dans leur groupe respectif
    def function_add_layer_group(self, layer_to_add):
        QgsProject.instance().addMapLayer(layer_to_add)

    # Function Suppression des donnees ajoutees dans QGis
    def functiondelete_layer_qgis(self):
        root = QgsProject.instance().mapLayers().values()
        for layer in root:
            QgsProject.instance().removeMapLayers([layer.id()])
        return True

    # Function Get file Sql
    def getFileContentSql(self, pathAndFileName):
        with open(pathAndFileName, 'r') as theFile:
            data = theFile.read()
            theFile.close()
            return data

    # Function pour ajouter des feuilles dans EXCEl
    def function_create_sheet(self, wb, sheet_name, list_user_export, header):
        # Execution de la bar
        bar_progress = self.progress_bar('Export des erreurs de Controls')
        ws_workbook = wb.add_sheet(sheet_name, cell_overwrite_ok=True)
        # print('Workbook', ';', ws_workbook)
        if list_user_export:
            for index_liste, k in enumerate(list_user_export):
                for colx, value in enumerate(k):
                    ws_workbook.write(index_liste + 1, colx, str(value))
                self.progress_processing(index_liste, len(list_user_export), bar_progress)
                if bar_progress.wasCanceled():
                    iface.messageBar().pushMessage('Info', 'Action Cancelled', level=Qgis.Info)
                    break
        colIdx = 0  # Start from Column 0
        font_style = xlwt.XFStyle()
        font_style.font.bold = True
        for indData in header:
            col = ws_workbook.col(colIdx)
            col.width = 256 * 20
            ws_workbook.write(0, colIdx, indData, font_style)  # Insert in First Row ( Row 0)
            colIdx = colIdx + 1

    # Function pour exporter les fichiers de mauavis format
    def function_export_error_fichier(self, var_folder_export_error_fichier, var_name_file, connection, var_schema):
        xlsfile_res = var_folder_export_error_fichier + "/" + var_name_file + ".xls"
        wb = xlwt.Workbook(encoding="UTF-8")
        requete = """select 
                    table_name,
                    'select * from '||max(table_schema)||'.'||'"'||table_name||'"' as req, 
                    array_agg(column_name::text) entete
                from information_schema.columns
                where table_schema = '""" + var_schema + """' and 
                (table_name like 'IG%' or table_name like 'OC%' or table_name like 'SI%' or table_name like 'TE%' or table_name like 'TR%') and 
                table_name not in ('TRONCON_ROUTE_07-26', 'TRONCON_VOIE_FERREE_07-26')
                group by table_name
                order by table_name
                        """
        res_execute_requete = self.function_execute_requete(requete, 'baba', connection)
        if res_execute_requete:
            for index_export in range(len(res_execute_requete)):
                value_feature = res_execute_requete[index_export]
                value_name_table = value_feature[0]
                value_req_execute = value_feature[1]
                value_entet = value_feature[2]
                valeu_export = self.function_execute_requete(value_req_execute, 'baba', connection)
                self.function_create_sheet(wb, str(value_name_table), valeu_export, value_entet)
            wb.save(xlsfile_res)


# Class pour Importer les donnees
class ImportShapeCSVBDD(GeneralFunctions):

    # Constructeur des variables qui change
    def __init__(self, var_connection):
        self.connection = var_connection
        # self.folder_data_shp = var_folder_data_shp
        # self.folder_data_csv = var_folder_data_csv
        self.list_name_file = ["Adresses_Optimum", "Calendrier", "Contours_PMZ", "Couverture_FTTH_Phase2",
                               "Extraction_MESC_ARCEP", "IMB_NRO", "Optimum", "PDD_Zone_PER_Phase2", "RBAL_Phase2",
                               "Raccordement", "ftth_cable", "ftth_pf", "ftth_site_immeuble",
                               "ftth_zone_eligibilite", "ipon"]

    # Function de chargement des layers dans Qgis
    def function_chargement_layer_qgis(self, folder_data):
        # folder_data = self.folder_data
        list_error_nommage_file = []
        bar_progress_char_qgis = self.progress_bar('Chargement des donnees dans Qgis')
        if folder_data:
            folder_iterate = os.listdir(folder_data)
            for index_char_qgis, file_etude in enumerate(folder_iterate):
                chemin = folder_data
                name, ext = os.path.splitext(file_etude)
                chem_etude = chemin + '/' + file_etude
                if name[9:] not in self.list_name_file:
                    list_error_nommage_file.append(file_etude)
                if ext in [".shp", ".csv"]:
                    layer_shp_etude = QgsVectorLayer(chem_etude, name, 'ogr')
                    try:
                        self.function_add_layer_group(layer_shp_etude)
                    except(Exception) as error:
                        return QMessageBox.warning(self.w, "Message dexecution de requete",
                                                   'Erreur dexecution du chargement du shape dans Qgis' + name)

                self.progress_processing(index_char_qgis, len(folder_iterate), bar_progress_char_qgis)
                if bar_progress_char_qgis.wasCanceled():
                    iface.messageBar().pushMessage('Info', 'Action Cancelled', level=Qgis.Info)
                    break
        return list_error_nommage_file

    # Function pour la creation des tables
    def function_create_table(self, table_name, schema_name, var_geom, var_extension):
        features = self.function_getlayer_QGis(table_name)
        table_name_rename = table_name[9:]
        list_fieldname = []
        for index_cm, field_name in enumerate(features.fields()):
            fielname = field_name.name().replace(' ', '_').replace("'", '') + ' text '
            list_fieldname.append(fielname)
        if var_geom:
            list_fieldname.append(var_geom + ' geometry')
        tuple_fieldname = ','.join(list_fieldname)
        req_create_table = 'CREATE TABLE IF NOT EXISTS ' + schema_name + '.' + '"' + var_extension + table_name_rename + '"' + '(' + tuple_fieldname + ')'  # .replace(' ','_').replace('-','_')
        req_drop_table = 'DROP TABLE IF EXISTS ' + schema_name + '.' + var_extension + '"' + table_name_rename + '"'  # .replace(' ','_').replace('-','_')# + '_input'
        return req_drop_table, req_create_table, tuple_fieldname

    # Function pour les insertions des donnees chargees dans Qgis dans la BDD
    def function_insert_data_qgis_bdd(self, var_schema_input, var_create_schema, var_rename_layer):
        list_insert_data = []
        # Execution de la bar
        bar_progress = self.progress_bar('Chargement des donnees dans Qgis, Creation du schema Input et Insertion')
        # Creation du Schema Ou seront importer les donnees
        if var_create_schema:
            create_schema_input = """DROP SCHEMA IF EXISTS """ + var_schema_input + """ CASCADE; CREATE SCHEMA """ + var_schema_input
            try:
                self.function_execute_requete(create_schema_input, '', self.connection)
            except(Exception) as error:
                return QMessageBox.warning(self.w, "Message dexecution de requete", 'Erreur dexecution :' + str(error))
        # Suppression des tables dans le schema si le schema nest pas a supprimer
        else:
            try:
                reque_drop_table = """select 'DROP TABLE IF EXISTS '|| table_schema ||'.' || quote_ident(table_name) as req 
                    from information_schema.tables where table_schema = '""" + var_schema_input + """'"""
                res_req_drop_table = self.function_execute_requete(reque_drop_table, 'res', self.connection)
                if res_req_drop_table:
                    for re in res_req_drop_table:
                        self.function_execute_requete(re[0], '', self.connection)
            except(Exception) as error:
                return QMessageBox.warning(self.w, "Message dexecution de requete",
                                           'Erreur dexecution suppression des tables: ' + str(error))

        len_maplayer = len(QgsProject.instance().mapLayers().values())
        list_table_create = []
        for index_map, layers_name_mapLayers in enumerate(QgsProject.instance().mapLayers().values()):
            layer_name = layers_name_mapLayers.name()  # [9:]
            layer_features = layers_name_mapLayers.getFeatures()
            list_table_create.append(layer_name)
            layer_type = layers_name_mapLayers.geometryType()  # 1=Ligne, 2=polygon, 0=Point, 4=Sans Geom

            # On ne cree et supprime que les couches chargees dans qgis
            # Tables avec Geometries
            if str(layer_type) != '4':
                try:
                    req_create_table = \
                    self.function_create_table(layer_name, var_schema_input, 'geom', var_rename_layer)[
                        1]  # Requete pour la creation des tables
                    self.function_execute_requete(req_create_table, '',
                                                  self.connection)  # Execution de la requete pour la creation des tables
                except(Exception) as error:
                    return QMessageBox.warning(self.w, "Message dexecution de requete",
                                               'Create des tables Non Executer' + layer_name)

            # Tables sans Geometrie
            elif str(layer_type) == '4':
                try:
                    req_create_table = self.function_create_table(layer_name, var_schema_input, '', var_rename_layer)[
                        1]  # Requete pour la creation des tables
                    self.function_execute_requete(req_create_table, '',
                                                  self.connection)  # Execution de la requete pour la creation des tables
                except(Exception) as error:
                    return QMessageBox.warning(self.w, "Message dexecution de requete",
                                               'Create des tables Non Executer' + layer_name)

            # Debut de limportations
            if layers_name_mapLayers.type() == QgsMapLayer.VectorLayer:  # and layer_name == 'Point_Network'
                layer_not_empty = len(list(layer_features))
                if layer_not_empty > 0:  # Ignorer linsertion des couches vides
                    layer_re_name = '"' + var_rename_layer + layer_name[9:] + '"'
                    list_fielname_sans_geom = \
                    self.function_create_table(layer_name, var_schema_input, '', var_rename_layer)[2].replace(' text ',
                                                                                                              '')
                    list_fielname_geom = \
                    self.function_create_table(layer_name, var_schema_input, 'geom', var_rename_layer)[2].replace(
                        ' text ', '').replace('geometry', '')
                    req_insert_prepare = 'INSERT INTO ' + var_schema_input + '.' + layer_re_name + '(' + list_fielname_geom + ') values'
                    req_insert_prepare_sans_geom = 'INSERT INTO ' + var_schema_input + '.' + layer_re_name + '(' + list_fielname_sans_geom + ') values'
                    list_insert_entite = []
                    layer_features = layers_name_mapLayers.getFeatures()
                    # print(layer_features, ';', layer_re_name)
                    insert_geom = ''
                    for index_layer, layer in enumerate(layer_features):
                        geome_text = layer.geometry().asWkt()
                        attr_insert = '-1'
                        replace_null_value = tuple(
                            [NULL if field in [NULL, '??'] else str(field).replace("'", '') for field in
                             layer.attributes()])
                        if geome_text:
                            insert_geom = 'geom'
                            attr_insert = replace_null_value + ("ST_GeomFromText('" + geome_text + "',2154)",)
                        if not geome_text:
                            insert_geom = 'sansgeom'
                            attr_insert = replace_null_value
                        list_insert_entite.append(attr_insert)
                    if insert_geom:
                        if insert_geom == 'geom':
                            req_insert_finale = req_insert_prepare + str(list_insert_entite).replace('[', '').replace(
                                ']', '').replace('"', '')
                            # list_insert_data.append(req_insert_finale)
                        elif insert_geom == 'sansgeom':
                            req_insert_finale = req_insert_prepare_sans_geom + str(list_insert_entite).replace('[',
                                                                                                               '').replace(
                                ']', '').replace('"', '')
                            # list_insert_data.append(req_insert_finale)
                        try:
                            self.function_execute_requete(req_insert_finale, '', self.connection)
                            # list_insert_data.append(req_insert_finale)
                            # print(req_insert_finale)
                        except(Exception) as error:
                            return QMessageBox.warning(self.w, "Message dexecution de requete",
                                                       'Requete Insertion des donnees Non Executer' + layer_name)
            self.progress_processing(index_map, len_maplayer, bar_progress)
            if bar_progress.wasCanceled():
                iface.messageBar().pushMessage('Info', 'Action Cancelled', level=Qgis.Info)
                break
        return True


# Class pour lexecution des functions SQL
class ExecuteFileSQL(GeneralFunctions):
    # Constructeur des variables qui change
    def __init__(self, var_connection, var_schema, var_file_sql_lfd):
        self.connection = var_connection
        self.name_schema = var_schema
        self.pathAndFileName = var_file_sql_lfd
        # r'C:\Users\babacar.fassa\Documents\GitHub\WASP_AMBITION\file_sql\lfd\requete_lfd.sql'
        # QFileDialog.getOpenFileName(None, "Selectionner le fichier SQL ", "", "SQL files (*.sql)")
        self.name_schema_in_requete_lfd_sql = 'var_lfd'

    # Function pour executer un file SQL
    def function_execute_sql(self):
        if self.pathAndFileName:  # [0]
            text_sql_file = self.getFileContentSql(self.pathAndFileName)  # [0]
            self.function_execute_requete(str(text_sql_file).replace(self.name_schema_in_requete_lfd_sql,
                                                                     self.name_schema), '', self.connection)


def function_execute_class_import_filesql(var_schema_name, var_sicreateschema, var_folder_export, var_file_sql_lfd,
                                          var_folder_data_shp, var_folder_data_csv):
    w = QWidget()
    connection = function_connexion()
    # Importation des donnees dans la BDD
    try:
        var_import_shape_csv_bdd = ImportShapeCSVBDD(connection)
        list_nommage_fichiers_autorises = var_import_shape_csv_bdd.list_name_file
        res_return_error_nommage_shp = var_import_shape_csv_bdd.function_chargement_layer_qgis(var_folder_data_shp)  # Import SHP
        res_return_error_nommage_csv = var_import_shape_csv_bdd.function_chargement_layer_qgis(var_folder_data_csv)  # Import CSV
        if not res_return_error_nommage_shp and not res_return_error_nommage_csv:
            # recup_folder_import = var_import_shape_csv_bdd.folder_data
            # 1 = nom_schema, 2 = SiCreateSchema, 3 = SiExtensionNomTable
            res_import_data_qgis = var_import_shape_csv_bdd.function_insert_data_qgis_bdd(var_schema_name,
                                                                                          var_sicreateschema, '')
            if res_import_data_qgis:
                delete_layer_qgis = var_import_shape_csv_bdd.functiondelete_layer_qgis()
                connection.commit()
                # if delete_layer_qgis:
                #     # Execution des fonctions SQL
                #     try:
                #         var_execute_file_sql = ExecuteFileSQL(connection, var_schema_name, var_file_sql_lfd)
                #         var_execute_file_sql.function_execute_sql()
                #         connection.commit()
                #         var_import_shape_csv_bdd.function_export_error_fichier(var_folder_export, 'export_res',
                #                                                                connection, var_schema_name)
                #     except(Exception, psycopg2.DatabaseError) as error:
                #         connection.close()
                #         return QMessageBox.warning(w, "Message de Traitement",
                #                                    'Erreur Execution des fonctions SQL: ' + str(error))
        else:
            var_import_shape_csv_bdd.functiondelete_layer_qgis()
            QMessageBox.warning(w, "Message dexecution de requete",
                        f"Le nommage de ces fichier: {str(','.join(res_return_error_nommage_shp))} "
                        f"{str(','.join(res_return_error_nommage_csv))} nest pas dans la liste de ceux autorises, "
                        f"donc le traitement s'arrete")

    except(Exception, psycopg2.DatabaseError) as error:
        connection.close()
        return QMessageBox.warning(w, "Message de Traitement", 'Erreur Import des données: ' + str(error))

    # Fin traitement
    QMessageBox.information(w, "Message dexecution de requete", 'Création des résultats LFD réalisée avec succès')


# var_folder_data = QFileDialog.getExistingDirectory(None,
#                                    'Selection Repertoire ou se trouve les Shapes et les CSV de la Donnees GraceTHD')
# function_execute_class_import_filesql('lfd', '', var_folder_data)

server = {
    'test': {'DB': 'lfd_bdd', 'user': 'admambigroup', 'MP': 'secure', 'host': '192.168.30.195', 'port': '5432'},
    'prod': {'DB': 'lfd_bdd', 'user': 'admambigroup', 'MP': 'secure', 'host': '192.168.30.194', 'port': '5432'}
}

DB = server['test']['DB']
user = server['test']['user']
MP = server['test']['MP']
host = server['test']['host']
port = server['test']['port']


def function_connexion():
    # Parameter connexion base
    global DB, user, MP, host, port
    # Connexion a la base
    try:
        connection = psycopg2.connect(user=user, password=MP, host=host, port=port, database=DB)
        return connection
    except(Exception, psycopg2.DatabaseError) as error:
        QMessageBox.critical(iface.mainWindow(), "Message de connexion de la base",
                             'Erreur de connexion de la base' + str(error))


schema = 'baba_test_45_v_20201125'
folder_global = r'V:\SIG\ORANGE-LFD\AUD\MANZAT\v20201203'
var_file_sql_annexe = ''  # str(folder_plugin) + "/file_sql/lfd/requete_lfd.sql"
path_folder_shp = folder_global + '\csv'
path_folder_csv = folder_global + '\shp'
path_folder_export = folder_global
# function_execute_class_import_filesql(schema, schema, path_folder_export, var_file_sql_annexe,
#                                       path_folder_shp, path_folder_csv)
