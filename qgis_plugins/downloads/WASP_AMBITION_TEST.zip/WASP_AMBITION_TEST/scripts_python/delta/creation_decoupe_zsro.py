import processing,xlrd,psycopg2,sys,xlwt
from qgis.PyQt.QtCore import *
from qgis.PyQt.QtGui import *
from qgis.core import * 
from qgis.utils import *
from qgis.PyQt.QtWidgets import *
import time
from qgis.PyQt.QtXml import QDomDocument

from ...params_connexion_import import *

def function_decoupe_zsro_general(schema_depart,schema_decoupe,schema_arrive):
	#Declaration des Parameters de connexion de la base
	# DB = 'MCD_ADN_sans_ct'
	# user = 'postgres'
	# MP = 'postgres'#'postgres'
	# host ='192.168.30.218'
	# port ='5432'

	# DB = 'MCD_ADN_sans_ct'
	# user = 'adn_ing'
	# MP = 'password'
	# host = '192.168.30.194'
	# port = '5432'

	global DB, user, MP, host, port

	w=QWidget()

	#Connexion a la base
	try:
		connection = psycopg2.connect(user=user,password=MP,host=host,port=port,database=DB)
	except(Exception, psycopg2.DatabaseError) as error:
		QMessageBox.warning(w, "Message de connexion de la base", 'Erreur de connexion de la base')

	#Function pour la progession bar
	def progress_bar(name_etape):
		prog = QProgressDialog(name_etape + ' : Veillez Patienter', 'Cancel', 0, 100)
		prog.setWindowModality(Qt.WindowModal)
		prog.setMinimumDuration(1)
		return prog

	def progress_processing(index,count_entite,progress_dialog):
		f = int(index + 1)
		pcnt = int(f/count_entite * 100/1)
		progress_dialog.setValue(pcnt)

	#Function pour executer une requete sql dans la base
	def function_execute_requete(requete_execute,req_fetch,connection):
		curs=connection.cursor()
		try:
			curs.execute(requete_execute)
			if req_fetch:
				data_req=[row for row in curs.fetchall()]
				if data_req:
					return data_req
		except(Exception, psycopg2.DatabaseError) as error:
			QMessageBox.warning(w, "Message dexecution de requete", 'Requete Non Executer : '+str(error)+' ; '+str(requete_execute))
		curs.close()

	def function_req_decoupe_zsro(schema_depart, schema_decoupe,schema_arrive):
		req_delta= """
		
			/*Creation de la function pour la creation du schema Decoupe_Depart*/
			Drop Schema if exists """+schema_decoupe+""" CASCADE ;
			Create Schema """+schema_decoupe+""";

			/*Creation de la function pour la creation de la requete dynamique pour la creation de la zsro*/
			DROP FUNCTION if exists """+schema_decoupe+""".create_zsro_decoupe_depart(text);
			Create or replace Function """+schema_decoupe+""".create_zsro_decoupe_depart(req_sch_dep text) 
				Returns table (sqlstmt_create text) as 
			$$
			begin Return Query execute
			'SELECT 
				''SELECT '' || array_to_string(ARRAY(SELECT ''o'' || ''.'' || c.column_name
					FROM information_schema.columns As c
						WHERE c.table_name = ''t_zsro'' 
						AND  c.column_name NOT IN(''geom'')
						and c.table_schema = '''||$1||'''
					), '','' ) || '',st_buffer(o.geom,0.2) as geom''|| '''||'''||
						'' FROM '||$1||'.'||'t_zsro As o'' As sqlstmt_create'; 
			End;
			$$ language plpgsql;

			/*Preapartion de la requete Execution pour la creation de la table t_zsro dans le schema de decoupe*/
			DROP FUNCTION if exists """+schema_decoupe+"""(text,text);
			CREATE OR REPLACE FUNCTION """+schema_decoupe+""".execute_create_zsro_decoupe_depart(sch_dep text, sch_decoupe_depart text) 
				RETURNS void 
			AS
			$$
			DECLARE
				-----Declaration des variables drop et create
				drop_table text;
				create_table text;
				
			BEGIN
				---Parcours de la table contenant les requetes a executer
				FOR 
				create_table 
					IN select 
						sqlstmt_create 
					from """+schema_decoupe+""".create_zsro_decoupe_depart($1)

				---Execution des requetes parcourus
				loop
					---RAISE NOTICE '%' , create_table;
					EXECUTE 'CREATE TABLE '||$2||'.'||'t_zsro as '||create_table ;
				end loop;
			END;
			$$
			LANGUAGE plpgsql;

			/* Creation de la function create_table_csv_decoup*/ 
			DROP FUNCTION if exists """+schema_decoupe+""".create_table_decoup(text, text);
			Create or replace Function """+schema_decoupe+""".create_table_decoup(sch_dep text, sch_decoupe_depart text) 
				Returns table (typee text, f_table_name text, req_create_tab text) as 
			$$
			DECLARE
				-----Declaration des variables drop et create
				name_table text;
				name_column text;
				type_geometry text;
			begin 

			type_geometry := 'case 
						when type = ''POINT''
							then ''st_within (sh_ar.geom, zs.geom)''
						when type = ''MULTIPOINT''
							then ''st_within (sh_ar.geom, zs.geom)''
						when type = ''POLYGON''
							then ''st_within (sh_ar.geom, zs.geom)''
						when type = ''MULTIPOLYGON''
							then ''st_within (sh_ar.geom, zs.geom)''
						when type = ''LINESTRING''
							then ''st_intersects (sh_ar.geom, zs.geom)''
						when type = ''MULTILINESTRING''
							then ''st_intersects (sh_ar.geom, zs.geom)''
					else ''st_within (sh_ar.geom, zs.geom)'' end';

			name_table:= 'case 
						when f_table_name =''vs_elem_ba_lt_st_nd''
							then ''t_baie''
						when f_table_name =''vs_elem_fo_cb_cl''
							then ''t_fibre''
						when f_table_name =''vs_elem_cl_cb''
							then ''t_cable''
						when f_table_name =''vs_elem_do_em''
							then ''t_document''
						when f_table_name =''vs_elem_eq_ba_lt_st_nd''
							then ''t_equipement''
						when f_table_name =''vs_elem_lv_nd''
							then ''t_love''
						when f_table_name =''vs_elem_lt_st_nd'' 
							then ''t_ltech''
						when f_table_name =''vs_elem_mq_nd''
							then ''t_masque''
						when f_table_name =''vs_elem_pt_nd''
							then ''t_ptech''
						when f_table_name =''vs_elem_rt_fo_cb_cl''
							then ''t_ropt''
						when f_table_name =''vs_elem_se_nd''
							then ''t_siteemission''
						when f_table_name =''vs_elem_st_nd''
							then ''t_sitetech''
						when f_table_name =''vs_elem_sf_nd''
							then ''t_suf''
						when f_table_name =''vs_elem_ti_ba_lt_st_nd''
							then ''t_tiroir''
						when f_table_name =''vs_elem_cs_bp_pt_nd''
							then ''t_cassette''
						when f_table_name =''vs_elem_cs_bp_lt_st_nd''
							then ''t_cassette''
						when f_table_name =''vs_elem_bp_pt_nd''
							then ''t_ebp''
						when f_table_name =''vs_elem_bp_sf_nd''
							then ''t_ebp''
						when f_table_name =''vs_elem_bp_lt_st_nd''
							then ''t_ebp''
					else f_table_name end';

			name_column:= 'case 
						when f_table_name =''vs_elem_ba_lt_st_nd''
							then ''ba_code = ba.ba_code''
						when f_table_name =''vs_elem_fo_cb_cl''
							then ''fo_code = ba.fo_code''
						when f_table_name =''vs_elem_cl_cb''
							then ''cb_code = ba.cb_code''
						when f_table_name =''vs_elem_do_em''
							then ''do_code = ba.do_code''
						when f_table_name =''vs_elem_eq_ba_lt_st_nd''
							then ''eq_code = ba.eq_code''
						when f_table_name =''vs_elem_lv_nd''
							then ''lv_id = ba.lv_id''
						when f_table_name =''vs_elem_lt_st_nd''
							then ''lt_code = ba.lt_code''
						when f_table_name =''vs_elem_mq_nd''
							then ''mq_id = ba.mq_id''
						when f_table_name =''vs_elem_pt_nd''
							then ''pt_code = ba.pt_code''
						when f_table_name =''vs_elem_rt_fo_cb_cl''
							then ''rt_id = ba.rt_id''
						when f_table_name =''vs_elem_se_nd''
							then ''se_code = ba.se_code''
						when f_table_name =''vs_elem_st_nd''
							then ''st_code = ba.st_code''
						when f_table_name =''vs_elem_sf_nd''
							then ''sf_code = ba.sf_code''
						when f_table_name =''vs_elem_ti_ba_lt_st_nd''
							then ''ti_code = ba.ti_code''
						when f_table_name =''vs_elem_cs_bp_pt_nd''
							then ''cs_code = ba.cs_code''
						when f_table_name =''vs_elem_cs_bp_lt_st_nd''
							then ''cs_code = ba.cs_code''
						when f_table_name =''vs_elem_bp_pt_nd''
							then ''bp_code = ba.bp_code''
						when f_table_name =''vs_elem_bp_sf_nd''
							then ''bp_code = ba.bp_code''
						when f_table_name =''vs_elem_bp_lt_st_nd''
							then ''bp_code = ba.bp_code''
					end';

			Return Query execute

			'SELECT 
				type::text as typee,f_table_name::text as f_table_name,
				case 
					when f_table_name in (''vs_elem_cs_bp_pt_nd'', ''vs_elem_cs_bp_lt_st_nd'', ''vs_elem_bp_pt_nd'', ''vs_elem_bp_sf_nd'', ''vs_elem_bp_lt_st_nd'')
						then 
							''insert into ''||'''||$2||'''||''.''||'||name_table||'||'' select ba.* from '||$1||'.''||
								'||name_table||'
								||'' ba join (''||

									'' select sh_ar.* from ''||f_table_schema||''.''||f_table_name||'' as sh_ar''||
									'' join ''||'''||$2||'''||''.t_zsro zs on ''||
										'||type_geometry||'||
								'')  decoup on decoup.''||
								'||name_column||'
					when f_table_name = ''vs_elem_cd_dm_cm''
						then
							''create table ''||'''||$2||'''||''.''||'||
							'case 
								when ''t_conduite''  = ''t_conduite'' 
									then ''t_conduite'' 
							end'||'||'' as select ba.* from ''||'''||$1||'''||''.''||
							'||
							'case 
								when ''t_conduite''  = ''t_conduite'' 
									then ''t_conduite'' 
							end'||'
							||'' ba join (''||

								'' select sh_ar.* from ''||f_table_schema||''.''||f_table_name||'' as sh_ar''||
								'' join ''||'''||$2||'''||''.t_zsro zs on ''||
									''st_within (sh_ar.geom, zs.geom)''||
							'')  decoup on decoup.''|| ''cd_code = ba.cd_code''
								
				else 
					''create table ''||'''||$2||'''||''.''||'||name_table||'
						||'' as ''||
					case 
						when (f_table_name like ''t_%'')
							then 
								''select sh_ar.* from ''||f_table_schema||''.''||f_table_name||'' as sh_ar''||
								'' join ''||'''||$2||'''||''.t_zsro zs on ''||
									'||type_geometry||'||'';''
						 when (f_table_name like ''vs_elem_%'')
							then 
								''select ba.* from '||$1||'.''||
								'||name_table||'
								||'' ba join (''||
							
									'' select sh_ar.* from ''||f_table_schema||''.''||f_table_name||'' as sh_ar''||
									'' join ''||'''||$2||'''||''.t_zsro zs on ''||
										'||type_geometry||'||
								'')  decoup on decoup.''||
								'||name_column||'
					end 
				end as req_create_tab
			FROM geometry_columns 
			WHERE f_table_schema = '''||$1||''' 
				AND (f_table_name like ''t_%'' and (f_table_name not in (''t_zsro'', ''t_znro'')) 
				or (f_table_name like ''vs_elem_%'' and f_table_name not in (''vs_elem_ba_lt_st_nd'',''vs_elem_lt_st_nd'',''vs_elem_st_nd'',''vs_elem_ti_ba_lt_st_nd''))) 
				and f_geometry_column = ''geom'' 
				order by f_table_name;
			'; 
			End;
			$$ language plpgsql;


			/*Preapartion de la requete Execution pour la creation de la table t_zsro dans le schema de decoupe*/
			DROP FUNCTION if exists """+schema_decoupe+""".execute_create_table_decoup(sch_dep text,sch_decoupe_depart text) ;
			CREATE OR REPLACE FUNCTION """+schema_decoupe+""".execute_create_table_decoup(sch_dep text,sch_decoupe_depart text) 
				RETURNS void 
			AS
			$$
			DECLARE
				-----Declaration des variables drop et create
				create_table text;
				create_table_generale text;
			BEGIN
			-- 	Partie pour la creation des tables non generales
				Execute 'drop table if exists '||$2||'.t_ebp;
				drop table if exists '||$2||'.t_cassette;
				create table '||$2||'.t_ebp as select * from '||$1||'.t_ebp;
				create table '||$2||'.t_cassette as select * from '||$1||'.t_cassette;
				truncate table '||$2||'.t_ebp; 
				truncate table '||$2||'.t_cassette';
				FOR 
				create_table 
					IN select 
						req_create_tab 
					from """+schema_decoupe+""".create_table_decoup($1, $2)
			-- 	Execution des requetes parcourus des tables non generales
				loop
			-- 	    RAISE NOTICE '%' , create_table;
					if create_table is not null then 
					EXECUTE create_table ;
					end if;
				end loop;
			-- 	Partie pour la creation des tables generales
				FOR 
				create_table_generale 
					IN select 
						'create table '||$2||'.'||table_name||' as select * from '||table_schema||'.'||table_name as req_table
					FROM information_schema.tables 
					WHERE table_schema  = ''||$1||''
						AND (table_name in ('t_znro', 't_position', 't_organisme', 't_reference', 't_baie', 't_ltech', 't_sitetech', 't_tiroir')) 
			-- 	Execution des requetes parcourus des tables generales
				loop
					-- RAISE NOTICE '%' , create_table;
					if create_table_generale is not null then 
					EXECUTE create_table_generale ;
					end if;
				end loop;
			-- 	Partie pour la creation de cond_chem
				Execute 'create table '||$2||'.t_cond_chem as 
				select cdc.* from '||$1||'.t_cond_chem cdc 
					join '||$2||'.t_conduite cd on cd.cd_code=cdc.dm_cd_code';
			-- 	Partie pour la creation de cab_cond
				Execute 'create table '||$2||'.t_cab_cond as 
				select cdc.* from '||$1||'.t_cab_cond cdc 
					join '||$2||'.t_conduite cd on cd.cd_code=cdc.cc_cd_code';
			END;
			$$
			LANGUAGE plpgsql;

			/* Execution de la function execute_create_zsro_decoupe_depart*/ 
			select * from """+schema_decoupe+""".execute_create_zsro_decoupe_depart('"""+schema_arrive+"""', '"""+schema_decoupe+"""');
			/* Execution de la function execute_create_table_csv_decoup*/ 
			select * from """+schema_decoupe+""".execute_create_table_decoup('"""+schema_depart+"""', '"""+schema_decoupe+"""')
		
			"""
		return req_delta
		
	def function_create_vues(schema_decoupe):
		req_create_vue = """
			SET search_path TO """+schema_decoupe+""",public;
			/*vs_elem_sf_nd*/
			DROP VIEW IF EXISTS "vs_elem_sf_nd";
			CREATE VIEW "vs_elem_sf_nd" AS
			SELECT 
			  * 
			FROM 
			  t_suf,
			  t_noeud
			WHERE 
			  t_suf.sf_nd_code = t_noeud.nd_code;

			  
			/*vs_elem_bp_sf_nd*/
			DROP VIEW IF EXISTS "vs_elem_bp_sf_nd";
			CREATE VIEW "vs_elem_bp_sf_nd" AS
			SELECT 
			  * 
			FROM 
			  t_ebp,
			  t_suf,
			  t_noeud
			WHERE 
			  t_ebp.bp_sf_code = t_suf.sf_code AND
			  t_suf.sf_nd_code = t_noeud.nd_code;

			  
			/*vs_elem_st_nd*/
			DROP VIEW IF EXISTS "vs_elem_st_nd";
			CREATE VIEW "vs_elem_st_nd" AS
			SELECT 
			  * 
			FROM 
			  t_sitetech,
			  t_noeud
			WHERE 
			  t_sitetech.st_nd_code = t_noeud.nd_code;

			  
			/*vs_elem_lt_st_nd*/
			DROP VIEW IF EXISTS "vs_elem_lt_st_nd";
			CREATE VIEW "vs_elem_lt_st_nd" AS
			SELECT 
			  * 
			FROM 
			  t_ltech,
			  t_sitetech,
			  t_noeud
			WHERE 
			  t_sitetech.st_nd_code = t_noeud.nd_code AND
			  t_ltech.lt_st_code = t_sitetech.st_code;
			  

			/*vs_elem_bp_lt_st_nd*/ 
			DROP VIEW IF EXISTS "vs_elem_bp_lt_st_nd";
			CREATE VIEW "vs_elem_bp_lt_st_nd" AS
			SELECT 
			  * 
			FROM 
			  t_ebp,
			  t_ltech,
			  t_sitetech,
			  t_noeud
			WHERE 
			  t_sitetech.st_nd_code = t_noeud.nd_code AND
			  t_ltech.lt_st_code = t_sitetech.st_code AND
			  t_ebp.bp_lt_code = t_ltech.lt_code;  

			/*vs_elem_cs_bp_lt_st_nd*/ 
			DROP VIEW IF EXISTS "vs_elem_cs_bp_lt_st_nd";
			CREATE VIEW "vs_elem_cs_bp_lt_st_nd" AS
			SELECT 
			  * 
			FROM 
			  t_cassette,
			  t_ebp,
			  t_ltech,
			  t_sitetech,
			  t_noeud
			WHERE 
			  t_sitetech.st_nd_code = t_noeud.nd_code AND
			  t_ltech.lt_st_code = t_sitetech.st_code AND
			  t_ebp.bp_lt_code = t_ltech.lt_code AND
			  t_cassette.cs_bp_code = t_ebp.bp_code
			  ;  
			  
			/*vs_elem_ba_lt_st_nd*/
			DROP VIEW IF EXISTS "vs_elem_ba_lt_st_nd";
			CREATE VIEW "vs_elem_ba_lt_st_nd" AS
			SELECT 
			  * 
			FROM 
			  t_baie,
			  t_ltech,
			  t_sitetech,
			  t_noeud
			WHERE 
			  t_sitetech.st_nd_code = t_noeud.nd_code AND
			  t_ltech.lt_st_code = t_sitetech.st_code AND
			  t_baie.ba_lt_code = t_ltech.lt_code;

			/*vs_elem_ti_ba_lt_st_nd*/
			DROP VIEW IF EXISTS "vs_elem_ti_ba_lt_st_nd";
			CREATE VIEW "vs_elem_ti_ba_lt_st_nd" AS
			SELECT 
			  * 
			FROM 
			  t_tiroir,
			  t_baie,
			  t_ltech,
			  t_sitetech,
			  t_noeud
			WHERE 
			  t_sitetech.st_nd_code = t_noeud.nd_code AND
			  t_ltech.lt_st_code = t_sitetech.st_code AND
			  t_baie.ba_lt_code = t_ltech.lt_code AND
			  t_tiroir.ti_ba_code = t_baie.ba_code;

			  
			/*vs_elem_eq_ba_lt_st_nd*/
			DROP VIEW IF EXISTS "vs_elem_eq_ba_lt_st_nd";
			CREATE VIEW "vs_elem_eq_ba_lt_st_nd" AS
			SELECT 
			  * 
			FROM 
			  t_equipement,
			  t_baie,
			  t_ltech,
			  t_sitetech,
			  t_noeud
			WHERE 
			  t_sitetech.st_nd_code = t_noeud.nd_code AND
			  t_ltech.lt_st_code = t_sitetech.st_code AND
			  t_baie.ba_lt_code = t_ltech.lt_code AND
			  t_equipement.eq_ba_code = t_baie.ba_code;

			   
			/*vs_elem_pt_nd*/
			DROP VIEW IF EXISTS "vs_elem_pt_nd";
			CREATE VIEW "vs_elem_pt_nd" AS
			SELECT 
			  * 
			FROM 
			  t_ptech,
			  t_noeud
			WHERE 
			  t_ptech.pt_nd_code = t_noeud.nd_code;

			/*vs_elem_mq_nd*/
			DROP VIEW IF EXISTS "vs_elem_mq_nd";
			CREATE VIEW "vs_elem_mq_nd" AS
			SELECT 
			  * 
			FROM 
			  t_masque,
			  t_noeud
			WHERE 
			  t_masque.mq_nd_code = t_noeud.nd_code;

			  
			/*vs_elem_cl_cb*/ 
			DROP VIEW IF EXISTS "vs_elem_cl_cb";
			CREATE VIEW "vs_elem_cl_cb" AS
			SELECT 
			  * 
			FROM 
			  t_cable,
			  t_cableline
			WHERE 
			  t_cableline.cl_cb_code = t_cable.cb_code;


			/*vs_elem_cl_cb_lv*/ 
			DROP VIEW IF EXISTS "vs_elem_cl_cb_lv";
			CREATE VIEW "vs_elem_cl_cb_lv" AS
			SELECT 
				*
			FROM "t_cableline" AS "cl"
			JOIN "t_cable" AS "cb" ON ("cl"."cl_cb_code" = "cb"."cb_code")
			LEFT JOIN "t_love" AS "lv" ON ("cb"."cb_code" = "lv"."lv_cb_code")
			--ORDER BY "cb"."cb_code"
			;

			  
			/*vs_elem_fo_cb_cl*/ 
			DROP VIEW IF EXISTS "vs_elem_fo_cb_cl";
			CREATE VIEW "vs_elem_fo_cb_cl" AS
			SELECT 
			  * 
			FROM 
			  t_fibre,
			  t_cable,
			  t_cableline
			WHERE 
			  t_fibre.fo_cb_code = t_cable.cb_code AND
			  t_cableline.cl_cb_code = t_cable.cb_code;

			  
			/*vs_elem_rt_fo_cb_cl*/
			DROP VIEW IF EXISTS "vs_elem_rt_fo_cb_cl";
			CREATE VIEW "vs_elem_rt_fo_cb_cl" AS  
			SELECT 
			  * 
			FROM 
			  t_ropt,
			  t_fibre,
			  t_cable,
			  t_cableline
			WHERE 
			  t_cable.cb_code = t_fibre.fo_cb_code AND
			  t_cableline.cl_cb_code = t_cable.cb_code AND
			  t_fibre.fo_code = t_ropt.rt_fo_code;

			  
			/*vs_elem_lv_nd*/
			DROP VIEW IF EXISTS "vs_elem_lv_nd";
			CREATE VIEW "vs_elem_lv_nd" AS
			  SELECT 
			  * 
			FROM 
			  t_love,
			  t_noeud
			WHERE 
			  t_love.lv_nd_code = t_noeud.nd_code;

			  
			/*vs_elem_bp_pt_nd*/ 
			DROP VIEW IF EXISTS "vs_elem_bp_pt_nd";
			CREATE VIEW "vs_elem_bp_pt_nd" AS
			SELECT 
			  * 
			FROM 
			  t_ebp,
			  t_ptech,
			  t_noeud
			WHERE 
			  t_ptech.pt_nd_code = t_noeud.nd_code AND
			  t_ebp.bp_pt_code = t_ptech.pt_code;

			  
			/*vs_elem_cs_bp_pt_nd*/  
			DROP VIEW IF EXISTS "vs_elem_cs_bp_pt_nd";
			CREATE VIEW "vs_elem_cs_bp_pt_nd" AS
			SELECT 
			  * 
			FROM 
			  t_cassette,
			  t_ebp,
			  t_ptech,
			  t_noeud
			WHERE 
			  t_ptech.pt_nd_code = t_noeud.nd_code AND
			  t_ebp.bp_pt_code = t_ptech.pt_code AND
			  t_cassette.cs_bp_code = t_ebp.bp_code;

			  
			/*vs_elem_se_nd*/  
			DROP VIEW IF EXISTS "vs_elem_se_nd";
			CREATE VIEW "vs_elem_se_nd" AS
			SELECT 
			  * 
			FROM 
			  t_siteemission,
			  t_noeud
			WHERE 
			  t_siteemission.se_nd_code = t_noeud.nd_code;
			  

			/*vs_elem_do_em*/  
			DROP VIEW IF EXISTS "vs_elem_do_em";
			CREATE VIEW "vs_elem_do_em" AS
			SELECT 
			  * 
			FROM 
			  t_document,
			  t_empreinte
			WHERE 
			  t_empreinte.em_do_code = t_document.do_code;
			  
			  
			/*vs_elem_cd_dm_cm*/ 
			DROP VIEW IF EXISTS "vs_elem_cd_dm_cm";
			CREATE VIEW "vs_elem_cd_dm_cm" AS
			SELECT 
			  t_cond_chem.dm_cd_code || t_cond_chem.dm_cm_code AS dm_id,
			  * 
			FROM 
			  t_conduite,
			  t_cond_chem,
			  t_cheminement
			WHERE 
			  t_cheminement.cm_code = t_cond_chem.dm_cm_code AND
			  t_cond_chem.dm_cd_code = t_conduite.cd_code;

			  
			/*vs_elem_cb_nd*/
			DROP VIEW IF EXISTS vs_elem_cb_nd;
			CREATE VIEW vs_elem_cb_nd AS
			SELECT DISTINCT
			  'ND1-' || cb.cb_code || '_' || cb.cb_nd1 AS cb_nd,
			  * 
			FROM 
			  t_cable AS cb,
			  t_noeud AS nd
			WHERE 
			  cb.cb_nd1 = nd.nd_code
			UNION
			SELECT DISTINCT
			  'ND2-' || cb.cb_code || '_' || cb.cb_nd1 AS cb_nd,
			  * 
			FROM 
			  t_cable AS cb,
			  t_noeud AS nd
			WHERE 
			  cb.cb_nd2 = nd.nd_code;"""
		return req_create_vue
	function_execute_requete(function_req_decoupe_zsro(schema_depart, schema_decoupe,schema_arrive),'',connection)
	connection.commit()
	function_execute_requete(function_create_vues(schema_decoupe),'',connection)
	connection.commit()
	QMessageBox.information(w, "Message dexecution du plugin", 'Execution du Plugin Terminee: Le schema decoupe sappelle pour faire tourner le calcul du Delta==> '+schema_decoupe)




#schema_depart='pr_3_1_sjs1_doe_v_20191220'
#schema_decoupe='decoupe_depart'
#function_decoupe_zsro_general(schema_depart,schema_decoupe)