# -*- coding: utf-8 -*-
from qgis.PyQt.QtCore import *
from qgis.PyQt.QtGui import *
from qgis.core import *
from qgis.utils import *
from qgis.PyQt.QtWidgets import *
import psycopg2
from datetime import datetime

from ...bdd.axione.params_connexion_import import *

# Class pour les fonctions generales
class GeneralFunctions:
    w = QWidget()
    # Function pour la progession bar1

    def progress_bar(self, name_etape):
        prog = QProgressDialog(name_etape + ' : Veillez Patienter', 'Cancel', 0, 100)
        prog.setWindowModality(Qt.WindowModal)
        prog.setMinimumDuration(1)
        return prog

    # Function pour la progession bar2
    def progress_processing(self, index, count_entite, progress_dialog):
        f = int(index + 1)
        pcnt = int(f / count_entite * 100 / 1)
        progress_dialog.setValue(pcnt)

    # Function pour executer une requete sql dans la base
    def function_execute_requete(self, requete_execute, req_fetch, connection):
        curs = connection.cursor()
        try:
            curs.execute(requete_execute)
            if req_fetch:
                data_req = [row for row in curs.fetchall()]
                if data_req:
                    return data_req
        except(Exception, psycopg2.DatabaseError) as error:
            QMessageBox.warning(self.w, "Message dexecution de requete",
                                'Requete Non Executer : ' + str(error) + ' ; ' + str(requete_execute))
        curs.close()

    # Function pour  Get layer dans la BD
    def function_getLayer_bdd(self, schema, table_name, key, rename_table, column_geom):
        uri = QgsDataSourceUri()
        uri.setConnection(host, port, DB, user, MP)
        uri.setDataSource(schema, table_name, column_geom, '', key)
        layer = QgsVectorLayer(uri.uri(False), rename_table, "postgres")
        if layer.isValid():
            # QgsProject.instance().addMapLayer(layer)
            return layer
        else:
            QMessageBox.warning(self.w, "Message", 'Erreur de recuperation de la table : ' + str(table_name))

    # Function Get layer dans Qgis
    def function_getlayer_QGis(self, layer_name):
        layers = [tree_layer.layer() for tree_layer in QgsProject.instance().layerTreeRoot().findLayers()]  # Pyqgis3
        for layer in layers:
            layerType = layer.type()
            if layerType == QgsMapLayer.VectorLayer:
                if layer.name() == layer_name:
                    return layer

    # Function pour ajouter les tables dans leur groupe respectif
    def function_add_layer_group(self, layer_to_add):
        QgsProject.instance().addMapLayer(layer_to_add)

    # Function Suppression du group ajoute dans QGis
    def functiondelete_layer_qgis(self):
        root = QgsProject.instance().mapLayers().values()
        for layer in root:
            QgsProject.instance().removeMapLayers([layer.id()])


class Import_Shape_CSV_BDD(GeneralFunctions):

    # Constructeur des variables qui change
    def __init__(self, var_name_za, var_folder_shp, var_name_schema):

        self.name_date = str(datetime.today().strftime('%Y%m%d'))
        self.name_za = str(var_name_za)  # QFileDialog.getExistingDirectory(None, 'Selection Repertoire ou se trouve les fichiers SQL pour GraceTHD')
        self.name_schema = var_name_schema #  self.name_za + '_' + self.name_date
        self.folder_shp = var_folder_shp  # QFileDialog.getExistingDirectory(None, 'Selection Repertoire ou se trouve les Shapes et les CSV de la Donnees GraceTHD')

    # Function de chargement des layers dans Qgis
    def function_chargement_layer_qgis(self):
        folder_data = self.folder_shp
        bar_progress_char_qgis = self.progress_bar('Chargement des donnees dans Qgis')
        if folder_data:
            # Declaration des noms des groupes a travers la function de creatino des groups
            # shape_group = self.function_create_groupe_name('SHAPE_GraceTHD')
            # csv_group = self.function_create_groupe_name('CSV_GraceTHD')
            folder_iterate = os.listdir(folder_data)
            for index_char_qgis, file_etude in enumerate(folder_iterate):
                chemin = folder_data
                name, ext = os.path.splitext(file_etude)
                chem_etude = chemin + '/' + file_etude
                if ext == ".shp":
                    layer_shp_etude = QgsVectorLayer(chem_etude, name, 'ogr')
                    try:
                        self.function_add_layer_group(layer_shp_etude)
                    except(Exception) as error:
                        QMessageBox.warning(self.w, "Message dexecution de requete",
                                            'Erreur dexecution du chargement du shape dans Qgis' + name)
                if ext == ".csv":
                    layer_csv_etude = QgsVectorLayer(chem_etude, name, 'ogr')
                    try:
                        self.function_add_layer_group(layer_csv_etude)
                    except(Exception) as error:
                        QMessageBox.warning(self.w, "Message dexecution de requete",
                                            'Erreur dexecution du chargement du csv dans Qgis' + name)
                self.progress_processing(index_char_qgis, len(folder_iterate), bar_progress_char_qgis)
                if bar_progress_char_qgis.wasCanceled():
                    iface.messageBar().pushMessage('Info', 'Action Cancelled', level=Qgis.Info)
                    break

    # Function pour la creation des tables
    def function_create_table(self, table_name, var_geom, var_extension):
        features = self.function_getlayer_QGis(table_name)
        list_fieldname = []
        for index_cm, field_name in enumerate(features.fields()):
            fielname = field_name.name().replace(' ', '_').replace("'", '') + ' text '
            list_fieldname.append(fielname)

        if var_geom:
            list_fieldname.append(var_geom + ' geometry')

        tuple_fieldname = ','.join(list_fieldname)
        req_create_table = 'CREATE TABLE IF NOT EXISTS ' + self.name_schema + '.' + '"' + var_extension + table_name + '"' + '(' + tuple_fieldname + ')'
        req_drop_table = 'DROP TABLE IF EXISTS ' + self.name_schema + '.' + var_extension + '"' + table_name + '"'
        return req_drop_table, req_create_table, tuple_fieldname

    # Function pour les insertions des donnees chargees dans Qgis dans la BDD
    def function_insert_data_qgis_BDD(self, var_create_schema, var_rename_layer, connection):
        # Execution de la bar
        bar_progress = self.progress_bar(
            'Chargement des donnees dans Qgis, Creation du schema Input et Insertion')

        # Creation du Schema Ou seront importer les donnees
        if var_create_schema:
            create_schema_input = """DROP SCHEMA IF EXISTS """ + self.name_schema + """ CASCADE; CREATE SCHEMA """ + self.name_schema
            try:
                self.function_execute_requete(create_schema_input, '', connection)
                # pass
            except(Exception) as error:
                QMessageBox.warning(self.w, "Message dexecution de requete",
                                    'Erreur dexecution :' + str(error))

        len_maplayer = len(QgsProject.instance().mapLayers().values())
        list_table_create = []
        for index_map, layers_name_mapLayers in enumerate(QgsProject.instance().mapLayers().values()):
            layer_name = layers_name_mapLayers.name()
            layer_features = layers_name_mapLayers.getFeatures()
            list_table_create.append(layer_name)
            layer_type = layers_name_mapLayers.geometryType()  # 1=Ligne, 2=polygon, 0=Point, 4=Sans Geom

            if var_create_schema:
                # On ne cree et supprime que les couches chargees dans qgis
                # Tables avec Geometries
                if str(layer_type) != '4':
                    try:
                        req_create_table = self.function_create_table(layer_name, 'geom', var_rename_layer)[1]  # Requete pour la creation des tables
                        # Execution de la requete pour la creation des tables
                        self.function_execute_requete(req_create_table, '', connection)
                    except(Exception) as error:
                        QMessageBox.warning(self.w, "Message dexecution de requete",
                                            'Create des tables Non Executer' + layer_name)

                # Tables sans Geometrie
                elif str(layer_type) == '4':
                    try:
                        req_create_table = self.function_create_table(layer_name, '', var_rename_layer)[
                            1]  # Requete pour la creation des tables
                        # print (req_create_table)
                        self.function_execute_requete(req_create_table, '',
                                                                        connection)  # Execution de la requete pour la creation des tables
                    except(Exception) as error:
                        QMessageBox.warning(self.w, "Message dexecution de requete",
                                            'Create des tables Non Executer' + layer_name)
            else:
                # Debut de limportations
                if layers_name_mapLayers.type() == QgsMapLayer.VectorLayer:  # and layer_name == 'Point_Network'
                    layer_not_empty = len(list(layer_features))
                    if layer_not_empty > 0:  # Ignorer linsertion des couches vides
                        layer_re_name = '"' + var_rename_layer + layer_name.upper() + '"'
                        list_fielname_sans_geom = \
                        self.function_create_table(layer_name, '', var_rename_layer)[2].replace(' text ', '')
                        list_fielname_geom = \
                        self.function_create_table(layer_name, 'geom', var_rename_layer)[2].replace(
                            ' text ', '').replace('geometry', '')
                        req_insert_prepare = 'INSERT INTO ' + self.name_schema + '.' + layer_re_name + '(' + list_fielname_geom + ') values'
                        req_insert_prepare_sans_geom = 'INSERT INTO ' + self.name_schema + '.' + layer_re_name + '(' + list_fielname_sans_geom + ') values'
                        list_insert_entite = []
                        layer_features = layers_name_mapLayers.getFeatures()
                        insert_geom = ''
                        for index_layer, layer in enumerate(layer_features):
                            geome_text = layer.geometry().asWkt()
                            attr_insert = '-1'
                            replace_null_value = tuple(
                                [NULL if field in [NULL, '??'] else unicode(field).replace("'", '') for field in
                                 layer.attributes()])
                            #                        print (replace_null_value)#str(layer.attributes()).replace(', None','')
                            #                        break
                            if geome_text:
                                insert_geom = 'geom'
                                attr_insert = replace_null_value + ("ST_GeomFromText('" + geome_text + "',2154)",)
                            if not geome_text:
                                insert_geom = 'sansgeom'
                                attr_insert = replace_null_value
                            list_insert_entite.append(attr_insert)
                        if insert_geom:
                            if insert_geom == 'geom':
                                req_insert_finale = req_insert_prepare + unicode(list_insert_entite).replace('[',
                                                                                                             '').replace(
                                    ']', '').replace('"', '')
                            elif insert_geom == 'sansgeom':
                                req_insert_finale = req_insert_prepare_sans_geom + unicode(list_insert_entite).replace('[',
                                                                                                                       '').replace(
                                    ']', '').replace('"', '')
                            try:
                                # print(req_insert_finale)
                                # break
                                self.function_execute_requete(req_insert_finale, '', connection)
                            except(Exception) as error:
                                QMessageBox.warning(self.w, "Message dexecution de requete",
                                                    'Requete Insertion des donnees Non Executer' + layer_name)
            self.progress_processing(index_map, len_maplayer, bar_progress)
            if bar_progress.wasCanceled():
                iface.messageBar().pushMessage('Info', 'Action Cancelled', level=Qgis.Info)
                break

    # Function add attributs
    def function_add_attributs(self, connection):
        w = QWidget()
        req_att = """select 
            'ALTER TABLE '|| table_schema || '."' || table_name||'" ADD COLUMN IF NOT EXISTS zs_code text, 
            ADD COLUMN IF NOT EXISTS zs_date text' as req_attr,
            'UPDATE '||table_schema||'."'||table_name||'" SET zs_code = ''""" + self.name_za + """'', 
            zs_date = ''""" + self.name_date + """'' where zs_code is null and zs_date is null ' 
            from information_schema.tables where table_schema ='""" + self.name_schema + """'"""
        res_req_att = self.function_execute_requete(req_att, 'bab', connection)
        if res_req_att:
            try:
                for index, req_dynamic in enumerate(res_req_att):
                    # self.function_execute_requete(req_dynamic[0], '', connection)
                    self.function_execute_requete(req_dynamic[1], '', connection)
            except(Exception, psycopg2.DatabaseError) as error:
                return QMessageBox.warning(w, "Message Exexcution", 'Erreur Creation des attribut zs_code_ zs_date')

    # Function copy FTTH_ZONE_ARRIERE.shp to t_zsro du schema echange
    def function_copy_tozsro(self, connection):
        w = QWidget()
        try:
            req_copy = """INSERT INTO echange.t_zsro(name, "num pm", comment, geom)
                select num_projet, ref_pm, Commentair, ST_Force4D(geom) from """ + self.name_schema + """."FTTH_ZONE_ARRIERE" as za
                WHERE NOT EXISTS ( SELECT name FROM echange.t_zsro WHERE name = za.ref_pm  );"""
            self.function_execute_requete(req_copy, '', connection)
        except(Exception, psycopg2.DatabaseError) as error:
            return QMessageBox.warning(w, "Message Exexcution", 'Erreur Insertiont_sro from FTTH_ZONE_ARRIERE')

    # Function copy FTTH_ZONE_ARRIERE.shp to t_zsro du schema echange
    def function_copy_baseprisebal_to_tprisebal(self, connection):
        w = QWidget()
        try:
            req_copy = """DROP TABLE IF EXISTS """ + self.name_schema + """.t_prise_bal; select * into """ + self.name_schema + """.t_prise_bal from """ + self.name_schema + '."BASE_PRISE_BAL"'
            self.function_execute_requete(req_copy, '', connection)
        except(Exception, psycopg2.DatabaseError) as error:
            return QMessageBox.warning(w, "Message Exexcution", 'Erreur Creation t_prise_bal')


def function_execute_class_import_shape_csv_bdd(var_name_schema, var_name_za, var_folder_shp):
    w = QWidget()
    # Partie Connexion a la base
    global user, MP, host, port, DB
    try:
        connection = psycopg2.connect(user=user, password=MP, host=host, port=port, database=DB)
    except(Exception, psycopg2.DatabaseError) as error:
        return QMessageBox.warning(w, "Message de connexion de la base", 'Erreur de connexion de la base')

    # Execution de import dans la BDD
    try:
        class_import_data = Import_Shape_CSV_BDD(var_name_za, var_folder_shp, var_name_schema)
        class_import_data.function_chargement_layer_qgis()
        class_import_data.function_insert_data_qgis_BDD('', '', connection) #  0 == Si create schema, 1 == rename si besoin
        class_import_data.function_add_attributs(connection)
        # # class_import_data.function_copy_tozsro(connection) # Ne pas tenir compte
        class_import_data.function_copy_baseprisebal_to_tprisebal(connection)
        class_import_data.functiondelete_layer_qgis()
        connection.commit()
        connection.close()
        QMessageBox.information(w, "Message de Traitement", 'Import des données réalisé avec succès')
    except(Exception, psycopg2.DatabaseError) as error:
        connection.close()
        return QMessageBox.warning(w, "Message de Traitement", 'Erreur Import des données: ' + str(error))


# function_execute_class_import_shape_csv_bdd('aps', 'NRO_01160_00004', r'V:\SIG\AXIONE\BDD\PM_00004\AVP')
# NRO_01160_00007
# NRO_01160_00004
