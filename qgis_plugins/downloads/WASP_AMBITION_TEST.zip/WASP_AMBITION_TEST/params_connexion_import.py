import psycopg2
from qgis.utils import iface
from qgis.PyQt.QtWidgets import QMessageBox
# Server Test
DB = 'MCD_ADN_sans_ct'
user = 'admambigroup'
MP = 'secure'
host = '192.168.30.195'
port = '5432'

# # Server Prod
# DB = 'MCD_ADN_sans_ct'
# user = 'admambigroup'
# MP = 'secure'
# host = '192.168.30.194'
# port = '5432'

# # Server Local
# DB = 'gracethd_v2_0_1'
# user = 'postgres'
# MP = 'MYPASSWORD'
# host = '127.0.0.1'
# port = '5439'
