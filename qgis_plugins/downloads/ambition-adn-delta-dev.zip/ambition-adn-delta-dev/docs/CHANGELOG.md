# Changelog Notes
## Tags
v_2023_01_11    Tags Version v_2023_01_11
v_2023_01_16    Tags Version v_2023_01_16
v_2023_01_17    Tags Version v_2023_01_17
vb_2020.12.15   First Tag pour tester
vb_2020.12.15.2 Second Tag pour tester
vd_2021_01_07   IMP: Mise en test
vp_2021_01_07   mise en Prod
## Commits
- Correction erreur mise a jour plugin (6ae3539) (Babacar FASSA) (2023-01-17)
- Correction erreur qmessageBox et ajout le changelog dans la documentation (6bab2af) (Babacar FASSA) (2023-01-16)
- Migration vers qgis3.22 version finale avec ajout de la methode du deploiement continu ainsi que la documentation avec mkdocs et la creation de tag a chaque modifications (2ca2d91) (Babacar FASSA) (2023-01-11)
- Migration vers qgis3.22 version finale avec ajout de la methode du deploiement continu ainsi que la documentation avec mkdocs et la creation de tag a chaque modifications (1588e85) (Babacar FASSA) (2023-01-11)
- closes #1; Correction de l'Erreur de connexion de la Base de données au niveau de l'éxecution du plugin (0720a71) (Babacar FASSA) (2021-12-17)
- IMP: Mise en test (37a8864) (Babacar) (2021-01-07)
- IMP: Mise en prod (2d75a43) (Babacar) (2021-01-07)
- Initial commit (fcf08aa) (Babacar) (2020-12-14)
## Merges
## AUTHORS
- Babacar
- Babacar FASSA
