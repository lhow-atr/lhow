import psycopg2
from qgis.PyQt.QtWidgets import QWidget, QMessageBox
from qgis.PyQt.QtXml import QDomDocument
from qgis.core import QgsApplication, QgsProject, QgsLayerTreeLayer, QgsDataSourceUri, QgsVectorLayer, QgsMapLayer
from qgis.utils import iface

import sys
from pathlib import Path

folder_plugin = str(Path(__file__).parent.parent)
sys.path.append(folder_plugin)
from bdd.params_connexion import DB, user, MP, host, port

# schema_depart='pr_3_4_exe_v_20191024'
# schema_arrive='pr_3_4_doe'}


def function_create_delta(schema_depart, schema_arrive, connection):
	w = QWidget()

	# Function pour executer une requete sql dans la base
	def function_req_delta(schema_depart, schema_arrive):
		req_delta = """
			DROP FUNCTION If EXISTS function_drop_table_deltat();
			CREATE OR REPLACE FUNCTION function_drop_table_deltat() RETURNS void AS
				$$
				DECLARE
				var_req_execute record;
				BEGIN
					FOR var_req_execute in 
						select
							'drop table if exists '||table_schema||'.'||table_name||';' as requete_drop
						from information_schema.tables
						where table_name in ('res_compare_geom_exe_deo', 'res_compare_geom_exe_deo_line',
						'res_compare_geom_exe_deo_point','res_compare_geom_exe_deo_polygon',
						'res_entites_ajoutees','res_entites_ajoutees_line',
						'res_entites_ajoutees_point','res_entites_ajoutees_polygon',
						'res_entites_supprimees','res_entites_supprimees_line',
						'res_entites_supprimees_point','res_entites_supprimees_polygon', 
						'table_requete_compare_geom', 'entite_ajoutes', 'entite_inexistantc')
						order by table_name
					LOOP
						IF var_req_execute.requete_drop is not null then
							EXECUTE var_req_execute.requete_drop;
						END IF;
					END LOOP;
			END;
			$$ LANGUAGE plpgsql;
			select * from function_drop_table_deltat();

			grant update on """ + schema_depart + """.t_zpbo to adn_ing;
			UPDATE """ + schema_depart + """.t_zpbo ZP SET zp_r4_code =tzp.bp_etiquet , zp_geolsrc = 'Maj_ZP_R4_code_'||current_date---tzp.bp_etiquet
			from (select BP.bp_etiquet, ZP.zp_r4_code, BP.bp_code, ZP.zp_code, PT.pt_code, ND.nd_code
					from """ + schema_depart + """.t_zpbo ZP
					left join """ + schema_depart + """.t_noeud ND ON ZP.zp_nd_code = ND.nd_code
					left join """ + schema_depart + """.t_ptech PT ON PT.pt_nd_code = ND.nd_code
					left join """ + schema_depart + """.t_ebp BP ON BP.bp_pt_code = PT.pt_code) tzp
			WHERE tzp.zp_code = ZP.zp_code and (ZP.zp_r4_code is null or ZP.zp_r4_code ='');


			DROP FUNCTION if exists """ + schema_arrive + """.prepare_copy_drop_table_compare();
			CREATE OR REPLACE FUNCTION """ + schema_arrive + """.prepare_copy_drop_table_compare() 
				RETURNS table (
					requete_compare_res_ajout text,
					requete_compare_res text,
					column_name_base text,
					requete_base text,
					column_name_compare text,
					requete_compare text,
					table_name_compare text,
					table_name_base text) AS
			$BODY$

			with 
				create_""" + schema_arrive + """_base as (
					---Requete de base pour identifier les clesprimaires de chaque table du schema """ + schema_arrive + """ et creation de la requete select
					SELECT 
						column_name  as column_name_base,table_name as table_name_base,
						'select coalesce('||column_name||',''Cest Vide'') ::text as cb_code,'||quote_literal(column_name)||' as column_name from '||table_schema||'.'||table_name as requete_base---,* 
					FROM INFORMATION_SCHEMA.COLUMNS
					WHERE table_schema ='""" + schema_arrive + """' AND ((ordinal_position = 3 and column_name LIKE '%_etiquet' or 
					(ordinal_position = 2 and column_name LIKE '%_etiquet')) or column_name in ('zd_r5_code', 'zp_r4_code', 'cm_r2_code', 'st_nom') ) 
					AND table_name in ('vs_elem_bp_pt_nd', 'vs_elem_cl_cb', 't_cheminement', 'vs_elem_pt_nd', 't_zdep', 't_zpbo', 'vs_elem_st_nd')),
				--  WHERE table_schema ='""" + schema_arrive + """' /*schema_1*/ AND ordinal_position = 1 (column_name LIKE '___code' OR column_name = 'cm_r2_code' OR column_name LIKE '%_etiquet' OR column_name = 'geom') AND table_name in ('t_ebp', 't_cable', 't_cheminement', 't_ptech', 't_zdep', 't_zpbo', 't_sitetech')),


				create_""" + schema_arrive + """_compare as (
					---Requete de base pour identifier les clesprimaires de chaque table du schema comparaison et creation de la requete select
					SELECT 
						column_name as column_name_compare, table_name as table_name_compare,
						'select coalesce('||column_name||',''Cest Vide'') ::text  as cb_code,'||quote_literal(column_name)||'  as column_name from '||table_schema||'.'||table_name as requete_compare---,* 
					FROM INFORMATION_SCHEMA.COLUMNS
					WHERE table_schema = '""" + schema_depart + """' AND ((ordinal_position = 3 and column_name LIKE '%_etiquet' or 
					(ordinal_position = 2 and column_name LIKE '%_etiquet')) or column_name in ('zd_r5_code', 'zp_r4_code', 'cm_r2_code', 'st_nom') )  
					AND table_name in ('vs_elem_bp_pt_nd', 'vs_elem_cl_cb', 't_cheminement', 'vs_elem_pt_nd', 't_zdep', 't_zpbo', 'vs_elem_st_nd')),
			--      WHERE table_schema ='""" + schema_depart + """' /*schema_1*/ AND (column_name LIKE '___code' OR column_name = 'cm_r2_code' OR column_name LIKE '%_etiquet' OR column_name = 'geom') AND table_name in ('t_ebp', 't_cable', 't_cheminement', 't_ptech', 't_zdep', 't_zpbo')),
					
				create_difference_base_compare as (
					---Requete ayant les deux resultats des deux premieres requetes pour ensuite faire la difference
					select 
						gb.column_name_base,
						gb.requete_base,
						dc.column_name_compare,
						dc.requete_compare,
						dc.table_name_compare,
						gb.table_name_base
					from create_""" + schema_arrive + """_base gb
						join create_""" + schema_arrive + """_compare dc on dc.column_name_compare=gb.column_name_base and dc.table_name_compare=gb.table_name_base)

			select 
				---#Comparer les donnees dans le schema Gracethd et celles dans le schema compare tout en regardant toutes les entites ne se trouvant pas dans les donnees du schema comprare
				coalesce(requete_base||' where coalesce('||column_name_base||',''Cest Vide'') ::text'||' not in ('||
				replace(requete_compare,','||''''||column_name_base||''''||'  as column_name ',' '),'select 0')||')' as requete_compare_res_ajout,
				---#Comparer les donnees dans le schema Compare et celles dans le schema """ + schema_arrive + """ tout en regardant toutes les entites ne se trouvant pas dans les donnees du schema """ + schema_arrive + """
				coalesce(requete_compare||' where coalesce('||column_name_base||',''Cest Vide'') ::text'||' not in ('||replace(requete_base,','||''''||column_name_base||''''||' as column_name ',' '),'select 0')||')' as requete_compare_res,
				column_name_base,
				requete_base,
				column_name_compare,
				requete_compare,
				table_name_compare,
				table_name_base
			from create_difference_base_compare ;

			$BODY$
				LANGUAGE sql VOLATILE;


			/* Partie II de la creation des tables entites ajoutes et supprimees*/

			CREATE OR REPLACE FUNCTION """ + schema_arrive + """.execute_prepare_copy_drop_table_compare() RETURNS void 
			AS
			$$
			DECLARE

				-----Declaration du variable text
				qry text := '';
				qry_ajouts text := '';
				-----Declaration du variable cursor
				row record;
				-----Declaration du variable cursor
				chemin_export text;
				query_pro text := 'select requete_compare_res,requete_compare_res_ajout from """ + schema_arrive + """.prepare_copy_drop_table_compare()';
			BEGIN

				
				---select genid_chemin_erreur_""" + schema_arrive + """($2) into chemin_export;
				FOR row IN EXECUTE query_pro
					
				LOOP
					IF length(qry) > 0 THEN
						qry := qry|| ' UNION ALL '::text;
					END IF;
					qry := qry || row.requete_compare_res;

					IF length(qry_ajouts) > 0 THEN
						qry_ajouts := qry_ajouts|| ' UNION ALL '::text;
					END IF;
					qry_ajouts := qry_ajouts || row.requete_compare_res_ajout;
						
				END LOOP;

				qry :=  'SELECT * FROM (' || qry::text|| ') AS A ';
				---RAISE NOTICE '%' , qry;
				EXECUTE 'DROP TABLE IF EXISTS """ + schema_arrive + """.entite_inexistantc';
				--RAISE NOTICE '%' , qry;
				EXECUTE 'CREATE TABLE """ + schema_arrive + """.entite_inexistantc as '||qry;

				qry_ajouts :=  'SELECT * FROM (' || qry_ajouts::text|| ') AS A ';
				--RAISE NOTICE '%' , qry;
				EXECUTE 'DROP TABLE IF EXISTS """ + schema_arrive + """.entite_ajoutes';
				EXECUTE 'CREATE TABLE """ + schema_arrive + """.entite_ajoutes as '||qry_ajouts;
				

			END;
			$$
			LANGUAGE plpgsql;


			/* creation des index */ 

			--DROP INDEX IF EXISTS """ + schema_arrive + """.ea_aj_idx;
			--CREATE INDEX ea_aj_idx
			--    ON """ + schema_arrive + """.entite_ajoutes USING btree
			--    (cb_code, column_name)
			--    TABLESPACE pg_default;
			--
			--DROP INDEX IF EXISTS """ + schema_arrive + """.ea_sup_idx;
			--CREATE INDEX ea_sup_idx
			--    ON """ + schema_arrive + """.entite_inexistantc USING btree
			--    (cb_code, column_name)
			--    TABLESPACE pg_default;
				

			/* Partie III executions des functions des creations des tables entitees et supprimees*/
			select """ + schema_arrive + """.execute_prepare_copy_drop_table_compare();

			/* Parti IV Suppression et creation des tables des entites supprimees et ajoutees avec la geometrie*/
			drop table if exists """ + schema_arrive + """.res_entites_ajoutees;
			drop table if exists """ + schema_arrive + """.res_entites_supprimees;
			create table """ + schema_arrive + """.res_entites_ajoutees(attribut text, geom geometry);
			create table """ + schema_arrive + """.res_entites_supprimees(attribut text, geom geometry);


			/* Parti V Creation de la requete dynamique des pour sortir les geometries ajoutees et supprimees*/
			CREATE OR REPLACE FUNCTION """ + schema_arrive + """.execute_res_entites_ajoutees(req text) RETURNS table (requete text) AS
			$$
			BEGIN
			RETURN QUERY EXECUTE $1;
			END;
			$$ LANGUAGE plpgsql;


			/* Parti VI Creation de la requete dynamique des pour inserer les geometries ajoutees et supprimees dans les tables crees*/
			CREATE OR REPLACE FUNCTION """ + schema_arrive + """.insert_res_entites_ajoutees(req text, res_table_error text) RETURNS void 
			AS
			$$
			DECLARE
				-----Declaration des variables requete_compare
				requete_compare text;
			BEGIN
				---Parcours de la table contenant les requetes a executer
				FOR requete_compare IN select requete from  """ + schema_arrive + """.execute_res_entites_ajoutees($1)
				---Execution des requetes parcourus
				loop
				--RAISE NOTICE '%' , requete_compare;
					EXECUTE 'INSERT INTO """ + schema_arrive + """.'||$2||'(attribut, geom) '||requete_compare||';';
				end loop;
			END;
			$$
			LANGUAGE plpgsql;



			--SET statement_timeout TO 10000000000000000000000000000000000000;
			/* Parti VII Execution finale pour sortir les resultats en geometry des Entites ajoutees*/ 
			/* MODIFIE POUR VALEURS NULL  - - - 
			texte modifié: 	''select ''||ea.column_name||'',''||''geom''||'' from ''||table_schema||''.''||col.table_name||'' 
			where ''||ea.column_name||''=''||quote_literal(ea.cb_code ) as req, ea.cb_code ,	col.table_schema, col.table_name,col.column_name 
			FROM """ + schema_arrive + """.entite_ajoutes ea ---COLUMN */ 

			select * from """ + schema_arrive + """.insert_res_entites_ajoutees('with export_resultat_entites_ajoutes as (
			select distinct

				''select ''||ea.column_name||'',''||''geom''||'' from ''||table_schema||''.''||col.table_name||'' where ''||ea.column_name||
				replace(''=''||quote_literal(ea.cb_code ),''=''||quote_literal(''Cest Vide''),'' is null'' )as req, ea.cb_code ,		col.table_schema, col.table_name,col.column_name 
			FROM """ + schema_arrive + """.entite_ajoutes ea ---COLUMN

			left join  INFORMATION_SCHEMA.COLUMNS col on ea.column_name=col.column_name
			where table_schema = ''""" + schema_arrive + """''  and ((ordinal_position = 3 and ea.column_name LIKE ''%_etiquet'' or 
			(ordinal_position = 2 and ea.column_name LIKE ''%_etiquet'')) 
			or ea.column_name in (''zd_r5_code'', ''zp_r4_code'', ''cm_r2_code'', ''st_nom'') )  and  col.table_name in (''vs_elem_bp_pt_nd'', ''vs_elem_cl_cb'', ''t_cheminement'', ''vs_elem_pt_nd'', ''t_zdep'', ''t_zpbo'', ''vs_elem_st_nd''))
			select req as requete  from export_resultat_entites_ajoutes  order by cb_code ;','res_entites_ajoutees' );

			/* Parti VIII Execution finale pour sortir les resultats en geometry des Entites supprimees*/
			select * from """ + schema_arrive + """.insert_res_entites_ajoutees('with export_resultat_entites_supprimees as (
			select distinct
				''select ''||ea.column_name||'',''||''geom''||'' from ''||table_schema||''.''||col.table_name||'' where ''||ea.column_name||
				replace(''=''||quote_literal(ea.cb_code ),''=''||quote_literal(''Cest Vide''),'' is null'' ) as req, ea.cb_code ,		col.table_schema, col.table_name,col.column_name 
			FROM """ + schema_arrive + """.entite_inexistantc ea ---COLUMN
			left join  INFORMATION_SCHEMA.COLUMNS col on ea.column_name=col.column_name
			where table_schema = ''""" + schema_depart + """''  and ((ordinal_position = 3 and ea.column_name LIKE ''%_etiquet'' or 
			(ordinal_position = 2 and ea.column_name LIKE ''%_etiquet'')) 
			or ea.column_name in (''zd_r5_code'', ''zp_r4_code'', ''cm_r2_code'', ''st_nom'') ) and  col.table_name in (''vs_elem_bp_pt_nd'', ''vs_elem_cl_cb'', ''t_cheminement'', ''vs_elem_pt_nd'', ''t_zdep'', ''t_zpbo'', ''vs_elem_st_nd''))
			select  req as requete from export_resultat_entites_supprimees  order by cb_code ;','res_entites_supprimees');



			/* Partie comparer geometry*/
			drop table if exists """ + schema_arrive + """.res_compare_geom_exe_deo;
			drop table if exists """ + schema_arrive + """.table_requete_compare_geom;
			create table """ + schema_arrive + """.res_compare_geom_exe_deo( attribut_code_exe text, attribut_geom_exe geometry,attribut_code_deo text,attribut_geom_deo geometry,diff_distance_01 text, difference_egal text); 

			/*Partie I de la Requete dynamique pour verifier les differences de geometries entre deux schemas differents*/
			with 
				EXE_EA as (
					SELECT column_name c_name_a, table_name t_name_a, table_schema as table_schema_a, 'select * from '||table_schema||'.'||table_name||' where '||column_name||' not in ('||'select ' ||column_name||' from '||table_schema||'.'||'entite_ajoutes)' as "req_a"
					FROM INFORMATION_SCHEMA.COLUMNS
					WHERE table_schema ='""" + schema_arrive + """' AND table_name in ('vs_elem_bp_pt_nd', 'vs_elem_cl_cb', 't_cheminement', 'vs_elem_pt_nd', 't_zdep', 't_zpbo', 'vs_elem_st_nd') AND ((ordinal_position = 3 and column_name LIKE '%_etiquet' or 
			(ordinal_position = 2 and column_name LIKE '%_etiquet')) 
			or column_name in ('zd_r5_code', 'zp_r4_code', 'cm_r2_code', 'st_nom') ) 
					),
				DEO_ES as(
					SELECT column_name as c_name_b, table_name t_name_b, table_schema as table_schema_b, 'select * from '||table_schema||'.'||table_name||' where '||column_name||' not in ('||'select ' ||column_name||' from '||'""" + schema_arrive + """'||'.'||'entite_inexistantc)' as "req_b"
					FROM INFORMATION_SCHEMA.COLUMNS
					WHERE table_schema ='""" + schema_depart + """' AND table_name in ('vs_elem_bp_pt_nd', 'vs_elem_cl_cb', 't_cheminement', 'vs_elem_pt_nd', 't_zdep', 't_zpbo', 'vs_elem_st_nd') AND  ((ordinal_position = 3 and column_name LIKE '%_etiquet' or 
			(ordinal_position = 2 and column_name LIKE '%_etiquet')) 
			or column_name in ('zd_r5_code', 'zp_r4_code', 'cm_r2_code', 'st_nom') )
					)
					
			select distinct 

			'SELECT texe.'||c_name_a||', texe.'||'geom'||', tdeo.'||c_name_a||', tdeo.'||'geom'||', st_dwithin(texe.geom,tdeo.geom,0.1) as diff_distance_01, st_equals(texe.geom,tdeo.geom) as diff_egal
			from '||table_schema_a ||'.'||t_name_a||' as texe 		 
			left join 	 
				(select * from '||table_schema_b||'.'||t_name_b||' where '||c_name_b||' not in (select cb_code from '||table_schema_a||'.entite_inexistantc)) as tdeo on tdeo.'||c_name_b||'=texe.'||c_name_a||'
			where texe.'||c_name_a||' not in 	 
				(select cb_code from '||table_schema_a||'.entite_ajoutes) AND (st_dwithin(texe.geom,tdeo.geom,0.1) = ''false'' or st_equals(texe.geom,tdeo.geom) = ''false'')
			order by texe.'||c_name_a as req

			into """ + schema_arrive + """.table_requete_compare_geom

			from EXE_EA
			inner join DEO_ES on DEO_ES.t_name_b = EXE_EA.t_name_a;

			/* Partie II creation de la table intermediaire de la requete dynamique des differences de geometries*/ 

			DROP FUNCTION if exists """ + schema_arrive + """.function_compare_geom();
			CREATE OR REPLACE FUNCTION """ + schema_arrive + """.function_compare_geom() RETURNS table (req text) AS
			$$
			BEGIN
			RETURN QUERY EXECUTE 'select req from """ + schema_arrive + """.table_requete_compare_geom';
			END;
			$$ LANGUAGE plpgsql;


			/* Partie III  Insertion des resultats dans la table des erreur*/
			CREATE OR REPLACE FUNCTION """ + schema_arrive + """.execute_copy_drop_table_compare() RETURNS void 
			AS
			$$
			DECLARE
				-----Declaration des variables requete_compare
				requete_compare text;
			BEGIN
				---Parcours de la table contenant les requetes a executer
				FOR requete_compare IN select req from  """ + schema_arrive + """.function_compare_geom()
				---Execution des requetes parcourus
				loop
					---RAISE NOTICE '%' , stmt;
					EXECUTE 'INSERT INTO """ + schema_arrive + """.res_compare_geom_exe_deo(
				attribut_code_exe, attribut_geom_exe, attribut_code_deo, attribut_geom_deo, diff_distance_01, difference_egal) '||requete_compare||';' ;
				end loop;
			END;
			$$
			LANGUAGE plpgsql;

			/*Execution Finale de la requete finale*/
			select * from """ + schema_arrive + """.execute_copy_drop_table_compare();
			
			
			/*Partie: Creation des tables pour la visualisation*/
			
			drop table if exists """ + schema_arrive + """.res_compare_geom_exe_deo_line;
			drop table if exists """ + schema_arrive + """.res_compare_geom_exe_deo_point;
			drop table if exists """ + schema_arrive + """.res_compare_geom_exe_deo_polygon;

			SELECT attribut_code_exe, attribut_geom_exe, attribut_code_deo, attribut_geom_deo, diff_distance_01, difference_egal
			into """ + schema_arrive + """.res_compare_geom_exe_deo_line
			FROM """ + schema_arrive + """.res_compare_geom_exe_deo 
				where (left(st_astext(attribut_geom_exe),10) = 'LINESTRING' or left(st_astext(attribut_geom_exe),15) = 'MULTILINESTRING');
				
			SELECT attribut_code_exe, attribut_geom_exe, attribut_code_deo, attribut_geom_deo, diff_distance_01, difference_egal
			into """ + schema_arrive + """.res_compare_geom_exe_deo_point
			FROM """ + schema_arrive + """.res_compare_geom_exe_deo 
				where (left(st_astext(attribut_geom_exe),5) = 'POINT' or left(st_astext(attribut_geom_exe),10) = 'MULTIPOINT');

			SELECT attribut_code_exe, attribut_geom_exe, attribut_code_deo, attribut_geom_deo, diff_distance_01, difference_egal
			into """ + schema_arrive + """.res_compare_geom_exe_deo_polygon
			FROM """ + schema_arrive + """.res_compare_geom_exe_deo 
				where (left(st_astext(attribut_geom_exe),12) = 'MULTIPOLYGON' or left(st_astext(attribut_geom_exe),7) = 'POLYGON');
			
			drop table if exists """ + schema_arrive + """.res_entites_ajoutees_line;
			drop table if exists """ + schema_arrive + """.res_entites_ajoutees_point;
			drop table if exists """ + schema_arrive + """.res_entites_ajoutees_polygon;

			SELECT attribut,geom
			into """ + schema_arrive + """.res_entites_ajoutees_line
			FROM """ + schema_arrive + """.res_entites_ajoutees
				where (left(st_astext(geom),10) = 'LINESTRING' or left(st_astext(geom),15) = 'MULTILINESTRING');
				
			SELECT attribut,geom
			into """ + schema_arrive + """.res_entites_ajoutees_point
			FROM """ + schema_arrive + """.res_entites_ajoutees 
				where (left(st_astext(geom),5) = 'POINT' or left(st_astext(geom),10) = 'MULTIPOINT');

			SELECT attribut,geom
			into """ + schema_arrive + """.res_entites_ajoutees_polygon
			FROM """ + schema_arrive + """.res_entites_ajoutees 
				where (left(st_astext(geom),12) = 'MULTIPOLYGON' or left(st_astext(geom),7) = 'POLYGON');
			
			drop table if exists """ + schema_arrive + """.res_entites_supprimees_line;
			drop table if exists """ + schema_arrive + """.res_entites_supprimees_point;
			drop table if exists """ + schema_arrive + """.res_entites_supprimees_polygon;

			SELECT attribut,geom
			into """ + schema_arrive + """.res_entites_supprimees_line
			FROM """ + schema_arrive + """.res_entites_supprimees
				where (left(st_astext(geom),10) = 'LINESTRING' or left(st_astext(geom),15) = 'MULTILINESTRING');
				
			SELECT attribut,geom
			into """ + schema_arrive + """.res_entites_supprimees_point
			FROM """ + schema_arrive + """.res_entites_supprimees 
				where (left(st_astext(geom),5) = 'POINT' or left(st_astext(geom),10) = 'MULTIPOINT');

			SELECT attribut,geom
			into """ + schema_arrive + """.res_entites_supprimees_polygon
			FROM """ + schema_arrive + """.res_entites_supprimees 
				where (left(st_astext(geom),12) = 'MULTIPOLYGON' or left(st_astext(geom),7) = 'POLYGON');"""
		return req_delta

	# Partie Suppression tables Deltat et Creation Deltat
	cursor_connexion = connection.cursor()
	cursor_connexion.execute(function_req_delta(schema_depart, schema_arrive)) 
	connection.commit()

	# Partie chargement de cousches dans qgis
	# Funciton de creations des noms des groups
	def function_create_groupe_name(name_groupe):
		root = QgsProject.instance().layerTreeRoot()
		# {name_groupe="Shape_Erreur_Control_Design_ADN"}
		group = root.findGroup(name_groupe)
		if group is not None:
			# for child in group.children():
			# QgsProject.instance().removeMapLayer(child.layerId())
			root.removeChildNode(group)
		shape_group = root.addGroup(name_groupe)
		return shape_group

	# Function pour ajouter les tables dans leur groupe respectif
	def function_add_layer_group(layer_to_add, groupe_name):
		# {QgsProject.instance().addMapLayer(layer_to_add,False)
		# groupe_name.insertChildNode(0,QgsLayerTreeLayer(layer_to_add))}
		# {notre_entite = len([feature for feature in layer_to_add.getFeatures()])  # len(list(layer_to_add.getFeatures()))
		# # if notre_entite > 0:}
		QgsProject.instance().addMapLayer(layer_to_add, False)
		groupe_name.insertChildNode(0, QgsLayerTreeLayer(layer_to_add))

	# Function pour  les tables deltas:
	def function_get_layer_bdd(schema, table_name, key, rename_table, path_folder,
								column_geom):
		global DB, user, MP, host, port
		uri = QgsDataSourceUri()
		uri.setConnection(host, port, DB, user, MP)
		uri.setDataSource(schema, table_name, column_geom, '', key)  # (schema, table_name, "geom")#Shape
		layer = QgsVectorLayer(uri.uri(False), rename_table, "postgres")
		if layer:
			# {Chem_Rep_export=path_folder + '/' + layer.name() + ".shp"
			# layer_bt_export = QgsVectorFileWriter.writeAsVectorFormat(layer,Chem_Rep_export, "LATIN1", layer.crs(), 'ESRI Shapefile')
			# QgsProject.instance().addMapLayer(layer)}
			return layer

	# Declaration des noms des groupes a travers la function de creatino des groups
	delta_group = function_create_groupe_name('Delta_Group')

	# Chargement des couches dans le group
	function_add_layer_group(
		function_get_layer_bdd(schema_arrive, 'res_compare_geom_exe_deo_polygon',
								'attribut_code_deo', 'res_compare_geom_exe_deo_polygon', '', 'attribut_geom_deo'),
		delta_group)
	function_add_layer_group(
		function_get_layer_bdd(schema_arrive, 'res_compare_geom_exe_deo_line',
								'attribut_code_deo', 'res_compare_geom_exe_deo_line', '', 'attribut_geom_deo'),
		delta_group)
	function_add_layer_group(
		function_get_layer_bdd(schema_arrive, 'res_compare_geom_exe_deo_point',
								'attribut_code_deo', 'res_compare_geom_exe_deo_point', '', 'attribut_geom_deo'),
		delta_group)

	function_add_layer_group(
		function_get_layer_bdd(schema_arrive, 'res_entites_ajoutees_polygon', 'geom',
								'res_entites_ajoutees_polygon', '', 'geom'), delta_group)
	function_add_layer_group(
		function_get_layer_bdd(schema_arrive, 'res_entites_ajoutees_line', 'geom',
								'res_entites_ajoutees_line', '', 'geom'), delta_group)
	function_add_layer_group(
		function_get_layer_bdd(schema_arrive, 'res_entites_ajoutees_point', 'geom',
								'res_entites_ajoutees_point', '', 'geom'), delta_group)

	function_add_layer_group(
		function_get_layer_bdd(schema_arrive, 'res_entites_supprimees_polygon', 'geom',
								'res_entites_supprimees_polygon', '', 'geom'), delta_group)
	function_add_layer_group(
		function_get_layer_bdd(schema_arrive, 'res_entites_supprimees_line', 'geom',
								'res_entites_supprimees_line', '', 'geom'), delta_group)
	function_add_layer_group(
		function_get_layer_bdd(schema_arrive, 'res_entites_supprimees_point', 'geom',
								'res_entites_supprimees_point', '', 'geom'), delta_group)

	# connection.close()

	# Partie application des styles
	def function_ajoute_style(connection):
		# {connection = psycopg2.connect(user=user, password=MP, host=host, port=port, database=DB)}
		cursor = connection.cursor()
		requete = """SELECT styleqml,stylename FROM public.layer_styles;"""
		cursor.execute(requete)
		all_styles = cursor.fetchall()
		for layers_name_map_layers in QgsProject.instance().mapLayers().values():
			if layers_name_map_layers.type() == QgsMapLayer.VectorLayer:  # and layers_name_map_layers.geometryType() in [QgsWkbTypes.PointGeometry,QgsWkbTypes.LineGeometry,QgsWkbTypes.PolygonGeometry]
				for i in all_styles:
					if layers_name_map_layers.name() == i[1]:
						styledoc = QDomDocument()
						styledoc.setContent(i[0])
						layers_name_map_layers.importNamedStyle(styledoc)
		if (connection):
			connection.commit()
			cursor.close()
			connection.close()
		iface.mapCanvas().refreshAllLayers()

	function_ajoute_style(connection)
	cursor_connexion.close()
	QMessageBox.information(w, "Message dexecution du plugin", 'Execution du Plugin Terminee')

# {schema_depart='pr_1_1_pre_doe_v_20190410'
# schema_arrive='pr_1_1_doe_v2'
# function_create_delta(schema_depart,schema_arrive)}
