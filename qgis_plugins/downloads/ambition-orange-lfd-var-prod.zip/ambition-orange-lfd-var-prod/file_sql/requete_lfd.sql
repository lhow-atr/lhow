SET search_path TO var_lfd, public;
GRANT ALL ON SCHEMA var_lfd TO lfd_ing;
GRANT SELECT, INSERT, Update ON ALL TABLES IN SCHEMA var_lfd TO lfd_ing;
ALTER DEFAULT PRIVILEGES IN SCHEMA var_lfd GRANT SELECT, INSERT, UPDATE  ON TABLES TO lfd_ing;
-- IG01.1
DROP TABLE IF EXISTS "IG01.1";
CREATE TABLE "IG01.1" as
with requete_ipon_chambre as (
select 
	array_to_string(array_agg(distinct nomcommunepm),',') nomcommunepm, 
	array_to_string(array_agg(distinct codecommunepm),',') codecommunepm,
	array_to_string(array_agg(distinct nomdupmreg),',') nomdupmreg,
	array_to_string(array_agg(distinct nomdupareg),',') nomdupareg, 
	array_to_string(array_agg(distinct positiondequipementptpb),',') positiondequipementptpb,
	nomsitepfpb,
	array_to_string(array_agg(distinct nomduptpb),',') nomduptpb,
	array_to_string(array_agg(distinct nomdupfpb),',') nomdupfpb,
	array_length(array_agg(distinct nomduptpb), 1) nombre_pt_pb
from ipon
where positiondequipementptpb = 'CHAMBRE'
group by nomsitepfpb)
select 
	distinct chf_req.*, chh_ft.codechchiffre2, chh_ft.codechchiffre1, chh_ft.refchambre
from requete_ipon_chambre chf_req
	left join chambre_ftth as chh_ft on chh_ft.codechchiffre2 = chf_req.codecommunepm and 
	(replace(to_char(chh_ft.codechchiffre1::int,'00000'),' ','') = replace(to_char((right(chf_req.nomsitepfpb, 5)::int),'00000'),' ',''))
where nombre_pt_pb::int > 1
order by chf_req.nomsitepfpb; 

CREATE or replace FUNCTION array_sum(NUMERIC[]) returns numeric AS 
$$
  SELECT sum(unnest) FROM (select unnest($1)) as foo;
$$
LANGUAGE sql;

CREATE or replace FUNCTION array_sum_int(int[]) returns int AS 
$$
  SELECT sum(unnest)::int FROM (select unnest($1)) as foo;
$$
LANGUAGE sql;

DROP TABLE IF EXISTS "IG06.3";
CREATE TABLE "IG06.3" as
with intermediare_igo6 as (
select
	array_agg(distinct ip.nomcommunepm) nom_commune_pm,
	ip.nomduptpb, 
	array_agg(distinct ip.codeimbzonedinfluencepfpbselonlesadresses) as code_imb_zone_d_influence_pf_pb_selon_les_adresses,
	array_agg(distinct(descriptionpfpb)),
	---sum(replace(ip.nb_el_du_code_immeuble, Null, '0')::int) nb_el_du_code_immeuble,
	array_to_string(array_agg(DISTINCT (ip.nomsitepfpb)),';') nom_site_pf_pb,
	array_to_string(array_agg(DISTINCT (ip.positiondequipementptpb)),';') position_d_equipement_pt_pb,
	array_agg(CASE
			WHEN ip.nbelducodeimmeuble IS NULL or ip.nbelducodeimmeuble = '' THEN
				0
			ELSE
				ip.nbelducodeimmeuble::int
		END) as nb_el_du_code_immeuble_replace,
	--count(ip.nb_el_du_code_immeuble) + ((count(ip.nb_el_du_code_immeuble) * 20)::float/100) as vingtpourcen,
	array_to_string(array_agg(distinct case when ip_pt.nombre_pt is null then 0 else ip_pt.nombre_pt::int end),';') as nombre_pt_ipon_file
from ipon ip
	left join table_data_ipon_pt ip_pt on ip_pt.nom_pt = ip.nomduptpb
group by ip.nomduptpb)
select 
	
	*,
	array_sum_int(nb_el_du_code_immeuble_replace) as nb_el_du_code_immeuble_sum, 
	array_sum_int(nb_el_du_code_immeuble_replace) + ((array_sum_int(nb_el_du_code_immeuble_replace) * 20)::float/100) as vingtpourcen
from intermediare_igo6;
---where array_sum_int(nb_el_du_code_immeuble_replace) + ((array_sum_int(nb_el_du_code_immeuble_replace) * 20)::float/100)::float > nombre_pt_ipon_file::float;

---IG06.1
DROP TABLE IF EXISTS "IG06.1";
CREATE TABLE "IG06.1" as
select
	*
from "IG06.3";

---IG06.2
DROP TABLE IF EXISTS "IG06.2";
CREATE TABLE "IG06.2" as
select 
	distinct imb.id_metier_, imb.nb_logemen, imb.batiment, zn.id_metier_ as id_metier_zone
from ftth_site_immeuble imb
	join ftth_zone_eligibilite zn on st_within(imb.geom, zn.geom);

--IA01.1
DROP TABLE IF EXISTS "IA01.1";
CREATE TABLE "IA01.1" as
select 
	distinct ref_cable,
	statut_ftt,
	type_longu,
	longueur,
	diametre,
	nb_fibre,
	type_cable,
	id_metier_,
	type_site_,
	id_metier1,
	type_site1,
	commentair,
	geom,
	tbsvg.id_cable_svg
from ftth_cable ft_cb
	join table_cable_svg tbsvg on tbsvg.id_cable_svg = right(ft_cb.ref_cable, 10);


--IA01.2
DROP TABLE IF EXISTS "IA01.2";
CREATE TABLE "IA01.2" as
select 
	*
from "IA01.1"
where statut_ftt != 'D' or type_longu != 'T';

--IA03.1
DROP TABLE IF EXISTS "IA03.1";
CREATE TABLE "IA03.1" as
select 
	ia.ref_cable, ia.nb_fibre, ia.diametre, fusion_appui_ft_appui_erdf.*
from "IA01.1" as ia
	left join (
		select 
			id_metier_ as id_metier_fusion, nom_com, nature,type,hauteur,ref_pt, geom
		from ftth_site_appui_ft
		union all
		select 
			id_metier_ as id_metier_fusion,nom_com,nature,type,hauteur,ref_pt,geom
		from ftth_site_appui_erdf
	) as fusion_appui_ft_appui_erdf on st_intersects(fusion_appui_ft_appui_erdf.geom, ia.geom);

--IA04.1
DROP TABLE IF EXISTS "IA04.1";
CREATE TABLE "IA04.1" as
select 
	distinct id_metier_fusion, nom_com, nature, type, hauteur, ref_pt, geom, esic.nom
from "IA03.1" ia
	left join export_site_ipon_commune esic on right(esic.nom, 7) = left(ia.id_metier_fusion,7)
where right(esic.nom, 7) is null;

--IA05.1
DROP TABLE IF EXISTS "IA05.1";
CREATE TABLE "IA05.1" as
with tab_ftth_cable as (
	select 
		*
	from "IA01.1"
	where statut_ftt = 'D' and type_longu = 'T')

select 'fourreaux orange'::text, (
		select sum(longueur::float) total_longueur  from tab_ftth_cable
			where type_site_ in ('Armoire', 'Chambre FTTH', 'NRA FTTH')) +
		(select sum(longueur::float) total_longueur  from tab_ftth_cable
			where type_site_ in ('Appui FTTH', 'Appui ERDF', 'Immeuble FTTH') and type_site1 in ('Chambre FTTH', 'NRA FTTH', 'Armoire'))
		as nature
		
union all 

select 'utilisation appui aeriens orange'::text, (
		select sum(longueur::float) total_longueur  from tab_ftth_cable
			where type_site_ in ('Appui FTTH') and type_site1 in ('Appui FTTH', 'Appui ERDF', 'Immeuble FTTH')) +

		COALESCE((select sum(longueur::float) total_longueur  from tab_ftth_cable
			where type_site_ in ('Appui ERDF', 'Immeuble FTTH') and type_site1 in ('Appui FTTH')),0)
		as nature
		
union all

select 'utilisation appui aeriens enedis'::text, (
		COALESCE((select sum(longueur::float) total_longueur  from tab_ftth_cable
			where type_site_ in ('Appui ERDF') and type_site1 in ('Appui ERDF')),0)) as nature
			
union all

select 'utilisation autre(facade, immeuble)'::text, (
		COALESCE((select sum(longueur::float) total_longueur  from tab_ftth_cable
			where type_site_ in ('Immeuble FTTH') and type_site1 in ('Immeuble FTTH')),0)) as nature
			
union all

select 'Lineaire deploye cable optique SRO-PBO'::text, (
		select sum(longueur::float) total_longueur  from tab_ftth_cable) as nature;

-- A Faire IA06.1 meme requete que IA01.1 avec la condition de sortir les cables dans SVG absent dans cable_fthh
--IA06.1
DROP TABLE IF EXISTS "IA06.1";
CREATE TABLE "IA06.1" as
select 
	distinct ref_cable,
	statut_ftt,
	type_longu,
	longueur,
	diametre,
	nb_fibre,
	type_cable,
	id_metier_,
	type_site_,
	id_metier1,
	type_site1,
	commentair,
	geom,
	tbsvg.id_cable_svg,
	right(ft_cb.ref_cable, 10)
from table_cable_svg tbsvg
	left join ftth_cable ft_cb on tbsvg.id_cable_svg = right(ft_cb.ref_cable, 10)
where right(ft_cb.ref_cable, 10) is null;

---RO01.1
DROP TABLE IF EXISTS "RO01.1";
CREATE TABLE "RO01.1" as
select 
	distinct id_metier1,
	type_site,
	id_metie_1,
	statut_ftt,
	type_pf,
	operateur,
	rome_ok
from ftth_pf
where rome_ok != 'O';


---RO01.2
DROP TABLE IF EXISTS "RO01.2";
CREATE TABLE "RO01.2" as
select 
	distinct ref_cable,
	statut_ftt,
	type_longu,
	longueur,
	diametre,
	nb_fibre,
	type_cable,
	id_metier_,
	type_site_,
	id_metier1,
	type_site1,
	operateur,
	usage_rome
from ftth_cable
where usage_rome != 'O';

---RO01.3
DROP TABLE IF EXISTS "RO01.3";
CREATE TABLE "RO01.3" as
select 
	distinct NOMDUPMREG,
	IDTIGREPMREG,
	NOMDUPTPM,
	NOMSITEPFPM,
	USAGEROMEPTPM,
	NOMDUPAREG,
	IDTIGREPAREG,
	NOMDUPTPA,
	NOMSITEPFPA,
	USAGEROMEPTPA,
	NOMDUPTPB,
	NOMSITEPFPB,
	USAGEROMEPTPB
from ipon
where usageromeptpm != 'O' or usageromeptpa != 'O' or usageromeptpb != 'O';


/*CREATE or replace FUNCTION array_sum_int(float[]) returns float AS 
$$
  SELECT sum(unnest)::float FROM (select unnest($1)) as foo;
$$
LANGUAGE sql;
DROP TABLE IF EXISTS "IA05.1";
CREATE TABLE "IA05.1" as
select 
	ft_cb.ref_cable,
	ft_cb.statut_ftt,
	ft_cb.type_longu,
	ft_cb.longueur,
	ft_cb.diametre,
	ft_cb.nb_fibre,
	ft_cb.type_cable,
	ft_cb.id_metier_,
	ft_cb.type_site_,
	ft_cb.id_metier1,
	ft_cb.type_site1,
	ft_cb.commentair,
	array_agg(ft_pr.longueur) longueur_parcours,
	round(array_sum_int(array_agg(ft_pr.longueur))::numeric,2) sum_longueur_parcours,
	array_agg(ft_pr.id_metier_) id_metier_parcours,
	'Somme Longueur Chambre FTTH'::text as sum_longueur
from ftth_cable ft_cb
	left join ftth_parcours ft_pr on st_within(ft_pr.geom, st_buffer(ft_cb.geom, 0.1))
where ft_cb.type_site_ = 'Chambre FTTH' or ft_cb.type_site1 = 'Chambre FTTH' 
group by ft_cb.ref_cable, ft_cb.statut_ftt,
	ft_cb.type_longu, ft_cb.longueur,
	ft_cb.diametre,	ft_cb.nb_fibre,
	ft_cb.type_cable, ft_cb.id_metier_,
	ft_cb.type_site_, ft_cb.id_metier1,
	ft_cb.type_site1, ft_cb.commentair

union all 
select 
	ft_cb.ref_cable,
	ft_cb.statut_ftt,
	ft_cb.type_longu,
	ft_cb.longueur,
	ft_cb.diametre,
	ft_cb.nb_fibre,
	ft_cb.type_cable,
	ft_cb.id_metier_,
	ft_cb.type_site_,
	ft_cb.id_metier1,
	ft_cb.type_site1,
	ft_cb.commentair,
	array_agg(ft_pr.longueur) longueur_parcours,
	round(array_sum_int(array_agg(ft_pr.longueur))::numeric,2) sum_longueur_parcours,
	array_agg(ft_pr.id_metier_) id_metier_parcours,
	'Somme Longueur Appui FTTH'::text as sum_longueur
from ftth_cable ft_cb
	left join ftth_parcours ft_pr on st_within(ft_pr.geom, st_buffer(ft_cb.geom, 0.1))
where (ft_cb.type_site_ = 'Appui FTTH' or ft_cb.type_site1 = 'Appui FTTH') and (ft_cb.type_site_ != 'Chambre FTTH' or ft_cb.type_site1 != 'Chambre FTTH') 
group by ft_cb.ref_cable, ft_cb.statut_ftt,
	ft_cb.type_longu, ft_cb.longueur,
	ft_cb.diametre,	ft_cb.nb_fibre,
	ft_cb.type_cable, ft_cb.id_metier_,
	ft_cb.type_site_, ft_cb.id_metier1,
	ft_cb.type_site1, ft_cb.commentair
union all 
select 
	ft_cb.ref_cable,
	ft_cb.statut_ftt,
	ft_cb.type_longu,
	ft_cb.longueur,
	ft_cb.diametre,
	ft_cb.nb_fibre,
	ft_cb.type_cable,
	ft_cb.id_metier_,
	ft_cb.type_site_,
	ft_cb.id_metier1,
	ft_cb.type_site1,
	ft_cb.commentair,
	array_agg(ft_pr.longueur) longueur_parcours,
	round(array_sum_int(array_agg(ft_pr.longueur))::numeric,2) sum_longueur_parcours,
	array_agg(ft_pr.id_metier_) id_metier_parcours,
	'Somme Longueur Appui ERDF'::text as sum_longueur
from ftth_cable ft_cb
	left join ftth_parcours ft_pr on st_within(ft_pr.geom, st_buffer(ft_cb.geom, 0.1))
where ft_cb.type_site_ = 'Appui ERDF' or ft_cb.type_site1 = 'Appui ERDF'
group by ft_cb.ref_cable, ft_cb.statut_ftt,
	ft_cb.type_longu, ft_cb.longueur,
	ft_cb.diametre,	ft_cb.nb_fibre,
	ft_cb.type_cable, ft_cb.id_metier_,
	ft_cb.type_site_, ft_cb.id_metier1,
	ft_cb.type_site1, ft_cb.commentair
union all 
select 
	ft_cb.ref_cable,
	ft_cb.statut_ftt,
	ft_cb.type_longu,
	ft_cb.longueur,
	ft_cb.diametre,
	ft_cb.nb_fibre,
	ft_cb.type_cable,
	ft_cb.id_metier_,
	ft_cb.type_site_,
	ft_cb.id_metier1,
	ft_cb.type_site1,
	ft_cb.commentair,
	array_agg(ft_pr.longueur) longueur_parcours,
	round(array_sum_int(array_agg(ft_pr.longueur))::numeric,2) sum_longueur_parcours,
	array_agg(ft_pr.id_metier_) id_metier_parcours,
	'Somme Longueur Immeuble_FTTH ou Site(Autre)'::text as sum_longueur
from ftth_cable ft_cb
	left join ftth_parcours ft_pr on st_within(ft_pr.geom, st_buffer(ft_cb.geom, 0.1))
where ft_cb.type_site_ in ('Immeuble_FTTH', 'Site(Autre)') or ft_cb.type_site1 in ('Immeuble_FTTH', 'Site(Autre)')
group by ft_cb.ref_cable, ft_cb.statut_ftt,
	ft_cb.type_longu, ft_cb.longueur,
	ft_cb.diametre,	ft_cb.nb_fibre,
	ft_cb.type_cable, ft_cb.id_metier_,
	ft_cb.type_site_, ft_cb.id_metier1,
	ft_cb.type_site1, ft_cb.commentair;*/
	
--SI01.1
DROP TABLE IF EXISTS "SI01.1";
CREATE TABLE "SI01.1" as
select 
	ft_pf.id_metier_ as id_metier_pf, ft_z.id_metier_
from ftth_zone_eligibilite ft_z
	left join ftth_pf ft_pf on ft_pf.id_metier_ = ft_z.id_metier_
where ft_pf.id_metier_ is null;

--SI02.1
-- A Faire Ajoute colonne rome_ok
DROP TABLE IF EXISTS "SI02.1";
CREATE TABLE "SI02.1" as
select 
	ft_pf.id_metier_ as id_metier_pf,
	ft_pf.id_metie_1,
	ft_pf.type_site,
	ft_pf.statut_ftt,
	ft_pf.type_pf,
	ft_pf.code_com,
	ft_z.id_metier_,
	ft_z.rome_ok

from ftth_zone_eligibilite ft_z
	join ftth_pf ft_pf on ft_pf.id_metier_ = ft_z.id_metier_;

--SI02.2
-- A Faire Ajouter colonne POSITION_D_EQUIPEMENT_PT_PB, HAUTEUR_PAR_RAPPORT_AU_SOL_PT_PB, OPERATEUR_IMMEUBLE_SITE_PF_PB, NOM_SISSI_LOCAL_TECHNIQUE_PT_PB
DROP TABLE IF EXISTS "SI02.2";
CREATE TABLE "SI02.2" as
select 
	distinct CODECOMMUNEPM,
	NOMCOMMUNEPM,
	NOMDUPMREG,
	NOMDUPAREG,
	NOMDUPFPB,
	ETATPRODUCTIONPFPB,
	DESCRIPTIONPFPB,
	ETATPHYSIQUEPTPB,
	NOMDUPTPB,
	NOMSITEPFPB,
	DESCRIPTIONDUSITEPB,
	POSITIONDEQUIPEMENTPTPB, 
	HAUTEURPARRAPPORTAUSOLPTPB, 
	OPERATEURIMMEUBLESITEPFPB, 
	NOMSISSILOCALTECHNIQUEPTPB
from ipon;

--SI03.1
DROP TABLE IF EXISTS "SI03.1";
CREATE TABLE "SI03.1" as
select 
	id_metier_,
	id_metie_1,
	type_site,
	statut_ftt,
	type_pf,
	code_com

from "SI02.1"
where statut_ftt != 'D';

DROP TABLE IF EXISTS "SI03.2";
CREATE TABLE "SI03.2" as
select 
	id_metier_,
	id_metie_1,
	type_site,
	statut_ftt,
	type_pf,
	code_com

from ftth_pf
where (id_metier_ like '%PA%' or id_metier_ like '%PM%' or id_metier_ like '%PEP%') and statut_ftt != 'D';

--SI04.1
DROP TABLE IF EXISTS "SI04.1";
CREATE TABLE "SI04.1" as
select 
	distinct CODECOMMUNEPM,
	NOMCOMMUNEPM,
	NOMDUPMREG,
	NOMDUPAREG,
	NOMDUPFPA,
	NOMDUPTPA,
	NOMSITEPFPA,
	NOMDUPFPB,
	ETATPRODUCTIONPFPB,
	DESCRIPTIONPFPB,
	ETATPHYSIQUEPTPB,
	NOMDUPTPB,
	NOMSITEPFPB,
	DESCRIPTIONDUSITEPB

from ipon
where etatproductionpfpb != 'Dploy' or etatphysiqueptpb != 'Actif';

--SI05.1
DROP TABLE IF EXISTS "SI05.1";
CREATE TABLE "SI05.1" as
select 
	Dossier,
	IdPM,
	IdentifiantProcessus,
	Localit,
	etatngociation,
	Etatsite,
	Sitebloqu,
	Nblogements,
	DateposeduPB,
	Envoiaccordsyndic,
	Retouraccordsyndic,
	Refusaccordsyndic,
	Datednonciationsyndic,
	Motifdnonciationsyndic,
	RaccordableSurDemandeRseau
from optimum
where (Nblogements is not null and Nblogements != '') and Nblogements::int > 3;

--SI06.1
DROP TABLE IF EXISTS "SI06.1";
CREATE TABLE "SI06.1" as
select  
	distinct 'rbal sans site immeuble'::text as req_nature, 
	rb.* 
from contour_pm zn join rbal rb on st_within(rb.geom, zn.geom)
	left join ftth_site_immeuble site on st_dwithin(rb.geom, site.geom, 0.1) where site.geom is null;

--SI06.2
DROP TABLE IF EXISTS "SI06.2";
CREATE TABLE "SI06.2" as
select  
	distinct 'site immeuble sans rbal'::text as req_nature, 
	site.* 
from contour_pm zn join ftth_site_immeuble site on st_within(site.geom, zn.geom)
	left join rbal rb on st_dwithin(rb.geom, site.geom, 0.1) where rb.geom is null;
	
--SI07.1
DROP TABLE IF EXISTS "SI07.1";
CREATE TABLE "SI07.1" as
select 
	ft_imb.id_metier_,
	ft_imb.code_com,
	ft_imb.nom_com,
	ft_imb.nb_logemen,
	op.Dossier,
	op.IdPM,
	op.IdentifiantProcessus,
	op.Localit,
	op.Nblogements

from optimum op
	full outer join ftth_site_immeuble ft_imb on op.Dossier = ft_imb.id_metier_
where (ft_imb.id_metier_ is null or ft_imb.id_metier_ = '') or (op.Dossier is null or op.Dossier = '');


--SI08.1
-- A Faire Idem que requete IG01.2 de ATHD
DROP TABLE IF EXISTS "SI08.1";
--CREATE TABLE "SI08.1" as
with tab_requete_ipon as (
select 
	distinct NOMCOMMUNEPM,
	NOMDUPFPB,
	DESCRIPTIONPFPB,
	NOMDUPTPB,
	NOMSITEPFPB,
	POSITIONDEQUIPEMENTPTPB,
	nomsissilocaltechniqueptpb
from ipon order by nomsitepfpb),
-- CH:en chambre
check_chambre as (
select 
	length(nomsitepfpb) length,
	array_to_string(REGEXP_MATCHES(nomsitepfpb::text, '[\w]{2}'), ',')::text = 'CH' check_nature,
	array_to_string(REGEXP_MATCHES(nomsitepfpb::text, '[A-Za-z0-9/]{5}$'), ',')::text ~* '[A-Za-z]' nbre_digit,
	* 
from tab_requete_ipon
where positiondequipementptpb = 'CHAMBRE' ),

-- AERIEN POTEAU ORANGE
check_aerien_orange as (
select 
	length(nomsitepfpb) length,
	array_to_string(REGEXP_MATCHES(nomsitepfpb::text, '[\w]{2}'), ',')::text = 'AP' check_nature,
	array_to_string(REGEXP_MATCHES(nomsitepfpb::text, '[A-Za-z0-9/]{7}$'), ',')::text ~* '[A-Za-z]' nbre_digit,
	* 
from tab_requete_ipon
where positiondequipementptpb = 'AERIEN POTEAU ORANGE' ),

-- AERIEN POTEAU ENEDIS
check_aerien_enedis as (
select 
	length(nomsitepfpb) length,
	array_to_string(REGEXP_MATCHES(nomsitepfpb::text, '[\w]{2}'), ',')::text = 'AP' check_nature,
	array_to_string(REGEXP_MATCHES(nomsitepfpb::text, '[A-Za-z0-9/E]{6}$'), ',')::text ~* '[A-Za-z]' nbre_digit,
	* 
from tab_requete_ipon
where positiondequipementptpb = 'AERIEN POTEAU ENEDIS' ),

-- FACADE COTE COUR ou FACADE COTE RUE ou like IMMEUBLE
check_aerien_facade_imb as (
select 
	length(nomsitepfpb) length,
	array_to_string(REGEXP_MATCHES(nomsitepfpb::text, '[\w]{3}'), ',')::text = 'IMB' check_nature,
	array_to_string(REGEXP_MATCHES(nomsitepfpb::text, '[A-Za-z0-9/]{7}$'), ',')::text ~* '[A-Za-z]' nbre_digit,
	* 
from tab_requete_ipon
where positiondequipementptpb like '%FACADE%' or positiondequipementptpb like '%IMMEUBLE%'),

-- AERIEN
check_aerien as (
select 
	length(nomsitepfpb) length,
	array_to_string(REGEXP_MATCHES(nomsitepfpb::text, '[\w]{2}'), ',')::text = 'AP' check_nature,
	array_to_string(REGEXP_MATCHES(nomsitepfpb::text, '[A-Za-z0-9/]{7}$'), ',')::text ~* '[A-Za-z]' nbre_digit,
	* 
from tab_requete_ipon
where positiondequipementptpb = 'AERIEN' )

select * into "SI08.1" from (
	select * from check_chambre where (check_nature is false or nbre_digit is true or length != 8 or nomsitepfpb != nomsissilocaltechniqueptpb) union all
	select * from check_aerien_orange where (check_nature is false or nbre_digit is true or length != 10 or nomsitepfpb != nomsissilocaltechniqueptpb) union all
	select * from check_aerien_enedis where (check_nature is false or nbre_digit is true or length != 10 or nomsitepfpb != nomsissilocaltechniqueptpb) union all
	select * from check_aerien_facade_imb where (check_nature is false or length != 16 or (nomsissilocaltechniqueptpb != 'facade' and left(nomsissilocaltechniqueptpb, 3) != 'LOC')) union all
	select * from check_aerien where (check_nature is false or length != 10 or nomsitepfpb != nomsissilocaltechniqueptpb)
) as t;

--SI09.1
DROP TABLE IF EXISTS "SI09.1";
--CREATE TABLE "SI09.1" as
with tab_requete_ipon as (
select 
	NOMCOMMUNEPM,
	NOMDUPMREG,
	NOMDUPAREG,
	NOMDUPFPB,
	DESCRIPTIONPFPB,
	NOMDUPTPB,
	NOMSITEPFPB,
	POSITIONDEQUIPEMENTPTPB,
	HAUTEURPARRAPPORTAUSOLPTPB
from ipon order by POSITIONDEQUIPEMENTPTPB),
-- CHAMBRE
check_chambre as (
select 
	*
from tab_requete_ipon
where positiondequipementptpb like '%CHAMBRE%' and hauteurparrapportausolptpb != 'HH : h inf  1,8 m'),

-- AERIEN
check_aerien as (
select 
	*
from tab_requete_ipon
where positiondequipementptpb like '%AERIEN%' and (hauteurparrapportausolptpb = '' or hauteurparrapportausolptpb is null)),

-- IMMEUBLE
check_immeuble as (
select 
	*
from tab_requete_ipon
where positiondequipementptpb = 'IMMEUBLE GAINE TECHNIQUE' and (hauteurparrapportausolptpb = '' or hauteurparrapportausolptpb is null) )

select distinct * into "SI09.1" from (
	select * from check_chambre union all
	select * from check_aerien union all
	select * from check_immeuble
) as t;

--SI10.1
DROP TABLE IF EXISTS "SI10.1";
with tab_requete_ipon as (
select 
	NOMCOMMUNEPM,
	NOMDUPMREG,
	NOMDUPAREG,
	NOMDUPFPB,
	DESCRIPTIONPFPB,
	NOMDUPTPB,
	NOMSITEPFPB,
	POSITIONDEQUIPEMENTPTPB,
	NATURETRAVAUX,
	CODEIMBZONEDINFLUENCEPFPBSELONLESADRESSES,
	ADDUCTION,
	ADDUCTABILITE
from ipon 
where CODEIMBZONEDINFLUENCEPFPBSELONLESADRESSES is not null and CODEIMBZONEDINFLUENCEPFPBSELONLESADRESSES != ''
order by POSITIONDEQUIPEMENTPTPB),
-- CHAMBRE
check_chambre as (
select 
	*
from tab_requete_ipon
where positiondequipementptpb like '%CHAMBRE%' and (naturetravaux = '' or naturetravaux is null)),

-- AERIEN
check_aerien as (
select 
	*
from tab_requete_ipon
where positiondequipementptpb like '%AERIEN%' and (naturetravaux = '' or naturetravaux is null)),

-- FACADE
check_facade as (
select 
	*
from tab_requete_ipon
where positiondequipementptpb like '%FACADE%' and (naturetravaux = '' or naturetravaux is null)),

-- IMMEUBLE
check_immeuble as (
select 
	*
from tab_requete_ipon
where positiondequipementptpb like '%IMMEUBLE%' and (naturetravaux = '' or naturetravaux is null))

select * into "SI10.1" from (
	select * from check_chambre union all
	select * from check_aerien union all
	select * from check_facade union all
	select * from check_immeuble
) as t;


--SI11.1
-- A Faire Verifier que adduction ou adductabilite est null ou vide
DROP TABLE IF EXISTS "SI11.1";
CREATE TABLE "SI11.1" as
--with tab_requete_ipon as (
select 
	distinct NOMCOMMUNEPM,
	NOMDUPMREG,
	NOMDUPAREG,
	NOMDUPFPB,
	DESCRIPTIONPFPB,
	NOMDUPTPB,
	NOMSITEPFPB,
	NATURETRAVAUX,
	CODEIMBZONEDINFLUENCEPFPBSELONLESADRESSES,
	ADDUCTION,
	ADDUCTABILITE
from ipon 
where adduction is null or adduction != '' or adductabilite is null or adductabilite != '';

/* AS
check_as as (
select 
	*
from tab_requete_ipon
where left(upper(adduction),2) = 'AS' and adductabilite != '1 : Simple - pas dappel client'),

-- Not AS
check_not_as as (
select 
	*
from tab_requete_ipon
where left(upper(ADDUCTION),2) != 'AS' and adductabilite != '2 : Complexe - appeler le client')

select * into "SI11.1" from (
	select * from check_as union all
	select * from check_not_as
) as t; */

--SI12.1
DROP TABLE IF EXISTS "SI12.1";
CREATE TABLE "SI12.1" as
select 
	NOMCOMMUNEPM,
	NOMDUPMREG,
	NOMDUPAREG,
	NOMDUPFPB,
	DESCRIPTIONPFPB,
	NOMDUPTPB,
	NOMSITEPFPB,
	POSITIONDEQUIPEMENTPTPB,
	OPERATEURIMMEUBLESITEPFPB,
	CODEIMBZONEDINFLUENCEPFPBSELONLESADRESSES,
	OIOPERATEURIMMEUBLE
from ipon
where operateurimmeublesitepfpb != 'VAR THD' and OIOPERATEURIMMEUBLE != 'VAR THD';

--SI13.1
DROP TABLE IF EXISTS "SI13.1";
CREATE TABLE "SI13.1" as
select 
	array_agg(distinct NOMCOMMUNEPM) NOMCOMMUNEPM,
	array_agg(distinct NOMDUPMREG) NOMDUPMREG,
	array_agg(distinct NOMDUPAREG) NOMDUPAREG,
	array_agg(distinct NOMDUPFPB) NOMDUPFPB,
	array_agg(distinct DESCRIPTIONPFPB) DESCRIPTIONPFPB,
	NOMDUPTPB,
	array_agg(distinct NOMSITEPFPB) NOMSITEPFPB,
	array_agg(distinct POSITIONDEQUIPEMENTPTPB) POSITIONDEQUIPEMENTPTPB,
	array_agg(distinct HAUTEURPARRAPPORTAUSOLPTPB) HAUTEURPARRAPPORTAUSOLPTPB

from ipon
where positiondequipementptpb like '%FACADE%'
group by nomduptpb;

---SU01.1
DROP TABLE IF EXISTS "SU01.1";
CREATE TABLE "SU01.1" as
select 
	distinct nomdupfpb, descriptionpfpb, nomduptpb, nomsitepfpb, 
	POSITIONDEQUIPEMENTPTPB, ADRESSEOUSOUSADRESSESITEPFPB
from ipon;

---SU02.2
DROP TABLE IF EXISTS "SU02.2";
CREATE TABLE "SU02.2" as
select 
	distinct id_metier_, type_site, id_metie_1,code_com
from ftth_pf;

---ZE01.1
DROP TABLE IF EXISTS "ZE01.1";
CREATE TABLE "ZE01.1" as
with intersect_siteimmeuble_zonel as 
(select
	sit_imb.id_metier_, sit_imb.nb_logemen, sit_imb.batiment,
	zft.id_metier_ as id_metier_zone
from ftth_site_immeuble sit_imb
	 left join ftth_zone_eligibilite zft on st_intersects(sit_imb.geom,zft.geom)
where zft.geom is not null)
select 
	inter.*,
	reqip.adresseousousadressesitepfpb,
	reqip.nomsitepfpb,
	reqip.descriptionpfpb,
	reqip.nomduptpb,
	reqip.nomdupfpb,
	reqip.codeimbzonedinfluencepfpbselonlesadresses,
	reqip.nbelducodeimmeuble,
	reqip.descriptiondusitecommentaires
from intersect_siteimmeuble_zonel as inter
	left join ipon as reqip on inter.id_metier_ = reqip.codeimbzonedinfluencepfpbselonlesadresses
where reqip.codeimbzonedinfluencepfpbselonlesadresses is null or 
	right(inter.id_metier_zone, 5) != replace(left(reqip.descriptionpfpb, 8), left(reqip.descriptionpfpb, 3),'');

--- "ZE01.2"
DROP TABLE IF EXISTS "ZE01.2";
CREATE TABLE "ZE01.2" as
with intersect_siteimmeuble_zonel as 
(select
	sit_imb.id_metier_, sit_imb.nb_logemen, sit_imb.batiment,
	zft.id_metier_ as id_metier_zone
from ftth_site_immeuble sit_imb
	 left join ftth_zone_eligibilite zft on st_intersects(sit_imb.geom,zft.geom)
where zft.geom is not null),
group_id_metier_zone as (
select 
	reqip.codeimbzonedinfluencepfpbselonlesadresses,
	array_to_string(array_agg(distinct reqip.descriptionpfpb), ',') description_pf_pb,
	array_to_string(array_agg(distinct inter.id_metier_), ',') id_metier_,
	array_to_string(array_agg(distinct inter.id_metier_zone), ',') id_metier_zone,
	array_to_string(array_agg(inter.nb_logemen), ',') nb_logemen
from intersect_siteimmeuble_zonel as inter
	left join ipon as reqip on inter.id_metier_ = reqip.codeimbzonedinfluencepfpbselonlesadresses

where reqip.descriptionpfpb is not null and reqip.descriptionpfpb != ''
group by reqip.codeimbzonedinfluencepfpbselonlesadresses
order by reqip.codeimbzonedinfluencepfpbselonlesadresses)

select distinct * from group_id_metier_zone
where description_pf_pb ~ right(id_metier_zone, 5) is false;