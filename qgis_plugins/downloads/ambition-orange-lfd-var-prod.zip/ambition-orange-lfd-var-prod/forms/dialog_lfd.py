# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'C:\Users\babacar.fassa\Downloads\dialog_lfd_for_bf\dialog_lfd.ui'
#
# Created by: PyQt5 UI code generator 5.11.3
#
# WARNING! All changes made in this file will be lost!

import sys
from pathlib import Path

from qgis.PyQt import QtWidgets, QtCore
from qgis.gui import QgsFileWidget, QgsDateTimeEdit
from qgis.core import QgsApplication
from qgis.utils import iface

# # {
# # Initialize QGIS Application
# app = QgsApplication([], False)
# QgsApplication.setPrefixPath("C:\QGIS 3.22.13\apps\qgis-ltr", True)
# QgsApplication.initQgis()

folder_plugin = str(Path(__file__).parent.parent)
sys.path.append(folder_plugin)
from scripts_python.file_import_data_lfd_var import function_execute_class_general_var

# {folder_plugin = r'C:\Users\babacar.fassa\Documents\GitHub\orange-lfd-var'
# sys.path.append(folder_plugin)
# from scripts_python.file_import_data_lfd_var import *


class UiDialog(object):
    def setupUi(self, Dialog):
        Dialog.setObjectName("Dialog")
        Dialog.resize(662, 519)
        self.buttonBox = QtWidgets.QDialogButtonBox(Dialog)
        self.buttonBox.setGeometry(QtCore.QRect(300, 470, 341, 32))
        self.buttonBox.setOrientation(QtCore.Qt.Horizontal)
        self.buttonBox.setStandardButtons(QtWidgets.QDialogButtonBox.Cancel | QtWidgets.QDialogButtonBox.Ok)
        self.buttonBox.setObjectName("buttonBox")
        self.textBrowser = QtWidgets.QTextBrowser(Dialog)
        self.textBrowser.setGeometry(QtCore.QRect(20, 140, 621, 311))
        self.textBrowser.setObjectName("textBrowser")
        self.label = QtWidgets.QLabel(Dialog)
        self.label.setGeometry(QtCore.QRect(20, 10, 61, 16))
        self.label.setObjectName("label")
        self.label_2 = QtWidgets.QLabel(Dialog)
        self.label_2.setGeometry(QtCore.QRect(260, 10, 111, 16))
        self.label_2.setObjectName("label_2")
        self.label_3 = QtWidgets.QLabel(Dialog)
        self.label_3.setGeometry(QtCore.QRect(500, 10, 91, 16))
        self.label_3.setObjectName("label_3")
        
        self.splitter_3 = QtWidgets.QSplitter(Dialog)
        self.splitter_3.setGeometry(QtCore.QRect(20, 90, 621, 20))
        self.splitter_3.setOrientation(QtCore.Qt.Horizontal)
        self.splitter_3.setObjectName("splitter_3")
        self.shp_directory = QgsFileWidget(self.splitter_3)
        self.shp_directory.setObjectName("mQgsFileWidget")
        self.csv_directory = QgsFileWidget(self.splitter_3)
        self.csv_directory.setObjectName("mQgsFileWidget_2")
        self.export_directory = QgsFileWidget(self.splitter_3)
        self.export_directory.setObjectName("mQgsFileWidget_3")
        self.svg_directory = QgsFileWidget(self.splitter_3)
        self.svg_directory.setObjectName("mQgsFileWidget_3")
        self.ipo_pt_directory = QgsFileWidget(self.splitter_3)
        self.ipo_pt_directory.setObjectName("mQgsFileWidget_3")
        
        self.splitter_4 = QtWidgets.QSplitter(Dialog)
        self.splitter_4.setGeometry(QtCore.QRect(20, 70, 621, 16))
        self.splitter_4.setOrientation(QtCore.Qt.Horizontal)
        self.splitter_4.setObjectName("splitter_4")
        self.label_4 = QtWidgets.QLabel(self.splitter_4)
        self.label_4.setObjectName("label_4")
        self.label_5 = QtWidgets.QLabel(self.splitter_4)
        self.label_5.setObjectName("label_5")
        self.label_6 = QtWidgets.QLabel(self.splitter_4)
        self.label_6.setObjectName("label_6")
        self.label_7 = QtWidgets.QLabel(self.splitter_4)
        self.label_7.setObjectName("label_7")
        self.label_8 = QtWidgets.QLabel(self.splitter_4)
        self.label_8.setObjectName("label_8")
        
        self.splitter = QtWidgets.QSplitter(Dialog)
        self.splitter.setGeometry(QtCore.QRect(20, 30, 621, 20))
        self.splitter.setOrientation(QtCore.Qt.Horizontal)
        self.splitter.setObjectName("splitter")
        self.code_nro = QtWidgets.QLineEdit(self.splitter)
        self.code_nro.setObjectName("lineEdit")
        self.nro_rat = QtWidgets.QLineEdit(self.splitter)
        self.nro_rat.setObjectName("lineEdit_2")
        self.mDateTimeEdit = QgsDateTimeEdit(self.splitter)
        self.mDateTimeEdit.setObjectName("mDateTimeEdit")

        self.retranslateUi(Dialog)
        self.buttonBox.accepted.connect(Dialog.accept)
        self.buttonBox.rejected.connect(Dialog.reject)
        QtCore.QMetaObject.connectSlotsByName(Dialog)

    def retranslateUi(self, Dialog):
        _translate = QtCore.QCoreApplication.translate
        Dialog.setWindowTitle(_translate("Dialog", "Traitement LFD VAR"))
        self.textBrowser.setHtml(_translate("Dialog",
                                            "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
                                            "<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
                                            "p, li { white-space: pre-wrap; }\n"
                                            "</style></head><body style=\" font-family:\'MS Shell Dlg 2\'; font-size:8.25pt; font-weight:400; font-style:normal;\">\n"
                                            "<p style=\" margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:7.8pt; font-weight:600;\">Objectifs</span><span style=\" font-size:7.8pt;\"> </span></p>\n"
                                            "<p style=\" margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:7.8pt;\">Ce module permet de lancer le traitement LFD des données importées en base de données, et d’exporter les résultats sou forme d’un fichier Excel (un  onglet par requête). </span></p>\n"
                                            "<p style=\" margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:7.8pt;\">  </span></p>\n"
                                            "<p style=\" margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:7.8pt; font-weight:600;\">Données d’entrée</span><span style=\" font-size:7.8pt;\"> </span></p>\n"
                                            "<p style=\" margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:7.8pt;\">Données transmises par le client, préparées au format CSV et SHP tout en respectant les noms ci-dessous: </span></p>\n"
                                            "<h5>1. CSV (</span><span style=\" font-size:7.8pt; background-color:#ffff00;\">liste des CSV attendus</span><span style=\" font-size:7.8pt;\">):</h5>\n"
                                            "<div> Chambre FTTH.csv</div>\n"
                                            "<div> ipon.csv</div>\n"
                                            "<div> Optimum.csv</div>\n"
                                            "<h5>2. Shapefiles (</span><span style=\" font-size:7.8pt; background-color:#ffff00;\">liste des Shapefiles attendus</span><span style=\" font-size:7.8pt;\">):</h5>\n"
                                            "<div> ftth_cable.shp</div>\n"
                                            "<div> ftth_parcours.shp</div>\n"
                                            "<div> ftth_pf.shp</div>\n"
                                            "<div> ftth_site_appui_erdf.shp</div>\n"
                                            "<div> ftth_site_appui_ft.shp</div>\n"
                                            "<div> ftth_site_immeuble.shp</div>\n"
                                            "<div> ftth_zone_eligibilite.shp</div>\n"

                                            "<p style=\" margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:7.8pt;\">  </span></p>\n"
                                            "<p style=\" margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:7.8pt; font-weight:600;\">Résultat</span><span style=\" font-size:7.8pt;\"> </span></p>\n"
                                            "<p style=\" margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:7.8pt;\">Les données sont intégrées en base de données dans un schéma dédié (gestion des versions), les résultats du traitement sont enregistrés au format Excel (avec un onglet pour chaque résultat de requête) </span></p>\n"
                                            "<p style=\" margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:7.8pt;\">  </span></p>\n"
                                            "<p style=\" margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:7.8pt; font-weight:600;\">Contraintes</span><span style=\" font-size:7.8pt;\"> </span></p>\n"
                                            "<p style=\" margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:7.8pt;\">Renseigner le « Code NRO » (INSEE &amp; 3 DIGIT), Renseigner le « NRO de rattachement » (COMMUNE), renseigner la « Date de livraison » (via le calendrier), le chemin cible des Shapefiles, le chemin cible des CSV, le chemin cible de l’export des résultats. </span></p></body></html>"))
        self.label.setText(_translate("Dialog", "Code NRO :"))
        self.label_2.setText(_translate("Dialog", "NRO de rattachement :"))
        self.label_3.setText(_translate("Dialog", "Date de livraison :"))
        self.label_4.setText(_translate("Dialog", "Dossier Shapefiles :"))
        self.label_5.setText(_translate("Dialog", "Dossier CSV :"))
        self.label_6.setText(_translate("Dialog", "Dossier cible :"))
        self.label_7.setText(_translate("Dialog", "Dossier SVG :"))
        self.label_8.setText(_translate("Dialog", "Dossier Ipon_PT :"))


class ClassGeneralDialog(QtWidgets.QDialog):
    def __init__(self, iface):
        QtWidgets.QDialog.__init__(self)
        self.iface = iface

    @staticmethod
    def get_version_plugin():
        folder_metada = open(f"{folder_plugin}\metadata.txt")
        for line in folder_metada:
            if str(line)[:7] == 'version':
                get_version = line.split('=')[1]
                folder_metada.close()
                return get_version


class ClassImportExecuteLfd(ClassGeneralDialog, UiDialog):
    def __init__(self, iface):
        ClassGeneralDialog.__init__(self, iface)
        self.setupUi(self)
        self.setWindowTitle("LFD " + str(self.get_version_plugin()) + " - Traitement LFD VAR ")
        self.shp_directory.setStorageMode(QgsFileWidget.GetDirectory)
        self.csv_directory.setStorageMode(QgsFileWidget.GetDirectory)
        self.export_directory.setStorageMode(QgsFileWidget.GetDirectory)
        self.svg_directory.setStorageMode(QgsFileWidget.GetDirectory)
        self.ipo_pt_directory.setStorageMode(QgsFileWidget.GetDirectory)
        self.buttonBox.button(QtWidgets.QDialogButtonBox.Ok).clicked.connect(self.run)

    def run(self):
        name_date = self.mDateTimeEdit.date().toString("yyyyMMdd")
        nom_nro = self.code_nro.text()
        nom_nro_rat = self.nro_rat.text()
        schema = '"' + str(nom_nro).lower() + '_' + str(nom_nro_rat).lower() + '_' + 'v_' + str(name_date) + '"'

        # {var_file_sql_annexe = str(folder_plugin) + "/file_sql/requete_lfd.sql"
        path_folder_shp = str(self.shp_directory.filePath())
        path_folder_csv = str(self.csv_directory.filePath())
        path_folder_export = str(self.export_directory.filePath())
        path_folder_svg = str(self.svg_directory.filePath())
        path_folder_pt = str(self.ipo_pt_directory.filePath())

        if not schema:  # len(text_titulaire) != 1 or  un seul MOE et
            QtWidgets.QMessageBox.critical(iface, "Message Du Choix", 'Veillez choisir un nom de schema')
        else:
            function_execute_class_general_var(schema, path_folder_export, path_folder_shp, path_folder_csv, path_folder_svg, path_folder_pt)


# # {
# baba_dialog = ClassImportExecuteLfd(iface)
# baba_dialog.show()
# sys.exit(app.exec_())