# **Plugin de Contrôle des données sur le projet LFD ATHD**
Ce Plugin est composé de deux parties, Import des données, Traitement LFD ATHD. Le Contrôle de données se fait par un lancement d'une serie de traitements qui seront décrits ci-dessous. Pour avoir plus de détails sur les Contrôles, reportez vous sur le [Fichier Spec des Contrôles](./assets/docs_spec/Details_Requetes_LFD_ATHD.xlsx).
## ***Import des données :***
- ### ***Objectif :***
Ce module permet de lancer les traitements LFD des données importées en base de données, et d’exporter les résultats sous forme d’un fichier Excel (un  onglet par requête). La base de données est celle configurée dans le projet : lfd_bdd.
- ### ***Données d’entrée :***
    [Exemple données d'entrée](./assets/docs_spec/donnees_sources.zip)
    - #### CSV (liste des CSV attendus):
        - ##### ipon.csv
        - ##### Optimum.csv
    - #### Shapefiles (liste des Shapefiles attendus):
        - ##### RBAL_Phase2.shp
        - ##### Contours_PMZ.shp
        - ##### Couverture_FTTH_Phase2.shp
        - ##### ftth_pf.shp
        - ##### ftth_site_immeuble.shp
        - ##### ftth_zone_eligibilite.shp
        - ##### IMB_NRO.shp
        - ##### PDD_Zone_PER_Phase2.shp
        - ##### RBAL_Phase2.shp
- ### ***Variables demandés :***
    - #### Code NRO
    - #### Code NRO de rattachement: COMMUNE
    - #### Choix de la date: via le calendrier
    - #### Choix dossier des Shapefiles
    - #### Choix dossier des CSV
    - #### Choix dossier des etiquettes
    - #### Choix dossier de l’export des résultat
- ### ***Résultats :***
    Les données sont intégrées en base de données dans un schéma dédié (gestion des versions), les résultats du traitement sont enregistrés dans la base de données et exportées au format Excel (avec un onglet pour chaque résultat de requête)
- ### ***Contraintes :***
    Toutes les données d'entrée doivent etre conformes et toutes les variables doivent etre renseignées
- ### ***Mode opératoire :***
    ![Erreur Image](assets/app_athd.png)
## ***Contrôle des données***
- ### ***Objectif :***
    Il est de réaliser cinquante contrôles qui sont :
    - ###### Contrôle IN02.1; Description: Calendrier de Déploiement; SUP
    - ###### Contrôle IN04.1; Description: Rapport des « échecs de raccordement »; SUP
    - ###### Contrôle IN03.1; Description: Requête ARCEP; SUP
    - ###### Contrôle IN07.1; Description: Requête IPON
    - ###### Contrôle IN01.1; Description: Requête OPTIMUM; SUP
    - ###### Contrôle IN06.1; Description: Shapefiles APS
    - ###### Contrôle SHP; Description: Cartographie du déploiement à l'echelle du NRO
    - ###### Contrôle SHP; Description: APD Génie Civil
    - ###### Contrôle IN05.1; Description: Shapefiles LFD
    - ###### Contrôle IN08.1; Description: Requête GEOFIBRE
    - ###### Contrôle TR01.1; Description: Nombre de prises total par commune
    - ###### Contrôle TR02.1; Description: Nombre de prises dans la zone de couverture par commune
    - ###### Contrôle TR04.1; Description: Prises en PB non collectifs raccordables
    - ###### Contrôle TR05.1; Description: Prises en PB collectifs raccordables; SUP
    - ###### Contrôle TR06.1; Description: Prises en PB collectifs éligible PA « REFUS »; SUP
    - ###### Contrôle TR07.1; Description: Objectif prises contractuelles 
    - ###### Contrôle TR08.1; Description: Nombre de prises raccordables contrat région; SUP
    - ###### Contrôle TE01.1; Description: 6 mois révolus après la pose du dernier PB de Rue
    - ###### Contrôle TE03.1; Description: Prises ouvertes commercialement sur toutes les communes rattachées au NRO; SUP
    - ###### Contrôle RACCO; Description: Taux d’échec de raccordement =<5% sur 8 semaines; SUP
    - ###### Contrôle TE04.1; Description: Traitement de tous les logements collectifs en zone PER; SUP
    - ###### Contrôle TE04.2; Description: Traitement de tous les logements collectifs hors zone PER
    - ###### Contrôle OC02.1; Description: Cohérence entre la carte de couverture réalisée et celle fournie en avant-vente (geometrie)
    - ###### Contrôle IG01.1; Description: Un seul PB par chambre et par appui ORANGE 
    - ###### Contrôle IG01.2; Description: anomalie nom_site_pf_pb et position_d_equipement_pt_pb
    - ###### Contrôle IG02.1; Description: PB posés à tort en chambre pour des adductions en façade
    - ###### Contrôle IG03.1; Description: Distances de raccordement excessif 
    - ###### Contrôle IG05.1; Description: Cohérence de l’ingénierie : 4 têtes maximum par PM
    - ###### Contrôle IG05.2; Description: Cohérence de l’ingénierie : Réserve au PM
    - ###### Contrôle IG06.1; Description: Cohérence de l’ingénierie : Réserve au PB 
    - ###### Contrôle IG06.2; Description: Cohérence de l’ingénierie : Réserve au PB 
    - ###### Contrôle IG06.3; Description: Cohérence de l’ingénierie : Réserve au PB 
    - ###### Contrôle IA01.1; Description: anomalie du type_longu ou du statut_ftth
    - ###### Contrôle IA01.2; Description: Bilan des linéaires complets
    - ###### Contrôle IA01.3; Description: Bilan des linéaires complets
    - ###### Contrôle SI01.1; Description: Zones d’éligibilité des PB
    - ###### Contrôle SI13.1; Description: Zones d’éligibilité des PB
    - ###### Contrôle SI01.2; Description: sites immeubles a ajouter/retirer des ZE PF PB IPON part1
    - ###### Contrôle SI01.3; Description: sites immeubles a ajouter/retirer des ZE PF PB IPON part2
    - ###### Contrôle SI02.1; Description: Injection de tous les immeubles dans GEOFIBRE (OPTIMUM/GFI)
    - ###### Contrôle SI03.1; Description: Clôture des projets sous GEOFIBRE
    - ###### Contrôle SI04.1; Description: Documents des collectifs dans OPTIMUM
    - ###### Contrôle SI05.1; Description: Hauteur des équipements dans IPON
    - ###### Contrôle SI06.1; Description: Présence des adresses dans OPTIMUM (GFI/RBAL)
    - ###### Contrôle SI07.1; Description: Raccordements complexes et à la demande
    - ###### Contrôle SI08.1; Description: Etat des PB  actif.
    - ###### Contrôle SI10.1; Description: remonter la liste des sites bloqués (attributs)
    - ###### Contrôle SI11.1; Description:  Conventions façades présentes sous OPTIMUM
    - ###### Contrôle SI12.1; Description: comparaison des sites supports GFI/IPON
    - ###### Contrôle SI12.2; Description: comparaison des sites supports GFI/IPON
- ### ***Résultats :***
    Les résultats du traitement sont enregistrés dans la base de données et exportées au format Excel (avec un onglet pour chaque résultat de requête)  
    ![Erreur Image](assets/ctrl_result.png)  
    [Exemple de resultat exportés](./assets/docs_spec/export_res.xls)
- ### ***Contraintes :***
    Toutes les données d'entrée doivent etre conformes et toutes les variables doivent etre renseignées