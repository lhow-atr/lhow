# Changelog Notes
## Tags
v_2023_01_03    Tags Version v_2023_01_03
v_2023_01_16    Tags Version v_2023_01_16
v_2023_01_17    Tags Version v_2023_01_17
v_2023_01_18    Tags Version v_2023_01_18
vd_2021_01_07   Mise en Dev
vp_2021_01_07   Mise en Prod
vt_2020.12.16   deploiement version test du 2020.12.16
vt_2020_12_16   Second Tag
## Commits
- suppression des fichiers suivants: Calendrier.csv, Raccordement.csv, Extraction MESC ARCEP.csv, Adresses_Optimum.csv; retrait des requetes suivantes: TR05.1, TR06.1, TR08.1, TE03.1, RACCO/Manuel, TE04.1; modifications des requetes suivantes: (TR07.1: remplacer le CSV calendrier par le CSV optimum; remplacer TOTAL indicatif prises raccordables par Nombre de logements; Ajout condition: Zone = EXP_P3_PER), (IA01.2: Ajout Coalesce), (IA01.3: Ajout attributs), (SI05.1: remonter AERIEN qui sont HH, CHAMBRE n'est pas HH) (3736ccd) (Babacar FASSA) (2023-01-18)
- suppression des fichiers suivants: Calendrier.csv, Raccordement.csv, Extraction MESC ARCEP.csv, Adresses_Optimum.csv; retrait des requetes suivantes: TR05.1, TR06.1, TR08.1, TE03.1, RACCO/Manuel, TE04.1; modifications des requetes suivantes: (TR07.1: remplacer le CSV calendrier par le CSV optimum; remplacer TOTAL indicatif prises raccordables par Nombre de logements; Ajout condition: Zone = EXP_P3_PER), (IA01.2: Ajout Coalesce), (IA01.3: Ajout attributs), (SI05.1: remonter AERIEN qui sont HH, CHAMBRE n'est pas HH) (a99a53a) (Babacar FASSA) (2023-01-18)
- Correction erreur mise a jour plugin (9fa69a7) (Babacar FASSA) (2023-01-17)
- Correction erreur qmessageBox et ajout le changelog dans la documentation (0ff4fb5) (Babacar FASSA) (2023-01-16)
- Migration vers qgis3.22 version finale avec ajout de la methode du deploiement continu ainsi que la documentation avec mkdocs et la creation de tag a chaque modifications (57afa1f) (Babacar FASSA) (2023-01-03)
- Creation configuration pour la Mise en prod automatique avec Gitlab (4a920ab) (Babacar FASSA) (2023-01-02)
- Test Mise en prod avec Gitlab (88ba38b) (Babacar FASSA) (2023-01-02)
- Test Mise en prod avec Gitlab (5eb2ea1) (Babacar FASSA) (2023-01-02)
- Test Mise en prod avec Gitlab (8de88cd) (Babacar FASSA) (2023-01-02)
- Test Mise en prod avec Gitlab (098cb7a) (Babacar FASSA) (2023-01-02)
- Test Mise en prod avec Gitlab (3bdced0) (Babacar FASSA) (2023-01-02)
- Test Mise en prod avec Gitlab (4984b44) (Babacar FASSA) (2023-01-02)
- Test Mise en prod avec Gitlab (4ceb052) (Babacar FASSA) (2023-01-02)
- Test Mise en prod avec Gitlab (0d1b3f6) (Babacar FASSA) (2023-01-02)
- Test Mise en prod avec Gitlab (2f59958) (Babacar FASSA) (2023-01-02)
- Test Mise en prod avec Gitlab (bf19b9e) (Babacar FASSA) (2023-01-02)
- Test Mise en prod avec Gitlab (a6cd9d5) (Babacar FASSA) (2023-01-02)
- Test Mise en prod avec Gitlab (7c6728c) (Babacar FASSA) (2023-01-02)
- Test Mise en prod avec Gitlab (fb78829) (Babacar FASSA) (2023-01-02)
- Test Mise en prod avec Gitlab (16123db) (Babacar FASSA) (2023-01-02)
- Test Mise en prod avec Gitlab (3352476) (Babacar FASSA) (2023-01-02)
- Test Mise en prod avec Gitlab (0e71b78) (Babacar FASSA) (2023-01-02)
- Test Mise en prod avec Gitlab (eeb57c4) (Babacar FASSA) (2023-01-02)
- Test Mise en prod avec Gitlab (d6b1336) (Babacar FASSA) (2023-01-02)
- Test Mise en prod avec Gitlab (b5ee296) (Babacar FASSA) (2023-01-02)
- Test Mise en prod avec Gitlab (22e5d3f) (Babacar FASSA) (2023-01-02)
- Test Mise en prod avec Gitlab (ebe8f1b) (Babacar FASSA) (2023-01-02)
- Test Mise en prod avec Gitlab (c87d8c2) (Babacar FASSA) (2023-01-02)
- Test Mise en prod avec Gitlab (b3e1bd0) (Babacar FASSA) (2023-01-02)
- Test Mise en prod avec Gitlab (94a7b6b) (Babacar FASSA) (2023-01-02)
- Migration vers qgis3.22 version finale avec ajout de la methode du deploiement continu ainsi que la documentation avec mkdocs (f5bcc2b) (Babacar FASSA) (2022-12-30)
- IMP: IG01.2 ==> A Faire Ajouter la condition si nom_site_pf_pb != nom_sissi_local_technique_pt_pb hormis les imb avec facade et loc_.IA01.2 ==> A Faire Remplacer Appui FTHH = Appui télécom FTTH; Appui ERDF = Appui commun FTTH. SI13.1 ==> A Faire Controle des superpositions des zones eligibilites. les requetes a retirer dans les résultats: TR03.1, TE02.1,OC01.1,OC03.1,IG04.1, IG07.1 (fcdf8ef) (Babacar FASSA) (2021-09-13)
- IMP:IG01.2 ==> A Faire Ajouter la condition si nom_site_pf_pb != nom_sissi_local_technique_pt_pb hormis les imb avec facade et loc_ (9722d28) (Babacar FASSA) (2021-09-13)
- IMP : Correction du Git (064b0a0) (babfas) (2021-06-24)
- Remove duplicated directory (10cade3) (babfas) (2021-06-24)
- Remove duplicated directory (36ab776) (babfas) (2021-06-24)
- Remove duplicated directory (76eef77) (babfas) (2021-06-24)
- Merge branch 'bfa_lfd' into 'master' (5665805) (Babacar) (2021-03-31)
- "IMP: DEV: TR, TE : retirer la condition "verifier que le site est dans la zone de couverture (DSP_ATHD_PHASE2_PER_RAC)" IG01.1 : utiliser "ADRESSE_LOCALISATION_SITE_PF_PB" plutot que "NOM_COMMUNE_PM" a verifier, la chambre CH/00213 a 2 PT et n'est pas remonter (ST FLOUR) IG01.2 : doublon dans le resultat utiliser "ADRESSE_LOCALISATION_SITE_PF_PB" plutot que "NOM_COMMUNE_PM" IG03.1 : verifier que distance = distance *1.3 IG04.1 : voir la methode de comptage (retirer la condition "verifier que le site est dans la zone de couverture (DSP_ATHD_PHASE2_PER_RAC)") IA01.2 : sortir la liste des cables comptés (nouvelle requete?) SI11.1 : revoir les regles de la macro + colonne a afficher NOM_COMMUNE_PM NOM_DU_PM_REG       NOM_DU_PA_REG         NOM_DU_PF_PA            NOM_DU_PF_PB                DESCRIPTION_PF_PB     NOM_DU_PT_PB    NOM_SITE_PF_PB   POSITION_D_EQUIPEMENT_PT_PB       ADRESSE_LOCALISATION_SITE_PF_PB SI05.1 : doublon dans le resultat - ajouter colonne PT_PB SI01.2 : utiliser "ADRESSE_LOCALISATION_SITE_PF_PB" plutot que "NOM_COMMUNE_PM" SI01.3 : utiliser "ADRESSE_LOCALISATION_SITE_PF_PB" plutot que "NOM_COMMUNE_PM" pas present dans l'export SI08.1 : utiliser "ADRESSE_LOCALISATION_SITE_PF_PB" plutot que "NOM_COMMUNE_PM" " (8aadfb4) (Babacar) (2021-03-31)
- Merge branch 'bfa_lfd' into 'master' (5f00560) (Babacar) (2021-03-22)
- "IMP:     POSITION_D_EQUIPEMENT_PT_PB         DF:poteauEDF est devenu AERIEN POTEAU ENEDIS         PO:poteau FT est devenu AERIEN POTEAU ORANGE         CH:en chambre est devenu CHAMBRE         FR:facade côté rue/gaine technique sont devenu FACADE COTE RUE / IMMEUBLE APPARENT / IMMEUBLE GAINE TECHNIQUE (007cbcf) (fassababacar) (2021-03-19)
- Merge branch 'bfa_lfd' into 'master' (3b13aa6) (Babacar) (2021-03-05)
- "IMP:     Les modifications pour une nouvelle mise sont faites. La version à installer est : « 2021.03.05 »     1.	Nouvelles requêtes     a.	SI01.1     Sortir toutes les entités de la table « ftth_pf » ayant pas de correspondance avec celles de la table « ftth_zone_eligibilité »  avec le filtre sur l’attribut « id_metier_ » de la table « ftth_pf » contient « PB »     b.	SI01.2     Intersection entre la table « ftth_site_immeuble » et  « ftth_zone_eligibilité », comparaison du résultat de l’intersection avec la table « requete_ipon » et vérifier les 5 dernier digits de l’attribut « id_metier_ » de la table « ftth_zone_eligibilité » et celui des 8 premiers digits (en supprimant les trois premiers digits) de l’attribut « description_pf_pb » de la table « requete_ipon »     2.	Mise à jour     a.	Nouveaux attributs     i.	description_du_site_commentaires     ii.	nom_site_pf_pb     b.	Nouvelles tables dans l’export     i.	IA01.1     ii.	IA01.2 " (88bc3e4) (fassababacar) (2021-03-05)
- Merge branch 'bfa_lfd' into 'master' (053dcee) (Babacar) (2021-03-02)
- "IMP: Ajout des nouvelles requetes ainsi que des modifications sur les requetes" (c754a9b) (fassababacar) (2021-03-02)
- Merge branch 'bfa_lfd' into 'master' (c0f7e12) (Babacar) (2021-01-07)
- "IMP: Mise en Prod" (841dbe1) (Babacar) (2021-01-07)
- "IMP: Mise en Dev" (edad9fb) (Babacar) (2021-01-07)
- Merge branch 'bfa_lfd' into 'master' (91f86ae) (Babacar) (2020-12-16)
- "IMP: Ajout des modifications pour mettre à jour les noms des fichiers en generiques" (4558535) (Babacar) (2020-12-16)
- Merge branch 'bfa_lfd' into 'master' (93778d3) (Babacar) (2020-12-08)
- "IMP: Test premiere branch réussi avec Succés" (23db16a) (Babacar) (2020-12-08)
- Merge branch 'bfa_lfd' into 'master' (b1aca2b) (Babacar) (2020-12-07)
- "IMP: Test premiere branch réussi avec Succés" (63f22e0) (Babacar) (2020-12-07)
- Merge branch 'bfa_lfd' into 'master' (aab2e3e) (Babacar) (2020-12-07)
- "IMP: Test premiere branch" (797e0d3) (Babacar) (2020-12-07)
- Initial commit (d3497ad) (Babacar) (2020-12-07)
## Merges
- IMP : Correction du Git (064b0a0)
- Merge branch 'bfa_lfd' into 'master' (5665805)
- Merge branch 'bfa_lfd' into 'master' (5f00560)
- Merge branch 'bfa_lfd' into 'master' (3b13aa6)
- Merge branch 'bfa_lfd' into 'master' (053dcee)
- Merge branch 'bfa_lfd' into 'master' (c0f7e12)
- Merge branch 'bfa_lfd' into 'master' (91f86ae)
- Merge branch 'bfa_lfd' into 'master' (93778d3)
- Merge branch 'bfa_lfd' into 'master' (b1aca2b)
- Merge branch 'bfa_lfd' into 'master' (aab2e3e)
## AUTHORS
- Babacar
- Babacar FASSA
- babfas
- fassababacar
