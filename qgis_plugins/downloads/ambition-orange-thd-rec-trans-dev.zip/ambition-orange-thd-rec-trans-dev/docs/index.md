# **Plugin de controle des données sur le projet Orange BTHD**
Ce Plugin permet de lancer des traitements THDB sur les données importées en base de données. L'ensemble des traitement seront décrits ci-dessous. Pour avoir plus de détails sur les controles, reportez vous sur le [Fichier Spec des controles](./assets/docs_spec/DICO_POINTS_CONTROLEvPIEPOM.xlsx).
## ***Modélisation***
Les données sources sont au format GraceTHD. Sur ces données, on peut avoir la partie transport, distribution, collecte etc. Afin de réaliser nos controles uniquement sur le transport, on a fait préalablement une modélisation pour extraire uniquement la partie transport. Cette modélisation est faite par des requetes se basant sur les attributs et les géométries.  
Exemple, pour extraire les cables et cheminement du transport, on se base sur la condition cb_typelog = 'TR' et cm_typelog in ('TR', 'TD').  
Pour les noeuds, on fusionne (sans doublon) tous les cb_nd1, cb_nd2 des cables déjà extraits, cm_ndcode1, cm_ndcode2 des cheminements déjà extraits et zd_nd_code des zones dep déjà extraites.  
Pour les sites techniques, on regardes les noeuds déjà extraits qui correspondent à la donnée source des sites techniques.  
En résumé, cette modélisation est faite de maniére relationnelle pour certaines tables et de maniére géométrique pour d'autre tables.
## ***Objectif :***
- Il est de réaliser cinante-huit contrôles qui sont :
    - ###### Contrôle RNRO.001 sur t_sitetech; Descripton: Shelter = Megalis NRA/bâtiment = Orange
    - ###### Contrôle RNRO.002 sur t_znro; Descripton: Toujours NRO-PON-PTP
    - ###### Contrôle RNRO.003 sur t_sitetech; Descripton: SHELTER OU BATIMENT
    - ###### Contrôle RNRO.004 sur t_noeud; Descripton: Format, erreur de typo
    - ###### Contrôle RNRO.005 sur t_sitetech; Descripton: Si transport en cours = EXISTANT > cf.  st_avct Si distri en cours = DEPLOYE > cf. zn_etat, EN SERVICE pour les elements construit EXISTANT pour la location
    - ###### Contrôle RNRO.011 sur t_tiroir; Descripton: Remonter les entités pour tous les ti_type = TETE et ti_code différent de ti_placement
    - ###### Contrôle RSRO.002 sur t_sitetech; Descripton: Toujours MEGALIS
    - ###### Contrôle RSRO.003 sur t_sitetech; Descripton: Toujours ADR
    - ###### Contrôle RSRO.004 sur t_sitetech; Descripton: Toujours SRO
    - ###### Contrôle RSRO.006 sur t_noeud; Descripton: Format, erreur de typo BLOCAGE JUSQU'AU NOM DE RUE
    - ###### Contrôle RSRO.007 sur t_zsro; Descripton: Toujours PM400 ou PM700, comparer à la référence IPON et câlage Source IPON ? Nombre de tete? lié à la reference de modele, lié à la hauteur de la baie (x2) contrôle du cable, des tetes dans OGRE
    - ###### Contrôle RSRO.009 sur t_sitetech; Descripton: Si transport en cours = EXISTANT Si distri en cours = DEPLOYE == Service
    - ###### Contrôle RSRO.012 sur t_noeud; Descripton: Vérifier tranche de déploiement + département rec
    - ###### Contrôle RSRO.013 sur t_noeud; Descripton: Vérifier code affaire rec
    - ###### Contrôle RSRO.014 sur t_noeud; Descripton: Nœud Megalis Bretagne + trigramme NRO rec
    - ###### Contrôle RSRO.015 sur t_noeud; Descripton: Nœud Megalis Bretagne + trigramme NRO + code armoire MEGALIS ou trouver le code armoire MEGALIS rec
    - ###### Contrôle REBP.001 sur BOITIER; Descripton: Si 'PA' :  MB;bp_code;zn_r3_code;PT xxxxx (PA);insee /NRO Sinon : MB;bp_code;zn_r3_code;PT xxxxx ;insee /NRO rec un nœud avec une zdep comment PA
    - ###### Contrôle REBP.002 sur BOITIER; Descripton: Toujours MEGALIS
    - ###### Contrôle REBP.003 sur BOITIER; Descripton: Toujours MEGALIS
    - ###### Contrôle REBP.004 sur BOITIER; Descripton: Toujours EXISTANT, ou EN SERVICE pour les contrôles en cours ?
    - ###### Contrôle REBP.008 sur BOITIER; Descripton: Comparer avec la référence OGRE comment extraire la donnée ? Nombre max de K7 compter nombre de casette modelisees (hors virtuelle)  < nb_ca < nb_max
    - ###### Contrôle REBP.012 sur BOITIER; Descripton: Pas de chevauchement ZPBO se chevauche si PBO dans la meme chambre (avertissemtn) ZPBO des immeubles (non bloquant)
    - ###### Contrôle RCAB.001 sur CABLE; Descripton: MEGALIS BRETAGNE + CAPACITE + FONCTION + DATE DE POSE + cb_code + nd_r3_code + cb_rf_code + cb_codeext structure , déjà fait dans OGRE
    - ###### Contrôle RCAB.002 sur CABLE; Descripton: Vérifier tranche de déploiement + département CF PLUS HAUT
    - ###### Contrôle RCAB.003 sur CABLE; Descripton: Vérifier code affaire CF PLUS HAUT
    - ###### Contrôle RCAB.004 sur CABLE; Descripton: Toujours MEGALIS
    - ###### Contrôle RCAB.005 sur CABLE; Descripton: Toujours MEGALIS
    - ###### Contrôle RCAB.006 sur CABLE; Descripton: Toujours REC
    - ###### Contrôle RCAB.007 sur CABLE; Descripton: Toujours EXISTANT , ou en service pour les contrôles en cours
    - ###### Contrôle RCAB.008 sur CABLE; Descripton: Toujours C 
    - ###### Contrôle RCAB.009 sur CABLE; Descripton: Toujours TR en transport
    - ###### Contrôle RCAB.010 sur CABLE; Descripton: Contrôle OGRE
    - ###### Contrôle RCAB.011 sur CABLE; Descripton: Comparer avec les dimensions validées THDB suivant RI, MEGALIS TR 72 144 288 432 576 720 EN M12 DI 12 24 36 48 72 144 M6
    - ###### Contrôle RCAB.012 sur CABLE; Descripton: Contrôle OGRE DOIT ETRE < cb_capafo
    - ###### Contrôle RCAB.013 sur CABLE; Descripton: Toujours 12 en transport
    - ###### Contrôle RCAB.014 sur CABLE; Descripton: RI à connaître par rapport référence câble suivant RI BLO / cable validés MB suivant liste des cables, et dmin / dmax integrer en table
    - ###### Contrôle RCAB.015 sur CABLE; Descripton: 15% cb_long + ne doit pas dépasser 2km sur cb.geom exception : si ligne droite
    - ###### Contrôle RCAB.016 sur CABLE; Descripton: Calcul automatique sur cb.geom (tolerance 20m)
    - ###### Contrôle RPTE.001 sur POINT TECHNIQUE; Descripton: Vérifier identification du propriétaire base sur les etiquettes attention au prop non identifié > PRIVE
    - ###### Contrôle RPTE.002 sur POINT TECHNIQUE; Descripton: Vérifier identification du gestionnaire base sur les etiquettes POUR LES INFRAS CRÉES UNIQUEMENT
    - ###### Contrôle RPTE.003 sur POINT TECHNIQUE; Descripton: Vérifier la conformité par rapport au pt_prop MB > CST SINON LOC
    - ###### Contrôle RPTE.004 sur POINT TECHNIQUE; Descripton: Vérifier par rapport au pt_prop (cas par cas) les MB sont en C
    - ###### Contrôle RPTE.005 sur POINT TECHNIQUE; Descripton: Type de site support (C = chambre, A = appui, I = immeuble)
    - ###### Contrôle RPTE.006 sur POINT TECHNIQUE; Descripton: Tirage ou Raccordement
    - ###### Contrôle RPTE.007 sur POINT TECHNIQUE; Descripton: Nature du site support verifier la taille de la chambre // nombre de boite cf. BLO pas PA en aerien
    - ###### Contrôle RPTE.008 sur POINT TECHNIQUE; Descripton: Vérifier tranche de déploiement + département rec
    - ###### Contrôle RPTE.009 sur POINT TECHNIQUE; Descripton: Vérifier code affaire rec
    - ###### Contrôle RPTE.010 sur POINT TECHNIQUE; Descripton: Format, erreur de typo minima INSSE COMMUNE
    - ###### Contrôle RPTE.011 sur POINT TECHNIQUE; Descripton: Toujours PT
    - ###### Contrôle RCHE.001 sur CHEMINEMENT; Descripton: Vérifier tranche de déploiement + département rec
    - ###### Contrôle RCHE.002 sur CHEMINEMENT; Descripton: Vérifier code affaire rec
    - ###### Contrôle RCHE.003 sur CHEMINEMENT; Descripton: Vérifier par rapport au pt_prop toujours en REC
    - ###### Contrôle RCHE.004 sur CHEMINEMENT; Descripton: Vérifier par rapport au pt_prop (cas par cas) toujours en E
    - ###### Contrôle RCHE.005 sur CHEMINEMENT; Descripton: Vérifier par rapport à livraison (Transport, distri ou les deux) fonction des cables, geom TR
    - ###### Contrôle RCHE.006 sur CHEMINEMENT; Descripton: Toujours TEL
    - ###### Contrôle RCHE.007 sur CHEMINEMENT; Descripton: 15% cb_long + ne doit pas dépasser 2km
    - ###### Contrôle RCHE.008 sur CHEMINEMENT; Descripton: Calcul automatique tolerance 1m sur geom
    - ###### Contrôle RCHE.009 sur CHEMINEMENT; Descripton: Vérifier au cheminement fonction des points techniques A > A > AERIEN A > C > CONDUITE C > C > CONDUITE

- ## ***Variables demandés :***
    - ###### Nom du schéma d'étude à sélectionner
    - ###### Code du déploiement + Département
    - ###### Code NRO ou SRO du départ de parcours
    - ###### Code Affaire
    - ###### Code Trigramme NRO
    - ###### Code INSEE NRO
    - ###### Code Armoire
- ## ***Résultats :***
    Les résultats sont dans la table: t_controle dans le schema étude declaré de l'interface
- ## ***Contraintes :***
    Tous les variables de l'interface doivent etre renseignés et correspondants aux données. 
- ## ***Mode opératoire :***
![Erreur Image](assets/ctrl_transport.png)
![Erreur Image](assets/ctrl_transport_message.png)