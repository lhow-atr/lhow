# -*- coding: utf-8 -*-
"""
/***************************************************************************
 ambition-orange-thd-rec-trans-prod
                                 A QGIS plugin
 Description
                             -------------------
        copyright            : (C) 2022 by Babacar FASSA
        email                : fassa_b@yahoo.fr
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
 This script initializes the plugin, making it known to QGIS.
"""


# noinspection PyPep8Naming
def classFactory(iface):  # pylint: disable=invalid-name
    """Load ambition-orange-thd-rec-trans-prod class from file ambition-orange-thd-rec-trans-prod.

    :param iface: A QGIS interface instance.
    :type iface: QgsInterface
    """
    #
    from .class_file_general_menu import ClassGeneraleMenu
    return ClassGeneraleMenu(iface)
