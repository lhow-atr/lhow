# Classse Generale
# import processing
import itertools
import xlrd
from qgis.PyQt.QtCore import Qt, QVariant
from qgis.core import QgsVectorLayer, QgsProject, QgsMapLayer, QgsSpatialIndex, QgsFeatureRequest, QgsDataSourceUri, QgsField, QgsFeature, QgsGeometry, NULL, Qgis
from qgis.utils import iface
from qgis.PyQt.QtWidgets import QWidget, QProgressDialog, QMessageBox
import datetime
import psycopg2
import psycopg2.extras
from shapely.geometry import Point, LineString, MultiPoint
from collections import defaultdict
import re

import sys
from pathlib import Path

folder_plugin = str(Path(__file__).parent.parent)
sys.path.append(folder_plugin)
from scripts_python.modelisation_reseau_transport import ModelisationTransport, ModelisationReseauTransport
from bdd_bthd.params_connexion import function_connexion, DB, user, MP, host, port

# {
# folder_plugin = r'C:\Users\babacar.fassa.AMBITION\Documents\GitHub\orange-thdb-rec-transport'#'C:\Users\babacar.fassa\Documents\GitHub\orange-thdb-rec-transport'
# sys.path.append(folder_plugin)
# from scripts_python.modelisation_reseau_transport import *
# from bdd_bthd.params_connexion import *


# Class pour les fonctions generales
class GeneralFunctions:
    w = QWidget()

    # Function pour la progession bar1
    @staticmethod
    def progress_bar(name_etape):
        prog = QProgressDialog(name_etape + ' : Veillez Patienter', 'Cancel', 0, 100)
        prog.setWindowModality(Qt.WindowModal)
        prog.setMinimumDuration(1)
        return prog

    # Function pour la progession bar2
    @staticmethod
    def progress_processing(index, count_entite, progress_dialog):
        f = int(index + 1)
        pcnt = int(f / count_entite * 100 / 1)
        progress_dialog.setValue(pcnt)

    # Function pour executer une requete sql dans la base
    def function_execute_requete(self, requete_execute, req_fetch, connection):
        curs = connection.cursor()
        try:
            curs.execute(requete_execute)
            if req_fetch:
                data_req = [row for row in curs.fetchall()]
                if data_req:
                    return data_req
        except(Exception, psycopg2.DatabaseError) as error:
            QMessageBox.warning(self.w, "Message dexecution de requete",
                                'Requete Non Executer : ' + str(error) + ' ; ' + str(requete_execute))
        connection.commit()
        curs.close()

    # Function pour  Get layer dans la BD
    def function_getlayer_bdd(self, schema, table_name, key, rename_table, column_geom):
        # {import qgis.core
        global DB, user, MP, host, port
        uri = QgsDataSourceUri()
        uri.setConnection(host, port, DB, user, MP)
        uri.setDataSource(schema, table_name, column_geom, '', key)
        layer = QgsVectorLayer(uri.uri(False), rename_table, "postgres")
        # {crs = layer.crs()
        # crs.createFromId(2154)
        # layer.setCrs(crs)
        if layer.isValid():
            return layer
        else:
            return QMessageBox.warning(self.w, "Message", 'Erreur de recuperation de la table : ' + str(table_name))

    # Function getlayer by name qgis
    @staticmethod
    def function_getlayer_name(layer_name):
        layers = [tree_layer.layer() for tree_layer in QgsProject.instance().layerTreeRoot().findLayers()]
        for layer in layers:
            layer_type = layer.type()
            if layer_type == QgsMapLayer.VectorLayer:
                if layer.name() == layer_name:
                    return layer

    # Function Get layer dans Qgis
    @staticmethod
    def function_getlayer_qgis(layer_name):
        layers = [tree_layer.layer() for tree_layer in QgsProject.instance().layerTreeRoot().findLayers()]
        for layer in layers:
            layer_type = layer.type()
            if layer_type == QgsMapLayer.VectorLayer:
                if layer.name() == layer_name:
                    return layer

    # Function pour identifier les doublons didentifiant
    def get_doublon(self, count_doublon_list):
        counts = {}
        result_double_list = []
        for i in count_doublon_list:
            counts[i[1]] = counts.get(i[1], 0) + 1
        for key, value in counts.items():
            if value > 1:
                for i in count_doublon_list:
                    if i[1] == key:
                        result_double_list.append([i[0], key])
        return result_double_list


# Class GeneralFunction BTHD
class GeneralFunctionsBthd:
    # Constructeur des variables qui change
    def __init__(self, var_schema, var_schema_ogre, var_connection, var_type_controle, var_depart_nro,
                 var_code_deploi_dep, var_code_affaire, var_trigrame_nro, var_insee_nro, var_code_armoire):
        self.schema = var_schema
        self.schema_ogre = var_schema_ogre
        self.connection = var_connection
        self.type_controle = var_type_controle
        self.depart_nro = var_depart_nro
        self.entite_nd_r1_code = var_code_deploi_dep  # Code deploiement + departement TR: T2-29  DI: T2-35
        self.entite_nd_r2_code = var_code_affaire  # code affaire  TR: 01109  DI: 01153
        self.trigramme_nro = var_trigrame_nro  # trigramme NRO  TR: CRO  DI: SDB
        self.insee_nro = var_insee_nro  # INSEE_NRO  TR: 29042  DI: 35326
        self.code_armoire = var_code_armoire  # code armoire MEGALIS  TR: S029  DI: S005

        self.list_resultats_controle = []
        # {self.entite_nd_r1_code = 'T2-29'  # Code deploiement + departement TR: T2-29  DI: T2-35
        # self.entite_nd_r2_code = '01109'  # code affaire  TR: 01109  DI: 01153
        # self.trigramme_nro = 'CRO'  # trigramme NRO  TR: CRO  DI: SDB
        # self.insee_nro = '29042'  # INSEE_NRO  TR: 29042  DI: 35326
        # self.code_armoire = 'S029'  # code armoire MEGALIS  TR: S029  DI: S005
        self.trigramme_nmb = 'NMB'  # Nœud Megalis Bretagne
        self.entite_statut = 'REC'  # Statut detude pour le distribution

        # Entite figees
        self.sep_pnt_virgule = ';'
        self.sep_slash = '/'
        self.sep_underscore = '_'
        self.sep_tiret6 = '-'
        self.message_pas_dans_condition = 'Pas dans la condition, veillez lajouter'
        self.message_pas_nombre = 'Nest pas un nombre'

        self.entite_nd_r3_code = str(self.trigramme_nmb) + str(
            self.trigramme_nro)  # Nœud Megalis Bretagne + trigramme NRO
        self.entite_nd_r4_code = self.entite_nd_r3_code + self.sep_underscore + str(
            self.code_armoire)  # Nœud Megalis Bretagne + trigramme NRO + code armoire MEGALIS

        # Declaration des attributs Partie Noeud
        self.attribut_nd_r1_code = 'nd_r1_code'
        self.attribut_nd_r2_code = 'nd_r2_code'
        self.attribut_nd_r3_code = 'nd_r3_code'
        self.attribut_nd_r4_code = 'nd_r4_code'
        self.attribut_nd_voie = 'nd_voie'

        # Declaration des entites
        self.entite_type_controle_di = 'DI'
        self.entite_type_controle_tr = 'TR'
        self.entite_avct_s = 'S'
        self.entite_avct_e = 'E'
        self.entite_avct_c = 'C'

        self.entite_organisme_orange = 'ORMB0000000001'
        self.entite_organisme_megalis = 'ORMB0000000000'
        self.entite_organisme_enedis = 'ORMB0000000003'
        self.twogramme_megalis = 'MB'
        self.format_nd_voie = 'INSEE/COMMUNE/NOM_VOIE/N°/CPLMT_N°'

        self.mes_sro_bloquant = 'SRO - INCOHERENCE ADRESSE - BLOQUANT'
        self.mes_sro_avertissement = 'SRO - INCOHERENCE ADRESSE -AVERTISSEMENT'

        self.message_nd_r1_code = "RSRO.012"
        self.message_nd_r2_code = "RSRO.013"
        self.message_nd_r3_code = "RSRO.014"
        self.message_nd_r4_code = "RSRO.015"
        self.message_nd_voie = "RNRO.004"

    # Function compare val_attribut and entity
    def function_compare_vale_attribut_entity(self, id_code, attribut, var_attribut, entity, var_message):
        if str(var_attribut).upper() == str(entity).upper():
            return True
        else:
            res = f"La valeur: « {var_attribut} » de lattribut « {attribut} » est different de la valeur de " \
                  f"reference: « {entity} »"
            self.list_resultats_controle.append([id_code, res, attribut, var_message])
            return res

    # Function Verif Only Number
    def function_verif_number(self, var_attribut):
        regex = re.compile('[A-Za-z]')
        res_respect = bool(re.search(regex, str(var_attribut)))
        return res_respect

    # Function Verif format nd_voie
    def function_verif_nd_voie(self, attribut_nd_voie, id_code, attribut):
        nd_voie_text = str(attribut_nd_voie).split('/')
        if len(nd_voie_text) != 5:
            mess_error = str(attribut_nd_voie) + ';' + str(self.mes_sro_bloquant)
            self.function_compare_vale_attribut_entity(id_code, attribut, mess_error, self.format_nd_voie, self.message_nd_voie)
        elif len(nd_voie_text) == 5:
            code_insee = 'code_insee: ' + self.mes_sro_bloquant
            name_commune = 'name_commune: ' + self.mes_sro_bloquant
            name_voix = 'nom_voix: ' + self.mes_sro_bloquant
            num_voix = 'num_voix: ' + self.mes_sro_avertissement
            num_cplmt = 'num_cplmt: ' + self.mes_sro_avertissement
            # {dico_check = {}
            respect_insee = self.function_verif_number(nd_voie_text[0])
            respect_num_voix = self.function_verif_number(
                nd_voie_text[3])  # bool(re.search(regex, nd_voie_text[3]))
            if len(nd_voie_text[0]) == 5 and respect_insee is False:
                code_insee = True
            if nd_voie_text[1]:
                name_commune = True
            if nd_voie_text[2]:
                name_voix = True
            if nd_voie_text[3] and respect_num_voix is False:
                num_voix = True
            if nd_voie_text[4]:
                num_cplmt = True
            if code_insee is not True:
                self.function_compare_vale_attribut_entity(id_code, attribut, code_insee, self.format_nd_voie, self.message_nd_voie)
            if name_commune is not True:
                self.function_compare_vale_attribut_entity(id_code, attribut, name_commune, self.format_nd_voie, self.message_nd_voie)
            if name_voix is not True:
                self.function_compare_vale_attribut_entity(id_code, attribut, name_voix, self.format_nd_voie, self.message_nd_voie)
            if num_voix is not True:
                self.function_compare_vale_attribut_entity(id_code, attribut, num_voix, self.format_nd_voie, self.message_nd_voie)
            if num_cplmt is not True:
                self.function_compare_vale_attribut_entity(id_code, attribut, num_cplmt, self.format_nd_voie, self.message_nd_voie)
            # {return value_return


# Class Pour la partie SRO
class SroTraitement(GeneralFunctionsBthd, GeneralFunctions):
    # Constructeur des variables qui change
    def __init__(self, var_schema, var_schema_ogre, var_connection, var_type_controle, var_depart_nro,
                 var_code_deploi_dep, var_code_affaire, var_trigrame_nro, var_insee_nro, var_code_armoire):
        super().__init__(var_schema, var_schema_ogre, var_connection, var_type_controle, var_depart_nro,
                         var_code_deploi_dep, var_code_affaire, var_trigrame_nro, var_insee_nro, var_code_armoire)

        # Declaration des tables
        self.layer_sitetech = 'vs_elem_st_nd'
        self.layer_zsro = 't_zsro'
        self.layer_znro = 't_znro'

        # Declaration des attributs Partie ZSRO ZNRO
        self.attribut_zs_nd_code = 'zs_nd_code'
        self.attribut_zs_capamax = 'zs_capamax'
        self.attribut_zs_etatpm = 'zs_etatpm'
        self.attribut_zs_zn_code = 'zs_zn_code'
        self.attribut_zn_etatlpm = 'zn_etatlpm'
        self.attribut_zn_code = 'zn_code'
        self.attribut_zn_nrotype = 'zn_nrotype'

        # Declaration des attributs Partie SRO
        self.attribut_st_code = 'st_code'
        self.attribut_st_prop = 'st_prop'
        self.attribut_st_typelog = 'st_typelog'
        self.attribut_st_typephy = 'st_typephy'
        self.attribut_st_avct = 'st_avct'
        self.attribut_st_nd_code = 'st_nd_code'
        self.attribut_st_comment = 'st_comment'

        # Declaration des entites
        self.entite_sro = 'SRO'
        self.entite_nro = 'NRO'
        self.entite_adr = 'ADR'
        self.entite_bat = 'BAT'
        self.entite_she = 'SHE'
        self.entite_etatpm_dp = 'DP'
        self.entite_etatpm_ec = 'EC'
        self.entite_zn_nrotype_pon_ptp = 'PON-PTP'

        self.message_zs_capamax = "RSRO.007"
        self.message_st_avct = "RSRO.009"
        self.message_st_prop = "RSRO.002"
        self.message_st_typephy = "RSRO.003"
        self.message_st_typelog = "RSRO.004"
        self.message_st_comment = "RSRO.005"
        self.message_distance_nro_pm = "RSRO.018"

        self.message_st_prop_nro = "RNRO.001"
        self.message_zn_nrotype_nro = "RNRO.002"
        self.message_st_typephy_nro = "RNRO.003"
        self.message_nd_voie_nro = "RNRO.004"
        self.message_st_avct_nro = "RNRO.005"
        self.message_geom_nro = "RNRO.010"
        self.message_sf_code_nro = "RNRO.011"

        self.message_text_zscapamax = f'le zs_capamax nest devrait etre PM400 / PM700 ou st_typephy_bat devrait etre ' \
                                      f'{self.entite_bat} et le st_prop devrait etre {self.entite_organisme_orange}' \
                                      f'{self.entite_organisme_orange}'
        self.message_text_stavct = f'le zs_etatpm devrait etre {self.entite_etatpm_dp} et le zn_etatlpm devrait etre ' \
                                   f'{self.entite_etatpm_ec} et le st_avct devrait etre {self.entite_avct_e}, ' \
                                   f'ni {self.entite_avct_s}'
        self.message_text_sttypephy = f'le st_typephy devrait etre {self.entite_adr} et le st_typelog devrait etre ' \
                                      f'{self.entite_sro}'
        self.message_text_stcomment = f'le st_comment doit etre rempli'

        self.message_text_sttypephy_trans = f'le st_typephy devrait etre {self.entite_bat} ou {self.entite_she}'

        self.message_text_distance_nro_pm = f'la distance nro_pm de cette entite est superieur a 14km'

        # Declaration des features des tables
        self.sro_sitetech = self.function_getlayer_bdd(self.schema, self.layer_sitetech, self.attribut_st_code,
                                                       self.layer_sitetech, 'geom')
        self.feature_sro_sitetech = [feat for feat in self.sro_sitetech.getFeatures()]

        self.sro_znro = self.function_getlayer_bdd(self.schema, self.layer_znro, '', self.layer_znro, 'geom')
        self.feature_znro = [feat for feat in self.sro_znro.getFeatures()]

        self.sro_zsro = self.function_getlayer_bdd(self.schema, self.layer_zsro, '', self.layer_zsro, 'geom')
        self.feature_zsro = [feat for feat in self.sro_zsro.getFeatures()]

    # Function Verif capacite armoire SRO
    def function_capacite_armoire(self, attribut_zs_capamax, st_typephy_bat, st_prop, value_id_code):
        var_verif_number = self.function_verif_number(attribut_zs_capamax)
        if var_verif_number is False:
            if int(attribut_zs_capamax) <= 720:
                return True  # 'PM400'
            elif 720 <= int(attribut_zs_capamax) <= 1008:
                return True  # 'PM700'
        elif str(st_typephy_bat).upper() == self.entite_bat.upper() and str(
                st_prop).upper() == self.entite_organisme_orange.upper():
            return True  # self.attribut_zs_capamax
        else:
            self.function_compare_vale_attribut_entity(value_id_code, self.attribut_zs_capamax, attribut_zs_capamax,
                                                       self.message_text_zscapamax, self.message_zs_capamax)

    # Function Verif avancement SRO
    def function_st_avct(self, zs_etatpm, zn_etatlpm, st_avct, value_id_code, var_message):
        if zs_etatpm == self.entite_etatpm_dp and zn_etatlpm == self.entite_etatpm_ec and st_avct == self.entite_avct_e:
            return True
        elif zs_etatpm == self.entite_etatpm_dp and zn_etatlpm == self.entite_etatpm_dp and st_avct == self.entite_avct_s:
            return True
        else:
            self.function_compare_vale_attribut_entity(value_id_code, self.attribut_st_avct, st_avct,
                                                       self.message_text_stavct, var_message)

    # Function Verif st_prop
    def function_st_prop(self, value_id_code, st_typephy, st_prop, var_message):
        if st_typephy == self.entite_adr and st_prop == self.entite_organisme_megalis:
            return True
        elif st_typephy == self.entite_bat and st_prop == self.entite_organisme_orange:
            return True
        elif st_typephy == self.entite_she and st_prop == self.entite_organisme_megalis:
            return True
        else:
            self.function_compare_vale_attribut_entity(value_id_code, self.attribut_st_prop, st_prop,
                                                       self.entite_organisme_megalis, var_message)

    # Function Verif st_typephy
    def function_st_typephy(self, value_id_code, st_typephy, st_typelog, var_message, var_message_text):
        if st_typephy == self.entite_adr and st_typelog == self.entite_sro:
            return True
        elif st_typephy == self.entite_bat and st_typelog == self.entite_nro:
            return True
        elif st_typephy == self.entite_she and st_typelog == self.entite_nro:
            return True
        else:
            self.function_compare_vale_attribut_entity(value_id_code, self.attribut_st_typephy, st_typephy,
                                                       var_message_text, var_message)

    # Function Verif st_comment
    def function_st_comment(self, value_id_code, st_comment, var_message):
        if st_comment:
            return True
        else:
            self.function_compare_vale_attribut_entity(value_id_code, self.attribut_st_comment, st_comment,
                                                       self.message_text_stcomment, var_message)

    # Function verification distance NRO PM
    def function_distance_nro_pm(self):
        req_distance = f"""select nd_code, distance_dep_arrive, distance_dep_pm, distance_pm_pbo 
            from t_noeud_traitement"""
        val_req_distance = self.function_execute_requete(req_distance, 'req_fetch', self.connection)
        for index_dis in range(len(val_req_distance)):
            feature_dis = val_req_distance[index_dis]
            id_code = feature_dis[0]
            distance_nro_pm = feature_dis[2]
            if distance_nro_pm is not None and float(distance_nro_pm) > 14000:
                self.list_resultats_controle.append([id_code, self.message_text_distance_nro_pm, distance_nro_pm, self.message_distance_nro_pm])

    # Function controle SRO
    def function_sro(self):
        try:
            bar_progress = self.progress_bar('Partie Traitement SRO')
            len_features_sro = len(self.feature_sro_sitetech)
            if self.feature_sro_sitetech:
                for index in range(len_features_sro):
                    value_feature = self.feature_sro_sitetech[index]
                    value_id_code = value_feature[self.attribut_st_code]
                    value_nd_code = value_feature[self.attribut_st_nd_code]
                    # Filtre sur le SRO Uniquement
                    if value_feature[self.attribut_st_typelog] == self.entite_sro:
                        # Controle st_prop different de Megalis Si SRO (ADR)
                        self.function_st_prop(value_id_code, value_feature[self.attribut_st_typephy],
                                              value_feature[self.attribut_st_prop], self.message_st_prop)

                        # Controle st_typephy different de ADR
                        self.function_st_typephy(value_id_code, value_feature[self.attribut_st_typephy],
                                                 value_feature[self.attribut_st_typelog], self.message_st_typephy,
                                                 self.message_text_sttypephy)

                        # Controle st_typelog different de SRO
                        self.function_st_typephy(value_id_code, value_feature[self.attribut_st_typephy],
                                                 value_feature[self.attribut_st_typelog], self.message_st_typelog,
                                                 self.message_text_sttypephy)

                        # Controle nd_r1_code different de entite_nd_r1_code
                        self.function_compare_vale_attribut_entity(value_id_code, self.attribut_nd_r1_code,
                                                                   value_feature[self.attribut_nd_r1_code],
                                                                   self.entite_nd_r1_code,
                                                                   self.message_nd_r1_code)

                        # Controle nd_r2_code different de entite_nd_r2_code
                        self.function_compare_vale_attribut_entity(value_id_code, self.attribut_nd_r2_code,
                                                                   value_feature[self.attribut_nd_r2_code],
                                                                   self.entite_nd_r2_code,
                                                                   self.message_nd_r2_code)

                        # Controle nd_r3_code different de entite_nd_r3_code
                        self.function_compare_vale_attribut_entity(value_id_code, self.attribut_nd_r3_code,
                                                                   value_feature[self.attribut_nd_r3_code],
                                                                   self.entite_nd_r3_code,
                                                                   self.message_nd_r3_code)

                        # Controle nd_r4_code different de entite_nd_r4_code
                        self.function_compare_vale_attribut_entity(value_id_code, self.attribut_nd_r4_code,
                                                                   value_feature[self.attribut_nd_r4_code],
                                                                   self.entite_nd_r4_code,
                                                                   self.message_nd_r4_code)

                        # Controle nd_voie different du format INSEE / COMMUNE / NOM_VOIE / N° / CPLMT_N°
                        self.function_verif_nd_voie(value_feature[self.attribut_nd_voie], value_id_code, self.attribut_nd_voie)
                        # self.list_resultats_controle.append([value_id_code, res, value_feature[self.attribut_nd_voie]])

                        # Controle zs_capamax different de la formule de la function function_capacite_armoire
                        for index_zsro in range(len(self.feature_zsro)):
                            value_feature_zsro = self.feature_zsro[index_zsro]
                            value_zs_nd_code = value_feature_zsro[self.attribut_zs_nd_code]
                            value_zs_capamax = value_feature_zsro[self.attribut_zs_capamax]
                            if value_zs_nd_code == value_nd_code:
                                self.function_capacite_armoire(value_zs_capamax,
                                                               value_feature[self.attribut_st_typephy],
                                                               value_feature[self.attribut_st_prop], value_id_code)

                                # Controle st_avct different de la formule de la function function_st_avct
                                for index_znro in range(len(self.feature_znro)):
                                    value_feature_znro = self.feature_znro[index_znro]
                                    value_zs_etatpm = value_feature_zsro[self.attribut_zs_etatpm]
                                    value_zn_etatlpm = value_feature_znro[self.attribut_zn_etatlpm]
                                    value_zs_zn_code = value_feature_zsro[self.attribut_zs_zn_code]
                                    value_zn_code = value_feature_znro[self.attribut_zn_code]
                                    if value_zs_zn_code == value_zn_code:
                                        # Controle st_avct en fonction du zn_etat et zn_etatlpm
                                        self.function_st_avct(value_zs_etatpm, value_zn_etatlpm,
                                                              value_feature[self.attribut_st_avct], value_id_code,
                                                              self.message_st_avct)

                        # Controle st_comment couleur de larmoire
                        self.function_st_comment(value_id_code, value_feature[self.attribut_st_comment],
                                                 self.message_st_comment)
                    else:
                        if value_feature[self.attribut_st_typelog] != self.entite_nro:
                            self.function_st_typephy(value_id_code, value_feature[self.attribut_st_typephy],
                                                     value_feature[self.attribut_st_typelog], self.message_st_typephy,
                                                     self.message_text_sttypephy)
                            self.function_st_typephy(value_id_code, value_feature[self.attribut_st_typephy],
                                                     value_feature[self.attribut_st_typelog], self.message_st_typelog,
                                                     self.message_text_sttypephy)

                    self.progress_processing(index, len_features_sro, bar_progress)
                    if bar_progress.wasCanceled():
                        iface.messageBar().pushMessage('Info', 'Action Cancelled', level=Qgis.Info)
                        break
            self.function_distance_nro_pm()
        except Exception as error:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            return QMessageBox.information(self.w, "Message-Execution-Plugin", f"Erreur sur la function_sro:\n {error} ... {exc_tb.tb_lineno}")

    # Function Controle NRO Transport
    def function_nro_transport(self):
        try:
            if self.feature_sro_sitetech:
                for index in range(len(self.feature_sro_sitetech)):
                    value_feature = self.feature_sro_sitetech[index]
                    value_id_code = value_feature[self.attribut_st_code]
                    value_nd_code = value_feature[self.attribut_st_nd_code]
                    # Filtre sur le SRO Uniquement
                    if value_feature[self.attribut_st_typelog] == self.entite_nro:
                        # Controle st_prop different de Megalis Si SRO (ADR) ou ORange si NRO (BAT)
                        self.function_st_prop(value_id_code, value_feature[self.attribut_st_typephy],
                                            value_feature[self.attribut_st_prop], self.message_st_prop_nro)

                        # Controle st_typephy different de SHE ou BAT
                        self.function_st_typephy(value_id_code, value_feature[self.attribut_st_typephy],
                                                value_feature[self.attribut_st_typelog], self.message_st_typephy_nro,
                                                self.message_text_sttypephy_trans)
                        # Controle nd_voie different du format INSEE / COMMUNE / NOM_VOIE / N° / CPLMT_N°
                        self.function_verif_nd_voie(value_feature[self.attribut_nd_voie], value_id_code, self.attribut_nd_voie)

                        # Controle
                        for index_zsro in range(len(self.feature_zsro)):
                            value_feature_zsro = self.feature_zsro[index_zsro]
                            value_zs_nd_code = value_feature_zsro[self.attribut_zs_nd_code]
                            if value_zs_nd_code == value_nd_code:
                                # Controle st_avct different de la formule de la function function_st_avct
                                for index_znro in range(len(self.feature_znro)):
                                    value_feature_znro = self.feature_znro[index_znro]
                                    value_zs_etatpm = value_feature_zsro[self.attribut_zs_etatpm]
                                    value_zn_etatlpm = value_feature_znro[self.attribut_zn_etatlpm]
                                    value_zs_zn_code = value_feature_zsro[self.attribut_zs_zn_code]
                                    value_zn_code = value_feature_znro[self.attribut_zn_code]
                                    value_zn_nrotype = value_feature_znro[self.attribut_zn_nrotype]
                                    if value_zs_zn_code == value_zn_code:
                                        # Controle st_avct en fonction du zn_etat et zn_etatlpm
                                        self.function_st_avct(value_zs_etatpm, value_zn_etatlpm,
                                                            value_feature[self.attribut_st_avct], value_id_code,
                                                            self.message_st_avct_nro)
                                        # Controle zn_nrotype different de PON-PTP
                                        self.function_compare_vale_attribut_entity(value_id_code, self.attribut_zn_nrotype,
                                                                                value_zn_nrotype,
                                                                                self.entite_zn_nrotype_pon_ptp,
                                                                                self.message_zn_nrotype_nro)

                    else:
                        if value_feature[self.attribut_st_typelog] != self.entite_sro:
                            self.function_st_typephy(value_id_code, value_feature[self.attribut_st_typephy],
                                                    value_feature[self.attribut_st_typelog], self.message_st_typephy_nro,
                                                    self.message_text_sttypephy_trans)
                            self.function_st_typephy(value_id_code, value_feature[self.attribut_st_typephy],
                                                    value_feature[self.attribut_st_typelog], self.message_st_typephy_nro,
                                                    self.message_text_sttypephy_trans)
        except Exception as error:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            return QMessageBox.information(self.w, "Message-Execution-Plugin", f"Erreur sur la function_nro_transport:\n {error} ... {exc_tb.tb_lineno}")


# Class Pour la partie EBP
class EbpTraitement(GeneralFunctionsBthd, GeneralFunctions):
    def __init__(self, var_schema, var_schema_ogre, var_connection, var_type_controle, var_depart_nro,
                 var_code_deploi_dep, var_code_affaire, var_trigrame_nro, var_insee_nro, var_code_armoire):
        super().__init__(var_schema, var_schema_ogre, var_connection, var_type_controle, var_depart_nro,
                         var_code_deploi_dep, var_code_affaire, var_trigrame_nro, var_insee_nro, var_code_armoire)
        self.layer_ebp = 'vs_elem_bp_pt_nd'
        self.layer_cassette = 't_cassette'
        self.layer_zpbo = 't_zpbo'
        self.layer_zdep = 't_zdep'
        # Declaration des attributs Partie EBP
        self.attribut_bp_code = 'bp_code'
        self.attribut_bp_etiquet = 'bp_etiquet'
        self.attribut_bp_codeext = 'bp_codeext'
        self.attribut_bp_prop = 'bp_prop'
        self.attribut_bp_gest = 'bp_gest'
        self.attribut_bp_avct = 'bp_avct'
        self.attribut_bp_ca_nb = 'bp_ca_nb'
        self.attribut_zp_code = 'zp_code'
        self.attribut_zd_code = 'zd_code'
        self.attribut_zd_comment = 'zd_comment'

        self.attribut_cs_code = 'cs_code'

        self.message_bp_prop = "REBP.002"
        self.message_bp_gest = "REBP.003"
        self.message_bp_avct = "REBP.004"
        self.message_bp_etiquet = "REBP.001"
        self.message_bp_ca_nb = "REBP.008"
        self.message_zpbo_geom_chev = "REBP.012"
        self.message_distance_pm_pbo = "REBP.013"
        self.message_position_boite_cb = "REBP.014"

        self.message_text_distance_pm_pbo = f'la distance pm_pbo de cette entite est superieur a 5km'
        self.message_text_position_boite_cb = f'Incoherence entre les tubes dans les boitiers et le cable rentrant'

    # Function pour le controle de bp_ca_nb
    def function_bp_ca_nb(self, value_bp_code):
        req_bp_nb_cas = """set search_path to """ + self.schema + """, public;
                select bp_code, bp_ca_nb, t.nbre_cass from t_ebp join (
                select cs_bp_code, count(*) as nbre_cass from t_cassette where cs_num::text != '0' group by cs_bp_code)
                 as t on t.cs_bp_code = bp_code;"""
        cassette_layer = self.function_execute_requete(req_bp_nb_cas, 'bab', self.connection)
        if cassette_layer:
            for index_cas in range(len(cassette_layer)):
                value_feature_cas = cassette_layer[index_cas]
                value_cs_bp_code = value_feature_cas[0]
                if value_cs_bp_code == value_bp_code:
                    self.function_compare_vale_attribut_entity(value_bp_code, self.attribut_bp_ca_nb, value_feature_cas[1],
                                                               value_feature_cas[2], self.message_bp_ca_nb)

    # Controle chevauchement des ZPBO
    def function_control_inclusion_chevauchement_zones_arrieres(self, layer_zpbo, var_attribut, var_zdep):
        # Creation Index des ligne decoupe
        feature_dict_zpbo = {f.id(): f for f in layer_zpbo.getFeatures()}
        index_zpbo = QgsSpatialIndex()
        for current, f in enumerate(feature_dict_zpbo.values()):
            geom_point = f.geometry()
            if geom_point != NULL or geom_point.isGeosValid():
                index_zpbo.insertFeature(f)
        bar_progress = self.progress_bar('Partie Traitement EBP: Chauvechement des zpbo')
        len_features = layer_zpbo.featureCount()
        for feat_zpbo, var_zbpo in enumerate(layer_zpbo.getFeatures()):
            geomzbpo = var_zbpo.geometry()
            if geomzbpo != NULL or geomzbpo.isGeosValid():
                candidates = index_zpbo.intersects(geomzbpo.boundingBox())
                if candidates:
                    for candidate_id in candidates:
                        attr_feature_dict_zpbo = feature_dict_zpbo[candidate_id]
                        geomzpbointersect = attr_feature_dict_zpbo.geometry()
                        if geomzpbointersect != NULL or geomzpbointersect.isGeosValid():
                            if geomzbpo.overlaps(geomzpbointersect):
                                self.function_compare_vale_attribut_entity(var_zbpo[var_attribut], var_attribut,
                                                                           var_zbpo[var_attribut], True,
                                                                           self.message_zpbo_geom_chev)
                                if var_zdep and var_zbpo[self.attribut_zd_comment] != '':
                                    self.function_compare_vale_attribut_entity(var_zbpo[var_attribut],
                                                                               var_attribut,
                                                                               var_zbpo[var_attribut],
                                                                               True, self.message_zpbo_geom_chev)
            self.progress_processing(feat_zpbo, len_features, bar_progress)
            if bar_progress.wasCanceled():
                iface.messageBar().pushMessage('Info', 'Action Cancelled', level=Qgis.Info)
                break

    # Controle des bp_etiquetes
    def function_bp_etiquet(self, var_feature_bp_code, var_feature_nd_r3_code, var_feature_bp_codeext,
                            var_feature_bp_etiquet):
        # Controle bp_etiquet
        # MEGALIS BRETAGNE + bp_code + nd_r3_code + PT
        # IPON + INSEE_NRO / TRIGRAMME NRO
        # Si 'PA' :  "MB";bp_code;zn_r3_code;PT xxxxx (PA);insee /NRO
        # Sinon : "MB";bp_code;zn_r3_code;PT xxxxx ;insee /NRO
        construct_bp_etiquet = self.twogramme_megalis + self.sep_pnt_virgule + \
                               str(var_feature_bp_code) + self.sep_pnt_virgule + \
                               str(var_feature_nd_r3_code) + self.sep_pnt_virgule + \
                               str(var_feature_bp_codeext[-9:]) + self.sep_pnt_virgule + self.insee_nro + \
                               self.sep_slash + str(self.trigramme_nro)
        if str(var_feature_bp_etiquet).upper().find(str('PA')) != -1:
            construct_bp_etiquet_pa = self.twogramme_megalis + self.sep_pnt_virgule + \
                                      str(var_feature_bp_code) + self.sep_pnt_virgule + \
                                      str(var_feature_nd_r3_code) + self.sep_pnt_virgule + \
                                      str(var_feature_bp_codeext[
                                          -9:]) + ' (PA)' + self.sep_pnt_virgule + self.insee_nro + \
                                      self.sep_slash + str(self.trigramme_nro)
            self.function_compare_vale_attribut_entity(var_feature_bp_code, self.attribut_bp_etiquet,
                                                       var_feature_bp_etiquet, construct_bp_etiquet_pa,
                                                       self.message_bp_etiquet)
        else:
            self.function_compare_vale_attribut_entity(var_feature_bp_code, self.attribut_bp_etiquet,
                                                       var_feature_bp_etiquet, construct_bp_etiquet,
                                                       self.message_bp_etiquet)

    # Function verification distance NRO PM
    def function_distance_pm_pbo(self):
        req_distance = f"""select nd_code, distance_dep_arrive, distance_dep_pm, distance_pm_pbo 
            from t_noeud_traitement"""
        val_req_distance = self.function_execute_requete(req_distance, 'req_fetch', self.connection)
        for index_dis in range(len(val_req_distance)):
            feature_dis = val_req_distance[index_dis]
            id_code = feature_dis[0]
            distance_pm_pbo = feature_dis[3]
            if distance_pm_pbo is not None and float(distance_pm_pbo) > 5000:
                self.list_resultats_controle.append([id_code, self.message_text_distance_pm_pbo, distance_pm_pbo, self.message_distance_pm_pbo])

    # Function verification positions boites cable rentrant
    def function_position_boite_cable_rentrant(self):
        req_pos = f"""set search_path to {self.schema}, public; 
            with prepare_data_boite as (
            select 
                bp.bp_code, bp.bp_etiquet, bp.bp_typephy, bp.bp_typelog,bp.bp_pt_code,
                count(ps.ps_code) as nbre_position,
                count(cs.cs_code) as nbre_cassette,
                array_agg(ps.ps_code) as ps_code,
                array_agg(cs.cs_code) as cs_code
            from t_ebp bp
                left join t_cassette cs on cs.cs_bp_code = bp.bp_code
                left join t_position ps on ps.ps_cs_code = cs.cs_code
            group by bp.bp_code, bp.bp_etiquet, bp.bp_typephy, bp.bp_typelog, bp.bp_pt_code
            order by bp.bp_code)
            
            select 
                bpp.bp_code, bpp.nbre_position, bpp.nbre_cassette, bpp.ps_code, cb.cb_code, cb.cb_capafo
            from prepare_data_boite bpp
                left join t_ptech pt on pt.pt_code = bpp.bp_pt_code
                left join t_cable cb on cb.cb_nd2 = pt.pt_nd_code"""
        val_req_pos = self.function_execute_requete(req_pos, 'req_fetch', self.connection)
        for index_pos in range(len(val_req_pos)):
            feature_pos = val_req_pos[index_pos]
            id_code = feature_pos[0]
            nbre_position_boite = feature_pos[1]
            cb_capafo = feature_pos[5]
            if nbre_position_boite is not None and cb_capafo is not None:
                if int(nbre_position_boite) < int(cb_capafo):
                    self.list_resultats_controle.append([id_code, self.message_text_position_boite_cb,
                                                        f"{nbre_position_boite}___{cb_capafo}",
                                                         self.message_position_boite_cb])

    # Controle EBP
    def function_ebp(self):
        try:
            ebp_layer = self.function_getlayer_bdd(self.schema, self.layer_ebp, self.attribut_bp_code, self.layer_ebp,
                                                   'geom')
            # {
            # zpbo_layer = self.function_getlayer_bdd(self.schema, self.layer_zpbo, self.attribut_zp_code,
            #                                         self.layer_zpbo, 'geom')
            # zdep_layer = self.function_getlayer_bdd(self.schema, self.layer_zdep, self.attribut_zp_code,
            #                                         self.layer_zdep, 'geom')
            feature_ebp_layer = [feat for feat in ebp_layer.getFeatures()]
            bar_progress = self.progress_bar('Partie Traitement EBP')
            features_len_ebp = len(feature_ebp_layer)
            if feature_ebp_layer:
                for index in range(features_len_ebp):
                    value_feature = feature_ebp_layer[index]
                    value_id_code = value_feature[self.attribut_bp_code]
                    value_bp_etiquet = value_feature[self.attribut_bp_etiquet]
                    value_bp_codeext = value_feature[self.attribut_bp_codeext]
                    # Controle bp_etiquetes
                    self.function_bp_etiquet(value_id_code, value_feature[self.attribut_nd_r3_code], value_bp_codeext,
                                             value_bp_etiquet)
                    # Controle bp_prop different de Megalis
                    self.function_compare_vale_attribut_entity(value_id_code, self.attribut_bp_prop,
                                                               value_feature[self.attribut_bp_prop],
                                                               self.entite_organisme_megalis, self.message_bp_prop)

                    # Controle bp_gest different de Megalis
                    self.function_compare_vale_attribut_entity(value_id_code, self.attribut_bp_gest,
                                                               value_feature[self.attribut_bp_gest],
                                                               self.entite_organisme_megalis, self.message_bp_gest)
                    # Controle bp_avct different de E
                    self.function_compare_vale_attribut_entity(value_id_code, self.attribut_bp_avct,
                                                               value_feature[self.attribut_bp_avct],
                                                               self.entite_avct_e, self.message_bp_avct)
                    # Controle bp_ca_nb different de sum de cs_bp_code
                    self.function_bp_ca_nb(value_id_code)
                    self.progress_processing(index, features_len_ebp, bar_progress)
                    if bar_progress.wasCanceled():
                        iface.messageBar().pushMessage('Info', 'Action Cancelled', level=Qgis.Info)
                        break

                # Controle chevauchement des ZPBO et ZDEP
                # self.function_control_inclusion_chevauchement_zones_arrieres(zpbo_layer, self.attribut_zp_code, '')
                # self.function_control_inclusion_chevauchement_zones_arrieres(zdep_layer, self.attribut_zd_code,
                # 'var_zdep')
                self.function_distance_pm_pbo()
                self.function_position_boite_cable_rentrant()

        except Exception as error:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            return QMessageBox.information(self.w, "Message-Execution-Plugin", f"Erreur sur la function_ebp:\n {error} ... {exc_tb.tb_lineno}")


# Class Pour la partie Cable
class CableTraitement(GeneralFunctionsBthd, GeneralFunctions):
    def __init__(self, var_schema, var_schema_ogre, var_connection, var_type_controle, var_depart_nro,
                 var_code_deploi_dep, var_code_affaire, var_trigrame_nro, var_insee_nro, var_code_armoire):
        super().__init__(var_schema, var_schema_ogre, var_connection, var_type_controle, var_depart_nro,
                         var_code_deploi_dep, var_code_affaire, var_trigrame_nro, var_insee_nro, var_code_armoire)

        self.layer_cable = 'vs_elem_cl_cb'
        self.layer_treference_ogre = 't_reference'

        # Declaration des attribut Partie Cables
        self.attribut_cb_code = 'cb_code'
        self.attribut_cb_codeext = 'cb_codeext'
        self.attribut_cb_etiquet = 'cb_etiquet'
        self.attribut_cb_r1_code = 'cb_r1_code'
        self.attribut_cb_r2_code = 'cb_r2_code'
        self.attribut_cb_prop = 'cb_prop'
        self.attribut_cb_gest = 'cb_gest'
        self.attribut_cb_statut = 'cb_statut'
        self.attribut_cb_avct = 'cb_avct'
        self.attribut_cb_typephy = 'cb_typephy'
        self.attribut_cb_typelog = 'cb_typelog'
        self.attribut_cb_modulo = 'cb_modulo'
        self.attribut_cb_capafo = 'cb_capafo'
        self.attribut_cb_dateins = 'cb_dateins'
        self.attribut_cb_rf_code = 'cb_rf_code'
        self.attribut_cb_fo_util = 'cb_fo_util'
        self.attribut_cb_diam = 'cb_diam'
        self.attribut_cl_long = 'cl_long'
        self.attribut_cb_lgreel = 'cb_lgreel'

        self.attribut_rf_code_ogre = 'rf_code'
        self.attribut_rf_design_ogre = 'rf_design'

        # Declaration des entites
        self.fo_d = 'FO'  # - D -
        self.entite_modulo_12 = '12'
        self.entite_modulo_6 = '6'
        self.entite_typephy_c = 'C'
        self.entite_typelog_di = 'DI'
        self.entite_typelog_tr = 'TR'
        self.entite_capafothd_di = ['12', '24', '36', '48', '72', '144']
        self.entite_capafothd_tr = ['72', '144', '288', '432', '576', '720']
        self.entite_type_imp_aerien = ['0', '1']
        self.entite_type_imp_conduite = ['7']
        self.entite_type_pose_cable_aerien = 'AERIEN'
        self.entite_type_pose_cable_conduite = 'CONDUITE'
        self.entite_type_pose_cable_mixte = 'MIXTE'
        # Message
        self.message_cb_etiquet = "RCAB.001"
        self.message_cb_r1_code = "RCAB.002"
        self.message_cb_r2_code = "RCAB.003"
        self.message_cb_prop = "RCAB.004"
        self.message_cb_gest = "RCAB.005"
        self.message_cb_statut = "RCAB.006"
        self.message_cb_avct = "RCAB.007"
        self.message_cb_typephy = "RCAB.008"
        self.message_cb_typelog = "RCAB.009"
        self.message_cb_rf_code = "RCAB.010"
        self.message_cb_modulo = "RCAB.013"
        self.message_cb_diam = "RCAB.014"
        self.message_cb_lgreel = "RCAB.015"
        self.message_cl_long = "RCAB.016"

        self.message_text_cbrfcode = f'le cb_rf_code est absent dans la table OGRE {self.layer_treference_ogre}'
        self.message_text_rfdesign = f'la valeur de cette attribut est absent dans lattribut rf_design de la table ' \
                                     f'OGRE {self.layer_treference_ogre}'

        req = """set search_path to """ + self.schema + """, public; select * from t_ref_diametre """
        self.list_diametre_cables_autorises = self.function_execute_requete(req, 'bab', self.connection)

    # Controle cb_etiquet coherence
    def function_cb_etiquet(self, feature_id_code, feature_attribut_cb_capafo, featutre_attribut_cb_dateins,
                            feature_attribut_cb_rf_code, feature_attribut_cb_codeext, feature_attribut_cb_typelog,
                            feature_attribut_cb_etiquet):
        # MEGALIS BRETAGNE + CAPACITE + FONCTION + DATE DE POSE + cb_code + nd_r3_code + cb_rf_code + cb_codeext
        'MB;144;FO-T-;2018-09-11;CBMB0115300037;NMBSDB;FCI;FI-35326-0001;35326/WSB/TR 18 9997'
        construct_cb_etiquet = self.twogramme_megalis + self.sep_pnt_virgule + \
                               str(feature_attribut_cb_capafo) + self.sep_pnt_virgule + \
                               self.fo_d + self.sep_tiret6 + feature_attribut_cb_typelog[:1] + self.sep_tiret6 + str(
            featutre_attribut_cb_dateins) + self.sep_pnt_virgule + \
                               str(feature_id_code) + self.sep_pnt_virgule + str(
            self.entite_nd_r4_code) + self.sep_pnt_virgule + \
                               str(feature_attribut_cb_rf_code) + self.sep_pnt_virgule + \
                               str(feature_attribut_cb_codeext)
        # Controle cb_etiquet conforme
        self.function_compare_vale_attribut_entity(feature_id_code, self.attribut_cb_etiquet,
                                                   feature_attribut_cb_etiquet, construct_cb_etiquet,
                                                   self.message_cb_etiquet)

    # Controle cb_rf_code, cb_capafo, cb_modulo, cb_fo_util
    def function_cb_rf_code_cb_capafo_cb_modulo_cb_fo_util(self, var_dictionnaire_cable_rf_coe, var_table_treference,
                                                           var_list_capa_autorise):
        bar_progress = self.progress_bar('Partie Traitement Cable: cb_rf_code, cb_capafo, cb_modulo, cb_fo_util')
        for index, (key, value) in enumerate(var_dictionnaire_cable_rf_coe.items()):
            error_cb_rf_code = False
            error_cb_capafo = []
            error_cb_modulo = []
            error_cb_fo_util = []
            for index_ogre in range(len(var_table_treference)):
                value_feature_ogre = var_table_treference[index_ogre]
                value_cb_rf_code_ogre = value_feature_ogre[self.attribut_rf_code_ogre]
                value_rf_design_ogree = value_feature_ogre[self.attribut_rf_design_ogre]
                if key == value_cb_rf_code_ogre:
                    error_cb_rf_code = True
                    regex_capafo = re.compile('[\d]+\sFO')
                    regex_modulo = re.compile('[modulo]+\s\d*')

                    res_regex_capafo = re.search(regex_capafo, value_rf_design_ogree)
                    res_regex_moduloo = re.search(regex_modulo, value_rf_design_ogree)
                    # {regex_typecab_pose = re.compile('mixte|sout$')
                    # res_regex_typecab_pose = re.search(regex_typecab_pose, value_rf_design_ogree)
                    # recup_typecab_pose = res_regex_typecab_pose[0].split(" ")[0]

                    for index_value in value:
                        respect_cb_fo_util = self.function_verif_number(index_value[2])
                        respect_cb_capafo = self.function_verif_number(index_value[1])

                        # Controle cb_fo_util superieur de cb_capafo
                        if respect_cb_fo_util is False and respect_cb_capafo is False and \
                                int(index_value[2]) > int(index_value[1]):
                            error_cb_fo_util.append([index_value[0], index_value[2], self.attribut_cb_fo_util])

                        # Controle cb_capafo different de capacite de OGRE
                        if str(res_regex_capafo[0].split(" ")[0]) != index_value[1] and index_value[
                            1] not in var_list_capa_autorise:
                            error_cb_capafo.append([index_value[0], index_value[1], self.attribut_cb_capafo])

                        # Controle cb_modulo different de modulo de OGRE
                        if str(res_regex_moduloo[0].split(" ")[1]) != index_value[3]:
                            error_cb_modulo.append([index_value[0], index_value[3], self.attribut_cb_modulo])

            # Controle cb_rf_code different de rf_code de OGRE
            if error_cb_rf_code is False:
                for index_val in range(len(value)):
                    feature_index_val = value[index_val]
                    self.function_compare_vale_attribut_entity(feature_index_val[0], self.attribut_cb_rf_code,
                                                               key, self.message_text_cbrfcode, self.message_cb_rf_code)

            # Controle cb_capafo, cb_modulo,  cb_fo_util
            fusion_liste_error = error_cb_capafo + error_cb_modulo + error_cb_fo_util
            for index_fusion in range(len(fusion_liste_error)):
                feature_index_fusion = fusion_liste_error[index_fusion]
                self.function_compare_vale_attribut_entity(feature_index_fusion[0], feature_index_fusion[2],
                                                           feature_index_fusion[1], self.message_text_rfdesign,
                                                           self.message_cb_rf_code)
            self.progress_processing(index, len(var_dictionnaire_cable_rf_coe.items()), bar_progress)
            if bar_progress.wasCanceled():
                iface.messageBar().pushMessage('Info', 'Action Cancelled', level=Qgis.Info)
                break

    # Controle Diametre des cables
    def function_cb_diam(self):
        try:
            req = """set search_path to """ + self.schema + """, public;
                select cb.cb_code, cm.cm_code, cm.cm_typ_imp, cb.cb_capafo, cb.cb_diam
                from t_cable cb
                    left join t_cab_cond cabc on cb.cb_code = cabc.cc_cb_code
                    left join t_cond_chem cdc on cdc.dm_cd_code = cabc.cc_cd_code
                    left join t_cheminement cm  on cdc.dm_cm_code = cm.cm_code
                order by cm.cm_typ_imp"""
            res_req = self.function_execute_requete(req, 'bab', self.connection)
            dict_diam_traitement = {}
            bar_progress = self.progress_bar('Partie Traitement Cable: cb_diam')
            if res_req:
                for index_diam in range(len(res_req)):
                    feature_diam = res_req[index_diam]
                    val_cb_code = feature_diam[0]
                    val_cm_code = feature_diam[1]
                    val_cm_typ_imp = feature_diam[2]
                    val_cb_capafo = feature_diam[3]
                    val_cb_diam = feature_diam[4]
                    concate_code_capa_diam = val_cb_code + self.sep_pnt_virgule + val_cb_capafo + self.sep_pnt_virgule + val_cb_diam
                    if concate_code_capa_diam in dict_diam_traitement:
                        dict_diam_traitement[concate_code_capa_diam].append([val_cm_typ_imp, val_cm_code])
                    else:
                        dict_diam_traitement[concate_code_capa_diam] = [[val_cm_typ_imp, val_cm_code]]
                    self.progress_processing(index_diam, len(res_req), bar_progress)
                    if bar_progress.wasCanceled():
                        iface.messageBar().pushMessage('Info', 'Action Cancelled', level=Qgis.Info)
                        break
            for index, (key_diam, val_diam) in enumerate(dict_diam_traitement.items()):
                dict_new_type_pose_cable = {}
                type_pose_cable = False
                if val_diam:
                    for index_val in range(len(val_diam)):
                        dict_new_type_pose_cable[val_diam[index_val][0]] = val_diam[index_val][1]
                    list_cm_imp = list(dict_new_type_pose_cable.keys())
                    list_cm_code = list(dict_new_type_pose_cable.values())
                    if len(list_cm_imp) == 1:
                        value_cm_type_imp = ''.join(filter(None, list_cm_imp))
                        if value_cm_type_imp in self.entite_type_imp_aerien:
                            type_pose_cable = self.entite_type_pose_cable_mixte
                        elif value_cm_type_imp in self.entite_type_imp_conduite:
                            type_pose_cable = self.entite_type_pose_cable_conduite
                    else:
                        type_pose_cable = self.entite_type_pose_cable_mixte

                    split_key_diam = key_diam.split(';')
                    val_cb_code_input = split_key_diam[0]
                    val_capa_input = str(split_key_diam[1]).replace(",", '.')
                    val_diam_input = str(split_key_diam[2]).replace(",", '.')
                    respect_val_capa_input = self.function_verif_number(val_capa_input)
                    respect_val_diam_input = self.function_verif_number(val_diam_input)
                    res_val_type_pose = False
                    if self.list_diametre_cables_autorises:
                        for index_ref_diam in range(len(self.list_diametre_cables_autorises)):
                            feature_ref_diam = self.list_diametre_cables_autorises[index_ref_diam]
                            val_type_pose = feature_ref_diam[0]
                            val_capafo = str(feature_ref_diam[1]).replace(",", '.')
                            val_min_diam = str(feature_ref_diam[2]).replace(",", '.')
                            val_max_diam = str(feature_ref_diam[3]).replace(",", '.')
                            respect_val_min_diam = self.function_verif_number(val_min_diam)
                            respect_val_max_diam = self.function_verif_number(val_max_diam)
                            if respect_val_min_diam is False and respect_val_diam_input is False and \
                                    respect_val_max_diam is False and respect_val_capa_input is False:
                                if float(val_capa_input) == float(val_capafo) and \
                                        str(type_pose_cable) == str(val_type_pose):
                                    res_val_type_pose = True
                                    if float(val_min_diam) <= float(val_diam_input) <= float(val_max_diam):
                                        pass_val_diam_input = True

                                    else:
                                        self.function_compare_vale_attribut_entity(val_cb_code_input,
                                                                                   self.attribut_cb_diam,
                                                                                   val_diam_input,
                                                                                   str(val_min_diam) + '_' +
                                                                                   str(val_max_diam),
                                                                                   self.message_cb_diam)
                            else:
                                self.function_compare_vale_attribut_entity(val_cb_code_input, self.attribut_cb_diam,
                                                                           f"{val_min_diam}_{val_diam_input}_"
                                                                           f"{val_max_diam}_{val_capa_input}",
                                                                           self.message_pas_nombre,
                                                                           self.message_cb_diam)
                        if res_val_type_pose is False:
                            self.function_compare_vale_attribut_entity(val_cb_code_input, self.attribut_cb_diam,
                                                                       val_diam_input,
                                                                       self.message_pas_dans_condition,
                                                                       self.message_cb_diam)
                self.progress_processing(index, len(dict_diam_traitement), bar_progress)
                if bar_progress.wasCanceled():
                    iface.messageBar().pushMessage('Info', 'Action Cancelled', level=Qgis.Info)
                    break
        except OSError as error:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            return QMessageBox.information(self.w, "Message-Execution-Plugin", f"Erreur sur la function_cb_diam:\n {error} ... {exc_tb.tb_lineno}")

    # Controle Cable
    def function_cable(self):
        try:
            cable_layer = self.function_getlayer_bdd(self.schema, self.layer_cable, self.attribut_cb_code,
                                                     self.layer_cable,
                                                     'geom')

            treference_ogre_layer = self.function_getlayer_bdd(self.schema_ogre, self.layer_treference_ogre,
                                                               self.attribut_rf_code_ogre, self.layer_treference_ogre, None)
            feature_cable_layer = [feat for feat in cable_layer.getFeatures()]
            request = QgsFeatureRequest().setFlags(QgsFeatureRequest.NoGeometry)
            feature_treference_ogre_layer = [feat for feat in treference_ogre_layer.getFeatures(request)]

            dictionnaire_cable_rf_coe = {}
            bar_progress = self.progress_bar('Partie Traitement Cable')
            len_features_cable = len(feature_cable_layer)
            if feature_cable_layer:
                for index in range(len_features_cable):
                    value_feature = feature_cable_layer[index]
                    value_id_code = value_feature[self.attribut_cb_code]
                    value_cb_etiquet = value_feature[self.attribut_cb_etiquet]
                    value_cb_codeext = value_feature[self.attribut_cb_codeext]
                    value_cb_rf_code = value_feature[self.attribut_cb_rf_code]
                    value_cl_long = value_feature[self.attribut_cl_long]
                    value_cb_lgreel = value_feature[self.attribut_cb_lgreel]
                    value_cb_capafo = value_feature[self.attribut_cb_capafo]
                    value_cb_fo_util = value_feature[self.attribut_cb_fo_util]
                    value_cb_modulo = value_feature[self.attribut_cb_modulo]
                    if value_cb_rf_code in dictionnaire_cable_rf_coe:
                        dictionnaire_cable_rf_coe[value_cb_rf_code].append([value_id_code, value_cb_capafo, value_cb_fo_util,
                                                                            value_cb_modulo])
                    else:
                        dictionnaire_cable_rf_coe[value_cb_rf_code] = [[value_id_code, value_cb_capafo, value_cb_fo_util,
                                                                        value_cb_modulo]]

                    # COntrole cb_etiquet selon la norme de la function function_cb_etiquet
                    self.function_cb_etiquet(value_id_code, value_feature[self.attribut_cb_capafo],
                                             value_feature[self.attribut_cb_dateins], value_feature[self.attribut_cb_rf_code],
                                             value_cb_codeext, value_feature[self.attribut_cb_typelog], value_cb_etiquet)

                    # Controle cb_r1_code different de entite_nd_r1_code
                    self.function_compare_vale_attribut_entity(value_id_code, self.attribut_cb_r1_code,
                                                               value_feature[self.attribut_cb_r1_code],
                                                               self.entite_nd_r1_code, self.message_cb_r1_code)
                    # Controle cb_r2_code different de entite_nd_r2_code
                    self.function_compare_vale_attribut_entity(value_id_code, self.attribut_cb_r2_code,
                                                               value_feature[self.attribut_cb_r2_code],
                                                               self.entite_nd_r2_code, self.message_cb_r2_code)
                    # Controle cb_prop different de Megalis
                    self.function_compare_vale_attribut_entity(value_id_code, self.attribut_cb_prop,
                                                               value_feature[self.attribut_cb_prop],
                                                               self.entite_organisme_megalis, self.message_cb_prop)

                    # Controle cb_gest different de Megalis
                    self.function_compare_vale_attribut_entity(value_id_code, self.attribut_cb_gest,
                                                               value_feature[self.attribut_cb_gest],
                                                               self.entite_organisme_megalis, self.message_cb_gest)
                    # Controle cb_statut different de Megalis
                    self.function_compare_vale_attribut_entity(value_id_code, self.attribut_cb_statut,
                                                               value_feature[self.attribut_cb_statut],
                                                               self.entite_statut, self.message_cb_statut)
                    # Controle cb_avct different de E
                    self.function_compare_vale_attribut_entity(value_id_code, self.attribut_cb_avct,
                                                               value_feature[self.attribut_cb_avct],
                                                               self.entite_avct_e, self.message_cb_avct)
                    # Controle cb_typephy different de C
                    self.function_compare_vale_attribut_entity(value_id_code, self.attribut_cb_typephy,
                                                               value_feature[self.attribut_cb_typephy],
                                                               self.entite_typephy_c, self.message_cb_typephy)
                    # Controle cb_typelog different de DI
                    if self.type_controle == self.entite_type_controle_di:
                        if value_feature[self.attribut_cb_typelog] not in (self.entite_typelog_di, self.entite_typelog_tr):
                            self.function_compare_vale_attribut_entity(value_id_code, self.attribut_cb_typelog,
                                                                       value_feature[self.attribut_cb_typelog],
                                                                       self.entite_typelog_di + '_' + self.entite_typelog_tr,
                                                                       self.message_cb_typelog)
                    elif self.type_controle == self.entite_type_controle_tr:
                        if value_feature[self.attribut_cb_typelog] != self.entite_typelog_tr:
                            self.function_compare_vale_attribut_entity(value_id_code, self.attribut_cb_typelog,
                                                                       value_feature[self.attribut_cb_typelog],
                                                                       self.entite_typelog_tr,
                                                                       self.message_cb_typelog)
                    # Controle cb_modulo different de 12
                    pass_cb_modulo = False
                    if str(value_feature[self.attribut_cb_modulo]) == self.entite_modulo_6 and \
                            value_feature[self.attribut_cb_typelog] == self.entite_typelog_di:
                        pass_cb_modulo = True
                    elif str(value_feature[self.attribut_cb_modulo]) == self.entite_modulo_12 and \
                            value_feature[self.attribut_cb_typelog] == self.entite_typelog_tr:
                        pass_cb_modulo = True
                    if pass_cb_modulo == False:
                        self.function_compare_vale_attribut_entity(value_id_code, self.attribut_cb_modulo,
                                                                   value_feature[self.attribut_cb_modulo],
                                                                   self.entite_modulo_6 + '_' + self.entite_modulo_12,
                                                                   self.message_cb_modulo)
                    # Controle cl_long different de longueur calcule de geometry
                    respect_value_cl_long = self.function_verif_number(value_cl_long)
                    value_geom = value_feature.geometry().length()
                    if respect_value_cl_long is False:
                        difference_lenght = value_geom - float(str(value_cl_long).replace(",", '.'))
                        if difference_lenght > 20:
                            self.function_compare_vale_attribut_entity(value_id_code, self.attribut_cl_long,
                                                                       value_cl_long, 20,
                                                                       self.message_cl_long)
                    elif respect_value_cl_long is True:
                        self.function_compare_vale_attribut_entity(value_id_code, self.attribut_cl_long, value_cl_long,
                                                                   self.message_pas_nombre, self.message_cl_long)

                    # Controle RCAB.017 Longueur cb_long < 2000 et cb_long < cb.geom*1,15
                    respect_value_cb_lgreel = self.function_verif_number(value_cb_lgreel)
                    if respect_value_cb_lgreel is False:
                        if float(str(value_cb_lgreel).replace(",", '.')) > 2000 or \
                                float(str(value_cb_lgreel).replace(",", '.')) > (value_geom * 1.15):
                            self.function_compare_vale_attribut_entity(value_id_code, self.attribut_cb_lgreel,
                                                                       value_cb_lgreel, value_geom * 1.15,
                                                                       self.message_cb_lgreel)
                    elif respect_value_cb_lgreel is True:
                        self.function_compare_vale_attribut_entity(value_id_code, self.attribut_cb_lgreel,
                                                                   value_cb_lgreel,
                                                                   self.message_pas_nombre, self.message_cb_lgreel)
                    self.progress_processing(index, len_features_cable, bar_progress)
                    if bar_progress.wasCanceled():
                        iface.messageBar().pushMessage('Info', 'Action Cancelled', level=Qgis.Info)
                        break
                # Controle cb_rf_code, cb_capafo, cb_modulo, cb_fo_util,  different de reference OGRE
                if self.type_controle == self.entite_type_controle_di:
                    self.function_cb_rf_code_cb_capafo_cb_modulo_cb_fo_util(dictionnaire_cable_rf_coe,
                                                                            feature_treference_ogre_layer,
                                                                            self.entite_capafothd_di)
                elif self.type_controle == self.entite_type_controle_tr:
                    self.function_cb_rf_code_cb_capafo_cb_modulo_cb_fo_util(dictionnaire_cable_rf_coe,
                                                                            feature_treference_ogre_layer,
                                                                            self.entite_capafothd_tr)
                # Controle cb_diam different de de la table de reference list_diametre_cables_autorises
                self.function_cb_diam()
        except Exception as error:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            return QMessageBox.information(self.w, "Message-Execution-Plugin", f"Erreur sur la function_cable:\n {error} ... {exc_tb.tb_lineno}")


# Class Pour la partie Points Techniques
class PointTechniquesTraitement(GeneralFunctionsBthd, GeneralFunctions):
    def __init__(self, var_schema, var_schema_ogre, var_connection, var_type_controle, var_depart_nro,
                 var_code_deploi_dep, var_code_affaire, var_trigrame_nro, var_insee_nro, var_code_armoire):
        super().__init__(var_schema, var_schema_ogre, var_connection, var_type_controle, var_depart_nro,
                         var_code_deploi_dep, var_code_affaire, var_trigrame_nro, var_insee_nro, var_code_armoire)
        self.layer_pt = 'vs_elem_pt_nd'

        # Declaration des attribut Partie Cables
        self.attribut_pt_code = 'pt_code'
        self.attribut_pt_typephy = 'pt_typephy'
        self.attribut_pt_typelog = 'pt_typelog'
        self.attribut_nd_type = 'nd_type'
        self.attribut_pt_avct = 'pt_avct'
        self.attribut_pt_proptyp = 'pt_proptyp'
        self.attribut_pt_prop = 'pt_prop'
        self.attribut_pt_gest = 'pt_gest'
        self.attribut_pt_codeex = 'pt_codeext'
        self.attribut_pt_nature = 'pt_nature'

        # Declaration des entites
        self.entite_nd_type_pt = 'PT'
        self.entite_pt_typephy = ['C', 'A', 'I']
        self.entite_pt_typelog = ['T', 'R']
        self.entite_pt_proptyp_cst = 'CST'
        self.entite_pt_proptyp_loc = 'LOC'

        self.message_pt_prop = "RPTE.001"
        self.message_pt_gest = "RPTE.002"
        self.message_pt_proptyp = "RPTE.003"
        self.message_pt_avct = "RPTE.004"
        self.message_pt_typephy = "RPTE.005"
        self.message_pt_typelog = "RPTE.006"
        self.message_pt_nature = "RPTE.007"
        self.message_nd_r1_code = "RPTE.008"
        self.message_nd_r2_code = "RPTE.009"
        self.message_nd_voie = "RPTE.010"
        self.message_nd_type = "RPTE.011"
        self.message_text_ptprop = f'le pt_prop devrait etre {self.entite_organisme_orange} ou autre par rapport au ' \
                                   f'remplissage de {self.attribut_pt_codeex}'
        self.message_text_ptgest = f'le pt_gest est faux puisse que le pt_prop est faux'
        self.message_text_ptnature = 'Incoherence du pt_nature'

    # Controle coherence pt_prop pt_gest
    def function_ptprop_ptgest(self, var_pt_codeext, var_pt_prop, var_value_id_code, value_feature_pt_prop):
        # Regle == Si pt_codeext est vide et pt_prop est rempli et different de Orange donc pt_gest doit etre rempli
        # Si pt_codeext est rempli pt_prop doit etre Orange et pt_gest est vide
        res_pt_prop = False
        if var_pt_codeext == '' and var_pt_prop != '' and var_pt_prop != self.entite_organisme_orange:
            res_pt_prop = True
        elif var_pt_codeext != '' and var_pt_prop == self.entite_organisme_orange:
            res_pt_prop = True
        else:
            self.function_compare_vale_attribut_entity(var_value_id_code, self.attribut_pt_prop,
                                                       value_feature_pt_prop[self.attribut_pt_prop],
                                                       self.message_text_ptprop, self.message_pt_prop)
            self.function_compare_vale_attribut_entity(var_value_id_code, self.attribut_pt_gest,
                                                       value_feature_pt_prop[self.attribut_pt_gest],
                                                       self.message_text_ptgest, self.message_pt_gest)

    # Function pour recuperer des occurrences
    def occur_dict(self, items):
        d = {}
        for i in items:
            if i in d:
                d[i] = d[i] + 1
            else:
                d[i] = 1
        return d

    # Controle pt_nature
    def function_ptnature(self):
        try:
            text_req = """set search_path to """ + self.schema + """, public;
            select 
                pt_code, pt_nd_code, pt_typephy, pt_nature, array_agg(distinct bp_code) as bp_code, count(bp_code), 
                array_agg(distinct ref_bp.rb_code) as rb_code, array_agg(distinct ref_bp.rb_design) as rb_design, array_agg(ref_bp.rb_volume) as rb_volume, 
                array_agg(distinct ref_bp.rb_nb_cas) as rb_nb_cas, 
                array_agg(distinct refc.lc_type) as lc_type, array_agg(distinct refc.ebp_mm_2) as ebp_mm2, array_agg(distinct refc.ebp_m_6) as ebp_m6,
                array_agg(distinct refc.ebp_t1_10) as ebp_t1_10, array_agg(distinct refc.ebp_t2_30) as ebp_t2_30, array_agg(distinct refc.ebp_t3_40) as ebp_t3_40,
                array ['0'::text] as indeterminee
            from t_ptech 
                left join t_ref_chambre refc on pt_nature = refc.lc_type
                left join t_ebp bp on bp.bp_pt_code = pt_code
                left join t_ref_ebp ref_bp on ref_bp.rb_code =  bp.bp_rf_code	
            where pt_typephy = 'C'--- and bp_code is not null
            group by pt_code, pt_nd_code, pt_typephy, pt_nature
            order by pt_code;"""
            res_text_req = self.function_execute_requete(text_req, 'bab', self.connection)
            dict_correspon = {'MM': 11, 'M': 12, 'T1': 13, 'T2': 14, 'T3': 15, 'IND': 16}  # Index des tailes de boites
            # M == 2 MM
            # T1 == 2 M, 4MM
            # T2 == 2 T1, 4M, 8MM
            # T3 == 2 T2, 4T1, 8M, 16MM
            dict_correspon_conversion = {'M': {'MM': 2, 'IND': 0},
                                         'T1': {'M': 2, 'MM': 4, 'IND': 0},
                                         'T2': {'T1': 2, 'M': 4, 'MM': 8, 'IND': 0},
                                         'T3': {'T2': 2, 'T1': 4, 'M': 8, 'MM': 16, 'IND': 0},
                                         'IND': {'IND': 0}}
            bar_progress = self.progress_bar('Partie Traitement Point techniques: pt_nature')
            if res_text_req:
                for index_pt in range(len(res_text_req)):
                    val_feature = res_text_req[index_pt]
                    value_id_code = val_feature[0]
                    value_bp_code = val_feature[4]
                    value_nature_chambre_base = val_feature[3]
                    value_bp_code_count = val_feature[5]
                    value_nature_chambre = val_feature[10]
                    if None not in value_bp_code:
                        var_surcharge_chambre = {}
                        value_bp_code_str = ','.join(value_bp_code)
                        if None not in value_nature_chambre:
                            value_nature_chambre_str = ','.join(value_nature_chambre)
                            # Renomme les rb_volume qui sont None
                            new_val_feature_rb_volume = ['IND' if (x is None or x == '') else x for x in val_feature[8]]
                            max_boite = max(new_val_feature_rb_volume)  # Recup de la boite max
                            min_boite = min(new_val_feature_rb_volume)  # Recup de la boite min
                            # Recup du nbre possible de la boite max dans la chambre
                            nbre_pos_max_boite_chbre = int(''.join(val_feature[dict_correspon[max_boite]]))
                            # Recup du nbre possible de la boite min dans la chambre
                            nbre_pos_min_boite_chbre = int(''.join(val_feature[dict_correspon[min_boite]]))
                            # recup du nbre occurence de boite entreprise
                            count_occuren_boite = self.occur_dict(new_val_feature_rb_volume)
                            nbre_max_boite_occuren = count_occuren_boite[max_boite]  # Recup nbre Max de la boite
                            # nbre_min_boite_occuren = count_occuren_boite[min_boite]  # Recup nbre Min de la boite
                            len_count_occuren_boite = len(count_occuren_boite)

                            if value_bp_code_count > 1:  # Cas ou une multutide de boite dans la Chambre
                                # Cas ou une multutide de boite Non identique dans la Chambre
                                if len_count_occuren_boite == 2:
                                    conversion_max_boite_to_min_boite = dict_correspon_conversion[max_boite][min_boite]
                                    cal_soustraire_deja_poser = nbre_pos_min_boite_chbre - conversion_max_boite_to_min_boite
                                    calcule_possible_boite_min = cal_soustraire_deja_poser - nbre_pos_min_boite_chbre
                                    var_pos_min_max = str(nbre_pos_min_boite_chbre) + '_' + str(nbre_pos_max_boite_chbre)
                                    count_occuren_boite_str = ','.join([str(k) + '_' + str(v) for k, v in
                                                                        count_occuren_boite.items()])
                                    if calcule_possible_boite_min < 0:  # Verif si possible de mettre la boite minimum
                                        var_surcharge_chambre[value_id_code] = [value_nature_chambre_str,
                                                                                str(calcule_possible_boite_min),
                                                                                count_occuren_boite_str, var_pos_min_max,
                                                                                value_bp_code_str, False]
                                    else:
                                        var_surcharge_chambre[value_id_code] = [value_nature_chambre_str,
                                                                                str(calcule_possible_boite_min),
                                                                                count_occuren_boite_str, var_pos_min_max,
                                                                                value_bp_code_str, True]

                                # Cas ou une multutide de boite identique dans la Chambre
                                elif len_count_occuren_boite == 1:
                                    # Verif si Boite entrep est < chambre possi
                                    if nbre_max_boite_occuren <= nbre_pos_max_boite_chbre:
                                        var_surcharge_chambre[value_id_code] = [value_nature_chambre_str,
                                                                                len_count_occuren_boite,
                                                                                nbre_max_boite_occuren,
                                                                                nbre_pos_max_boite_chbre,
                                                                                value_bp_code_str, True]
                                    else:
                                        var_surcharge_chambre[value_id_code] = [value_nature_chambre_str,
                                                                                len_count_occuren_boite,
                                                                                nbre_max_boite_occuren,
                                                                                nbre_pos_max_boite_chbre,
                                                                                value_bp_code_str, False]
                                else:  # Hormis entre 1 et 2 dans la chambre
                                    var_surcharge_chambre[value_id_code] = [value_nature_chambre_str,
                                                                            len_count_occuren_boite,
                                                                            nbre_max_boite_occuren,
                                                                            nbre_pos_max_boite_chbre,
                                                                            value_bp_code_str,
                                                                            'Pas de lintervalle de 1 et 2 boites']

                            else:  # Cas ou une seule de boite dans la Chambre
                                # Verif si Boite entrep est < chambre possi
                                if nbre_max_boite_occuren <= nbre_pos_max_boite_chbre:
                                    var_surcharge_chambre[value_id_code] = [value_nature_chambre_str,
                                                                            len_count_occuren_boite,
                                                                            nbre_max_boite_occuren,
                                                                            nbre_pos_max_boite_chbre,
                                                                            value_bp_code_str, True]
                                else:
                                    var_surcharge_chambre[value_id_code] = [value_nature_chambre_str,
                                                                            len_count_occuren_boite,
                                                                            nbre_max_boite_occuren,
                                                                            nbre_pos_max_boite_chbre,
                                                                            value_bp_code_str, False]
                        else:
                            var_surcharge_chambre[value_id_code] = [value_nature_chambre_base,
                                                                    'Pas de reference dans ref_chambre',
                                                                    '', '', value_bp_code_str, False]
                        for key, value in var_surcharge_chambre.items():
                            if value[-1] is not True:
                                value_res = str(','.join([str(char) for char in value]))
                                self.function_compare_vale_attribut_entity(key, self.attribut_pt_nature,
                                                                           value_res, self.message_text_ptnature,
                                                                           self.message_pt_nature)
                    self.progress_processing(index_pt, len(res_text_req), bar_progress)
                    if bar_progress.wasCanceled():
                        iface.messageBar().pushMessage('Info', 'Action Cancelled', level=Qgis.Info)
                        break
        except Exception as error:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            return QMessageBox.information(self.w, "Message-Execution-Plugin", f"Erreur sur la function_ptnature:\n "
                                                                               f"{error} ... {exc_tb.tb_lineno}")

    # Controle PT
    def function_pointtechniques(self):
        try:
            bar_progress = self.progress_bar('Partie Traitement Points Techniques')
            pt_layer = self.function_getlayer_bdd(self.schema, self.layer_pt, self.attribut_pt_code, self.layer_pt,
                                                  'geom')
            feature_pt_layer = [feat for feat in pt_layer.getFeatures()]
            if feature_pt_layer:
                for index in range(len(feature_pt_layer)):
                    value_feature = feature_pt_layer[index]
                    value_id_code = value_feature[self.attribut_pt_code]
                    value_typephy = value_feature[self.attribut_pt_typephy]
                    value_typelog = value_feature[self.attribut_pt_typelog]

                    # Controle pt_proptyp different de CST LOC
                    if value_feature[self.attribut_pt_prop] == self.entite_organisme_megalis:
                        self.function_compare_vale_attribut_entity(value_id_code, self.attribut_pt_proptyp,
                                                                   value_feature[self.attribut_pt_proptyp],
                                                                   self.entite_pt_proptyp_cst, self.message_pt_proptyp)
                    else:
                        self.function_compare_vale_attribut_entity(value_id_code, self.attribut_pt_proptyp,
                                                                   value_feature[self.attribut_pt_proptyp],
                                                                   self.entite_pt_proptyp_loc, self.message_pt_proptyp)

                    # Controle pt_typephy different de C, A, I
                    if value_typephy not in self.entite_pt_typephy:
                        self.function_compare_vale_attribut_entity(value_id_code, self.attribut_pt_typephy,
                                                                   value_feature[self.attribut_pt_typephy],
                                                                   '_'.join(self.entite_pt_typephy), self.message_pt_typephy)

                    # Controle pt_typelog different de T, R
                    if value_typelog not in self.entite_pt_typelog:
                        self.function_compare_vale_attribut_entity(value_id_code, self.attribut_pt_typelog,
                                                                   value_feature[self.attribut_pt_typelog],
                                                                   '_'.join(self.entite_pt_typelog), self.message_pt_typelog)
                    # Controle nd_r1_code different de entite_nd_r1_code
                    self.function_compare_vale_attribut_entity(value_id_code, self.attribut_nd_r1_code,
                                                               value_feature[self.attribut_nd_r1_code],
                                                               self.entite_nd_r1_code, self.message_nd_r1_code)

                    # Controle nd_r2_code different de entite_nd_r2_code
                    self.function_compare_vale_attribut_entity(value_id_code, self.attribut_nd_r2_code,
                                                               value_feature[self.attribut_nd_r2_code],
                                                               self.entite_nd_r2_code, self.message_nd_r2_code)

                    # Controle nd_voie different du format INSEE / COMMUNE / NOM_VOIE / N° / CPLMT_N°
                    self.function_verif_nd_voie(value_feature[self.attribut_nd_voie], value_id_code, self.attribut_nd_voie)

                    # Controle nd_type different de PT
                    self.function_compare_vale_attribut_entity(value_id_code, self.attribut_nd_type,
                                                               value_feature[self.attribut_nd_type],
                                                               self.entite_nd_type_pt, self.message_nd_type)

                    # Controle ptprop_ptgest par rapport a la formule de la function function_ptprop_ptgest
                    self.function_ptprop_ptgest(value_feature[self.attribut_pt_codeex], value_feature[self.attribut_pt_prop],
                                                value_id_code, value_feature)

                    # Controle pt_avct different de E si ORANGE/ENEDIS et C Autre
                    val_cal_ptavct = self.message_pas_dans_condition
                    if value_feature[self.attribut_pt_prop] in (self.entite_organisme_orange, self.entite_organisme_enedis):
                        val_cal_ptavct = self.entite_avct_e
                    elif value_feature[self.attribut_pt_prop] == self.entite_organisme_megalis:
                        val_cal_ptavct = self.entite_avct_c
                    self.function_compare_vale_attribut_entity(value_id_code, self.attribut_pt_avct,
                                                               value_feature[self.attribut_pt_avct],
                                                               val_cal_ptavct, self.message_pt_avct)
                    self.progress_processing(index, len(feature_pt_layer), bar_progress)
                    if bar_progress.wasCanceled():
                        iface.messageBar().pushMessage('Info', 'Action Cancelled', level=Qgis.Info)
                        break
                # Controle pt_nature
                self.function_ptnature()
        except Exception as error:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            return QMessageBox.information(self.w, "Message-Execution-Plugin", f"Erreur sur la function_pointtechniques:\n {error} ... {exc_tb.tb_lineno}")


# Class pour la partie Cheminement
class CheminementTraitement(GeneralFunctionsBthd, GeneralFunctions):
    def __init__(self, var_schema, var_schema_ogre, var_connection, var_type_controle, var_depart_nro,
                 var_code_deploi_dep, var_code_affaire, var_trigrame_nro, var_insee_nro, var_code_armoire):
        super().__init__(var_schema, var_schema_ogre, var_connection, var_type_controle, var_depart_nro,
                         var_code_deploi_dep, var_code_affaire, var_trigrame_nro, var_insee_nro, var_code_armoire)
        self.layer_cheminement = 't_cheminement'

        # Declaration des attribut Partie Cheminement
        self.attribut_cm_code = 'cm_code'
        self.attribut_cm_nature = 'cm_nature'
        self.attribut_cm_lgreel = 'cm_lgreel'
        self.attribut_cm_r1_code = 'cm_r1_code'
        self.attribut_cm_r2_code = 'cm_r2_code'
        self.attribut_cm_typ_imp = 'cm_typ_imp'
        self.attribut_cm_statut = 'cm_statut'
        self.attribut_cm_avct = 'cm_avct'
        self.attribut_cm_typelog = 'cm_typelog'
        self.attribut_cm_long = 'cm_long'

        # Declaration des entites
        self.entite_cm_nature_tel = 'TEL'
        self.entite_cm_typ_imp_aerien = '0'
        self.entite_cm_typ_imp_conduite = '7'
        self.entite_pt_typephy_a = 'A'
        self.entite_pt_typephy_c = 'C'
        self.entite_list_cm_typelog = ['TR', 'DI']
        self.entite_list_cm_typelog_tr = ['TR', 'TD']
        self.entite_cm_typelog_td = 'TD'
        self.entite_cm_typelog_tr = 'TR'

        self.message_cm_r1_code = "RCHE.001"
        self.message_cm_r2_code = "RCHE.002"
        self.message_cm_statut = "RCHE.003"
        self.message_cm_avct = "RCHE.004"
        self.message_cm_typelog = "RCHE.005"
        self.message_cm_nature = "RCHE.006"
        self.message_cm_lgreel = "RCHE.007"
        self.message_cm_long = "RCHE.008"
        self.message_cm_typ_imp = "RCHE.009"

    # Function qui permet de recuperer les cm_typ_imp des cheminements selon les origines/extremites des PT
    def function_recup_cm_propp(self, origine_pt_typephy, extremite_pt_typephy):
        # Partie Aerien <-> Aerien
        if origine_pt_typephy == self.entite_pt_typephy_a and extremite_pt_typephy == self.entite_pt_typephy_a:
            return self.entite_cm_typ_imp_aerien  # 'Aerien & Aerien'

        # Partie Conduide <-> Conduite
        elif origine_pt_typephy == self.entite_pt_typephy_c and extremite_pt_typephy == self.entite_pt_typephy_c:
            return self.entite_cm_typ_imp_conduite  # 'Conduide & Conduide'

        # Partie Aerien <-> Conduite et vis-versa
        elif origine_pt_typephy == self.entite_pt_typephy_a and extremite_pt_typephy == self.entite_pt_typephy_c:
            return self.entite_cm_typ_imp_conduite  # 'Aerien & Conduite'

        elif origine_pt_typephy == self.entite_pt_typephy_c and extremite_pt_typephy == self.entite_pt_typephy_a:
            return self.entite_cm_typ_imp_conduite  # 'Conduite & Aerien'

        else:
            return self.message_pas_dans_condition

    # Function pour cm_typ_imp et cm_typelog
    def function_cm_typ_imp_cm_typelog(self):
        dict_cm_typelog = {}
        req_cm_pt_cb = """set search_path to """ + self.schema + """, public;
            select cm.cm_code,  cm.cm_typ_imp, pto.pt_typephy, pte.pt_typephy, cb.cb_code, cm.cm_typelog, cb.cb_typelog 
            from t_cheminement cm 
                left join t_cond_chem cdc on cdc.dm_cm_code = cm.cm_code
                left join t_cab_cond cabc on cdc.dm_cd_code = cabc.cc_cd_code
                left join t_cable cb on cabc.cc_cb_code = cb.cb_code
                left join t_ptech pto on pto.pt_nd_code = cm_ndcode1
                left join t_ptech pte on pte.pt_nd_code = cm_ndcode2
            order by cm.cm_code"""
        cheminement_layer = self.function_execute_requete(req_cm_pt_cb, 'bab', self.connection)
        bar_progress = self.progress_bar('Partie Traitement Cheminement: cm_typ_imp_cm_typelog')
        if cheminement_layer:
            for index_cm in range(len(cheminement_layer)):
                feature_cm = cheminement_layer[index_cm]
                value_id_code = feature_cm[0]
                value_cm_typ_imp = feature_cm[1]
                value_pt_typephy_origine = feature_cm[2]
                value_pt_typephy_extremite = feature_cm[3]
                value_cm_typelog = feature_cm[5]
                value_cb_typelog = feature_cm[6]
                value_cb_code = feature_cm[4]
                var_compare_liaisaon = self.function_recup_cm_propp(value_pt_typephy_origine, value_pt_typephy_extremite)
                # Ajout dict cm_typlog
                if value_id_code not in dict_cm_typelog:
                    # Controle cm_typ_imp conforme aux regles de la function function_recup_cm_propp
                    if str(value_cm_typ_imp) != str(var_compare_liaisaon):
                        self.function_compare_vale_attribut_entity(value_id_code, self.attribut_cm_typ_imp,
                                                                   value_cm_typ_imp, f'{var_compare_liaisaon} _ '
                                                                                     f'{str(value_pt_typephy_origine)} _ '
                                                                                     f'{str(value_pt_typephy_extremite)}',
                                                                   self.message_cm_typ_imp)
                    dict_cm_typelog[value_id_code] = [[value_cb_typelog, value_cb_code, value_cm_typelog]]
                else:
                    dict_cm_typelog[value_id_code].append([value_cb_typelog, value_cb_code, value_cm_typelog])
                self.progress_processing(index_cm, len(cheminement_layer), bar_progress)
                if bar_progress.wasCanceled():
                    iface.messageBar().pushMessage('Info', 'Action Cancelled', level=Qgis.Info)
                    break

            for index_cm_typelog, (key, vals) in enumerate(dict_cm_typelog.items()):
                list_uniq_val = []
                value_cb_code_dic = {}
                value_cm_typelog_dict = {}
                for index_val in range(len(vals)):
                    value_cb_code_dic[vals[index_val][1]] = vals[index_val][0]
                    value_cm_typelog_dict[key] = vals[index_val][2]
                    if vals[index_val][0] not in list_uniq_val:
                        list_uniq_val.append(vals[index_val][0])
                dict_cm_typelog[key] = list_uniq_val
                # len_list_uniq_val = len(list_uniq_val)
                for key_input, val_input in value_cm_typelog_dict.items():
                    if key_input == key:
                        if self.type_controle == self.entite_type_controle_tr:
                            if val_input not in self.entite_list_cm_typelog_tr:
                                self.function_compare_vale_attribut_entity(key, self.attribut_cm_typelog,
                                                                           val_input,
                                                                           ','.join(self.entite_list_cm_typelog_tr),
                                                                           self.message_cm_typelog)
                        else:
                            self.function_compare_vale_attribut_entity(key, self.attribut_cm_typelog,
                                                                       val_input, self.message_pas_dans_condition,
                                                                       self.message_cm_typelog)
                self.progress_processing(index_cm_typelog, len(dict_cm_typelog), bar_progress)
                if bar_progress.wasCanceled():
                    iface.messageBar().pushMessage('Info', 'Action Cancelled', level=Qgis.Info)
                    break

    def function_cheminement(self):
        try:
            cheminement_layer = self.function_getlayer_bdd(self.schema, self.layer_cheminement, '', self.layer_cheminement,
                                                           'geom')
            feature_cheminement_layer = [feat for feat in cheminement_layer.getFeatures()]
            bar_progress = self.progress_bar('Partie Traitement Cheminement')
            if feature_cheminement_layer:
                for index in range(len(feature_cheminement_layer)):
                    value_feature = feature_cheminement_layer[index]
                    value_id_code = value_feature[self.attribut_cm_code]
                    value_cm_long = value_feature[self.attribut_cm_long]

                    # Controle cm_long different de Calculer
                    value_geom = value_feature.geometry().length()
                    difference_geom = value_geom - float(value_cm_long)
                    if difference_geom > 1:
                        self.function_compare_vale_attribut_entity(value_id_code, self.attribut_cm_long, value_cm_long, 1,
                                                                   self.message_cm_long)

                    # Controle cm_statut different de Megalis
                    self.function_compare_vale_attribut_entity(value_id_code, self.attribut_cm_statut,
                                                               value_feature[self.attribut_cm_statut],
                                                               self.entite_statut, self.message_cm_statut)
                    # Controle cm_avct different de E
                    self.function_compare_vale_attribut_entity(value_id_code, self.attribut_cm_avct,
                                                               value_feature[self.attribut_cm_avct],
                                                               self.entite_avct_e, self.message_cm_avct)

                    # Controle cm_r1_code different de entite_nd_r1_code
                    self.function_compare_vale_attribut_entity(value_id_code, self.attribut_cm_r1_code,
                                                               value_feature[self.attribut_cm_r1_code],
                                                               self.entite_nd_r1_code, self.message_cm_r1_code)
                    # Controle cm_r2_code different de entite_nd_r2_code
                    self.function_compare_vale_attribut_entity(value_id_code, self.attribut_cm_r2_code,
                                                               value_feature[self.attribut_cm_r2_code],
                                                               self.entite_nd_r2_code, self.message_cm_r2_code)
                    # Controle cm_nature different de TEL
                    self.function_compare_vale_attribut_entity(value_id_code, self.attribut_cm_nature,
                                                               value_feature[self.attribut_cm_nature],
                                                               self.entite_cm_nature_tel, self.message_cm_nature)
                    # Controle cm_lgreel 15% cb_long + ne doit pas depasser 2km
                    if value_feature[self.attribut_cm_lgreel] != NULL:
                        verfi_only_number = self.function_verif_number(value_feature[self.attribut_cm_lgreel])
                        if verfi_only_number is False:
                            value_calcul = ((float(value_feature[self.attribut_cm_lgreel]) * 15) / 100) > 2000
                            if value_calcul is not False:
                                self.function_compare_vale_attribut_entity(value_id_code, self.attribut_cm_lgreel,
                                                                           value_feature[self.attribut_cm_lgreel], value_calcul,
                                                                           self.message_cm_lgreel)
                        else:
                            self.function_compare_vale_attribut_entity(value_id_code, self.attribut_cm_lgreel,
                                                                       self.message_pas_nombre,
                                                                       value_feature[self.attribut_cm_lgreel],
                                                                       self.message_cm_lgreel)
                    self.progress_processing(index, len(feature_cheminement_layer), bar_progress)
                    if bar_progress.wasCanceled():
                        iface.messageBar().pushMessage('Info', 'Action Cancelled', level=Qgis.Info)
                        break
                # Controle cm_typ_imp conforme aux regles de la function function_recup_cm_propp
                self.function_cm_typ_imp_cm_typelog()
        except Exception as error:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            return QMessageBox.information(self.w, "Message-Execution-Plugin", f"Erreur sur la function_cheminement:\n {error} ... {exc_tb.tb_lineno}")


# Class pour la partie Adresse
class AdresseTraitement(GeneralFunctionsBthd, GeneralFunctions):
    def __init__(self, var_schema, var_schema_ogre, var_connection, var_type_controle, var_depart_nro,
                 var_code_deploi_dep, var_code_affaire, var_trigrame_nro, var_insee_nro, var_code_armoire):
        super().__init__(var_schema, var_schema_ogre, var_connection, var_type_controle, var_depart_nro,
                         var_code_deploi_dep, var_code_affaire, var_trigrame_nro, var_insee_nro, var_code_armoire)
        self.layer_adresse = 't_adresse'

        # Declaration des attribut Partie Cheminement
        self.attribut_ad_code = 'ad_code'
        self.attribut_ad_iaccgst = 'ad_iaccgst'
        self.attribut_ad_gest = 'ad_gest'

        # Declaration des entites
        self.entite_ad_iaccgst_0 = '0'
        self.entite_ad_iaccgst_1 = '1'

        self.message_ad_iaccgst = "RADR.001"
        self.message_ad_gest = "RADR.002"
        self.message_text_adgest = f'la valeur de lattribut {self.attribut_ad_iaccgst} est incoherent par rapport a lattribut {self.attribut_ad_gest}'

    def function_adresse(self):
        try:
            adresse_layer = self.function_getlayer_bdd(self.schema, self.layer_adresse, '', self.layer_adresse, 'geom')
            feature_adresse_layer = [feat for feat in adresse_layer.getFeatures()]
            bar_progress = self.progress_bar('Partie Traitement Adresse')
            if feature_adresse_layer:
                for index in range(len(feature_adresse_layer)):
                    value_feature = feature_adresse_layer[index]
                    value_id_code = value_feature[self.attribut_ad_code]
                    value_ad_iaccgst = value_feature[self.attribut_ad_iaccgst]
                    value_ad_gest = value_feature[self.attribut_ad_gest]
                    if str(value_ad_iaccgst) == self.entite_ad_iaccgst_0 and value_ad_gest == NULL:
                        res = True
                    elif str(value_ad_iaccgst) == self.entite_ad_iaccgst_1 and value_ad_gest != NULL:
                        res = True
                    else:
                        self.function_compare_vale_attribut_entity(value_id_code, self.attribut_ad_iaccgst, value_ad_iaccgst,
                                                                self.message_text_adgest, self.message_ad_iaccgst)
                        self.function_compare_vale_attribut_entity(value_id_code, self.attribut_ad_gest, value_ad_gest,
                                                                self.message_text_adgest, self.message_ad_gest)
                    self.progress_processing(index, len(feature_adresse_layer), bar_progress)
                    if bar_progress.wasCanceled():
                        iface.messageBar().pushMessage('Info', 'Action Cancelled', level=Qgis.Info)
                        break
        except Exception as error:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            return QMessageBox.information(self.w, "Message-Execution-Plugin", f"Erreur sur la function_adresse:\n {error} ... {exc_tb.tb_lineno}")


# Class pour la partie Tiroir
class TiroirTraitement(GeneralFunctionsBthd, GeneralFunctions):
    def __init__(self, var_schema, var_schema_ogre, var_connection, var_type_controle, var_depart_nro,
                 var_code_deploi_dep, var_code_affaire, var_trigrame_nro, var_insee_nro, var_code_armoire):
        super().__init__(var_schema, var_schema_ogre, var_connection, var_type_controle, var_depart_nro,
                         var_code_deploi_dep, var_code_affaire, var_trigrame_nro, var_insee_nro, var_code_armoire)
        self.layer_tiroir = 'vs_elem_ti_ba_lt_st_nd'

        # Declaration des attribut Partie Cheminement
        self.attribut_ti_code = 'ti_code'
        self.attribut_ti_codeext = 'ti_codeext'
        self.attribut_ti_placemt = 'ti_placemt'
        self.attribut_ti_type = 'ti_type'

        # Declaration des entites
        self.entite_ti_type_tete = 'TETE'

        self.message_ti_type = "RNRO.011"
        self.message_text_ti_type = f'ti_codeext est différent de ti_placemt pour ti_code'

    def function_tiroir(self):
        try:
            tiroir_layer = self.function_getlayer_bdd(self.schema, self.layer_tiroir, self.attribut_ti_code, self.layer_tiroir, 'geom')
            feature_tiroir_layer = [feat for feat in tiroir_layer.getFeatures()]
            bar_progress = self.progress_bar('Partie Traitement Tiroir')
            if feature_tiroir_layer:
                for index in range(len(feature_tiroir_layer)):
                    value_feature = feature_tiroir_layer[index]
                    value_id_code = value_feature[self.attribut_ti_code]
                    value_ti_codeext = value_feature[self.attribut_ti_codeext]
                    value_ti_type = value_feature[self.attribut_ti_type]
                    value_ti_placemt = value_feature[self.attribut_ti_placemt]
                    if value_ti_type == self.entite_ti_type_tete:
                        check_value_ti_codeext = str(value_ti_codeext).replace('.', '').isdigit()
                        check_value_ti_placemt = str(value_ti_placemt).replace('.', '').isdigit()
                        if check_value_ti_codeext and check_value_ti_placemt:
                            if int(float(value_ti_codeext.replace(',', '.'))) != int(float(value_ti_placemt.replace(',', '.'))):
                                self.function_compare_vale_attribut_entity(value_id_code, self.attribut_ti_placemt, value_ti_placemt, value_ti_codeext, self.message_ti_type)
                    self.progress_processing(index, len(feature_tiroir_layer), bar_progress)
                    if bar_progress.wasCanceled():
                        iface.messageBar().pushMessage('Info', 'Action Cancelled', level=Qgis.Info)
                        break
        except Exception as error:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            return QMessageBox.information(self.w, "Message-Execution-Plugin", f"Erreur sur la function_tiroir:\n {error} ... {exc_tb.tb_lineno}")


# Class Parcour reseau par Attribut
class ParcoursReseauAttribut(GeneralFunctionsBthd, GeneralFunctions):
    def __init__(self, var_schema, var_schema_ogre, var_connection, var_type_controle, var_depart_nro,
                 var_code_deploi_dep, var_code_affaire, var_trigrame_nro, var_insee_nro, var_code_armoire):
        super().__init__(var_schema, var_schema_ogre, var_connection, var_type_controle, var_depart_nro,
                         var_code_deploi_dep, var_code_affaire, var_trigrame_nro, var_insee_nro, var_code_armoire)
        self.layer_cable = 'vs_elem_cl_cb'
        self.layer_noeud = 't_noeud'

        # Declaration des attribut Partie Cables
        self.attribut_cb_code = 'cb_code'
        self.attribut_cb_nd1 = 'cb_nd1'
        self.attribut_cb_nd2 = 'cb_nd2'
        self.attribut_nd_code = 'nd_code'
        self.attribut_cb_lgreel = 'cb_lgreel'
        self.message_cb_lgreel = "RCAB.015"

        # Preapartion des listes pour le parcours du reseau
        self.list_shape_lignes = []
        self.list_shape_points = []

    # Function pour Verifier les origines extremites doublon id des lignes et points
    def function_check_origine_extremite_id(self):
        try:
            shape_ligne = self.function_getlayer_bdd(self.schema, self.layer_cable, self.attribut_cb_code, self.layer_cable,
                                                     'geom')
            shape_point = self.function_getlayer_bdd(self.schema, self.layer_noeud, '', self.layer_noeud, 'geom')
            # Creation des listes pour checker les doublons
            list_check_ligne_id = []
            list_check_ligne_exetremite = []
            list_check_ligne_origine_extremite = []
            list_check_point_id = []
            list_check_point_id_absent_extremite_ligne = []

            # Creation shapefile pour le resultat des erreurs de verification de la detection des origines extremites
            check_detection = QgsVectorLayer("LineString?crs=epsg:2154", "erreur_detection_ligne", "memory")
            check_detection_pr = check_detection.dataProvider()
            check_detection_pr.addAttributes(
                [QgsField('id_code', QVariant.String), QgsField('erreur', QVariant.String)])
            check_detection.updateFields()
            check_detection.commitChanges()

            # Creation shapefile pour le resultat des erreurs de verification pour Point
            check_detection_point = QgsVectorLayer("Point?crs=epsg:2154", "erreur_detection_point", "memory")
            check_detection_point_pr = check_detection_point.dataProvider()
            check_detection_point_pr.addAttributes(
                [QgsField('id_code', QVariant.String), QgsField('erreur', QVariant.String)])
            check_detection_point.updateFields()
            check_detection_point.commitChanges()

            # Partie shape Ligne et preparation des listes utilitaires
            bar_progress = self.progress_bar('Partie Traitement ParcoursReseauAttribut')
            for index_cable, cable in enumerate(shape_ligne.getFeatures()):
                geometry_lignes = cable.geometry()
                if geometry_lignes != NULL or geometry_lignes.isGeosValid():
                    geom_wkt_ligne = geometry_lignes.asWkt(2)

                    # Remplissage de la liste list_shape_lignes pour le parcours du reseau
                    self.list_shape_lignes.append([cable[self.attribut_cb_code], cable[self.attribut_cb_nd1],
                                                   cable[self.attribut_cb_nd2], geometry_lignes.length()])
                    # Append List ID Ligne
                    attribute_ligne_id = [geom_wkt_ligne, cable[self.attribut_cb_code]]
                    list_check_ligne_id.append(attribute_ligne_id)

                    # Append List Extremite Ligne
                    attribute_ligne_extremite = [geom_wkt_ligne, cable[self.attribut_cb_nd2]]
                    list_check_ligne_exetremite.append(attribute_ligne_extremite)

                    # Erreur Origine egale Extremite Ligne
                    if cable[self.attribut_cb_nd1] == cable[self.attribut_cb_nd2]:
                        attribute_ligne_origine_extremite = [geom_wkt_ligne, cable[self.attribut_cb_code]]
                        list_check_ligne_origine_extremite.append(attribute_ligne_origine_extremite)
                self.progress_processing(index_cable, shape_ligne.featureCount(), bar_progress)
                if bar_progress.wasCanceled():
                    iface.messageBar().pushMessage('Info', 'Action Cancelled', level=Qgis.Info)
                    break

            # Partie shape Point et preparation des listes utilitaires
            for index_point, point in enumerate(shape_point.getFeatures()):

                # Remplissage de la liste list_shape_points pour le parcours du reseau
                self.list_shape_points.append([point[self.attribut_nd_code], -1])

                geom_wkt_point = point.geometry().asWkt(2)
                # Append List ID Point
                attribute_point_id = [geom_wkt_point, point[self.attribut_nd_code]]
                list_check_point_id.append(attribute_point_id)

                # Append List ID Point absent extremite cable
                point_in_extremite_ligne = 'nok'
                for index_extremite, extremite in enumerate(list_check_ligne_exetremite):
                    if point[self.attribut_nd_code] == extremite[1]:
                        point_in_extremite_ligne = 'ok'
                if point_in_extremite_ligne == 'nok':
                    attribute_point_id_absent_extremite_ligne = [geom_wkt_point, point[self.attribut_nd_code]]
                    list_check_point_id_absent_extremite_ligne.append(attribute_point_id_absent_extremite_ligne)
                self.progress_processing(index_point, shape_point.featureCount(), bar_progress)
                if bar_progress.wasCanceled():
                    iface.messageBar().pushMessage('Info', 'Action Cancelled', level=Qgis.Info)
                    break
            # Erreur Shape identification des doublons didentifiant de Ligne
            erreur_doublon_id_ligne = 'Erreur : Cette Entite est presente plus dune fois dans ID_CODE du shape Ligne'
            for ligne_double in self.get_doublon(list_check_ligne_id):
                attrs = [ligne_double[1], erreur_doublon_id_ligne]
                elem = QgsFeature()
                elem.setGeometry(QgsGeometry.fromWkt(ligne_double[0]))
                elem.setAttributes(attrs)
                check_detection_pr.addFeatures([elem])

            # Erreur Shape identification des doublons extremites de Ligne
            erreur_doublon_extremite_ligne = 'Erreur : Cette Entite est presente plus dune fois dans Extremite du shape ' \
                                             'Ligne'
            for ligne_double_extremite in self.get_doublon(list_check_ligne_exetremite):
                attrs = [ligne_double_extremite[1], erreur_doublon_extremite_ligne]
                elem = QgsFeature()
                elem.setGeometry(QgsGeometry.fromWkt(ligne_double_extremite[0]))
                elem.setAttributes(attrs)
                check_detection_pr.addFeatures([elem])

            # Erreur Shape identification des origines egal extremite de Ligne
            erreur_origine_extremite_ligne = 'ERREUR: Cette Entite a un ID_CODE qui est a la fois origine et extemite'
            for ligne_origine_extremite in list_check_ligne_origine_extremite:
                attrs = [ligne_origine_extremite[1], erreur_origine_extremite_ligne]
                elem = QgsFeature()
                elem.setGeometry(QgsGeometry.fromWkt(ligne_origine_extremite[0]))
                elem.setAttributes(attrs)
                check_detection_pr.addFeatures([elem])

            # Erreur Shape identification des doublons didentifiant de Point
            erreur_doublon_id_point = 'Erreur : Cette Entite est presente plus dune fois dans le shape Point'
            for point_double in self.get_doublon(list_check_point_id):
                attrs = [point_double[1], erreur_doublon_id_point]
                elem = QgsFeature()
                elem.setGeometry(QgsGeometry.fromWkt(point_double[0]))
                elem.setAttributes(attrs)
                check_detection_point_pr.addFeatures([elem])

            # # Erreur Shape identification des Point ID absents dans extremites du Ligne
            # erreur_id_absent_extremite_ligne = 'ERREUR: Cette Entite nest pas presente dans extremite du shape Ligne'
            # for IdAbsentExtremiteLigne in list_check_point_id_absent_extremite_ligne:
            #     attrs = [IdAbsentExtremiteLigne[1], erreur_id_absent_extremite_ligne]
            #     elem = QgsFeature()
            #     elem.setGeometry(QgsGeometry.fromWkt(IdAbsentExtremiteLigne[0]))
            #     elem.setAttributes(attrs)
            #     check_detection_point_pr.addFeatures([elem])

            count_check_detection = check_detection.featureCount()
            count_check_detection_point = check_detection_point.featureCount()
            if count_check_detection > 0:
                QgsProject.instance().addMapLayer(check_detection)
            if count_check_detection_point > 0:
                QgsProject.instance().addMapLayer(check_detection_point)
            return count_check_detection, count_check_detection_point
        except Exception as error:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            return QMessageBox.information(self.w, "Message-Execution-Plugin", f"Erreur sur la function_check_origine_extremite_id:\n {error} ... {exc_tb.tb_lineno}")

    # Function Parcours avec Point
    def function_parcours_reseau(self, noeud, niveau, distance):
        try:
            bar_progress = self.progress_bar('Execution Du calcul du Nbre de Fibre')
            if niveau < 1000:
                len_list_ligne = len(self.list_shape_lignes)
                for index_ligne, var_shape_ligne in enumerate(self.list_shape_lignes):
                    if var_shape_ligne[1] == noeud:
                        self.function_parcours_reseau(var_shape_ligne[2], niveau + 1, var_shape_ligne[3] + distance)
                    self.progress_processing(index_ligne, len_list_ligne, bar_progress)
                    if bar_progress.wasCanceled():
                        iface.messageBar().pushMessage('Info', 'Action Cancelled', level=Qgis.Info)
                        break
                # Ajout la distance calcule dans Points
                for var_shape_point in self.list_shape_points:
                    if var_shape_point[0] == noeud:
                        var_shape_point[1] = distance
            return 0, 0
        except Exception as error:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            return QMessageBox.information(self.w, "Message-Execution-Plugin", f"Erreur sur la function_parcours_reseau:\n {error} ... {exc_tb.tb_lineno}")

    def function_cb_lgreel_parcours(self):
        try:
            bar_progress = self.progress_bar('Partie Traitement cb_lgreel_parcours')
            for index, shape_ligne in enumerate(self.list_shape_lignes):
                distance_pbo_nro = False
                for shape_point in self.list_shape_points:
                    if shape_ligne[2] == shape_point[0]:
                        distance_pbo_nro = shape_point[1]
                if distance_pbo_nro > 15000:
                    self.function_compare_vale_attribut_entity(shape_ligne[0], self.attribut_cb_lgreel, distance_pbo_nro,
                                                               15000, self.message_cb_lgreel)
                self.progress_processing(index, len(self.list_shape_lignes), bar_progress)
                if bar_progress.wasCanceled():
                    iface.messageBar().pushMessage('Info', 'Action Cancelled', level=Qgis.Info)
                    break
        except Exception as error:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            return QMessageBox.information(self.w, "Message-Execution-Plugin", f"Erreur sur la function_cb_lgreel_parcours:\n {error} ... {exc_tb.tb_lineno}")


# Class pour des creations et insertion dans la BDD
class CreateTableBdd(GeneralFunctionsBthd, GeneralFunctions):

    def __init__(self, var_schema, var_schema_ogre, var_connection, var_type_controle, var_depart_nro,
                 var_code_deploi_dep, var_code_affaire, var_trigrame_nro, var_insee_nro, var_code_armoire):
        super().__init__(var_schema, var_schema_ogre, var_connection, var_type_controle, var_depart_nro,
                         var_code_deploi_dep, var_code_affaire, var_trigrame_nro, var_insee_nro, var_code_armoire)

        self.var_fichier = str(folder_plugin) + "/file_excel/DICO_POINTS_CONTROLEvPIEPOM.xlsx"
        self.var_fichier_ref_boite = str(folder_plugin) + '/file_excel/t_ref_ebp.xlsx'
        self.var_fichier_ref_chambre = str(folder_plugin) + '/file_excel/t_ref_chambre.xlsx'
        self.var_fichier_ref_diametre = str(folder_plugin) + '/file_excel/t_ref_diametre.xlsx'

        self.name_table_create = 't_ref_controle'
        self.name_table_error_controle_create = f't_controle_{self.code_armoire}'
        self.name_t_ref_ebp = 't_ref_ebp'
        self.name_t_ref_chambre = 't_ref_chambre'
        self.name_t_ref_diametre = 't_ref_diametre'
        self.list_column_name_ref_join = False

        self.function_execute_function_ref_boite_chambre()

    # Function pour la creation de la table t_ref_boite, t_ref_chambre
    def function_ref_boite_chambre(self, var_fichier, var_name_table):
        try:
            if var_fichier:
                workbook = xlrd.open_workbook(var_fichier, on_demand=True)
                worksheet = workbook.sheet_by_index(0)
                first_row = []  # Header
                for col in range(worksheet.ncols):
                    name_column = str(worksheet.cell_value(0, col))
                    first_row.append(name_column)
                data_dict = []
                for row in range(1, worksheet.nrows):
                    elm = {}
                    for col in range(worksheet.ncols):
                        elm[first_row[col]] = str(worksheet.cell_value(row, col)).replace("'", '"').replace('.0', '')
                    data_dict.append(elm)

                list_column_name_ref = [str(key) for key in data_dict[0].keys()]
                self.list_column_name_ref_join = ','.join(list_column_name_ref)
                req_create_table = """DROP TABLE IF EXISTS """ + self.schema + """.""" + var_name_table + \
                                   """;CREATE TABLE """ + self.schema + """.""" + var_name_table + """(""" + ','.join(
                    [str(key) + '  text'
                     for key in list_column_name_ref]) + """)"""

                list_for_insert = []
                for index_header in range(len(data_dict)):
                    var_tuple = str(tuple(data_dict[index_header].values()))
                    list_for_insert.append(var_tuple)
                text_list_for_insert = """INSERT INTO """ + self.schema + """.""" + var_name_table + """(""" + \
                                       self.list_column_name_ref_join + """) VALUES """ + ','.join(list_for_insert)

                # Execution de la creation de la table t_ref_controle et insertion
                self.function_execute_requete(req_create_table, '', self.connection)
                self.function_execute_requete(text_list_for_insert, '', self.connection)
                self.connection.commit()
            else:
                QMessageBox.warning(self.w, "Message de connexion de la base", f'Erreur lecture: {var_fichier}')
        except Exception as error:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            return QMessageBox.information(self.w, "Message-Execution-Plugin", f"Erreur sur la function_ref_boite_chambre:\n {var_fichier}\n{error} ... {exc_tb.tb_lineno}")

    def function_execute_function_ref_boite_chambre(self):
        bar_progress = self.progress_bar('Creation des tables de refernce')
        features = [1]
        for feature_id, geometry in enumerate(features):
            self.function_ref_boite_chambre(self.var_fichier_ref_boite, self.name_t_ref_ebp)
            self.function_ref_boite_chambre(self.var_fichier_ref_chambre, self.name_t_ref_chambre)
            self.function_ref_boite_chambre(self.var_fichier_ref_diametre, self.name_t_ref_diametre)
            self.progress_processing(feature_id, len(features), bar_progress)
            if bar_progress.wasCanceled():
                iface.messageBar().pushMessage('Info', 'Action Cancelled', level=Qgis.Info)
                break

    # Function pour la creation de la table t_ref_controle pour les codes
    def function_create_table_ref_controle(self):
        try:
            if self.var_fichier:
                workbook = xlrd.open_workbook(self.var_fichier, on_demand=True)
                worksheet = workbook.sheet_by_index(0)
                first_row = []  # Header
                list_column_autorises = ['id_controle', 'nom_table', 'ct_criticité', 'ct_comment', 'id_code',
                                         'id_etiquet / id_codeext', 'ct_attendu']
                for col in range(worksheet.ncols):
                    name_column = str(worksheet.cell_value(0, col))
                    first_row.append(name_column)
                data_dict = []
                for row in range(1, worksheet.nrows):
                    elm = {}
                    for col in range(worksheet.ncols):
                        if first_row[col] in list_column_autorises:
                            elm[first_row[col]] = str(worksheet.cell_value(row, col)).replace("'", '"')
                    data_dict.append(elm)

                list_column_name_ref = [str(key).replace(' / id_codeext', '') for key in data_dict[0].keys()]
                self.list_column_name_ref_join = ','.join(list_column_name_ref)
                req_create_table = """DROP TABLE IF EXISTS """ + self.schema + """.""" + self.name_table_create + \
                                   """;CREATE TABLE """ + self.schema + """.""" + self.name_table_create + """(""" + ','.join(
                    [str(key) + '  text'
                     for key in list_column_name_ref]) + """)"""
                req_create_table_error_control = req_create_table.replace(self.name_table_create,
                                                                          self.name_table_error_controle_create)
                list_for_insert = []
                for index_header in range(len(data_dict)):
                    var_tuple = str(tuple(data_dict[index_header].values()))
                    list_for_insert.append(var_tuple)
                text_list_for_insert = """INSERT INTO """ + self.schema + """.""" + self.name_table_create + """(""" + \
                                       self.list_column_name_ref_join + """) VALUES """ + ','.join(list_for_insert)

                # Execution de la creation de la table t_ref_controle et insertion
                self.function_execute_requete(req_create_table, '', self.connection)
                self.function_execute_requete(req_create_table_error_control, '', self.connection)
                self.function_execute_requete(text_list_for_insert, '', self.connection)
        except Exception as error:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            return QMessageBox.information(self.w, "Message-Execution-Plugin", f"Erreur sur la function_create_table_ref_controle:\n {error} ... {exc_tb.tb_lineno}")

    # Function pour linsertion des erreurs de controles dans la BDD
    def function_insert_erreur_control_bdd(self):
        try:
            req_ref_controle = """select * from """ + self.schema + """.""" + self.name_table_create
            res_req_ref_controle = self.function_execute_requete(req_ref_controle, 'bab', self.connection)
            list_insert_value = []
            bar_progress = self.progress_bar('Partie Traitement insert_erreur_control_bdd')
            for index_controle in range(len(self.list_resultats_controle)):
                value_feature_error_cntrl = self.list_resultats_controle[index_controle]
                id_controle = False
                nom_table = False
                ct_criticite = False
                ct_comment = False
                id_code = value_feature_error_cntrl[0]
                id_etiquete = value_feature_error_cntrl[0]
                ct_attendu = value_feature_error_cntrl[1]
                for index_ref_control in range(len(res_req_ref_controle)):
                    value_feature_ref_controle = res_req_ref_controle[index_ref_control]
                    if value_feature_ref_controle[0] == value_feature_error_cntrl[3]:
                        id_controle = value_feature_ref_controle[0]
                        nom_table = value_feature_ref_controle[1]
                        ct_criticite = value_feature_ref_controle[2]
                        ct_comment = value_feature_ref_controle[3]
                tuple_insert = tuple([id_controle, nom_table, ct_criticite, ct_comment, id_code, id_etiquete, ct_attendu])
                list_insert_value.append(str(tuple_insert))
                self.progress_processing(index_controle, len(self.list_resultats_controle), bar_progress)
                if bar_progress.wasCanceled():
                    iface.messageBar().pushMessage('Info', 'Action Cancelled', level=Qgis.Info)
                    break
            if list_insert_value:
                text_list_for_insert = """INSERT INTO """ + self.schema + """.""" + self.name_table_error_controle_create + """(""" + \
                                       str(self.list_column_name_ref_join) + """) VALUES """ + ','.join(list_insert_value)
                # Partie insertion finale des erreurs dans la BDD
                self.function_execute_requete(text_list_for_insert, '', self.connection)
        except Exception as error:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            return QMessageBox.information(self.w, "Message-Execution-Plugin", f"Erreur sur la function_insert_erreur_control_bdd:\n {error} ... {exc_tb.tb_lineno}")

    # Function pour la spatialisation et recuperation des zs_r4_code
    def function_get_zs_r4_code(self):
        var_requete = f"""set search_path to {self.schema} , public;
        DROP FUNCTION IF EXISTS create_tab_geom_general(var_schema text, var_name_table_controle text);
        create or replace function create_tab_geom_general(var_schema text, var_name_table_controle text) returns void as $$
            declare
            var_req_execute record;
            qry text := '';
            var_name_table_create text := 'tab_all_geometrie_id_code';
            var_name_index_geom_table_create text := 'tab_all_geometrie_geom_gist';
            var_name_index_idcode_table_create text := 'tab_all_geometrie_id_code_idx';
            
            begin
            EXECUTE 'DROP TABLE IF EXISTS '||var_schema||'.'||var_name_table_create;
            EXECUTE 'DROP INDEX IF EXISTS '||var_schema||'.'||var_name_index_geom_table_create;
            FOR var_req_execute in
                select 
                    tab_geom.table_schema,
                    tab_geom.table_name,
                    tab_geom.columns_list,
                    'select distinct '||tab_geom.columns_list||' from '||tab_geom.table_schema||'.'||tab_geom.table_name as req
                from geometry_columns 
                    join (select 
                            max(table_schema) table_schema, 
                            table_name, 
                            quote_literal(table_name)|| '::text as name_table, ' ||array_to_string(array_agg(column_name::text), ',')||'::text as id_code, geom' columns_list
                        from information_schema.columns
                        where (ordinal_position = 1) and 
                            ---(table_name like 't_%' or table_name like 'vs_elem_%') and 
                            table_schema = var_schema
                        group by table_name order by table_name) as tab_geom on tab_geom.table_name = f_table_name
                WHERE f_table_schema = var_schema and f_table_name in ('vs_elem_cl_cb','t_cheminement','t_znro','t_zsro','t_zpbo','t_zdep', 't_adresse','vs_elem_bp_pt_nd','vs_elem_pt_nd','vs_elem_st_nd') 
                order by f_table_name
                LOOP
                    if var_req_execute.req is not null then
                    IF length(qry) > 0 THEN
                        qry := qry|| ' UNION ALL '::text;
                    END IF;
                    qry := qry || var_req_execute.req;
                    end if;
                END LOOP;
                EXECUTE 'CREATE TABLE ' || var_schema || '.'||var_name_table_create||' as '||qry;
                EXECUTE 'CREATE INDEX '||var_name_index_geom_table_create||' ON '||var_schema ||'.'||var_name_table_create||' USING gist(geom)';
                EXECUTE 'CREATE INDEX '||var_name_index_idcode_table_create||' ON '|| var_schema ||'.'||var_name_table_create||' USING btree (id_code COLLATE pg_catalog."default")';
                --RAISE NOTICE '%' , qry;
            begin
                EXECUTE 'ALTER TABLE IF EXISTS '||var_name_table_controle||' ADD COLUMN IF NOT EXISTS zs_r4_code text';
                ---EXECUTE 'ALTER TABLE IF EXISTS '||var_name_table_controle||' ADD COLUMN IF NOT EXISTS geom geometry';
                EXECUTE 'ALTER TABLE '||var_name_table_controle||' ADD COLUMN id SERIAL PRIMARY KEY';
                EXECUTE 'UPDATE '||var_name_table_controle||' as tbrute
                    SET zs_r4_code = tf.zsr4code
                    ---,geom = tf.namegeometry
                from (
                    --Within
                    select 
                        ctr.*, all_tab.name_table, all_tab.geom as namegeometry, zs.zs_r4_code as zsr4code
                    from '||var_name_table_controle||' as ctr
                        left join tab_all_geometrie_id_code as all_tab on ctr.id_code = all_tab.id_code
                        left join t_zsro zs on st_within(all_tab.geom, zs.geom)
                    where all_tab.name_table in (''t_zpbo'',''t_zdep'', ''t_adresse'',''vs_elem_bp_pt_nd'',
                    ''vs_elem_pt_nd'',''vs_elem_st_nd'')
                    union
                    --Intersect
                    select 
                        ctr.*, all_tab.name_table, all_tab.geom, zs.zs_r4_code
                    from '||var_name_table_controle||' as ctr
                        left join tab_all_geometrie_id_code as all_tab on ctr.id_code = all_tab.id_code
                        left join t_zsro zs on st_dwithin(all_tab.geom, zs.geom, 0.1)
                    where all_tab.name_table in (''vs_elem_cl_cb'',''t_cheminement'')
                ) as tf where tbrute.id_code = tf.id_code;';
            end;
            end;
        $$ language plpgsql volatile;
        select * from create_tab_geom_general('{self.schema}', '{self.name_table_error_controle_create}');"""
        self.function_execute_requete(var_requete, '', self.connection)


# Class DICO POINTS CONTROLES THDB
class DicoPointControlesThdbDistribution(SroTraitement, EbpTraitement, CableTraitement, PointTechniquesTraitement,
                                         CheminementTraitement, AdresseTraitement, TiroirTraitement, ParcoursReseauAttribut,
                                         CreateTableBdd):
    def __init__(self, var_schema, var_schema_ogre, var_connection, var_type_controle, var_depart_nro,
                 var_code_deploi_dep, var_code_affaire, var_trigrame_nro, var_insee_nro, var_code_armoire):
        super().__init__(var_schema, var_schema_ogre, var_connection, var_type_controle, var_depart_nro,
                         var_code_deploi_dep, var_code_affaire, var_trigrame_nro, var_insee_nro, var_code_armoire)

        # Partie execution SRO
        self.function_sro()
        # Partie execution EBP
        self.function_ebp()
        # Partie execution Cables
        self.function_cable()
        # Partie execution Points Techniques
        self.function_pointtechniques()
        # Partie execution Cheminements
        self.function_cheminement()
        # Partie execution Adresse
        self.function_adresse()
        # Partie execution Tiroir
        self.function_tiroir()
        # Partie execution Distance NRO_PBO
        self.res_count_check_detection, self.res_count_check_detection_point = \
            self.function_check_origine_extremite_id()
        if self.res_count_check_detection == 0 and self.res_count_check_detection_point == 0:
            self.function_parcours_reseau(self.depart_nro, 0, 0)
            self.function_cb_lgreel_parcours()
        # Partie execution Insertion des erreurs dans la BDD
        self.function_create_table_ref_controle()
        self.function_insert_erreur_control_bdd()
        self.function_get_zs_r4_code()


def function_execute_dicopointcontrolesthdbtransport(schema, depart_nro, var_type_controle,
                                                        var_code_deploi_dep, var_code_affaire, var_trigrame_nro,
                                                        var_insee_nro, var_code_armoire):
    global DB, user, MP, host, port
    w = QWidget()
    try:
        # Partie Modelisation des donnes transports
        recupe_new_schema = ModelisationTransport(schema, var_code_armoire)
        schema = recupe_new_schema.name_schema_modelisation_trans

        # Partie Modelisation topologique des donnes transports et calculs
        ModelisationReseauTransport(schema, depart_nro)

        # Partie Creation des tables
        connection = psycopg2.connect(user=user, password=MP, host=host, port=port, database=DB)
        CreateTableBdd(schema, schema, connection, var_type_controle, depart_nro,
                       var_code_deploi_dep, var_code_affaire, var_trigrame_nro, var_insee_nro, var_code_armoire)

        # Partie Traitement
        DicoPointControlesThdbDistribution(schema, schema, connection, var_type_controle,
                                           depart_nro, var_code_deploi_dep, var_code_affaire,
                                           var_trigrame_nro, var_insee_nro, var_code_armoire)
        connection.close()
        QMessageBox.information(w, "Message-Plugin", f'Execution du Traitement Reussi. Les resultats sont dans le schema suivant : {schema}')
    except(Exception, psycopg2.DatabaseError) as error:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        return QMessageBox.warning(w, "Message-Plugin", f'Erreur de Execution: {error} ... {exc_tb.tb_lineno}')


# {
# schema = 'trans_01109_dlg_v4'  # DI recd_z01153_v20201009  TR: trans_01109_dlg_v4 trans_model schema_test
# schema_ogre = 'trans_01109_dlg_v4'
# depart_nro = 'NDMB0110901961'  # TR: NDMB0110901961 DI: NDMB0115301362
# # var_phase = 'REC'
# # var_moe_name = 'MOE'
# # var_pr_name = 'PR_BABA'
# # var_file_echange = r'C:\Users\babacar.fassa\Documents\GitHub\WASP_AMBITION\file_sql\create_modele_echange.sql'
# # function_execute_controle_design(schema, var_file_echange, var_moe_name, var_pr_name, var_phase)
# var_code_deploi_dep = 'T2-56'  # 'T2-29'
# var_code_affaire = '01042'  # '01109'
# var_trigrame_nro = 'PLM'  # 'CRO'
# var_insee_nro = '56165'  # '29042'
# var_code_armoire = 'S011011'  # 'S029'
# function_execute_dicopointcontrolesthdbtransport(schema, depart_nro, 'TR',
#                                                     var_code_deploi_dep, var_code_affaire, var_trigrame_nro,
#                                                     var_insee_nro, var_code_armoire)
