from .class_file_global_menu import ambition_menu, var_class_init_custom_menu_bar
from .vidange_cache_qgis import function_delete_cache_qgis
from .forms.check_bthd_form import ClassCheckBthdTransporExecuteDialog
from qgis.PyQt.QtWidgets import QMessageBox, QWidget


class ClassGeneraleMenu:
    def __init__(self, iface):
        self.iface = iface
        self.name_menu_projet = var_class_init_custom_menu_bar.funct_add_submenu_projet_to_global(ambition_menu, 'ORANGE-BTHD')
        self.name_group_trans = "A.3. ORANGE-BTHD-REC-TRANSPORT"

    def initGui(self):
        # PIQUETAGE Submenu
        res_vidange = function_delete_cache_qgis()
        if res_vidange[1] is False:
            QMessageBox.warning(QWidget(), "Message dexecution de requete", 'Le cache nest pas vide ... ' + str(res_vidange))

        self.dtsri_rec_menu = var_class_init_custom_menu_bar.func_add_submenu_group_to_projet(self.name_menu_projet, self.name_group_trans)

        var_class_init_custom_menu_bar.func_add_action_menu(self.dtsri_rec_menu,
                                                            "A.2.1 Check des données de Transport",
                                                            self.exe_class_checkdistrirec_dialog)

    def unload(self):
        self.iface.removePluginMenu(self.name_group_trans, self.dtsri_rec_menu.menuAction())

    def exe_class_checkdistrirec_dialog(self):
        self.execheckdistrirec = ClassCheckBthdTransporExecuteDialog(self.iface)
        self.execheckdistrirec.exec_()
