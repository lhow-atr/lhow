import psycopg2
from qgis.utils import iface
from qgis.PyQt.QtWidgets import QMessageBox
# # Server Test
# DB = 'MCD_ADN_sans_ct'
# user = 'adn_ing'
# MP = 'password'
# host = '192.168.30.195'
# port = '5432'

# # Server Test
# DB = 'MCD_ADN_sans_ct'
# user = 'admambigroup'
# MP = 'secure'
# host = '192.168.30.195'
# port = '5432'

# Server Prod
DB = 'MCD_ADN_sans_ct'
user = 'admambigroup'
MP = 'secure'
host = '192.168.30.194'
port = '5432'

# # Server Test
# DB = 'gracethd_v2_0_1'
# user = 'postgres'
# MP = 'MYPASSWORD'
# host = '127.0.0.1'
# port = '5439'


def function_connexion():
    # Parameter connexion base
    global DB, user, MP, host, port
    # Connexion a la base
    try:
        connection = psycopg2.connect(user=user, password=MP, host=host, port=port, database=DB)
        return connection
    except(Exception, psycopg2.DatabaseError) as error:
        QMessageBox.critical(iface.mainWindow(), "Message de connexion de la base",
                             'Erreur de connexion de la base' + str(error))
