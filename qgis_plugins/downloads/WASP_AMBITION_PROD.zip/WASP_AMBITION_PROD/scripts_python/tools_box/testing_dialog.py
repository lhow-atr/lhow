from qgis.PyQt import QtCore, QtWidgets
from qgis.PyQt.QtWidgets import QApplication, QMessageBox
from qgis.gui import QgsCheckableComboBox, QgsDateTimeEdit, QgsFileWidget
from qgis.utils import iface
import datetime
import sys
from pathlib import Path

# https://www.daniweb.com/programming/software-development/threads/415573/python-pyqt-understanding-modules-classes-and-objects

folder_plugin = str(Path(__file__).parent.parent.parent)


class ClassUiDesignDialog(object):
    def setupUi(self, var_dialog):
        self.now = datetime.datetime.now()

        # Partie de la declaration de la fenetre de boite de dialog
        var_dialog.setObjectName("Controle_Des_DesignDialogBase")
        var_dialog.setWindowModality(QtCore.Qt.ApplicationModal)
        var_dialog.setEnabled(True)
        var_dialog.resize(800, 800)
        var_dialog.setMouseTracking(False)
        var_dialog.setWindowTitle("DESIGN v0.01 - Importation des donnees dans la BDD")

        # Partie de la creation dun container de dessin de la boite de dialog
        self.verticalLayoutWidget = QtWidgets.QWidget(var_dialog)
        self.verticalLayoutWidget.setGeometry(QtCore.QRect(30, 30, 700, 700))
        self.verticalLayoutWidget.setObjectName("verticalLayoutWidget")

        # Partie de la creation sous container
        self.verticalLayout = QtWidgets.QVBoxLayout(self.verticalLayoutWidget)
        self.verticalLayout.setContentsMargins(0, 0, 0, 0)
        self.verticalLayout.setObjectName("verticalLayout")

        # Partie de la creation d'une Grille pour organiser les labels et leur object
        self.gridLayout = QtWidgets.QGridLayout()
        self.gridLayout.setObjectName("gridLayout")

        # Partie de la creation du label Nom_PR
        self.label_12 = QtWidgets.QLabel(self.verticalLayoutWidget)
        self.label_12.setObjectName("label_12")
        self.label_12.setText("Nom du pr")
        self.gridLayout.addWidget(self.label_12, 0, 0)  # Ajout du label dans la grille

        # Partie de la creation du label Statut
        self.label_2 = QtWidgets.QLabel(self.verticalLayoutWidget)
        self.label_2.setObjectName("label_2")
        self.label_2.setText("STATUT")
        self.gridLayout.addWidget(self.label_2, 0, 1)  # Ajout du label dans la grille

        # Partie de la creation du label Choisir la date
        self.label_18 = QtWidgets.QLabel(self.verticalLayoutWidget)
        self.label_18.setObjectName("label_18")
        self.label_18.setText("Choisir la date")
        self.gridLayout.addWidget(self.label_18, 0, 2)  # Ajout du label dans la grille

        # Partie de la creation du label label_folder
        self.label_folder = QtWidgets.QLabel(self.verticalLayoutWidget)
        self.label_folder.setObjectName("label_folder")
        self.label_folder.setText("label_folder")
        self.gridLayout.addWidget(self.label_folder, 2, 0)  # Ajout du label dans la grille

        # Partie de la creation du label label_checkbox
        self.label_checkbox = QtWidgets.QLabel(self.verticalLayoutWidget)
        self.label_checkbox.setObjectName("label_checkbox")
        self.label_checkbox.setText("label_checkbox")
        self.gridLayout.addWidget(self.label_checkbox, 2, 1)  # Ajout du label dans la grille

        # Partie de la creation du label label_folder
        self.label_number = QtWidgets.QLabel(self.verticalLayoutWidget)
        self.label_number.setObjectName("label_number")
        self.label_number.setText("label_number")
        self.gridLayout.addWidget(self.label_number, 2, 2)  # Ajout du label dans la grille

        # Partie de la creation du Nom pr_baba
        self.name_pr = QtWidgets.QLineEdit(self.verticalLayoutWidget)
        self.name_pr.setMinimumSize(QtCore.QSize(111, 0))
        self.name_pr.setObjectName("name_pr")
        self.name_pr.setText("pr_baba")
        self.gridLayout.addWidget(self.name_pr, 1, 0)  # Ajout du label dans la grille

        # Partie de la creation du Nom name_statut
        self.name_statut = QgsCheckableComboBox(self.verticalLayoutWidget)
        self.name_statut.setMinimumSize(QtCore.QSize(106, 0))
        self.name_statut.setObjectName("name_statut")
        # self.name_statut.addItem("AOR")  # Pour inserer un element par element
        self.name_statut.addItems(['AOR', 'DEO', 'DEP', 'DIU', 'DOE', 'DET', 'EXE', 'MCO', 'PRO'])
        self.gridLayout.addWidget(self.name_statut, 1, 1)  # Ajout du label dans la grille

        # Partie de la creation du Nom name_date
        self.name_date = QgsDateTimeEdit(self.verticalLayoutWidget)
        self.name_date.setEnabled(True)
        self.name_date.setMinimumSize(QtCore.QSize(110, 0))
        self.name_date.setDateTime(QtCore.QDateTime(QtCore.QDate(self.now.year, self.now.month, self.now.day)))
        self.name_date.setCalendarPopup(True)
        self.name_date.setAllowNull(False)
        self.name_date.setObjectName("name_date")
        self.gridLayout.addWidget(self.name_date, 1, 2)

        self.exemple_directory = QgsFileWidget(self.verticalLayoutWidget)
        self.exemple_directory.setObjectName("exemple_directory")
        self.exemple_directory.setStorageMode(QgsFileWidget.GetDirectory)
        self.gridLayout.addWidget(self.exemple_directory, 3, 0)

        self.exemple_checkbox = QtWidgets.QCheckBox(self.verticalLayoutWidget)
        self.exemple_checkbox.setObjectName("exemple_checkbox")
        self.gridLayout.addWidget(self.exemple_checkbox, 3, 1)

        self.exemple_spinbox = QtWidgets.QDoubleSpinBox(self.verticalLayoutWidget)
        self.exemple_spinbox.setObjectName("exemple_spinbox")
        self.gridLayout.addWidget(self.exemple_spinbox, 3, 2)

        self.verticalLayout.addLayout(self.gridLayout)  # Ajout de la grille dans le vertitcallayout

        # Partie de la creation du Nom textBrowser
        self.textBrowser = QtWidgets.QTextBrowser(self.verticalLayoutWidget)
        self.textBrowser.setObjectName("textBrowser")
        self.textBrowser.setHtml(
            # Ouverture Parametrage du HTML
            """
            <!DOCTYPE html>
            <html lang="en">
            <head>
                <meta charset="UTF-8">
                <title>Title</title>
                <style type="text/css">
                    div, li {text-indent: 25px; font-size:11pt}
                    body {text-align: justify; font: sans-serif;}
                </style>
            </head>
            <body>
            """

            # Corp du text
            """
            <h3> Objectifs: </h3>
                <div> Ce module permet d'integrer un livrable en base de données. </div>
            <h3> Données en entrée: </h3>
                <div> L'ensemble des shapefiles et tables CSV qui composent le livrable à intégrer en base de données 
                doit être dans un répertoire unique. L'utilisateur renseigne les paramètres correspondants au livrable 
                à importer en base de données. S'il n'existe pas de schéma existant avec les paramètres renseignés, 
                un nouveau schéma est alors créé, et les données importées.</div>
            <h3> Résultat: </h3>
                <div> Le livrable est importé dans un schéma en base de données.</div>
            <h3> Contraintes: </h3>
                <div> Le livrable à intégrer doit respecter le formalisme du MCD.</div>
            <h3> Restrictions:</h3>
                <ol>
                  <li> Valeur d'attribut  ' NULL ' remplacée par ' 0 '</li>
                  <li> Attributs de type ' DATE ' non importés </li>
                </ol>
            """

            # Fin Parametrage du HTML
            """
            < / body >
            < / html > """
        )
        self.verticalLayout.addWidget(self.textBrowser)  # Ajout du textBrowser dans le vertitcallayout

        # Partie de la creation du Nom button_box
        self.button_box = QtWidgets.QDialogButtonBox(self.verticalLayoutWidget)
        self.button_box.setOrientation(QtCore.Qt.Horizontal)
        self.button_box.setStandardButtons(QtWidgets.QDialogButtonBox.Cancel | QtWidgets.QDialogButtonBox.Ok)
        self.button_box.setObjectName("button_box")
        self.verticalLayout.addWidget(self.button_box)  # Ajout du button_box dans le vertitcallayout

        # self.retranslateUi(Controle_Des_DesignDialogBase)
        self.button_box.accepted.connect(var_dialog.accept)
        self.button_box.rejected.connect(var_dialog.reject)
        QtCore.QMetaObject.connectSlotsByName(var_dialog)


def baba():
    var_pr = ''
    var_statut = ''
    print(f'Nom du PR: {var_pr}\nLes statuts choisis: {var_statut}')


# if __name__ == "__main__":
#     app = QApplication(sys.argv)
#     Form = QtWidgets.QDialog()
#     ui = Ui_Controle_Des_DesignDialogBase()
#     ui.setupUi(Form)
#     Form.show()
#     name_pr = ui.name_pr.text()
#     name_statut = ui.name_statut.currentText()
#     name_date = ui.name_date.date().toString("yyyyMMdd")
#     print(name_pr, ';', name_statut, ';', name_date)
#     ui.button_box.button(QtWidgets.QDialogButtonBox.Ok).clicked.connect(baba)
#     sys.exit(app.exec_())


class ClassGeneralDialog(QtWidgets.QDialog):
    def __init__(self, iface):
        QtWidgets.QDialog.__init__(self)
        self.iface = iface

    def get_version_plugin(self):
        folder_metada = open(folder_plugin + "\metadata.txt")
        for line in folder_metada:
            if str(line)[:7] == 'version':
                get_version = line.split('=')[1]
                folder_metada.close()
                return get_version


class ClassTestExecuteDialog(ClassGeneralDialog, ClassUiDesignDialog):
    def __init__(self, iface):
        ClassGeneralDialog.__init__(self, iface)
        self.setupUi(self)
        self.setWindowTitle("DESIGN " + str(self.get_version_plugin()) + " - Importation des donnees dans la BDD")
        self.button_box.button(QtWidgets.QDialogButtonBox.Ok).clicked.connect(self.run)

    def run(self):
        list_statut = self.name_statut
        text_statut = [x for x in list_statut.currentText().split(',') if x]

        if len(text_statut) != 1:
            QMessageBox.critical(self.iface.mainWindow(), "Message Du Choix", 'Veillez cocher un Seul STATUT')
        else:
            name_date = self.name_date.date().toString("yyyyMMdd")
            nom_pr = self.name_pr.text()
            nom_phase = "".join(text_statut)
            schema = str(nom_pr).lower() + '_' + str(nom_phase).lower() + '_' + 'v_' + str(name_date)
            print(str(self.exemple_directory.filePath()), ';', self.exemple_checkbox.isChecked(), ';',
                  self.exemple_spinbox.value())
            print(len(text_statut), ';', text_statut, ';', schema)
            QMessageBox.critical(self.iface.mainWindow(), "Message Du Choix", schema)

# app = QApplication(sys.argv)
# baba_dialog = ClassTestExecuteDialog(iface)
# baba_dialog.show()
# sys.exit(app.exec_())
