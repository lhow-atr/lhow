import processing,xlrd,psycopg2,sys,xlwt
from qgis.PyQt.QtCore import *
from qgis.PyQt.QtGui import *
from qgis.core import * 
from qgis.utils import *
from collections import defaultdict
from qgis.gui import *
from qgis.PyQt.QtWidgets import *
import time
import datetime

from shapely.geometry import Point,LineString,MultiPoint
from shapely.ops import split

from ...params_connexion import *


def function_Dimensionnement_boitiers_optiques(schema, var_MOE, var_PR, var_phase):
	# Parameter connexion base
	# DB = 'MCD_ADN_sans_ct'
	# user = 'adn_ing'
	# MP = 'password'
	# host = '192.168.30.194'
	# port = '5432'

	global DB, user, MP, host, port

	table_zsro = 't_zsro'
	attribut_zs_refpm = 'zs_refpm'
	var_aud = 'AUD'
	var_type = 'AUD'

	# Declaration de la variable pour les messages derreur
	w = QWidget()
	# Connexion a la base
	try:
		connection = psycopg2.connect(user=user,password=MP,host=host,port=port,database=DB)
	except(Exception, psycopg2.DatabaseError) as error:
		QMessageBox.warning(w, "Message de connexion de la base", 'Erreur de connexion de la base')

	# Declaration de la variable pour les messages derreur
	w = QWidget()

	# Function pour la progession bar1
	def progress_bar(name_etape):
		prog = QProgressDialog(name_etape + ' : Veillez Patienter', 'Cancel', 0, 100)
		prog.setWindowModality(Qt.WindowModal)
		prog.setMinimumDuration(1)
		return prog
		
	# Function pour la progession bar2
	def progress_processing(index, count_entite, progress_dialog):
		f = int(index + 1)
		pcnt = int(f/count_entite * 100/1)
		progress_dialog.setValue(pcnt)
		
	# Function pour executer une requete sql dans la base
	def function_execute_requete(requete_execute, req_fetch, connection):
		curs=connection.cursor()
		try:
			curs.execute(requete_execute)
			if req_fetch:
				data_req=[row for row in curs.fetchall()]
				if data_req:
					return data_req
		except(Exception, psycopg2.DatabaseError) as error:
			QMessageBox.warning(w, "Message dexecution de requete", 'Requete Non Executer : '+str(error)+' ; '+str(requete_execute))
		curs.close()

	# Function for return layer objet
	def function_return_layer(base_name, user_name, password, host_name, port_name, schema_name, table_name, key):
		try:
			uri = QgsDataSourceUri()
			DB = base_name
			user = user_name
			MP = password
			host = host_name
			port = port_name
			schema = schema_name
			uri.setConnection(host, port, DB, user, MP)
			uri.setDataSource(schema, table_name, "geom", '', key)
			layer = QgsVectorLayer(uri.uri(False), table_name, "postgres")
			# QgsProject.instance().addMapLayer(layer)
			if layer.isValid():
				# QgsProject.instance().addMapLayer(layer)
				return layer
		except (Exception, psycopg2.DatabaseError) as error:
			QMessageBox.warning(w, "Message de connexion de la base", 'Erreur de connexion de la base')
		
	listing_error_control_ADN = []
	now = datetime.datetime.now()
	nowdate = str(now.year) + '-' + str(now.month).zfill(2) + '-' + str(now.day).zfill(2)
	prefix_id_error = 'AUD_'

	# B01_Installation de boitiers optiques
	def function_B01(schema):
		# Verifier limplantation de boitiers BPE au maximum tous les 500m (nombre depissures equivalent a la capacite du cable)
		def function_B01_1_general():
			# cb_PrimaryKey = "cb_code"
			# ebp_PrimaryKey = "bp_code"
			# features_cable = function_return_layer(DB,user,MP,host,port,schema,'vs_elem_cl_cb',cb_PrimaryKey)  # function_getlayer_name('t_cable')
			# features_pt = function_return_layer(DB,user,MP,host,port,schema,'vs_elem_bp_pt_nd',ebp_PrimaryKey)  # function_getlayer_name('t_ebp')
			bar_progress = progress_bar('function_B01_1: Identification des cables de longueur supérieur à 500')
			class function_create_infra_final():
				@staticmethod
				def cut_line_at_points(line, points):

					# First coords of line
					coords = list(line.coords)

					# Keep list coords where to cut (cuts = 1)
					cuts = [0] * len(coords)
					cuts[0] = 1
					cuts[-1] = 1

					# Add the coords from the points
					coords += [list(p.coords)[0] for p in points]    
					cuts += [1] * len(points)        

					# Calculate the distance along the line for each point    
					dists = [line.project(Point(p)) for p in coords]
					# sort the coords/cuts based on the distances    
					# see http://stackoverflow.com/questions/6618515/sorting-list-based-on-values-from-another-list    
					coords = [p for (d, p) in sorted(zip(dists, coords))]    
					cuts = [p for (d, p) in sorted(zip(dists, cuts))]          

					# generate the Lines    
					#lines = [LineString([coords[i], coords[i+1]]) for i in range(len(coords)-1)]    
					lines = []

					for i in range(len(coords)-1):    
						if cuts[i] == 1:    
							# find next element in cuts == 1 starting from index i + 1 
							try :
								j = cuts.index(1, i + 1)
								lines.append(LineString(coords[i:j+1]))
							except ValueError:
								result_error = ValueError
					return lines

				@staticmethod
				def multipart_to_singlepart(geom):
					
					multiGeom = QgsGeometry()
					geometries = []

					if geom.type()==QgsWkbTypes.LineGeometry:
						if geom.isMultipart():
							multiGeom = geom.asMultiPolyline()
							for i in multiGeom:
								geometries.append(QgsGeometry().fromPolylineXY(i))
						else:
							geometries.append(geom)

					return geometries

				@staticmethod
				def function_multipart_to_singlepart(layer_cable):
					
					multiline_to_sigleline = QgsVectorLayer("LineString?crs=epsg:2154", "multiline_to_sigleline", "memory")
					multiline_to_sigleline_pr2 = multiline_to_sigleline.dataProvider()
					multiline_to_sigleline_attr2 = layer_cable.dataProvider().fields().toList()
					multiline_to_sigleline_pr2.addAttributes(multiline_to_sigleline_attr2)

					for feature_cab in layer_cable.getFeatures():
						geom_cable=feature_cab.geometry()
						
						geometries = function_create_infra_final.multipart_to_singlepart(geom_cable)
						
						outFeat = QgsFeature()
						attrs = feature_cab.attributes()
						outFeat.setAttributes(attrs)

						for g in geometries:
							outFeat.setGeometry(g)
							multiline_to_sigleline_pr2.addFeatures([outFeat])
							
					multiline_to_sigleline.updateFields()
					multiline_to_sigleline.commitChanges()
					
					return multiline_to_sigleline

				# Suppression de doublons de géométrie plus detection Origine/Extremite
				@staticmethod
				def function_B01_1(layer_chem,layer_boite):
					bar_progress=progress_bar('Suppression de doublons de géométrie plus detection Origine/Extremite')
					layer_features=layer_chem#function_return_layer(DB,user,MP,host,port,schema,layer_chem,'')
					features_boite=layer_boite
					
					#Creation des shapefles des erreurs
					cable_decoupe= QgsVectorLayer("LineString?crs=EPSG:2154", "cable_decoupe", "memory")
					cable_decoupe_pr= cable_decoupe.dataProvider()
					cable_decoupe.startEditing()
					cable_decoupe_pr.addAttributes([QgsField('NOM', QVariant.String),QgsField('LG_REELLE', QVariant.Double, 'double', 200, 2),\
						QgsField('origine', QVariant.String),QgsField('exetremite', QVariant.String)])#,QgsField('PROPRIETAI', QVariant.String)
					cable_decoupe.updateFields()
					cable_decoupe.commitChanges()
					
					#Creation Index des boites
					list_get_etiquet=[]
					geoms_boite = {}#dict()
					index_boite = QgsSpatialIndex()
					for current, f in enumerate(features_boite.getFeatures()):
						geom_boite=f.geometry()
						if geom_boite != NULL  or geom_boite.isGeosValid():
							#if str(f['nd_r4_code'])[:3] != prefix_BFI: #Sauf les prises dont nd_r4_code est different de CFI
							geoms_boite[f.id()] = geom_boite
							index_boite.insertFeature(f)
							list_get_etiquet.append([f.id(),f[1]])
					list_boite_cable=[]
					if layer_features.isValid():
						features = layer_features.getFeatures(QgsFeatureRequest().setSubsetOfAttributes([]))#
						geoms = dict()
						null_geom_features = set()
						index = QgsSpatialIndex()
						liste_avec_doublon_geometry=[]
						
						for current, f in enumerate(features):
							if not f.hasGeometry():
								null_geom_features.add(f.id())
								continue
							geoms[f.id()] = f.geometry()
							index.addFeature(f)

						unique_features = dict(geoms)
						for feature_id, geometry in geoms.items():
							if feature_id not in unique_features:
								continue
							candidates = index.intersects(geometry.boundingBox())
							candidates.remove(feature_id)
							for candidate_id in candidates:
								#if candidate_id not in unique_features:
									#continue
								if geometry.isGeosEqual(geoms[candidate_id]):
									#listing_erreor_control_ADN.append([unique_features[candidate_id].buffer(0.5,0.5),message_chem])
									del unique_features[candidate_id]
						count=0
						for index, geom_line in unique_features.items():
							geom_cab_decoupe=geom_line#QgsGeometry.fromWkt(uniq)
							
							
							boite_origine_geom='-1'
							boite_extremite_geom='-1'
							
							boite_origine='-1'
							boite_extremite='-1'
							
							geom_cable=geom_line
							
							if geom_line.wkbType()==QgsWkbTypes.MultiLineString:
								geom_line_type=geom_line.asMultiPolyline()
								cable_origine=geom_line_type[0][0]
								cable_extremite=geom_line_type[-1][-1]
								
							if geom_line.wkbType()==QgsWkbTypes.LineString:
								geom_line_type=geom_line.asPolyline()
								cable_origine=geom_line_type[0]
								cable_extremite=geom_line_type[-1]
							
							candidates = index_boite.intersects(geom_line.boundingBox())
							if candidates:
								for candidate_id in candidates:
									geomboite = geoms_boite[candidate_id]
									if geomboite.within(geom_line.buffer(0.1,0.1)):
										if (QgsGeometry.fromPointXY(QgsPointXY(cable_origine))).within(geomboite.buffer(0.1,0.1)):
											boite_origine_geom=candidate_id
										if (QgsGeometry.fromPointXY(QgsPointXY(cable_extremite))).within(geomboite.buffer(0.1,0.1)):
											boite_extremite_geom=candidate_id
							if boite_origine_geom != '-1' or boite_extremite_geom != '-1':
								for current, f in enumerate(list_get_etiquet):#features_boite.getFeatures()
									if boite_origine_geom == f[0]:#f.id()
										boite_origine=f[1]
									if boite_extremite_geom == f[0]:
										boite_extremite=f[1]
							longueur=geom_cab_decoupe.length()
							if boite_origine != '-1' and boite_extremite != '-1' and longueur > 500:
								list_boite_cable.append(boite_origine)
								list_boite_cable.append(boite_extremite)
								count += 1
								feat = QgsFeature()
								feat.setGeometry(geom_cab_decoupe)
								attrs=['Cab_'+unicode(count),longueur,boite_origine,boite_extremite]#,''
								feat.setAttributes(attrs)
								cable_decoupe_pr.addFeatures([feat])
							progress_processing(index,len(unique_features),bar_progress)
							if bar_progress.wasCanceled():
								iface.messageBar().pushMessage('Info', 'Action Cancelled', level=Qgis.Info)
								break
						cable_decoupe.commitChanges()
						cable_decoupe.updateExtents()
						#QgsProject.instance().addMapLayer(cable_decoupe)
					else:
						QMessageBox.warning(w, "Doublons de cheminement", 'Layer invalide')
					return list_boite_cable

				@staticmethod
				def function_creat_infra(layer_cable,layer_ptech):
					bar_progress=progress_bar('Creation de la couche de decoupe des lignes Plus Execution de la function Doublon')
					
					#Creation des shapefles des erreurs
					Infra_Createe= QgsVectorLayer("LineString?crs=EPSG:2154", "Infra_Createe", "memory")
					Infra_Createe_pr= Infra_Createe.dataProvider()
					Infra_Createe.startEditing()
					Infra_Createe_pr.addAttributes([QgsField('NOM', QVariant.String),QgsField('LG_REELLE', QVariant.Double, 'double', 200, 2)])#,QgsField('PROPRIETAI', QVariant.String)
					Infra_Createe.updateFields()
					Infra_Createe.commitChanges()
					
					count=0
					
					list_infra_creat_Avec_doublon=[]
					list_lines_for_merge=[]
					
					#Creation dictionnary pour recuperer les points a decouper pour chaque ligne
					linestring_dict_points = defaultdict(list)
					
					#Creation Index des boites
					geoms_ptech = {}#dict()
					index_ptech = QgsSpatialIndex()
					for current, f in enumerate(layer_ptech.getFeatures()):
						geom_ptech=f.geometry()
						if geom_ptech != NULL  or geom_ptech.isGeosValid():
							geoms_ptech[f.id()] = geom_ptech
							index_ptech.insertFeature(f)
					#Len Features
					len_features_cable=len([feature for feature in layer_cable.getFeatures()])
					for index, feature_cab in enumerate(layer_cable.getFeatures()):
						geom_cable=feature_cab.geometry()
						candidates = index_ptech.intersects(geom_cable.boundingBox())
						if candidates:
							for candidate_id in candidates:
								geomptech = geoms_ptech[candidate_id]
								geom_ptech_wkt2=Point(geomptech.asPoint())
								if geomptech.within(geom_cable.buffer(0.1,0.1)):
									linestring_dict_points[geom_cable].append(geom_ptech_wkt2)
						progress_processing(index,len_features_cable,bar_progress)
						if bar_progress.wasCanceled():
							iface.messageBar().pushMessage('Info', 'Action Cancelled', level=Qgis.Info)
							break
					#Creation du shape de decoupe des lignes
					list_result_cut_linest=[]
					for index, (key, value) in enumerate(linestring_dict_points.items()):  
						geom_cable_wkt2=LineString(key.asPolyline())
						#print (['LineString']+(key.asPolyline()))
						#break
						result_cut_linest=function_create_infra_final.cut_line_at_points(geom_cable_wkt2,value)
						list_result_cut_linest.append(result_cut_linest)
						for index, cut_line in enumerate(result_cut_linest):
							geom_inf_decoupe=QgsGeometry.fromWkt(unicode(cut_line).replace('LINESTRING','LineString'))
							count += 1
							feat = QgsFeature()
							feat.setGeometry(geom_inf_decoupe)
							longueur=geom_inf_decoupe.length()
							if str(longueur) != '0.0':
								attrs=['INFRA_'+unicode(count),longueur]#,''
								feat.setAttributes(attrs)
								Infra_Createe_pr.addFeatures([feat])
						progress_processing(index,len(linestring_dict_points),bar_progress)
						if bar_progress.wasCanceled():
							iface.messageBar().pushMessage('Info', 'Action Cancelled', level=Qgis.Info)
							break
						
					Infra_Createe.commitChanges()
					Infra_Createe.updateExtents()
					
					#QgsProject.instance().addMapLayer(Infra_Createe)
					features_cable=Infra_Createe#function_getlayer_name('Infra_Createe')
					#features_boite=function_getlayer_name('t_ebp')
					boite_plus_500m=function_create_infra_final.function_B01_1(features_cable,layer_ptech)
					#return Infra_Createe#.name()
					return boite_plus_500m
					
			# layer_infra=function_create_infra_final.function_multipart_to_singlepart(features_cable)
			# layer_decoupe_erreur_boite=function_create_infra_final.function_creat_infra(layer_infra,features_pt)
			# print (layer_decoupe_erreur_boite)
			# requete_B01_1 = """
			# 	select bp.bp_code,bp.bp_etiquet,st_astext(st_buffer(bp.geom, 0.5)) as geom
			# 	from """+schema+""".vs_elem_bp_pt_nd bp """
			requete_B01_1 = """
						set search_path to """+schema+""", public;
						select * from t_cable cb
							left join t_cableline cl on cl.cl_cb_code = cb.cb_code
						where cb.cb_capafo::int > 96 and ST_Length(cl.geom)::int > 600 """
			message_B01_1 = 'B01_1'  # 'Boite implanté au delà de 500m'
			list_requete_B01_1 = function_execute_requete(requete_B01_1, 'bab', connection)
			if list_requete_B01_1:
				for index_B01_1, B01_1 in enumerate(list_requete_B01_1):
					geom = B01_1[-1]
					if geom:
						listing_error_control_ADN.append([B01_1[0], geom, message_B01_1])
					# for boite in layer_decoupe_erreur_boite:
					# 	if boite == B01_1[1]:
					# 		# print(boite,';',B01_1[1])
					# 		if geom:
					# 			listing_error_control_ADN.append([B01_1[0],geom,message_B01_1])
					progress_processing(index_B01_1,len(list_requete_B01_1),bar_progress)
					if bar_progress.wasCanceled():
						iface.messageBar().pushMessage('Info', 'Action Cancelled', level=Qgis.Info)
						break
		# Execution function function_B01_2
		function_B01_1_general()
		# Eviter l'implantation de boitiers optiques en partie privative
		def function_B01_2(schema):
			bar_progress = progress_bar('Execution de la function_B01_2, Veillez patientez')
			requete_B01_2 = """
				select bp.bp_code,bp.bp_etiquet, v_par.id_par, v_par.pers_moral,st_astext(st_buffer(bp.geom, 0.5)) as geom 
				from """+schema+""".vs_elem_bp_pt_nd bp
					left join """+schema+""".vs_parcelles_znro v_par on st_intersects(bp.geom,v_par.geom)
				where v_par.pers_moral in ('0','5','6','7','8','')
				"""
			list_requete_B01_2=function_execute_requete(requete_B01_2,'bab',connection)
			message_B01_2 = 'B01_2'  # 'Boitier implanté en partie privative'
			if list_requete_B01_2:
				for index_b01, b01 in enumerate(list_requete_B01_2):
					geom=b01[4]
					if geom:
						listing_error_control_ADN.append([b01[0],geom,message_B01_2])
					progress_processing(index_b01,len(list_requete_B01_2),bar_progress)
					if bar_progress.wasCanceled():
						iface.messageBar().pushMessage('Info', 'Action Cancelled', level=Qgis.Info)
						break
		# Execution function function_B01_2
		function_B01_2(schema)
		
		# Eviter l'implantation de PBO sous chaussée
		def function_B01_3(schema):
			bar_progress=progress_bar('Execution de la function_B01_3, Veillez patientez')
			requete_B01_3="""select 
					bp.bp_code, bp.bp_etiquet, bp.bp_pt_code, bp.bp_typelog, pt.pt_typephy, pt.pt_nature, 
					'PBO implanté sous chaussée avec méthode attributaire' as def_methode,
					st_astext(st_buffer(nd.geom, 0.5)) as geom
				from """+schema+""".t_ebp bp
					left join """+schema+""".t_ptech pt on pt.pt_code=bp.bp_pt_code
					left join """+schema+""".t_noeud nd on nd.nd_code=pt.pt_nd_code
				where bp.bp_typelog='PBO' and pt.pt_typephy ='C' and pt.pt_nature like '%C'

				union

				select 
					bp.bp_code, bp.bp_etiquet, bp.bp_pt_code, bp.bp_typelog, pt.pt_typephy, pt.pt_nature,
					'PBO implanté sous chaussée avec méthode geometrique (cm_passage)' as def_methode,
					st_astext(st_buffer(nd.geom, 0.5)) as geom
				from """+schema+""".t_ebp bp
					left join """+schema+""".t_ptech pt on pt.pt_code=bp.bp_pt_code
					left join """+schema+""".t_noeud nd on nd.nd_code=pt.pt_nd_code
					left join """+schema+""".t_cheminement cm on st_intersects(cm.geom,nd.geom)
				where bp.bp_typelog='PBO' and pt.pt_typephy ='C' and cm.cm_passage ='CHAU'
				"""
			list_requete_B01_3 = function_execute_requete(requete_B01_3,'bab',connection)
			
			message_B01_3='B01_3'  # 'PBO implanté sous chaussé'
			if list_requete_B01_3:
				for index_B01_3, B01_3 in enumerate(list_requete_B01_3):
					geom=B01_3[7]
					if geom:
						listing_error_control_ADN.append([B01_3[0],geom,message_B01_3])#B01_3[6]
					progress_processing(index_B01_3,len(list_requete_B01_3),bar_progress)
					if bar_progress.wasCanceled():
						iface.messageBar().pushMessage('Info', 'Action Cancelled', level=Qgis.Info)
						break
		# Execution function_B01_3
		function_B01_3(schema)
		
		# Vérifier qu'il n'y a pas de boitiers optiques sans point technique (hors BFI)
		def function_B01_4(schema):
			bar_progress=progress_bar('Execution de la function_B01_4, Veillez patientez')
			requete_B01_4="""select 
					bp.bp_code, bp.bp_etiquet, bp.bp_pt_code, bp.bp_typelog, pt.pt_typephy, 
					pt.pt_nature,st_astext(st_buffer(nd.geom, 0.5)) as geom
				from """+schema+""".t_ebp bp
					left join """+schema+""".t_ptech pt on pt.pt_code=bp.bp_pt_code
					left join """+schema+""".t_noeud nd on nd.nd_code=pt.pt_nd_code
				where left(bp.bp_etiquet,3)!= 'BFI' and bp.bp_typelog not in ('DTI','PTO') and 
				bp.bp_pt_code is null"""
			list_requete_B01_4=function_execute_requete(requete_B01_4,'bab',connection)
			message_B01_4='B01_4'#'Boite sans Point Techniques'
			if list_requete_B01_4:
				for index_B01_4, B01_4 in enumerate(list_requete_B01_4):
					geom=B01_4[6]
					if geom:
						listing_error_control_ADN.append([B01_4[0],geom,message_B01_4])
					progress_processing(index_B01_4,len(list_requete_B01_4),bar_progress)
					if bar_progress.wasCanceled():
						iface.messageBar().pushMessage('Info', 'Action Cancelled', level=Qgis.Info)
						break
		# Execution function_B01_4
		function_B01_4(schema)
	# Execution Function function_B01(schema)
	function_B01(schema)

	# B02_Taille des BPO en fonction des points techniques
	def function_B02(schema):
		# Vérifier qu'il n'y a pas de PBO implantés dans des points techniques de type L0T
		def function_B02_1(schema):
			bar_progress=progress_bar('Execution de la function_B02_1, Veillez patientez')
			requete_B02_1="""select 
					bp.bp_code, bp.bp_etiquet, bp.bp_pt_code, bp.bp_typelog, pt.pt_typephy, 
					pt.pt_nature,st_astext(st_buffer(nd.geom, 0.5)) as geom
				from """+schema+""".t_ebp bp
					left join """+schema+""".t_ptech pt on pt.pt_code=bp.bp_pt_code
					left join """+schema+""".t_noeud nd on nd.nd_code=pt.pt_nd_code
				where bp.bp_typelog ='PBO' and pt.pt_nature='L0T'
				"""
			list_requete_B02_1=function_execute_requete(requete_B02_1,'bab',connection)
			message_B02_1='B02_1'#'PBO implanté dans un point technique de type L0T'
			if list_requete_B02_1:
				for index_B02_1, B02_1 in enumerate(list_requete_B02_1):
					geom=B02_1[6]
					if geom:
						listing_error_control_ADN.append([B02_1[0],geom,message_B02_1])
					progress_processing(index_B02_1,len(list_requete_B02_1),bar_progress)
					if bar_progress.wasCanceled():
						iface.messageBar().pushMessage('Info', 'Action Cancelled', level=Qgis.Info)
						break
		# Execution function_B02_1
		function_B02_1(schema)
		# Vérifier qu'il n'y a pas plus de trois boitiers implantés sur les points techniques aériens ORANGE
		def function_B02_2(schema):
			bar_progress=progress_bar('Execution de la function_B02_2, Veillez patientez')
			requete_B02_2="""select 
					count(bp.bp_code) count_bp, array_agg(bp.bp_etiquet) bp_etiquet, array_agg(pt.pt_etiquet) pt_etiquet,
					array_agg(pt.pt_prop) pt_prop, pt.pt_code, st_astext(st_buffer(nd.geom, 0.5)) as geom
				from """+schema+""".t_ebp bp
					left join """+schema+""".t_ptech pt on pt.pt_code=bp.bp_pt_code
					left join """+schema+""".t_noeud nd on nd.nd_code=pt.pt_nd_code
					left join """+schema+""".t_organisme org on org.or_code=pt.pt_prop
				where pt.pt_typephy='A'
				group by pt.pt_code, nd.geom
				having count(bp.bp_code) > 2
				"""
			list_requete_B02_2=function_execute_requete(requete_B02_2,'bab',connection)
			message_B02_2='B02_2'#'Point technique de type Appui de proprietaire Orange avec plus de trois Boite'
			if list_requete_B02_2:
				for index_B02_2, B02_2 in enumerate(list_requete_B02_2):
					geom=B02_2[5]
					if geom:
						listing_error_control_ADN.append([B02_2[0],geom,message_B02_2])
					progress_processing(index_B02_2,len(list_requete_B02_2),bar_progress)
					if bar_progress.wasCanceled():
						iface.messageBar().pushMessage('Info', 'Action Cancelled', level=Qgis.Info)
						break
		# Execution function_B02_2
		function_B02_2(schema)
	# Execution Function function_B02(schema)
	function_B02(schema)

	# B03_Taille des BPO en fonction des câbles
	def function_B03(schema):
		# Vérifier le type de PBO en fonction des câbles
		def function_B03_1(schema):
			bar_progress=progress_bar('Execution de la function_B03_1, Veillez patientez')
			requete_B03_1="""select 
					bp.bp_code, bp.bp_etiquet, replace(replace(bp.bp_typephy,'B0',''),'B','') capa_boite, 
					cb.cb_capafo,cb.cb_etiquet, st_astext(st_buffer(nd.geom, 0.5)) as geom
				from """+schema+""".t_ebp bp
					left join """+schema+""".t_ptech pt on pt.pt_code=bp.bp_pt_code
					left join """+schema+""".t_noeud nd on nd.nd_code=pt.pt_nd_code
					left join """+schema+""".t_cable cb on cb.cb_nd2=nd.nd_code
				where replace(replace(bp.bp_typephy,'B0',''),'B','')::int < (cb.cb_capafo::int + (cb.cb_capafo::int * 0.3))::int and 
				bp.bp_typelog ='PBO' and left(bp.bp_etiquet,3) !='BFI' and bp.bp_typephy != 'AUTR'
				
				"""
			list_requete_B03_1=function_execute_requete(requete_B03_1,'bab',connection)
			message_B03_1='B03_1'#'Capacité PBO different de la capacité du cable rentrant'
			if list_requete_B03_1:
				for index_B03_1, B03_1 in enumerate(list_requete_B03_1):
					geom=B03_1[5]
					if geom:
						listing_error_control_ADN.append([B03_1[0],geom,message_B03_1])
					progress_processing(index_B03_1,len(list_requete_B03_1),bar_progress)
					if bar_progress.wasCanceled():
						iface.messageBar().pushMessage('Info', 'Action Cancelled', level=Qgis.Info)
						break
		# Execution function_B03_1
		function_B03_1(schema)
			
		# Vérifier que les PBO  comprennent 2 K7 PBO + K7 AVAL (EPISSURAGE) + 30% du câble amont
		def function_B03_2(schema):
			pass
		# Execution function_B03_2
		function_B03_2(schema)
	# Execution Function function_B03(schema)
	function_B03(schema)

	# B04_Boitiers optiques inférieurs à 6 dm³ sur aérien FT en aval PM
	def function_B04(schema):
		# Vérifier qu'il n'y a pas de PBO de Taille 2 en aérien ORANGE
		def function_B04_1(schema):
			bar_progress=progress_bar('Execution de la function_B04_1, Veillez patientez')
			requete_B04_1="""select 
					bp.bp_code, bp.bp_etiquet, pt.pt_etiquet,pt.pt_prop, pt.pt_code, refb.rb_rf_code, 
					st_astext(st_buffer(nd.geom, 0.5)) as geom
				from """+schema+""".t_ebp bp
					left join """+schema+""".t_ptech pt on pt.pt_code=bp.bp_pt_code
					left join """+schema+""".t_noeud nd on nd.nd_code=pt.pt_nd_code
					left join """+schema+""".t_organisme org on org.or_code=pt.pt_prop
					left join """+schema+""".t_refboite refb on refb.rb_rf_code=bp.bp_rf_code
				where org.or_nom='ORANGE' and pt.pt_typephy='A' and rb_volume::int > 6
				"""
			list_requete_B04_1 = function_execute_requete(requete_B04_1, 'bab', connection)
			message_B04_1 = 'B04_1'  # 'Boitier sur PT Aerien avec volume inférieur à 6dm3'
			if list_requete_B04_1:
				for index_B04_1, B04_1 in enumerate(list_requete_B04_1):
					geom = B04_1[6]
					if geom:
						listing_error_control_ADN.append([B04_1[0], geom, message_B04_1])
					progress_processing(index_B04_1, len(list_requete_B04_1), bar_progress)
					if bar_progress.wasCanceled():
						iface.messageBar().pushMessage('Info', 'Action Cancelled', level=Qgis.Info)
						break
		# Execution function_B04_1
		function_B04_1(schema)
	# Execution Function function_B03(schema)
	function_B04(schema)

	# B05_Boitiers optiques fictif raccordé par un CDI
	def function_B05(schema):
		# Vérifier qu'il n'y a pas de BFI raccordés avec CDI
		def function_B05_1(schema):
			bar_progress = progress_bar('Execution de la function_B05_1, Veillez patientez')
			requete_B05_1 = """select 
					distinct bp.bp_code, bp.bp_etiquet, pt.pt_etiquet,pt.pt_prop, pt.pt_code, cb1.cb_etiquet, 
					st_astext(st_buffer(nd.geom, 0.5)) as geom
				from """+schema+""".t_ebp bp 
					left join """+schema+""".t_ptech pt on pt.pt_code=bp.bp_pt_code
					left join """+schema+""".t_noeud nd on nd.nd_code=pt.pt_nd_code
					left join """+schema+""".t_cable cb1 on nd.nd_code=cb1.cb_nd1 or cb1.cb_nd2=nd.nd_code
				where left(bp.bp_etiquet,3) ='BFI' and (left(cb1.cb_etiquet,3) !='CFI' and cb1.cb_typelog != 'RA')
				"""
			list_requete_B05_1 = function_execute_requete(requete_B05_1,'bab',connection)
			message_B05_1='B05_1'  # 'Boitier CFI raccordé à un cable sortant different de CFI'
			if list_requete_B05_1:
				for index_B05_1, B05_1 in enumerate(list_requete_B05_1):
					geom=B05_1[6]
					if geom:
						listing_error_control_ADN.append([B05_1[0],geom,message_B05_1])
					progress_processing(index_B05_1,len(list_requete_B05_1),bar_progress)
					if bar_progress.wasCanceled():
						iface.messageBar().pushMessage('Info', 'Action Cancelled', level=Qgis.Info)
						break
		# Execution function_B04_1
		function_B05_1(schema)
	# Execution Function function_B03(schema)
	function_B05(schema)

	# B06_Limiter les boitiers optiques sur les câbles de forte capacité
	def function_B06():
		# Vérifier que les BPE implantées sur les câbles de forte capacité permettent de faire de l'étoilement
		def function_B01_1():
			pass
			
	# B07_Implantation des loves sur infrastructure à créer
	def function_B07(schema):
		# Vérifier la présence de love dans toutes les chambres ADN et par câble
		def function_B07_1(schema):
			bar_progress=progress_bar('Execution de la function_B07_1, Veillez patientez')
			requete_B07_1="""select 
					org.or_nom,pt.pt_etiquet,pt.pt_prop,lv.lv_id, lv.lv_nd_code,lv.lv_cb_code,
					't_love est vide',st_astext(st_buffer(ND.geom, 0.5)) as geom
				from """+schema+""".t_ptech pt
					left join """+schema+""".t_love lv on lv.lv_nd_code=pt.pt_nd_code
					left join """+schema+""".t_organisme org on org.or_code=pt.pt_prop
					left join """+schema+""".t_cable cb on cb.cb_nd1=lv.lv_nd_code or cb.cb_nd2=lv.lv_nd_code
					left join """+schema+""".t_noeud nd ON nd.nd_code = lv.lv_nd_code
				where pt.pt_typephy='C' and org.or_code=(select cb.cb_prop from """+schema+""".t_cable cb where left(cb.cb_etiquet,3) ='CDI' group by cb.cb_prop limit 1) 
				and lv.lv_nd_code is null
				"""
			list_requete_B07_1=function_execute_requete(requete_B07_1,'bab',connection)
			message_B07_1='B07_1'#'Chambre 0 Avec des loves'
			if list_requete_B07_1:
				for index_B07_1, B07_1 in enumerate(list_requete_B07_1):
					geom=B07_1[7]
					if geom:
						listing_error_control_ADN.append([B07_1[0],geom,message_B07_1])
					progress_processing(index_B07_1,len(list_requete_B07_1),bar_progress)
					if bar_progress.wasCanceled():
						iface.messageBar().pushMessage('Info', 'Action Cancelled', level=Qgis.Info)
						break
		# Execution function_B07_1
		function_B07_1(schema)
		
		# Hors chambre 0
		def function_B07_2(schema):
			bar_progress=progress_bar('Execution de la function_B07_2, Veillez patientez')
			requete_B07_2="""Select PT.pt_etiquet, count(LV.lv_id) count_lv, st_astext(st_buffer(ND.geom, 0.5)) as geom
				from """+schema+""".t_ptech PT
							   left join """+schema+""".t_cheminement CM ON PT.pt_nd_code = CM.cm_ndcode2
							   left join """+schema+""".t_sitetech ST ON CM.cm_ndcode1 = ST.st_nd_code or CM.cm_ndcode2 = ST.st_nd_code
							   left join """+schema+""".t_love LV ON LV.lv_nd_code = PT.pt_nd_code
							   left join """+schema+""".t_noeud ND ON ND.nd_code = PT.pt_nd_code 
				where PT.pt_typephy ='C' AND (CM.cm_ndcode1 = ST.st_nd_code or CM.cm_ndcode2 = ST.st_nd_code)
				group by PT.pt_etiquet, ND.geom
				having count(LV.lv_id) >0
				"""
			list_requete_B07_2=function_execute_requete(requete_B07_2,'bab',connection)
			message_B07_2='B07_2'#'Chambre 0 Avec des loves'
			if list_requete_B07_2:
				for index_B07_2, B07_2 in enumerate(list_requete_B07_2):
					geom=B07_2[2]
					if geom:
						listing_error_control_ADN.append([B07_2[0],geom,message_B07_2])
					progress_processing(index_B07_2,len(list_requete_B07_2),bar_progress)
					if bar_progress.wasCanceled():
						iface.messageBar().pushMessage('Info', 'Action Cancelled', level=Qgis.Info)
						break
		# Execution function_B07_2
		function_B07_2(schema)
		
		# Verifier la presence de love de pistonnage
		def function_B07_3(schema):
			bar_progress=progress_bar('Execution de la function_B07_3, Veillez patientez')#pr_2_2_exe_v2_exe_v_20190930
			requete_B07_3="""SET search_path = """+schema+""", public;
				select 
					distinct lv.lv_id,lv.lv_cb_code,lv.lv_nd_code,lv.lv_long,
					cb.cb_code,cb.cb_etiquet,cb.cb_nd1,cb.cb_nd2,
					cl.cl_code,cl.cl_cb_code,cl.cl_long,
					pt.pt_code,
					pt.pt_nd_code,
					pt.pt_typephy,
					st_astext(st_buffer(cl.geom, 0.5))
				from t_cable cb
					left join t_cableline cl on (cl.cl_cb_code=cb.cb_code)
					left join t_love lv on (cb.cb_nd1 = lv.lv_nd_code or cb.cb_nd2 = lv.lv_nd_code)
					left join t_ptech pt on pt.pt_nd_code = cb.cb_nd1 or cb.cb_nd2 = pt.pt_nd_code
				where cl.cl_long::float::int > 200 and lv.lv_nd_code is null and pt.pt_typephy = 'A'"""

			list_requete_B07_3=function_execute_requete(requete_B07_3,'bab',connection)
			message_B07_3='B07_3'#'presence de love de pistonnage sur pt_aerien'
			if list_requete_B07_3:
				for index_B07_3, B07_3 in enumerate(list_requete_B07_3):
					geom=B07_3[-1]
					if geom:
						listing_error_control_ADN.append([B07_3[4],geom,message_B07_3])
					progress_processing(index_B07_3,len(list_requete_B07_3),bar_progress)
					if bar_progress.wasCanceled():
						iface.messageBar().pushMessage('Info', 'Action Cancelled', level=Qgis.Info)
						break
		# Execution function_B07_3
		function_B07_3(schema)

		# ABSENCE DE LOVE DANS LES CHAMBRES ADN
		def function_b07_4(schema):
			bar_progress = progress_bar(
				'Execution de la function_b07_4, Veillez patientez')  # pr_2_2_exe_v2_exe_v_20190930
			requete_b07_4 = """SET search_path = """ + schema + """, public;
						select 
							distinct lv.lv_id,lv.lv_cb_code,lv.lv_nd_code,lv.lv_long,
							cb.cb_code,cb.cb_etiquet,cb.cb_nd1,cb.cb_nd2,
							cl.cl_code,cl.cl_cb_code,cl.cl_long,
							pt.pt_code,
							pt.pt_nd_code,
							pt.pt_typephy,
							st_astext(st_buffer(cl.geom, 0.5))
						from t_cable cb
						left join t_cableline cl on (cl.cl_cb_code=cb.cb_code)
						left join t_love lv on (cb.cb_nd1 = lv.lv_nd_code or cb.cb_nd2 = lv.lv_nd_code)
						left join t_ptech pt on pt.pt_nd_code = cb.cb_nd1 or cb.cb_nd2 = pt.pt_nd_code
						where cl.cl_long::float::int > 500 and lv.lv_nd_code is null and pt.pt_typephy = 'C' and pt_gest = 'OR000000000161'"""

			list_requete_b07_4 = function_execute_requete(requete_b07_4, 'bab', connection)
			message_b07_4 = 'B07_4'  # 'presence de love de pistonnage sur pt_aerien'
			if list_requete_b07_4:
				for index_b07_4, b07_4 in enumerate(list_requete_b07_4):
					geom = b07_4[-1]
					if geom:
						listing_error_control_ADN.append([b07_4[4], geom, message_b07_4])
					progress_processing(index_b07_4, len(list_requete_b07_4), bar_progress)
					if bar_progress.wasCanceled():
						iface.messageBar().pushMessage('Info', 'Action Cancelled', level=Qgis.Info)
						break

		# Execution function_b07_4
		function_b07_4(schema)
	# Execution Function function_B07(schema)
	function_B07(schema)

	# Creation de la table erreur_Control sil nexiste pas
	requete_create_tab="""SET search_path = """+schema+""", public;
		CREATE TABLE if not exists t_echange
		(
			cle text, --VARCHAR(254),
			ident text, --VARCHAR(254),
			localisation text, --VARCHAR(20),
			num_sro text, --VARCHAR(20),
			phase text, --VARCHAR(20),
			type_rem text, --VARCHAR(20),
			support text, --VARCHAR(20),
			id text, --VARCHAR(254),
			com_init text, --VARCHAR(254),
			date_cr text, --TIMESTAMP,
			criticite text, --VARCHAR(20),
			actions text, --VARCHAR(20),
			destinataire text, --VARCHAR(254),
			prise_en_compte text, --VARCHAR(20),
			valid_derog text, --VARCHAR(20),
			com_rep text, --VARCHAR(254),
			date_rep text, --TIMESTAMP,
			lien_inter_rem text, --VARCHAR(254),
			geom geometry(Polygon,2154),
			CONSTRAINT t_echange_pk PRIMARY KEY (ec_code)
		)
		WITH (
		  OIDS=FALSE
		);
		ALTER TABLE t_echange
		  OWNER TO adn_ing;
		GRANT ALL ON TABLE t_echange TO adn_ing;
		GRANT ALL ON TABLE t_echange TO postgres;"""
	# Execution de la creation de la table erreur_control
	function_execute_requete(requete_create_tab,'',connection)

	table_erreur_control_adn = 't_echange'
	req_erreur_control_adn = """select count (*)::int from """+schema+"""."""+table_erreur_control_adn
	get_count_erreur_control_adn = function_execute_requete(req_erreur_control_adn, 'bab', connection)
	value_get_count_erreur_control_adn = get_count_erreur_control_adn[0][0]   # ','.join([str(i).replace(',','').replace('(','').replace(')','') for i in get_count_erreur_control_adn])

	# Function pour inserer dans la table derreur control adn
	def function_create_tab_shape_erreur_control_design(schema,table_zsro,attribut_zs_refpm,\
		var_aud,var_MOE,var_PR,var_phase,var_type):
		# shape_erreur_control_design,pr_shape_erreur_control_design,

		name_pr_techange = str(var_PR).upper()[0:-15].replace('_','-')
		
		bar_progress=progress_bar('Insertion des erreurs dans la base sur schema correspondant')
		len_features_error=len([feature for feature in listing_error_control_ADN])
		
		req_tab_code_erreur = """select * from """+schema+""".t_code_erreur"""
		table_code_erreur = function_execute_requete(req_tab_code_erreur,'bab',connection)
		
		#export Shapefile erreur de control des designs
		layer_zsro=function_return_layer(DB,user,MP,host,port,schema,table_zsro,'')
		#features_zsro = layer_zsro.getFeatures()
		geoms_zsro = {}
		index_zsro  = QgsSpatialIndex()
		for current, f in enumerate(layer_zsro.getFeatures()):
			geom_zsro =f.geometry()
			if geom_zsro != NULL  or geom_zsro.isGeosValid():
				geoms_zsro[f.id()] = geom_zsro
				index_zsro.insertFeature(f)
		
		count = int(value_get_count_erreur_control_adn)
		for feature_id, geom in enumerate(listing_error_control_ADN):
			geom_error=QgsGeometry.fromWkt(geom[1])#geom[1]
			Name_PM='Pas de Zone SRO en Intersection ou bien lattribut zs_refpm du shapefile t_zsro est vide'
			id_zsro='-1'
			id_comment = geom[2]
			id_categorie = geom[2]
			id_criticite = ''
			id_type = ''
			candidates = index_zsro.intersects(geom_error.boundingBox())
			id_cles = var_aud+'_'+var_MOE+'_'+unicode(count).zfill(6)
			id_code_entite = geom[0]
			if candidates:
				for candidate_id in candidates:
					geom_zsro = geoms_zsro[candidate_id]
					if geom_error.intersects(geom_zsro.buffer(0.1,0.1)):
						id_zsro=candidate_id
						
			if id_zsro != '-1':
				for current, f in enumerate(layer_zsro.getFeatures()):
					if id_zsro == f.id():
						Name_PM=f[attribut_zs_refpm]
			
			for current_code_erreur, var_code_erreur in enumerate(table_code_erreur):
				if var_code_erreur[0] == geom[2]: # Code egale column 2
					id_comment = var_code_erreur[3] # Comment egale column 3
					id_categorie = var_code_erreur[2] # Categorie egale column 1
					id_criticite = var_code_erreur[4] # Criticite egale column 4
					id_type = var_code_erreur[1] # Criticite egale column 4

			feat = QgsFeature()
			feat.setGeometry(geom_error)#geom[1]
			geome_text=geom_error.asWkt()#geom[1]
			if geome_text != '':
				count += 1
				requete_insert_tab_echange = """INSERT INTO """+schema+"""."""+"""t_echange"""+"""(
						cle, ident, localisation, num_sro, phase, type_rem, support, 
						id, com_init, date_cr, criticite, actions, 
						destinataire, prise_en_compte, valid_derog, com_rep, date_rep, 
						lien_inter_rem, geom)
						VALUES ('"""+str(id_cles)+"""','"""+str(var_MOE)+"""','"""+str(name_pr_techange)+"""','"""+str(Name_PM)+"""','"""+str(var_phase)+"""','"""+str(id_type)+"""','"""+str(id_categorie)+"""', 
								'"""+str(id_code_entite)+"""','"""+str(id_comment)+"""','"""+str(nowdate)+"""','"""+str(id_criticite)+"""', null, 
								null,null,null,null,null, 
								null,""" + """ST_GeomFromText(st_astext(ST_Geometryn(ST_GeomFromText('""" + str(geome_text) + """',2154),1)),2154)"""+""");"""

				# Execution de linsertion de la table erreur_control
				function_execute_requete(requete_insert_tab_echange,'',connection)
			
			progress_processing(feature_id,len_features_error,bar_progress)
			if bar_progress.wasCanceled():
				iface.messageBar().pushMessage('Info', 'Action Cancelled', level=Qgis.Info)
				break
		
	function_create_tab_shape_erreur_control_design(schema,table_zsro,attribut_zs_refpm,\
		var_aud,var_MOE,var_PR,var_phase,var_type)

	connection.commit()
	connection.close()
	QMessageBox.information(w, "Message-Execution-Plugin", 'Contrôle du dimensionnent des boitiers réalisé avec succès')
# Execution de la function generale
# function_Dimensionnement_boitiers_optiques(schema)