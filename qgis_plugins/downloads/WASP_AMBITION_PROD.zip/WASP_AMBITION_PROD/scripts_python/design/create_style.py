from qgis.core import *
from random import randrange

def function_style_lines_renderercategory(layer_name, attribut_name):
    # Get the active layer (must be a vector layer)
    layer = QgsProject.instance().mapLayersByName(layer_name)[0]
    # get unique values
    fni = layer.fields().lookupField(attribut_name)
    unique_values = layer.dataProvider().uniqueValues(fni)

    # define categories
    categories = []
    for unique_value in unique_values:
        # initialize the default symbol for this geometry type
        # symbol = QgsSymbol.defaultSymbol(layer.geometryType())
        style_lines = {'color': '%d, %d, %d' % (randrange(0, 256), randrange(0, 256), randrange(0, 256)),
                       'width': '0.5', 'line_style': 'dash'}
        # symbol = QgsLineSymbol.createSimple(style_lines)

        symbol = QgsLineSymbol.createSimple(style_lines)
        symbol_l2 = QgsSimpleLineSymbolLayer.create({'line_style': 'solide', 'color': 'white', 'width': '0.01'})
        symbol.appendSymbolLayer(symbol_l2)

        # create renderer object
        category = QgsRendererCategory(unique_value, symbol, str(unique_value))
        # entry for the list of category items
        categories.append(category)

    # create renderer object
    renderer = QgsCategorizedSymbolRenderer(attribut_name, categories)

    # assign the created renderer to the layer
    if renderer is not None:
        layer.setRenderer(renderer)
    layer.triggerRepaint()


# function_style('t_zsro', 'zs_refpm')
function_style_lines_renderercategory('vs_elem_cl_cb', 'cb_capafo')


def create_sympbol():
    # Create simple symbols For Polygon
    self.fill_symbol = QgsFillSymbol.createSimple(
        {'color': '#ffffff',
         'outline_color': 'black'
         })

    # Create simple symbols For Lines
    style_lines = {'color': '#ffffff', 'outline_color': 'black', 'line_width': '3', 'width': '0.8',
                   'line_style': 'solid'}
    self.line_symbol = QgsLineSymbol.createSimple(style_lines)

    # Create simple symbols For Point
    self.marker_symbol = QgsMarkerSymbol.createSimple({'color': '#ffffff', 'size': '3', 'outline_color': 'black'})


layer = iface.activeLayer()

symbol = QgsSymbol.defaultSymbol(layer.geometryType())
renderer = QgsRuleBasedRenderer(symbol)


def rule_based_symbology(layer, renderer, label, expression, symbol, shape, color):
    root_rule = renderer.rootRule()
    rule = root_rule.children()[0].clone()
    rule.setLabel(label)
    rule.setFilterExpression(expression)
    rule.symbol().symbolLayer(0).setShape(shape)
    rule.symbol().setColor(QColor(color))
    root_rule.appendChild(rule)
    layer.setRenderer(renderer)
    layer.triggerRepaint()


rules = [['PBO', """"bp_typelog" = 'PBO'""", QgsSimpleMarkerSymbolLayerBase.Circle, 'Green'],
         ['BPE', """"bp_typelog" = 'BPE'""", QgsSimpleMarkerSymbolLayerBase.Triangle, 'Blue'],
         ['AUTRE', """"bp_typelog" not in ('BPE', 'PBO')""", QgsSimpleMarkerSymbolLayerBase.Diamond, 'Red']]

for rule in rules:
    rule_based_symbology(layer, renderer, rule[0], rule[1], symbol, rule[2], rule[3])

renderer.rootRule().removeChildAt(0)
iface.layerTreeView().refreshLayerSymbology(layer.id())

layer = iface.activeLayer()

# Important link for creating style
# Typpe de categorize
# https: // snorfalorpagus.net / blog / 2014 / 03 / 04 / symbology - of - vector - layers - in -qgis - python - plugins /
# gis.stackexchange.com / questions / 366523 / enabling - symbol - levels - using - pyqgis
# https: // docs.qgis.org / 3.4 / pdf / en / QGIS - 3.4 - PyQGISDeveloperCookbook - en.pdf
# #  Exemple Rule Render
# python.hotexamples.com / examples / qgis.core / QgsLineSymbol / createSimple / python - qgslinesymbol - createsimple - method - examples.html
# gis.stackexchange.com / questions / 86770 / how - to - programmatically - set - a - rule - based - renderer - in -qgis
# gis.stackexchange.com / questions / 366133 / how - to - change - a - line - symbol - layer - type - using - pyqgis
# https: // gis.stackexchange.com / questions / 366523 / enabling - symbol - levels - using - pyqgis
# https: // gis.stackexchange.com / questions / 340300 / creating - categorization - by - symbols - using - pyqgis
# https: // gis.stackexchange.com / questions / 282335 / adding - new - rule - by - using - qgsrulebasedrenderer - to - existing - one - in -pyqgis
#
