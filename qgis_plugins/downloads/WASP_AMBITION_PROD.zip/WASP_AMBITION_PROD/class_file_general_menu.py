from PyQt5.QtCore import *
from PyQt5.QtGui import *
from qgis.core import *

import os.path

from .forms.design.importBDD_form import *
from .forms.design.check_design_form import *
from .forms.design.check_upnview_form import *
from .forms.design.check_boite_form import *
from .forms.design.check_formalisme_form import *
from .forms.design.check_appview_form import *
from .forms.design.check_cables_form import *
from .forms.design.form_import_bdd import *

from .forms.delta.check_decoupe_delta_form import *
from .forms.delta.check_delta_form import *

from .forms.dpi.check_dpigetinfo_form import *
from .forms.dpi.check_dpivisiteterrain_form import *
from .forms.dpi.check_dpigetinfo_form_v2 import *
from .forms.dpi.check_dpivisiteterrain_form_v2 import *

from .forms.design.creation_model import *
from .forms.design.decoupe_ligne_point import *

from .forms.axione_echange.import_data_form import *

from .forms.lfd.dialog_lfd import *

from .vidange_cache_qgis import *



# ---------------------------------------------
	
class class_generale_menu:
	def __init__(self, iface):
		self.iface = iface
		self.ambition_menu = None

	def atrqgis_add_submenu(self, submenu):
		if self.ambition_menu != None:
			self.ambition_menu.addMenu(submenu)
		else:
			self.iface.addPluginToMenu("&atrqgis", submenu.menuAction())
	
	def get_version_deploy_plugin(self):
		folder_plugin = os.path.dirname(os.path.abspath(__file__))
		folder_metada  = open(folder_plugin + "\metadata.txt")
		get_version_deploy ='Not_Found'
		for line in folder_metada :
			if str(line)[:6] == 'deploy':
				get_version_deploy = str(line.split('=')[1])
		folder_metada .close()
		return get_version_deploy

	def initGui(self):
		res_vidange = function_delete_cache_qgis()
		if res_vidange[1] is False:
			QMessageBox.warning(QWidget(), "Message dexecution de requete", 'Le cache nest pas vide ... ' +
								str(res_vidange))

		# Uncomment the following two lines to have atrqgis accessible from a top-level menu
		self.ambition_menu = QtWidgets.QMenu(QCoreApplication.translate("atrqgis", self.get_version_deploy_plugin()))
		self.iface.mainWindow().menuBar().insertMenu(self.iface.firstRightStandardMenu().menuAction(),
													 self.ambition_menu)

		# Test Group Menu Plugin
		# ADN Menu
		self.adn_menu = QtWidgets.QMenu(QCoreApplication.translate("atrqgis", "&ADN"))
		self.atrqgis_add_submenu(self.adn_menu)
		self.controle_design = self.adn_menu.addMenu('Contrôle DESIGN')
		# CONTROLE DESIGN Submenu
		icon = QIcon(os.path.dirname(__file__) + "/icons/import.png")
		self.animate_lines_action = QtWidgets.QAction(icon, "A.1.1 Import de données",
													  self.iface.mainWindow())
		self.animate_lines_action.triggered.connect(self.baba_fonc)
		self.controle_design.addAction(self.animate_lines_action)

		icon = QIcon(os.path.dirname(__file__) + "/icons/design.png")
		self.check_design_action = QtWidgets.QAction(icon, "A.1.2 Contrôle du design", self.iface.mainWindow())
		self.check_design_action.triggered.connect(self.exe_class_checkdesignD0_dialog)
		self.controle_design.addAction(self.check_design_action)

		icon = QIcon(os.path.dirname(__file__) + "/icons/upnview.png")
		self.vue_upnview_action = QtWidgets.QAction(icon, "A.1.3 SPATIALISATION DES CONTOLS UPNVIEW",
													self.iface.mainWindow())
		self.vue_upnview_action.triggered.connect(self.exe_class_checkupnview_dialog)
		self.controle_design.addAction(self.vue_upnview_action)

		icon = QIcon(os.path.dirname(__file__) + "/icons/boite.jfif")
		self.check_boite_action = QtWidgets.QAction(icon, "A.1.4 Contrôle du dimensionnent des boitiers",
													self.iface.mainWindow())
		self.check_boite_action.triggered.connect(self.exe_class_checkboite_dialog)
		self.controle_design.addAction(self.check_boite_action)

		icon = QIcon(os.path.dirname(__file__) + "/icons/formalise.jfif")
		self.check_formalisme_action = QtWidgets.QAction(icon, "A.1.5 Contrôle du format des données",
														 self.iface.mainWindow())
		self.check_formalisme_action.triggered.connect(self.exe_class_checkformalisme_dialog)
		self.controle_design.addAction(self.check_formalisme_action)

		icon = QIcon(os.path.dirname(__file__) + "/icons/cable.png")
		self.check_cables_action = QtWidgets.QAction(icon, "A.1.6 Contrôle des câbles", self.iface.mainWindow())
		self.check_cables_action.triggered.connect(self.exe_class_checkcable_dialog)
		self.controle_design.addAction(self.check_cables_action)

		icon = QIcon(os.path.dirname(__file__) + "/icons/vues.png")
		self.application_vues_action = QtWidgets.QAction(icon, "A.1.7 Génération du projet QGIS",
														 self.iface.mainWindow())
		self.application_vues_action.triggered.connect(self.exe_class_checkappview_dialog)
		self.controle_design.addAction(self.application_vues_action)

		icon = QIcon(os.path.dirname(__file__) + "/icons/vues.png")
		self.baba_action = QtWidgets.QAction(icon, "Babacar_Test", self.iface.mainWindow())
		self.baba_action.triggered.connect(self.baba_fonc)
		self.controle_design.addAction(self.baba_action)

		# # DESIGN Submenu
		# self.check_design_menu = QtWidgets.QMenu(QCoreApplication.translate("atrqgis", "&ADN - DESIGN "))
		# self.atrqgis_add_submenu(self.check_design_menu)
		#
		# icon = QIcon(os.path.dirname(__file__) + "/icons/import.png")
		# self.animate_lines_action = QtWidgets.QAction(icon, "A.1.1 IMPORTATION DES DONNES DANS LA BASE", self.iface.mainWindow())
		# self.animate_lines_action.triggered.connect(self.baba_fonc)
		# self.check_design_menu.addAction(self.animate_lines_action)

		# ADN Menu
		self.piquetage_menu = self.adn_menu.addMenu('PIQUETAGE')
		# CONTROLE DESIGN Submenu

		# PIQUETAGE Submenu
		# self.piquetage_menu = QtWidgets.QMenu(QCoreApplication.translate("atrqgis", "&ADN - PIQUETAGE "))
		# self.atrqgis_add_submenu(self.piquetage_menu)

		icon = QIcon(os.path.dirname(__file__) + "/icons/atrqgis_attribute_join.png")
		self.xlxsToxls_action = QtWidgets.QAction(icon, "A.2.1 Conversion des fiches XLSX en XLS",
												  self.iface.mainWindow())
		self.xlxsToxls_action.triggered.connect(self.baba_fonc)
		self.piquetage_menu.addAction(self.xlxsToxls_action)

		icon = QIcon(os.path.dirname(__file__) + "/icons/ptech.jfif")
		self.syntheseFA_action = QtWidgets.QAction(icon, "A.2.2 Intégration des caractéristiques d'appuis",
												   self.iface.mainWindow())
		self.syntheseFA_action.triggered.connect(self.exe_class_checkdpigetinfo_dialog)
		self.piquetage_menu.addAction(self.syntheseFA_action)

		icon = QIcon(os.path.dirname(__file__) + "/icons/releve.jfif")
		self.intRetourTerrain_action = QtWidgets.QAction(icon, "A.2.3 Intégration des contre-relevés terrain",
														 self.iface.mainWindow())
		self.intRetourTerrain_action.triggered.connect(self.exe_class_checkdpiVt_dialog)
		self.piquetage_menu.addAction(self.intRetourTerrain_action)

		icon = QIcon(os.path.dirname(__file__) + "/icons/ptech.jfif")
		self.syntheseFA_action_v2 = QtWidgets.QAction(icon, "A.2.2_V2 Intégration des caractéristiques d'appuis",
													  self.iface.mainWindow())
		self.syntheseFA_action_v2.triggered.connect(self.exe_class_checkdpigetinfo_dialog_v2)
		self.piquetage_menu.addAction(self.syntheseFA_action_v2)

		icon = QIcon(os.path.dirname(__file__) + "/icons/releve.jfif")
		self.intRetourTerrain_action_v2 = QtWidgets.QAction(icon, "A.2.3_V2 Intégration des contre-relevés terrain",
															self.iface.mainWindow())
		self.intRetourTerrain_action_v2.triggered.connect(self.exe_class_checkdpiVt_dialog_v2)
		self.piquetage_menu.addAction(self.intRetourTerrain_action_v2)

		# DELTA Submenu
		# self.delta_menu = QtWidgets.QMenu(QCoreApplication.translate("atrqgis", "&ADN - DELTA"))
		# self.atrqgis_add_submenu(self.delta_menu)
		self.delta_menu = self.adn_menu.addMenu('DELTA')

		icon = QIcon(os.path.dirname(__file__) + "/icons/decoupe.png")
		self.decoupe_delta_action = QtWidgets.QAction(icon, "A.1.1 Découpage d'un livrable à la ZSRO",
													  self.iface.mainWindow())
		self.decoupe_delta_action.triggered.connect(self.exe_class_checkDecoupeDelta_dialog)
		self.delta_menu.addAction(self.decoupe_delta_action)

		icon = QIcon(os.path.dirname(__file__) + "/icons/delta.png")
		self.delta_action = QtWidgets.QAction(icon, "A.1.2 Analyse des écarts entre deux livrables",
											  self.iface.mainWindow())
		self.delta_action.triggered.connect(self.exe_class_checkDelta_dialog)
		self.delta_menu.addAction(self.delta_action)

		# Modelisation de Reseau
		# self.modelisation_menu = QtWidgets.QMenu(QCoreApplication.translate("atrqgis", "&MODELISATION DE RESEAU "))
		# self.atrqgis_add_submenu(self.modelisation_menu)
		self.modelisation_menu = self.adn_menu.addMenu('MODELISATION DE RESEAU')

		icon = QIcon(os.path.dirname(__file__) + "/icons/mdel_reseau.png")
		self.modelisation_action = QtWidgets.QAction(icon, "A.1.1 Modelisation de Reseau", self.iface.mainWindow())
		self.modelisation_action.triggered.connect(self.exe_class_create_mode_dialog)
		self.modelisation_menu.addAction(self.modelisation_action)

		icon = QIcon(os.path.dirname(__file__) + "/icons/decoupe.png")
		self.Decoupe_action = QtWidgets.QAction(icon, "A.1.2 Decoupe des Lignes en fonction des points",
												self.iface.mainWindow())
		self.Decoupe_action.triggered.connect(self.exe_class_decoupe_dialog)
		self.modelisation_menu.addAction(self.Decoupe_action)

		icon = QIcon(os.path.dirname(__file__) + "/icons/import.png")
		self.import_shp_bdd_action = QtWidgets.QAction(icon, "A.1.3 Import des shapefiles dans la BDD",
													   self.iface.mainWindow())
		self.import_shp_bdd_action.triggered.connect(self.exe_class_impor_bbd_shp_dialog)
		self.modelisation_menu.addAction(self.import_shp_bdd_action)

		# Geronimo_QGIS Submenu
		# self.gerom_qgis_menu = QtWidgets.QMenu(QCoreApplication.translate("atrqgis", "&GERONIMO_QGIS"))
		# self.atrqgis_add_submenu(self.gerom_qgis_menu)

		self.ethd_menu = QtWidgets.QMenu(QCoreApplication.translate("atrqgis", "&ETHD RIP"))
		self.atrqgis_add_submenu(self.ethd_menu)
		self.gerom_qgis_menu = self.ethd_menu.addMenu('GERONIMO_QGIS')

		icon = QIcon(os.path.dirname(__file__) + "/icons/atrqgis_attribute_join.png")
		self.prepTemp_action = QtWidgets.QAction(icon, "A.1.1 Preparation du Fichier Tampon", self.iface.mainWindow())
		self.prepTemp_action.triggered.connect(self.baba_fonc)
		self.gerom_qgis_menu.addAction(self.prepTemp_action)

		icon = QIcon(os.path.dirname(__file__) + "/icons/atrqgis_merge.png")
		self.IntResultGero_action = QtWidgets.QAction(icon, "A.1.2 Integration du resultat Geronimo",
													  self.iface.mainWindow())
		self.IntResultGero_action.triggered.connect(self.baba_fonc)
		self.gerom_qgis_menu.addAction(self.IntResultGero_action)

		# AXIONE Menu
		self.axione_menu = QtWidgets.QMenu(QCoreApplication.translate("atrqgis", "&AXIONE"))
		self.atrqgis_add_submenu(self.axione_menu)
		self.couche_echange_menu = self.axione_menu.addMenu('Couche échange')
		# AXIONE ECHANGE Submenu
		icon = QIcon(os.path.dirname(__file__) + "/icons/import.png")
		self.integrate_aps_action = QtWidgets.QAction(icon, "Intégration APS", self.iface.mainWindow())
		self.integrate_aps_action.triggered.connect(self.exe_class_import_data_axione_dialog)
		self.couche_echange_menu.addAction(self.integrate_aps_action)

		# LFD Menu
		self.lfd_menu = QtWidgets.QMenu(QCoreApplication.translate("atrqgis", "&LFD"))
		self.atrqgis_add_submenu(self.lfd_menu)
		self.atfd_sub_menu = self.lfd_menu.addMenu('ATHD')
		# ATHD Submenu
		icon = QIcon(os.path.dirname(__file__) + "/icons/import.png")
		self.traitement_lfd_action = QtWidgets.QAction(icon, "Traitement LFD", self.iface.mainWindow())
		self.traitement_lfd_action.triggered.connect(self.exe_class_import_execute_lfd)
		self.atfd_sub_menu.addAction(self.traitement_lfd_action)

		# Deploiement Plugins Submenu
		self.deploy_plugin_menu = QtWidgets.QMenu(QCoreApplication.translate("atrqgis", "&Deploiement des Plugins ATR"))
		self.atrqgis_add_submenu(self.deploy_plugin_menu)
		icon = QIcon(os.path.dirname(__file__) + "/icons/deploy.jpg")
		self.deploy_action = QtWidgets.QAction(icon, "A.1.1 Deploy", self.iface.mainWindow())
		# self.deploy_action.triggered.connect(self.exe_class_deploy_plugin_dialog)
		self.deploy_plugin_menu.addAction(self.deploy_action)
		


	def unload(self):
		if self.ambition_menu != None:
			self.iface.mainWindow().menuBar().removeAction(self.ambition_menu.menuAction())
		else:
			self.iface.removePluginMenu("&atrqgis", self.check_design_menu.menuAction())
			self.iface.removePluginMenu("&atrqgis", self.piquetage_menu.menuAction())
			self.iface.removePluginMenu("&atrqgis", self.delta_menu.menuAction())
			self.iface.removePluginMenu("&atrqgis", self.gerom_qgis_menu.menuAction())

	
	def baba_fonc(self):
		self.baba_dialog = class_import_dialog(self.iface)
		self.baba_dialog.exec_()
	
	def exe_class_checkdesignD0_dialog(self):
		self.execheckdesign = class_checkdesignD0_dialog(self.iface)
		self.execheckdesign.exec_()

	def exe_class_checkupnview_dialog(self):
		self.execheckupnview = class_checkupnview_dialog(self.iface)
		self.execheckupnview.exec_()

	def exe_class_checkboite_dialog(self):
		self.execheckboite = class_checkboite_dialog(self.iface)
		self.execheckboite.exec_()
	
	def exe_class_checkformalisme_dialog(self):
		self.execheckformalisme = class_checkformalisme_dialog(self.iface)
		self.execheckformalisme.exec_()
	
	def exe_class_checkappview_dialog(self):
		self.execheckappview = class_checkappview_dialog(self.iface)
		self.execheckappview.exec_()

	def exe_class_checkDecoupeDelta_dialog(self):
		self.execheckdecoupedelta = class_checkDecoupeDelta_dialog(self.iface)
		self.execheckdecoupedelta.exec_()
	
	def exe_class_checkDelta_dialog(self):
		self.execheckdelta = class_checkDelta_dialog(self.iface)
		self.execheckdelta.exec_()
	
	def exe_class_checkdpigetinfo_dialog(self):
		self.execheckdpigetinfo = class_checkdpigetinfo_dialog(self.iface)
		self.execheckdpigetinfo.exec_()

	# class_checkdpigetinfo_dialog_v2
	def exe_class_checkdpigetinfo_dialog_v2(self):
		self.checkdpigetinfo_v2 = class_checkdpigetinfo_dialog_v2(self.iface)
		self.checkdpigetinfo_v2.exec_()

	# class_checkdpigetinfo_dialog_v2
	def exe_class_checkdpiVt_dialog_v2(self):
		self.checkdpiVt_dialog_v2 = class_checkdpiVt_dialog_v2(self.iface)
		self.checkdpiVt_dialog_v2.exec_()

	
	def exe_class_checkdpiVt_dialog(self):
		self.execheckdpiVT = class_checkdpiVt_dialog(self.iface)
		self.execheckdpiVT.exec_()

	# Modelisation du reseau
	def exe_class_create_mode_dialog(self):
		self.exemodel = class_create_mode_dialog(self.iface)
		self.exemodel.exec_()

	# Decoupe des lignes en fonction des points
	def exe_class_decoupe_dialog(self):
		try:
			self.exedecoupe.refresh_layers()
		except:
			self.exedecoupe = class_decoupe_dialog(self.iface)
		self.exedecoupe.exec_()

	# Import des shapefiles dans la BDD
	def exe_class_impor_bbd_shp_dialog(self):
		self.execlass_impor_bbd_shp_dialog = class_impor_bbd_shp_dialog(self.iface)
		self.execlass_impor_bbd_shp_dialog.exec_()

	# Controle des cables
	def exe_class_checkcable_dialog(self):
		self.execable = class_checkcable_dialog(self.iface)
		self.execable.exec_()

	# Couche echange Axione
	def exe_class_import_data_axione_dialog(self):
		self.execable = class_import_data_axione_dialog(self.iface)
		self.execable.exec_()

	# Couche LFD Integration
	def exe_class_import_execute_lfd(self):
		self.exelfdinte = ClassImportExecuteLfd(self.iface)
		self.exelfdinte.exec_()

	# Deploiement des Plugins ATR
	# def exe_class_deploy_plugin_dialog(self):
	# 	self.exedeploy = class_deploy_plugin_dialog(self.iface)
	# 	self.exedeploy.exec_()