SET search_path TO var_schema,public;
drop table if exists l_ec_organisme cascade;
CREATE TABLE l_ec_organisme (code text,libelle text,definition text, CONSTRAINT l_ec_organisme_type_pk PRIMARY KEY (code));
INSERT INTO l_ec_organisme(code, libelle, definition) 
	VALUES 
		('ADT','ADTIM FTTH','Délégataire ADTIM FTTH'),
		('ADN',	'ADN',	'Maitre dOuvrage - Syndicat Mixte Ardèche Drôme Numérique'),
		('AMO',	'AMO', null),
		('CSP',	'CSPS',	'Coordinateur Sécurité et de Protection de la Santé'),
		('ATR',	'ATR',	'Maitre dŒuvre dExecution Desserte FTTH - Groupement AMBITION'),
		('EIF',	'EIFFAGE','Groupement EIFFAGE'),
		('INE',	'INEO',	'Groupement INEO'),
		('SOB',	'SOBECA','Groupement SOBECA'),
		('IMO',	'IMOPTEL','Groupement IMOPTEL'),
		('SER',	'SERFIM TIC','Groupement SERFIM TIC'),
		('AXI',	'AXIONE','Groupement AXIONE'),
		('BET',	'BETREC','Maitre dŒuvre dExecution Locaux FTTH - BETREC'),
		('IBS',	'IBSE','Maitre dŒuvre dExecution Locaux FTTH - IBSE'),
		('COO',	'COORDINATION',	'Organisme demandeur dune coordination des travaux');

drop table if exists l_ec_statut cascade;
CREATE TABLE l_ec_statut (code text,libelle text,definition text, CONSTRAINT l_ec_statut_type_pk PRIMARY KEY (code));
INSERT INTO l_ec_statut(code, libelle, definition) VALUES
('DEP','PRELIMINAIRE','Etude Préliminaire'),
('DEO','OPTIMALITE','Etude dOptimalité'),
('PRO','PRO','Projet'),
('EXE','EXECUTION','Etude dExécution'),
('DET ','TRAVAUX','Réalisation des Travaux'),
('AOR','RECEPTION','Réception des ouvrages'),
('DIU','EXPLOITATION','Exploitation'),
('MCO',Null,Null),
('DOE',Null,Null);

drop table if exists l_ec_type cascade;
CREATE TABLE l_ec_type (code text,libelle text,definition text, CONSTRAINT l_ec_type_type_pk PRIMARY KEY (code));
INSERT INTO l_ec_type(code, libelle, definition) VALUES
('DER','DEROGATION',NULL),
('CON','CONVENTION',NULL),
('ELA','ELAGAGE',NULL),
('ING','INGENIERIE',NULL),
('ADR','ADRESSAGE',NULL),
('COO','COORDINATION',NULL),
('OPT','OPTIMISATION',NULL),
('DEC','DECOUPAGE',NULL),
('AUD','AUDIT',NULL),
('REM','REMARQUE',NULL);

drop table if exists l_ec_support cascade;
CREATE TABLE l_ec_support (code text,libelle text,definition text, CONSTRAINT l_ec_support_type_pk PRIMARY KEY (code));
INSERT INTO l_ec_support(code, libelle, definition) VALUES
('SUF','SUF','Site Utilisateur Final'),
('DGC','DGC','Dossier génie civil'),
('CHO','CHB_ORANGE','Chambre ORANGE'),
('APO','POT_ORANGE','Appui ORANGE'),
('APB','POT_ENEDIS','Appui ENEDIS'),
('AUT','AUT','Autre support');

drop table if exists l_ec_critique cascade;
CREATE TABLE l_ec_critique (code text,libelle text,definition text, CONSTRAINT l_ec_critique_type_pk PRIMARY KEY (code));
INSERT INTO l_ec_critique(code, libelle, definition) VALUES
('AVER','AVERTISSEMENT','Avertissement, réserve mineure'),
('BLOQ','BLOQUANT','Point bloquant, réserve majeure'),
('INFO','INFORMATION','Remarque ne faisant pas lobjet de reserve');

drop table if exists l_ec_action cascade;
CREATE TABLE l_ec_action (code text,libelle text,definition text, CONSTRAINT l_ec_action_type_pk PRIMARY KEY (code));
INSERT INTO l_ec_action(code, libelle, definition) VALUES
('IMM','IMMEDIATE','Pour action immédiate'),
('PHA','PHASE SUIVANTE','A corriger lors de la phase suivante'),
('SO','SANS OBJET','Sans objet');

drop table if exists l_ec_traitement cascade;
CREATE TABLE l_ec_traitement (code text,libelle text,definition text, CONSTRAINT l_ec_traitement_type_pk PRIMARY KEY (code));
INSERT INTO l_ec_traitement(code, libelle, definition) VALUES
('OUI','OUI','Traité'),
('NON','NON','Non traité'),
('SO','SANS OBJET','Sans objet');

drop table if exists l_ec_etat cascade;
CREATE TABLE l_ec_etat (code text,libelle text,definition text, CONSTRAINT l_ec_etat_type_pk PRIMARY KEY (code));
INSERT INTO l_ec_etat(code, libelle, definition) VALUES
('OK','VALIDE','Validé'),
('KO','REFUSE','Refusé'),
('SO','SANS OBJET','Sans objet');

drop table if exists t_echange cascade;
CREATE TABLE t_echange
(
cle text, --VARCHAR(254),
ident text, --VARCHAR(254),
localisation text, --VARCHAR(20),
num_sro text, --VARCHAR(20),
phase text, --VARCHAR(20),
type_rem text, --VARCHAR(20),
support text, --VARCHAR(20),
id text, --VARCHAR(254),
com_init text, --VARCHAR(254),
date_cr text, --TIMESTAMP,
criticite text, --VARCHAR(20),
actions text, --VARCHAR(20),
destinataire text, --VARCHAR(254),
prise_en_compte text, --VARCHAR(20),
valid_derog text, --VARCHAR(20),
com_rep text, --VARCHAR(254),
date_rep text, --TIMESTAMP,
lien_inter_rem text, --VARCHAR(254),
geom geometry(Polygon,2154),
  CONSTRAINT t_echange_pk PRIMARY KEY (cle)
  -- ,
  -- CONSTRAINT t_echange_ec_organisme_fkey FOREIGN KEY (ec_organisme)
      -- REFERENCES l_ec_organisme ( code ) MATCH SIMPLE ON UPDATE NO ACTION ON DELETE NO ACTION,
  -- CONSTRAINT t_echange_ec_statut_fkey FOREIGN KEY (ec_statut)
      -- REFERENCES l_ec_statut ( code ) MATCH SIMPLE ON UPDATE NO ACTION ON DELETE NO ACTION,
  -- CONSTRAINT t_echange_ec_type_fkey FOREIGN KEY (ec_type)
      -- REFERENCES l_ec_type ( code ) MATCH SIMPLE ON UPDATE NO ACTION ON DELETE NO ACTION,
  -- CONSTRAINT t_echange_ec_support_fkey FOREIGN KEY (ec_support)
      -- REFERENCES l_ec_support ( code ) MATCH SIMPLE ON UPDATE NO ACTION ON DELETE NO ACTION,
  -- CONSTRAINT t_echange_ec_critique_fkey FOREIGN KEY (ec_critique)
      -- REFERENCES l_ec_critique ( code ) MATCH SIMPLE ON UPDATE NO ACTION ON DELETE NO ACTION,
  -- CONSTRAINT t_echange_ec_action_fkey FOREIGN KEY (ec_action)
      -- REFERENCES l_ec_action ( code ) MATCH SIMPLE ON UPDATE NO ACTION ON DELETE NO ACTION,
  -- CONSTRAINT t_echange_ec_destinataire_fkey FOREIGN KEY (ec_destinataire)
      -- REFERENCES l_ec_organisme ( code ) MATCH SIMPLE ON UPDATE NO ACTION ON DELETE NO ACTION,
  -- CONSTRAINT t_echange_ec_traitement_fkey FOREIGN KEY (ec_traitement)
      -- REFERENCES l_ec_traitement ( code ) MATCH SIMPLE ON UPDATE NO ACTION ON DELETE NO ACTION,
  -- CONSTRAINT t_echange_ec_etat_fkey FOREIGN KEY (ec_etat)
      -- REFERENCES l_ec_etat ( code ) MATCH SIMPLE ON UPDATE NO ACTION ON DELETE NO ACTION,
  -- CONSTRAINT t_echange_ec_link_fkey FOREIGN KEY (ec_link)
      -- REFERENCES t_echange ( ec_code ) MATCH SIMPLE ON UPDATE NO ACTION ON DELETE NO ACTION
	  );
DROP INDEX if exists t_echange_geom_gist;
CREATE INDEX t_echange_geom_gist ON t_echange USING gist(geom);

drop table if exists t_code_erreur cascade;
CREATE TABLE t_code_erreur (ID_CODE text, CATEGORIE text, TYPE_OBJET text, COMMENTAIRE text, CRITICITE text, Dev_Status text, Nom_Plugins text, Nom text, Description  text);

insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('S01','GTHD','TABLE','INCOHERENCE FORMALISME DES DONNEES','BLOQUANT','OK','Control des Formalismes');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('S01','GTHD','TABLE','INCOHERENCE FORMALISME DES DONNEES','BLOQUANT','OK','Control des Formalismes');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('S01','GTHD','TABLE','INCOHERENCE FORMALISME DES DONNEES','BLOQUANT','OK','Control des Formalismes');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('S01','GTHD','TABLE','INCOHERENCE FORMALISME DES DONNEES','BLOQUANT','OK','Control des Formalismes');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('S01','GTHD','TABLE','INCOHERENCE FORMALISME DES DONNEES','BLOQUANT','OK','Control des Formalismes');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('S01','GTHD','TABLE','INCOHERENCE FORMALISME DES DONNEES','BLOQUANT','OK','Control des Formalismes');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('S01','GTHD','TABLE','INCOHERENCE FORMALISME DES DONNEES','BLOQUANT','OK','Control des Formalismes');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('S02','GTHD','ADRESSE','INCOHERENCE DE NOMMAGE OU DE PLAGE POUR AD_CODE OU AD_BATCODE DANS T_ADRESSE','BLOQUANT','OK','Control des Formalismes');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('S02','GTHD','ADRESSE','INCOHERENCE DE NOMMAGE OU DE PLAGE POUR AD_CODE OU AD_BATCODE DANS T_ADRESSE','BLOQUANT','OK','Control des Formalismes');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('S02','GTHD','ADRESSE','INCOHERENCE DE NOMMAGE OU DE PLAGE POUR AD_CODE OU AD_BATCODE DANS T_ADRESSE','BLOQUANT','OK','Control des Formalismes');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('S03','GTHD','PTECH','INCOHERENCE DE NOMMAGE OU DE PLAGE OU DE STATUS DANS T_PTECH','BLOQUANT','OK','Control des Formalismes');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('S03','GTHD','PTECH','INCOHERENCE DE NOMMAGE OU DE PLAGE OU DE STATUS DANS T_PTECH','BLOQUANT','OK','Control des Formalismes');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('S03','GTHD','PTECH','INCOHERENCE DE NOMMAGE OU DE PLAGE OU DE STATUS DANS T_PTECH','BLOQUANT','OK','Control des Formalismes');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('S03','GTHD','PTECH','INCOHERENCE DE NOMMAGE OU DE PLAGE OU DE STATUS DANS T_PTECH','BLOQUANT','OK','Control des Formalismes');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('S04','GTHD','BOITE','INCOHERENCE DE NOMMAGE OU DE PLAGE OU DE STATUS DANS T_EBP','BLOQUANT','OK','Control des Formalismes');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('S04','GTHD','BOITE','INCOHERENCE DE NOMMAGE OU DE PLAGE OU DE STATUS DANS T_EBP','BLOQUANT','OK','Control des Formalismes');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('S04','GTHD','BOITE','INCOHERENCE DE NOMMAGE OU DE PLAGE OU DE STATUS DANS T_EBP','BLOQUANT','OK','Control des Formalismes');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('S04','GTHD','BOITE','INCOHERENCE DE NOMMAGE OU DE PLAGE OU DE STATUS DANS T_EBP','BLOQUANT','OK','Control des Formalismes');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('S04','GTHD','BOITE','INCOHERENCE DE NOMMAGE OU DE PLAGE OU DE STATUS DANS T_EBP','BLOQUANT','OK','Control des Formalismes');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('S05','GTHD','CHEMINEMENT','INCOHERENCE DE NOMMAGE OU DE PLAGE OU DE STATUS DANS T_CHEMINEMENT','BLOQUANT','OK','Control des Formalismes');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('S05','GTHD','CHEMINEMENT','INCOHERENCE DE NOMMAGE OU DE PLAGE OU DE STATUS DANS T_CHEMINEMENT','BLOQUANT','OK','Control des Formalismes');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('S05','GTHD','CHEMINEMENT','INCOHERENCE DE NOMMAGE OU DE PLAGE OU DE STATUS DANS T_CHEMINEMENT','BLOQUANT','OK','Control des Formalismes');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('S05','GTHD','CHEMINEMENT','INCOHERENCE DE NOMMAGE OU DE PLAGE OU DE STATUS DANS T_CHEMINEMENT','BLOQUANT','OK','Control des Formalismes');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('S06','GTHD','ZDEP','INCOHERENCE DE NOMMAGE OU DE PLAGE OU DE STATUS DANS T_ZDEP','BLOQUANT','OK','Control des Formalismes');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('S06','GTHD','ZDEP','INCOHERENCE DE NOMMAGE OU DE PLAGE OU DE STATUS DANS T_ZDEP','BLOQUANT','OK','Control des Formalismes');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('S06','GTHD','ZDEP','INCOHERENCE DE NOMMAGE OU DE PLAGE OU DE STATUS DANS T_ZDEP','BLOQUANT','OK','Control des Formalismes');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('S06','GTHD','ZDEP','INCOHERENCE DE NOMMAGE OU DE PLAGE OU DE STATUS DANS T_ZDEP','BLOQUANT','OK','Control des Formalismes');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('S07','GTHD','CABLE','INCOHERENCE DE NOMMAGE OU DE PLAGE OU DE STATUS DANS T_CABLE','BLOQUANT','EN COURS','Control des Formalismes');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('S07','GTHD','CABLE','INCOHERENCE DE NOMMAGE OU DE PLAGE OU DE STATUS DANS T_CABLE','BLOQUANT','OK','Control des Formalismes');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('S07','GTHD','CABLE','INCOHERENCE DE NOMMAGE OU DE PLAGE OU DE STATUS DANS T_CABLE','BLOQUANT','OK','Control des Formalismes');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('S07_1','GTHD','CABLE','?','?','A FAIRE','Control des Formalismes');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('S07_2','GTHD','CABLE','INCOHERENCE ORIGINE DU CABLE','BLOQUANT','OK','Control des Formalismes');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('S07_3','GTHD','CABLE','INCOHERENCE EXTREMITE DU CABLE','BLOQUANT','OK','Control des Formalismes');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('S07','GTHD','CABLE','INCOHERENCE DE NOMMAGE OU DE PLAGE OU DE STATUS DANS T_CABLE','BLOQUANT','OK','Control des Formalismes');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('S07','GTHD','CABLE','INCOHERENCE DE NOMMAGE OU DE PLAGE OU DE STATUS DANS T_CABLE','BLOQUANT','A FAIRE','Control des Formalismes');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('S08','GTHD','FIBRE','INCOHERENCE DE NOMMAGE OU DE PLAGE OU DE STATUS DANS T_FIBRE','BLOQUANT','A FAIRE','Control des Formalismes');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('S08','GTHD','FIBRE','INCOHERENCE DE NOMMAGE OU DE PLAGE OU DE STATUS DANS T_FIBRE','BLOQUANT','A FAIRE','Control des Formalismes');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('S08','GTHD','FIBRE','INCOHERENCE DE NOMMAGE OU DE PLAGE OU DE STATUS DANS T_FIBRE','BLOQUANT','A FAIRE','Control des Formalismes');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('S09','GTHD','SITETECH','INCOHERENCE DE NOMMAGE OU DE PLAGE OU DE STATUS DANS T_SITETECH','BLOQUANT','OK','Control des Formalismes');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('S09','GTHD','SITETECH','INCOHERENCE DE NOMMAGE OU DE PLAGE OU DE STATUS DANS T_SITETECH','BLOQUANT','OK','Control des Formalismes');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('S09','GTHD','SITETECH','INCOHERENCE DE NOMMAGE OU DE PLAGE OU DE STATUS DANS T_SITETECH','BLOQUANT','OK','Control des Formalismes');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('S10','GTHD','LTECH','INCOHERENCE DE NOMMAGE OU DE PLAGE OU DE STATUS DANS L_TECH','BLOQUANT','OK','Control des Formalismes');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('S10','GTHD','LTECH','INCOHERENCE DE NOMMAGE OU DE PLAGE OU DE STATUS DANS L_TECH','BLOQUANT','OK','Control des Formalismes');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('S10','GTHD','LTECH','INCOHERENCE DE NOMMAGE OU DE PLAGE OU DE STATUS DANS L_TECH','BLOQUANT','OK','Control des Formalismes');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('S11','GTHD','ZNRO','INCOHERENCE NRO DE RATTACHEMENT POUR LA ZNRO','BLOQUANT','OK','Control des Formalismes');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('S11','GTHD','ZNRO','INCOHERENCE NRO DE RATTACHEMENT POUR LA ZNRO','BLOQUANT','OK','Control des Formalismes');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('S11','GTHD','ZNRO','INCOHERENCE NRO DE RATTACHEMENT POUR LA ZNRO','BLOQUANT','OK','Control des Formalismes');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('S12','GTHD','ZSRO','INCOHERENCE  NRO, SRO DE RATTACHEMENT POUR LA ZSRO','BLOQUANT','OK','Control des Formalismes');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('S12','GTHD','ZSRO','INCOHERENCE  NRO, SRO DE RATTACHEMENT POUR LA ZSRO','BLOQUANT','OK','Control des Formalismes');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('S12','GTHD','ZSRO','INCOHERENCE  NRO, SRO DE RATTACHEMENT POUR LA ZSRO','BLOQUANT','OK','Control des Formalismes');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('S12','GTHD','ZSRO','INCOHERENCE  NRO, SRO DE RATTACHEMENT POUR LA ZSRO','BLOQUANT','OK','Control des Formalismes');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('S13','GTHD','ZSRO','INCOHERENCE DE GEOMETRIE DE LA ZSRO','BLOQUANT','OK','Control des Formalismes');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('S12','GTHD','ZSRO','INCOHERENCE  NRO, SRO DE RATTACHEMENT POUR LA ZSRO','BLOQUANT','OK','Control des Formalismes');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('S14','GTHD','ZPBO','INCOHERENCE NRO, SRO, OU PBO DE RATTACHEMENT POUR LA ZPBO','BLOQUANT','OK','Control des Formalismes');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('S14','GTHD','ZPBO','INCOHERENCE NRO, SRO, OU PBO DE RATTACHEMENT POUR LA ZPBO','BLOQUANT','OK','Control des Formalismes');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('S14','GTHD','ZPBO','INCOHERENCE NRO, SRO, OU PBO DE RATTACHEMENT POUR LA ZPBO','BLOQUANT','OK','Control des Formalismes');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('S14','GTHD','ZPBO','INCOHERENCE NRO, SRO, OU PBO DE RATTACHEMENT POUR LA ZPBO','BLOQUANT','OK','Control des Formalismes');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('S15','GTHD','ZPBO','INCOHERENCE DE GEOMETRIE DE LA ZPBO','BLOQUANT','OK','Control des Formalismes');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('S14','GTHD','ZPBO','INCOHERENCE NRO, SRO, OU PBO DE RATTACHEMENT POUR LA ZPBO','BLOQUANT','OK','Control des Formalismes');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('','?','?','?','?','A FAIRE','Control des Formalismes');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('','?','?','?','?','OK','Control des Formalismes');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('','?','?','?','?','OK','Control des Formalismes');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('','?','?','?','?','OK','Control des Formalismes');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('','?','?','?','?','OK','Control des Formalismes');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('','?','?','?','?','OK','Control des Formalismes');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('','?','?','?','?','OK','Control des Formalismes');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('','?','?','?','?','A FAIRE','Control des Formalismes');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('','?','?','?','?','A FAIRE','Control des Formalismes');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('','?','?','?','?','A FAIRE','Control des Formalismes');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('','?','?','?','?','A FAIRE','Control des Formalismes');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('','?','?','?','?','A FAIRE','Control des Formalismes');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('','?','?','?','?','A FAIRE','Control des Formalismes');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('','?','?','?','?','OK','Control des Formalismes');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('','?','?','?','?','A FAIRE','Control des Formalismes');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('','?','?','?','?','A FAIRE','Control des Formalismes');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('','?','?','?','?','A FAIRE','Control des Formalismes');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('S16','GTHD','ZPBO','INCOHERENCE DU NOMBRE DE SUF DE LA ZPBO','BLOQUANT','A FAIRE','Control des Formalismes');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('S16','GTHD','ZPBO','INCOHERENCE DU NOMBRE DE SUF DE LA ZPBO','BLOQUANT','OK','Control des Formalismes');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('S16','GTHD','ZPBO','INCOHERENCE DU NOMBRE DE SUF DE LA ZPBO','BLOQUANT','OK','Control des Formalismes');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('S16','GTHD','ZPBO','INCOHERENCE DU NOMBRE DE SUF DE LA ZPBO','BLOQUANT','OK','Control des Formalismes');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('S17','?','?','?','?','A FAIRE','Control des Formalismes');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('S17','?','?','?','?','A FAIRE','Control des Formalismes');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('S17','?','?','?','?','A FAIRE','Control des Formalismes');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('S18','GTHD','PTECH','ABSENCE DPI DU POINT TECHNIQUE CHAMBRE','BLOQUANT','A FAIRE','Control des Formalismes');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('S18_1','GTHD','PTECH','ABSENCE DPI DU POINT TECHNIQUE CHAMBRE','BLOQUANT','OK','Control des Formalismes');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('S18_2','GTHD','PTECH','ABSENCE DPI DU POINT TECHNIQUE CHAMBRE','BLOQUANT','A OPTIMISER','Control des Formalismes');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('S19','GTHD','PTECH','ABSENCE DPI DU POINT TECHNIQUE APPUIS','BLOQUANT','A FAIRE','Control des Formalismes');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('S19_1','GTHD','PTECH','ABSENCE DPI DU POINT TECHNIQUE APPUIS','BLOQUANT','OK','Control des Formalismes');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('S19_2','GTHD','PTECH','ABSENCE DPI DU POINT TECHNIQUE APPUIS','BLOQUANT','A OPTIMISER','Control des Formalismes');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('S20','GTHD','PTECH','ABSENCE DPI DU POINT TECHNIQUE POTELET','BLOQUANT','A FAIRE','Control des Formalismes');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('S20_1','GTHD','PTECH','ABSENCE DPI DU POINT TECHNIQUE POTELET','BLOQUANT','OK','Control des Formalismes');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('S20_2','GTHD','PTECH','ABSENCE DPI DU POINT TECHNIQUE POTELET','BLOQUANT','A OPTIMISER','Control des Formalismes');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('S21','?','?','?','?','A FAIRE','Control des Formalismes');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('S21_1','?','?','?','?','A FAIRE','Control des Formalismes');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('S21_1','?','?','?','?','A FAIRE','Control des Formalismes');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('S21_2','?','?','?','?','A FAIRE','Control des Formalismes');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('S21_2','?','?','?','?','A FAIRE','Control des Formalismes');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('S22','?','?','?','?','A FAIRE','Control des Formalismes');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('S22_1','GTHD','CHEMINEMENT','ABSENCE DE RESEAU DE TRANSPORT A MOINS DE 100M DU SRO','AVERTISSEMENT ','A FAIRE','Control des Formalismes');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('S22_1','GTHD','CHEMINEMENT','ABSENCE DE RESEAU DE TRANSPORT A MOINS DE 100M DU SRO','AVERTISSEMENT ','OK','Control des Formalismes');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('S23_1','?','?','?','?','A FAIRE','Control des Formalismes');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('S23_2','?','?','?','?','A FAIRE','Control des Formalismes');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('S24','GTHD','ZSRO','PRISE SITUEE A PLUS DE 19KM DU NRO','BLOQUANT','A FAIRE','Control des Formalismes');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('S24','GTHD','ZSRO','PRISE SITUEE A PLUS DE 19KM DU NRO','BLOQUANT','A FAIRE','Control des Formalismes');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('S21_1','GTHD','ZSRO','ZSRO SITUEE HORS 300 et 500','BLOQUANT','OK','Control des Formalismes');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('S21_2','GTHD','ZSRO','ZSRO SITUEE HORS linterval','BLOQUANT','A FAIRE','Control des Formalismes');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('S21_3','GTHD','ZSRO','enveloppe des sufs hors zsro','BLOQUANT','A FAIRE','Control des Formalismes');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('S21_4','GTHD','ZSRO','?','BLOQUANT','A FAIRE','Control des Formalismes');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('Z01_1','GTHD','CABLE','Cable avec probleme daccrochage ou deconnecter du reseau','Information','OK','Control des Formalismes');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('Z01_2','GTHD','CABLE','Cable dessine dans le mauvais sens','Information','OK','Control des Formalismes');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('D01','?','?','?','?','A FAIRE','');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('D01_1','INGENIERIE','CHEMINEMENT','PRESENCE CHEMINEMENT EN PARALLELE','BLOQUANT','A FAIRE','Control du Design');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('D01_1','INGENIERIE','CHEMINEMENT','PRESENCE CHEMINEMENT EN PARALLELE','BLOQUANT','OK','Control du Design');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('D01_1','INGENIERIE','CHEMINEMENT','PRESENCE CHEMINEMENT EN PARALLELE','BLOQUANT','OK','Control du Design');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('D02_1','INGENIERIE','CHEMINEMENT','PRESENCE CHEMINEMENT SANS CABLE','AVERTISSEMENT ','A FAIRE','Control du Design');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('D02_1','INGENIERIE','CHEMINEMENT','PRESENCE CHEMINEMENT SANS CABLE','AVERTISSEMENT ','OK','Control du Design');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('D03_1','INGENIERIE','CABLE','PRESENCE CABLE SANS CHEMINEMENT','BLOQUANT','A FAIRE','Control du Design');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('D03_1','INGENIERIE','CABLE','PRESENCE CABLE SANS CHEMINEMENT','BLOQUANT','OK','Control du Design');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('D04','INGENIERIE','?','?','?','A FAIRE','Control du Design');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('D04_1','INGENIERIE','?','?','?','A FAIRE','Control du Design');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('D04_2','INGENIERIE','?','?','?','A FAIRE','Control du Design');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('D04_3','INGENIERIE','?','?','?','A FAIRE','Control du Design');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('D05','INGENIERIE','ZPBO','PRESENCE DE PLUS DE 5 PRISES DANS LA ZPBO','AVERTISSEMENT ','A FAIRE','Control du Design');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('D05_1','INGENIERIE','ZPBO','PRESENCE DE PLUS DE 5 PRISES DANS LA ZPBO','AVERTISSEMENT ','OK','Control du Design');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('D06','INGENIERIE','?','?','?','A FAIRE','Control du Design');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('D06_1','INGENIERIE','?','?','?','A FAIRE','Control du Design');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('D07','INGENIERIE','?','?','?','A FAIRE','Control du Design');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('D07_1','INGENIERIE','?','?','?','A FAIRE','Control du Design');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('D08','INGENIERIE','?','?','?','A FAIRE','Control du Design');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('D08_1','INGENIERIE','CABLE','CABLE DE RACCORDEMENT SUPERIEUR A 100M (JUSQU’À 200M)','AVERTISSEMENT ','OK','Control du Design');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('D08_2','INGENIERIE','CABLE','CABLE FICTIF SUPERIEUR A 100M','AVERTISSEMENT ','OK','Control du Design');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('D08_3','INGENIERIE','CABLE','CABLE DE RACCORDEMENT SUPERIEUR A 500M','AVERTISSEMENT ','OK','Control du Design');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('D09','INGENIERIE','?','?','?','A FAIRE','Control du Design');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('D09_1','INGENIERIE','SUF','PRISE NON RACCORDEE','BLOQUANT','OK','Control du Design');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('D09_2','INGENIERIE','CABLE','CABLE DE RACCORDEMENT SANS PRISE','BLOQUANT','OK','Control du Design');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('D09_3','INGENIERIE','CABLE','CABLE DE RACCORDEMENT SUPERIEUR A 200M (JUSQU’À 500M)','AVERTISSEMENT ','A FAIRE','Control du Design');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('D10','INGENIERIE','CHEMINEMENT','?','?','A FAIRE','Control du Design');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('D10_1','INGENIERIE','CHEMINEMENT','CHEMINEMENT SUPERIEUR A 600M','?','A FAIRE','Control du Design');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('B01','?','?','?','?','A FAIRE','Dimensionnement des Boites');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('B01','?','?','?','?','A FAIRE','Dimensionnement des Boites');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('B01_1','INGENIERIE','BOITE','BOITIER DE TYPE BPE A IMPLANTER AU DELA DE 500M SUR LES CABLE >144FO','AVERTISSEMENT ','OK','Dimensionnement des Boites');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('B01_2','INGENIERIE','BOITE','BOITIER IMPLANTE EN PARTIE PRIVATIVE','AVERTISSEMENT ','OK','Dimensionnement des Boites');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('B01_3','INGENIERIE','BOITE','PBO IMPLANTE SOUS CHAUSSE','AVERTISSEMENT ','OK','Dimensionnement des Boites');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('B01_4','INGENIERIE','BOITE','BOITIER SANS POINT TECHNIQUE','BLOQUANT','OK','Dimensionnement des Boites');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('B02','?','?','?','?','A FAIRE','Dimensionnement des Boites');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('B02_1','INGENIERIE','BOITE','PBO IMPLANTE DANS UN POINT TECHNIQUE DE TYPE L0T','BLOQUANT','OK','Dimensionnement des Boites');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('B02_2','INGENIERIE','BOITE','POINT TECHNIQUE DE TYPE APPUI ORANGE AVEC TROIS BOITIERS','BLOQUANT','OK','Dimensionnement des Boites');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('B03','?','?','?','?','A FAIRE','Dimensionnement des Boites');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('B03_1','INGENIERIE','BOITE','CAPACITE DU BOITIER INCOHERENTE AVEC LA CAPACITE DU CABLE ENTRANT','BLOQUANT','OK','Dimensionnement des Boites');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('B03_2','INGENIERIE','BOITE','BOITIER SUR POINT TECHNIQUE AERIEN ORANGE AVEC VOLUME INFERIEUR A 6DM3','BLOQUANT','EN COURS','Dimensionnement des Boites');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('B04','?','?','?','?','A FAIRE','Dimensionnement des Boites');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('B04_1','INGENIERIE','BOITE','BOITIER SUR POINT TECHNIQUE AERIEN ORANGE AVEC VOLUME INFERIEUR A 6DM3','BLOQUANT','OK','Dimensionnement des Boites');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('B05','?','?','?','?','A FAIRE','Dimensionnement des Boites');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('B05_1','INGENIERIE','BOITE','BOITIER FICTIF RACCORDE A UN CABLE AUTRE QUE FICTIF','BLOQUANT','OK','Dimensionnement des Boites');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('B06','?','?','?','?','A FAIRE','Dimensionnement des Boites');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('B06_1','INGENIERIE','BOITE','?','?','EN COURS','Dimensionnement des Boites');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('B07','?','?','?','?','A FAIRE','Dimensionnement des Boites');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('B07_1','INGENIERIE','LOVE','ABSENCE DE LOVE DANS LA CHAMBRE ADN','BLOQUANT','OK','Dimensionnement des Boites');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('B07_2','INGENIERIE','LOVE','PRESENCE DE LOVE DANS LA CHAMBRE 0','BLOQUANT','OK','Dimensionnement des Boites');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('B07_3','INGENIERIE','LOVE','ABSENCE DE LOVE DE PISTONNAGE EN AERIEN','BLOQUANT','OK','Dimensionnement des Boites');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('C01','INGENIERIE','CABLE','?','BLOQUANT','OK','Dimensionnement des Cables');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('C01','INGENIERIE','CABLE','?','BLOQUANT','OK','Dimensionnement des Cables');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('C01_1','INGENIERIE','CABLE','Calcul du cm_fo_util','BLOQUANT','OK','Dimensionnement des Cables');

insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('C02','INGENIERIE','CABLE','Incoherence entre Capacite Utilie et Capafo','BLOQUANT','OK','Dimensionnement des Cables');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('C02_1','INGENIERIE','CABLE','Incoherence entre Capacite Utilie et Capafo','BLOQUANT','OK','Dimensionnement des Cables');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('C03','INGENIERIE','CABLE','Incoherence de loptimisation des changements de cable','BLOQUANT','OK','Dimensionnement des Cables');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('C03_1','INGENIERIE','CABLE','Incoherence de loptimisation des changements de cable','BLOQUANT','EN COURS','Dimensionnement des Cables');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('C04','INGENIERIE','CABLE','?','BLOQUANT','A FAIRE','Dimensionnement des Cables');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('C04_1','INGENIERIE','CABLE','?','BLOQUANT','OK','Dimensionnement des Cables');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('C05','INGENIERIE','CABLE','CFI raccordes a des PBO','BLOQUANT','OK','Dimensionnement des Cables');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('C05_1','INGENIERIE','CABLE','CFI raccordes a des PBO','BLOQUANT','OK','Dimensionnement des Cables');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('C06','INGENIERIE','CABLE','Cables de forte capacite inferieurs a 300m','BLOQUANT','OK','Dimensionnement des Cables');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('C06_1','INGENIERIE','CABLE','Cables de forte capacite inferieurs a 300m','BLOQUANT','OK','Dimensionnement des Cables');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('C06_2','INGENIERIE','CABLE','Cables de forte capacite inferieurs a 300m','BLOQUANT','OK','Dimensionnement des Cables');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('C07','INGENIERIE','CABLE','?','BLOQUANT','A FAIRE','Dimensionnement des Cables');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('C07_1','INGENIERIE','CABLE','?','BLOQUANT','A FAIRE','Dimensionnement des Cables');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('A01','?','?','?','?','A FAIRE','Dimensionnement des Baies');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('A01','?','?','?','?','A FAIRE','Dimensionnement des Baies');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('A01_1','?','?','?','?','A FAIRE','Dimensionnement des Baies');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('A01_2','?','?','?','?','A FAIRE','Dimensionnement des Baies');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('A01_3','?','?','?','?','A FAIRE','Dimensionnement des Baies');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('A02','?','?','?','?','A FAIRE','Dimensionnement des Baies');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('A02_1','?','?','?','?','A FAIRE','Dimensionnement des Baies');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('A02_2','?','?','?','?','A FAIRE','Dimensionnement des Baies');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('A03','?','?','?','?','A FAIRE','Dimensionnement des Baies');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('A03_1','?','?','?','?','A FAIRE','Dimensionnement des Baies');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('A03_2','?','?','?','?','A FAIRE','Dimensionnement des Baies');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('A04','?','?','?','?','A FAIRE','Dimensionnement des Baies');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('A04_1','?','?','?','?','A FAIRE','Dimensionnement des Baies');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('M01','?','?','?','?','A FAIRE','Dimensionnement des Baies');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('M01','?','?','?','?','A FAIRE','Dimensionnement des Baies');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('M01_1','?','?','?','?','A FAIRE','Dimensionnement des Baies');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('M02','?','?','?','?','A FAIRE','Dimensionnement des Baies');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('M02_1','?','?','?','?','A FAIRE','Dimensionnement des Baies');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('M03','?','?','?','?','A FAIRE','Dimensionnement des Baies');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('M03_1','?','?','?','?','A FAIRE','Dimensionnement des Baies');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('M03_2','?','?','?','?','A FAIRE','Dimensionnement des Baies');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('M03_3','?','?','?','?','A FAIRE','Dimensionnement des Baies');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('F01','?','?','?','?','A FAIRE','Control du FIBRAGE');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('F01','?','?','?','?','A FAIRE','Control du FIBRAGE');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('F01_1','?','?','?','?','A FAIRE','Control du FIBRAGE');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('F02','?','?','?','?','A FAIRE','Control du FIBRAGE');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('F02_1','?','?','?','?','A FAIRE','Control du FIBRAGE');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('F02_2','?','?','?','?','A FAIRE','Control du FIBRAGE');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('F02_3','?','?','?','?','A FAIRE','Control du FIBRAGE');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('F03','?','?','?','?','A FAIRE','Control du FIBRAGE');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('F03_1','?','?','?','?','A FAIRE','Control du FIBRAGE');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('F03_2','?','?','?','?','A FAIRE','Control du FIBRAGE');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('F03_3','?','?','?','?','A FAIRE','Control du FIBRAGE');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('F03_4','?','?','?','?','A FAIRE','Control du FIBRAGE');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('F03_5','?','?','?','?','A FAIRE','Control du FIBRAGE');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('F03_6','?','?','?','?','A FAIRE','Control du FIBRAGE');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('F03_7','?','?','?','?','A FAIRE','Control du FIBRAGE');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('F03_8','?','?','?','?','A FAIRE','Control du FIBRAGE');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('F03_9','?','?','?','?','A FAIRE','Control du FIBRAGE');
insert into t_code_erreur (ID_CODE, CATEGORIE, TYPE_OBJET, COMMENTAIRE, CRITICITE, Dev_Status, Nom_Plugins) VALUES('F03_10','?','?','?','?','A FAIRE','Control du FIBRAGE');



GRANT ALL ON TABLE t_code_erreur TO adn_ing;
GRANT ALL ON TABLE t_code_erreur TO postgres;

GRANT ALL ON TABLE t_echange TO adn_ing;
GRANT ALL ON TABLE t_echange TO postgres;





/*SET search_path TO schema_input, public;
drop table if exists t_code_erreur cascade;
CREATE TABLE t_code_erreur (code_fonction_controle  text,categorie text,commentaire text, criticite text,nom_Plugins text,description text);
GRANT ALL ON TABLE t_code_erreur TO adn_ing;
GRANT ALL ON TABLE t_code_erreur TO postgres;
COPY t_code_erreur(code_fonction_controle,categorie,commentaire, criticite,nom_Plugins,description) 
FROM 'C:\Users\babacar.fassa\Documents\Plugins_Scripts\table_code_message_erreur.csv' DELIMITER ';' CSV HEADER;*/