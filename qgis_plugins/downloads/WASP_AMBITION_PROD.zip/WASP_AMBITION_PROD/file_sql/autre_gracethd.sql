GRANT USAGE ON SCHEMA schema_name to adn_ing;
GRANT CREATE ON SCHEMA schema_name to adn_ing;
--GRANT SELECT, INSERT ON ALL TABLES IN SCHEMA schema_name TO adn_ing;
-- GRANT ALL ON TABLE contre_releve TO adn_ing;

SET search_path to schema_name, public;
CREATE OR REPLACE VIEW schema_name.vs_dep_znro AS
with Q1 AS
		(Select DZN.*
		FROM dep_.znro DZN, t_znro ZN
		where DZN.nro_ref  = ZN.zn_r2_code),
	Q2 AS (
		  SELECT znro.*
			FROM dep_.znro , q1
			WHERE ST_Intersects(Q1.geom, znro.geom)
			)
select *
from q2;
-- ALTER TABLE vs_dep_znro OWNER TO postgres;


CREATE OR REPLACE VIEW schema_name.vs_resopt_noeuds AS
SELECT resopt_noeuds.gid,
	id_reseau ,
	id_element ,
	rang_opt ,
	niveau ,
	etat_racco ,
	supp_racco ,
	support ,
	nom ,
	cle_ext ,
	sites ,
	prises ,
	equip ,
	cout ,
	id_nod_pri ,
	l_nod_pri ,
	id_nod_sup ,
	l_nod_sup ,
	l_pto_min ,
	l_pto_max ,
	l_pto_tot ,
	c_noeud ,
	c_reseau ,
	c_prise ,
	nom_nro ,
	ancien_nom ,
	resopt_noeuds.geom
FROM dep_.resopt_noeuds, schema_name.vs_dep_znro
WHERE st_within(resopt_noeuds.geom, vs_dep_znro.geom);
-- ALTER TABLE schema_name.vs_resopt_noeuds OWNER TO postgres;


CREATE OR REPLACE VIEW schema_name.vs_suf_majic AS
SELECT suf_majic.gid,
	ccodep ,
	code_insee ,
	nb_indiv ,
	nb_collect ,
	nb_prof ,
	suf_majic.nb_total ,
	nb_propri ,
	suf_majic.geom
FROM dep_.suf_majic, schema_name.vs_dep_znro
WHERE st_within(suf_majic.geom, vs_dep_znro.geom);
-- ALTER TABLE schema_name.vs_resopt_noeuds OWNER TO postgres;


CREATE OR REPLACE VIEW schema_name.vs_resopt_lienstransport AS
SELECT resopt_lienstransport.gid,
	id_reseau,
	id_element ,
	rang_opt ,
	niveau ,
	segment ,
	support ,
	nom ,
	cle_ext ,
	sites ,
	prises ,
	fibres ,
	fibres_p2p ,
	fibres_pon ,
	fibres_res ,
	cables ,
	longueur ,
	cout ,
	id_nod_pri ,
	id_nod_sup ,
	nom_nro ,
	ancien_nom ,
	resopt_lienstransport.geom
FROM dep_.resopt_lienstransport, schema_name.vs_dep_znro
WHERE st_within(resopt_lienstransport.geom, vs_dep_znro.geom);
-- ALTER TABLE schema_name.vs_resopt_lienstransport OWNER TO postgres;


CREATE OR REPLACE VIEW schema_name.vs_resopt_lienstransport AS
SELECT resopt_lienstransport.gid,
	id_reseau,
	id_element ,
	rang_opt ,
	niveau ,
	segment ,
	support ,
	nom ,
	cle_ext ,
	sites ,
	prises ,
	fibres ,
	fibres_p2p ,
	fibres_pon ,
	fibres_res ,
	cables ,
	longueur ,
	cout ,
	id_nod_pri ,
	id_nod_sup ,
	nom_nro ,
	ancien_nom ,
	resopt_lienstransport.geom
FROM dep_.resopt_lienstransport, schema_name.vs_dep_znro
WHERE st_within(resopt_lienstransport.geom, vs_dep_znro.geom);
-- ALTER TABLE schema_name.vs_resopt_lienstransport OWNER TO postgres;


CREATE OR REPLACE VIEW schema_name.vs_resopt_liens AS
SELECT resopt_liens.gid,
	id_reseau,
	id_element ,
	rang_opt ,
	niveau ,
	segment ,
	support ,
	nom ,
	cle_ext ,
	sites ,
	prises ,
	fibres ,
	fibres_p2p ,
	fibres_pon ,
	fibres_res ,
	cables ,
	longueur ,
	cout ,
	id_nod_pri ,
	id_nod_sup ,
	nom_nro ,
	ancien_nom ,
	resopt_liens.geom
FROM dep_.resopt_liens, schema_name.vs_dep_znro
WHERE st_within(resopt_liens.geom, vs_dep_znro.geom);
-- ALTER TABLE schema_name.vs_resopt_liens OWNER TO postgres;

--Creation des routes a lechelle du projet
create table schema_name."troncon_rff" as
select
	tvf.*
from troncon_lineaire."TRONCON_VOIE_FERREE_07-26" as tvf
	join t_znro as zn on ST_DWithin(zn.geom,tvf.geom, 0.1);

create table schema_name."troncon_route" as
select
	tvf.*
from troncon_lineaire."TRONCON_ROUTE_07-26" as tvf
	join t_znro as zn on ST_DWithin(zn.geom,tvf.geom, 0.1);

create table schema_name."troncon_pr" as
select
	tvf.*
from troncon_lineaire."bornage_pr_shp_l93_201807" as tvf
	join t_znro as zn on ST_DWithin(zn.geom,tvf.geom, 0.1);

-- Create vue parcelle
CREATE OR REPLACE VIEW vs_parcelles_znro AS
	 SELECT cadastre_domanialite.id_par,
		cadastre_domanialite.id_com,
		cadastre_domanialite.parcelle,
		cadastre_domanialite.dvoilib,
		cadastre_domanialite.nat_droit,
		cadastre_domanialite.pers_moral,
		cadastre_domanialite.geom
	   FROM parcelles.cadastre_domanialite,
		t_znro
	  WHERE st_Within(cadastre_domanialite.geom, t_znro.geom);
	ALTER TABLE vs_parcelles_znro OWNER TO postgres;

-- Create t_refboite
CREATE TABLE t_refboite
	(
		rb_code text NOT NULL,
		rb_rf_code text ,
		rb_ca_nbmax text ,
		rb_volume text ,
		rb_pressu text ,
		rb_creadat text ,
		rb_majdate text ,
		rb_majsrc text ,
		rb_abddate text ,
		rb_abdsrc text   ,
		CONSTRAINT t_refboite_pkey PRIMARY KEY (rb_code)
	) ;

-- Create t_refcable
	CREATE TABLE t_refcable
	(
		rc_code text NOT NULL,
		rc_rf_code text ,
		rc_capafo text ,
		rc_modulo text ,
		rc_diam text ,
		rc_typpose text,
		rc_portee text ,
		rc_norm text ,
		rc_rfcomac text ,
		rc_ancref text ,
		CONSTRAINT t_refcable_pkey PRIMARY KEY (rc_code)
	) ;

-- Ajout attribut ADN
ALTER TABLE t_zdep ADD COLUMN IF NOT EXISTS zd_r5_code text;
--Drop table if exists "TRONCON_VOIE_FERREE_07-26";
--Drop table if exists "TRONCON_ROUTE_07-26";

-- FUNCTION pour Convertir les multilinesstring to linestring
DROP FUNCTION if exists convert_multlines_to_lines(text);
Create or replace Function convert_multlines_to_lines(var_schema_name text) Returns void as $$
    DECLARE
        -----Declaration des variables drop et create
        var_req_execute record;
    begin
			FOR var_req_execute in
					select
			'UPDATE '||f_table_name||' cl1 SET geom = ST_SetSRID(cl2.linemerge, 2154)
				from ('||
				'select '||'ST_LineMerge(ST_Force2D(geom)) as linemerge, *'||' from '||f_table_schema||'.'||f_table_name||' where ST_GeometryType(geom) != ''ST_LineString'''
				||') as cl2
			WHERE '||
			case
				when f_table_name = 't_cableline' then 'cl1.cl_code=cl2.cl_code'
				when f_table_name = 't_cheminement' then 'cl1.cm_code=cl2.cm_code'
			end as req_convert, f_table_name
					from geometry_columns
					where f_table_schema  = $1 and f_table_name  in ('t_cableline','t_cheminement')--,

					LOOP
							IF var_req_execute.req_convert is not null THEN
			EXECUTE var_req_execute.req_convert;
							END IF;
					END LOOP;
    end;
$$ language plpgsql;
select * from convert_multlines_to_lines('schema_name');

--Ajout des droit

--GRANT INSERT, SELECT ON TABLE vs_dep_znro TO adn_ing;
--GRANT ALL ON TABLE vs_dep_znro TO postgres;
--
--GRANT INSERT, SELECT ON TABLE vs_resopt_noeuds TO adn_ing;
--GRANT ALL ON TABLE vs_resopt_noeuds TO postgres;
--
--GRANT INSERT, SELECT ON TABLE vs_suf_majic TO adn_ing;
--GRANT ALL ON TABLE vs_suf_majic TO postgres;
--
--GRANT INSERT, SELECT ON TABLE vs_resopt_lienstransport TO adn_ing;
--GRANT ALL ON TABLE vs_resopt_lienstransport TO postgres;
--
--GRANT INSERT, SELECT ON TABLE vs_resopt_lienstransport TO adn_ing;
--GRANT ALL ON TABLE vs_resopt_lienstransport TO postgres;
--
--GRANT INSERT, SELECT ON TABLE vs_resopt_liens TO adn_ing;
--GRANT ALL ON TABLE vs_resopt_liens TO postgres;
--
--GRANT INSERT, SELECT ON TABLE troncon_voie_ferree TO adn_ing;
--GRANT ALL ON TABLE troncon_voie_ferree TO postgres;
--
--GRANT INSERT, SELECT ON TABLE troncon_route TO adn_ing;
--GRANT ALL ON TABLE troncon_route TO postgres;
--
--GRANT INSERT, SELECT ON TABLE vs_parcelles_znro TO adn_ing;
--GRANT ALL ON TABLE vs_parcelles_znro TO postgres;
--
--GRANT INSERT, SELECT ON TABLE t_refboite TO adn_ing;
--GRANT ALL ON TABLE t_refboite TO postgres;
--
--GRANT INSERT, SELECT ON TABLE t_refcable TO adn_ing;
--GRANT ALL ON TABLE t_refcable TO postgres;

GRANT SELECT, INSERT, Update ON ALL TABLES IN SCHEMA schema_name TO adn_ing;
ALTER DEFAULT PRIVILEGES IN SCHEMA schema_name GRANT SELECT, INSERT, UPDATE  ON TABLES TO adn_ing;


--GRANT ALL ON TABLE check_attribut_cles_etrangeres TO adn_ing;
--GRANT ALL ON TABLE check_attribut_duplique TO adn_ing;
--GRANT ALL ON TABLE check_attribut_not_null TO adn_ing;
--GRANT ALL ON TABLE check_attribut_moins TO adn_ing;
--GRANT ALL ON TABLE check_attribut_plus TO adn_ing;
--GRANT ALL ON TABLE check_table_manquante TO adn_ing;
--GRANT ALL ON TABLE check_erreur_statut_mcd TO adn_ing;

