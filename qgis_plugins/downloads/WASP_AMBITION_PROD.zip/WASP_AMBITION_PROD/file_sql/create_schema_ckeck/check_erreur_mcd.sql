SET search_path TO schema_etude_input, schema_mcd_mod, public;
--- Partie Creation des Tables references (table l)
DROP FUNCTION If EXISTS function_check_tables_references(text,text);
CREATE OR REPLACE FUNCTION function_check_tables_references(schem_input text,schem_mode_mcd text) RETURNS void AS
$$
DECLARE
var_req_execute record;
BEGIN
	FOR var_req_execute in 
		select 'create table if not exists ' || schem_input || '.' || table_name ||' as select * from ' || TABLE_SCHEMA || '.' ||table_name as create_table
		from INFORMATION_SCHEMA.TABLES 
		where TABLE_SCHEMA = ''||schem_mode_mcd||'' and table_name like 'l_%'
	LOOP
	--RAISE NOTICE '%', var_req_execute.create_table;
	EXECUTE var_req_execute.create_table;
	END LOOP;
END;
$$ LANGUAGE plpgsql;
--select * from function_check_tables_references('schema_etude_input','schema_mcd_mod'); 

-- Parti Mise a jour des valeurs NULL apres import
DROP FUNCTION If EXISTS function_update_values_Null(text,text);
CREATE OR REPLACE FUNCTION function_update_values_Null(schem_input text) RETURNS void AS
$$
DECLARE
var_req_execute record;
BEGIN
	FOR var_req_execute in 
		select 
		    'UPDATE '||t.table_schema||'."'||t.table_name||'" set '||t.column_name||' = NULL  WHERE '||t.column_name||' =''NULL'';' as requete,
		    t.column_name, 
		    t.table_name table_name
		from information_schema.columns as t
		WHERE t.table_schema = ''||schem_input||'' and t.column_name != 'geom'
	LOOP
		-- RAISE NOTICE '%', var_req_execute.column_name;
		IF var_req_execute.requete is not null then
			EXECUTE var_req_execute.requete;
		END IF;
	END LOOP;
END;
$$ LANGUAGE plpgsql;
     
--- Partie Creation des tables manquantes par rapport au Modele MCD
DROP FUNCTION If EXISTS function_check_tables_manquantes(text,text);
CREATE OR REPLACE FUNCTION function_check_tables_manquantes(schem_input text,schem_mode_mcd text) RETURNS void AS
$$
DECLARE
var_req_execute record;
BEGIN
	--- Suppreesion de la table check_table_manquante
	EXECUTE 'DROP TABLE IF EXISTS check_table_manquante';
	EXECUTE 'CREATE TABLE IF NOT EXISTS check_table_manquante(  def text,  tablename text)';
	FOR var_req_execute in 
		select 
		    create_table::text,
		    note::text,
		     table_name::text
		from (
		select 
		    'create table IF NOT EXISTS '||''||schem_input||''||'."'||s.table_name||'" as (select * from '||s.table_schema||'."'||s.table_name||'") with no data;' as create_table,
		    'Table en Moins Par rapport au MCD' as note, 
		    s.table_name as table_name
		from information_schema.columns s
		    WHERE 
			s.table_schema = ''||schem_mode_mcd||'' and s.table_name like 't_%'
		except 
		select 
		    'create table IF NOT EXISTS '||t.table_schema||'."'||t.table_name||'" as (select * from '||''||schem_mode_mcd||''||'."'||t.table_name||'") with no data;',
		    'Table en Moins Par rapport au MCD' as note, 
		    t.table_name as table_name
		from information_schema.columns as t
		    WHERE 
			t.table_schema = ''||schem_input||'' and t.table_name like 't_%' 
		) t order by t.table_name
	LOOP
	--RAISE NOTICE '%', var_req_execute.create_table;
	EXECUTE 'INSERT INTO check_table_manquante(def, tablename) VALUES ('||
		quote_literal(var_req_execute.note)||','||
		quote_literal(var_req_execute.table_name)||')';
	EXECUTE var_req_execute.create_table;
	END LOOP;
END;
$$ LANGUAGE plpgsql;

--select * from function_check_tables_manquantes('schema_etude_input','schema_mcd_mod')

-- Parti Creation des champs en plus par rapport au Modele MCD
DROP FUNCTION If EXISTS function_check_champs_plus(text,text);
CREATE OR REPLACE FUNCTION function_check_champs_plus(schem_input text,schem_mode_mcd text) RETURNS void AS
$$
DECLARE
var_req_execute record;
BEGIN
	--- Suppreesion de la table check_attribut_plus
	EXECUTE 'DROP TABLE IF EXISTS check_attribut_plus';
	EXECUTE 'CREATE TABLE IF NOT EXISTS check_attribut_plus(  attribut text,  def text,  tablename text)';
	FOR var_req_execute in 
		select 
		    'ALTER TABLE '||schem_input||'."'||table_name||'" DROP COLUMN '||column_name||';' as requete,
		    column_name, note, table_name
		from (
		select 
		    t.column_name, 
		    'Champs en Plus Par rapport au Format GraceTHD' as note, 
		    t.table_name table_name
		from information_schema.columns as t
		    WHERE 
			t.table_schema =  ''||schem_input||'' and t.table_name like 't_%'
		except 
		select 
		    s.column_name, 
		    'Champs en Plus Par rapport au Format GraceTHD' as note, 
		    s.table_name
		from information_schema.columns s
		    WHERE 
			s.table_schema = ''||schem_mode_mcd||'' and s.table_name like 't_%'
		) as cp
	LOOP
		-- RAISE NOTICE '%', var_req_execute.column_name;
		EXECUTE 'INSERT INTO check_attribut_plus(attribut,  def, tablename) VALUES ('||
	 		quote_literal(var_req_execute.column_name)||','||
	 		quote_literal(var_req_execute.note)||','||
	 		quote_literal(var_req_execute.table_name)||')';
	 	EXECUTE var_req_execute.requete;
	END LOOP;
END;
$$ LANGUAGE plpgsql;
--select * from function_check_champs_plus('schema_etude_input','schema_mcd_mod')

--ALTER TABLE t_cable ADD COLUMN new_column_name text;

-- Parti Creation des champs en plus par rapport au Modele MCD

DROP FUNCTION If EXISTS function_check_champs_moins(text,text);
CREATE OR REPLACE FUNCTION function_check_champs_moins(schem_input text,schem_mode_mcd text) RETURNS void AS
$$
DECLARE
var_req_execute record;
BEGIN
	--- Suppreesion de la table check_attribut_moins
	EXECUTE 'DROP TABLE IF EXISTS check_attribut_moins';
	EXECUTE 'CREATE TABLE IF NOT EXISTS check_attribut_moins(  attribut text,  def text,  tablename text)';
	FOR var_req_execute in
		select 
		    'ALTER TABLE '||schem_input||'."'||table_name||'" ADD COLUMN IF NOT EXISTS '||column_name||' text;' as requete,
		    column_name, note, table_name
		from (
		select 
		    s.column_name, 
		    'Champs en Moins Par rapport au Format GraceTHD' as note, 
		    s.table_name
		from information_schema.columns s
		    WHERE 
			s.table_schema = ''||schem_mode_mcd||'' and 
			s.table_name like 't_%'
		except 
		select 
		    t.column_name, 
		    'Champs en Moins Par rapport au Format GraceTHD' as note, 
		    t.table_name
		from information_schema.columns as t
		    WHERE 
			t.table_schema = ''||schem_input||'' and 
			t.table_name like 't_%' 
		) t where column_name not like '%gid%' order by t.table_name
	LOOP
		-- RAISE NOTICE '%', var_req_execute.column_name;
		EXECUTE 'INSERT INTO check_attribut_moins(attribut,  def, tablename) VALUES ('||
	 		quote_literal(var_req_execute.column_name)||','||
	 		quote_literal(var_req_execute.note)||','||
	 		quote_literal(var_req_execute.table_name)||')';
	 	EXECUTE var_req_execute.requete;
	END LOOP;
END;
$$ LANGUAGE plpgsql;
--select * from function_check_champs_moins('schema_etude_input','schema_mcd_mod')
--ALTER TABLE schema_mcd_mod.t_cable ADD COLUMN new_column_name text;

-- Parti Creation des attributs avec la contraintes not null rapport au Modele MCD
DROP FUNCTION If EXISTS function_check_attribut_not_null(text,text);
CREATE OR REPLACE FUNCTION function_check_attribut_not_null(schem_input text,schem_mode_mcd text) RETURNS void AS
$$
DECLARE
var_req_execute record;
BEGIN
	--- Suppreesion de la table check_attribut_moins
	EXECUTE 'DROP TABLE IF EXISTS check_attribut_not_null';
	EXECUTE 'CREATE TABLE check_attribut_not_null(  def text,  drop_contraint text,  table_name text)';
	FOR var_req_execute in 
		select 
		'INSERT INTO check_attribut_not_null ' || 'select ''Attribut Qui ne doit pas etre Null Pour '||
			mcd_gra.column_name::text||'_'||mcd_gra.table_name||''' as def,'||quote_literal(column_name)||'::text as attribut,'||
			quote_literal(t.table_name)||'::text from '||t.table_schema||'.'||mcd_gra.table_name||' where '||column_name||' is null;' as requete
		FROM INFORMATION_SCHEMA.COLUMNS mcd_gra
		left join (select distinct table_name, table_schema from INFORMATION_SCHEMA.COLUMNS where table_schema =''||schem_input||'' AND 
			table_name like 't_%') as t on mcd_gra.table_name =t.table_name
		WHERE mcd_gra.table_schema =''||schem_mode_mcd||'' AND mcd_gra.table_name like 't_%' and is_nullable = 'NO'
	LOOP
		-- RAISE NOTICE '%', var_req_execute.column_name;
	 	EXECUTE var_req_execute.requete;
	END LOOP;
END;
$$ LANGUAGE plpgsql;
--select * from function_check_attribut_not_null('schema_etude_input','schema_mcd_mod')

-- Parti Creation des attributs en double rapport au Modele MCD
DROP FUNCTION If EXISTS function_check_attribut_double(text,text);
CREATE OR REPLACE FUNCTION function_check_attribut_double(schem_input text,schem_mode_mcd text) RETURNS void AS
$$
DECLARE
var_req_execute record;
BEGIN
	EXECUTE 'DROP TABLE IF EXISTS  check_attribut_duplique';
	EXECUTE 'CREATE TABLE check_attribut_duplique(  table_name text,  attribut text,  nombre text)';
	FOR var_req_execute in 
		with test as (select tc.table_schema,tc.constraint_type,ccu.column_name,ccu.table_name
		from 
		information_schema.table_constraints tc
		JOIN information_schema.constraint_column_usage AS ccu
		  ON ccu.constraint_name = tc.constraint_name
		where 
		tc.constraint_type = 'PRIMARY KEY'
		and tc.table_schema = ''||schem_mode_mcd||''
		and tc.table_name like 't_%'
		order by tc.table_schema,
		     tc.table_name) 
		select distinct 'INSERT INTO check_attribut_duplique '||'select '||quote_literal(t.table_name)||','||t.column_name||
		', count(1) from '||inputt.table_schema||'.'||inputt.table_name||' group by '||t.column_name||' having count(1) > 1;' requete
		from test t
		left join (select distinct table_name, table_schema from INFORMATION_SCHEMA.COLUMNS 
		where table_schema =''||schem_input||'' AND table_name like 't_%'and table_name not in ('t_cab_cond','t_cond_chem')
		) as inputt on t.table_name =inputt.table_name
	LOOP
		-- RAISE NOTICE '%', var_req_execute.column_name;
		IF var_req_execute.requete is not null then
			EXECUTE var_req_execute.requete;
		END IF;
	END LOOP;
END;
$$ LANGUAGE plpgsql;
--select * from function_check_attribut_double('schema_etude_input','schema_mcd_mod')

-- Parti Creation des erreurs de cles etrangere rapport au Modele MCD
DROP FUNCTION If EXISTS function_check_attribut_cles_entrangeres(text,text);
CREATE OR REPLACE FUNCTION function_check_attribut_cles_entrangeres(schem_input text,schem_mode_mcd text) RETURNS void AS
$$
DECLARE
var_req_execute record;
BEGIN
	EXECUTE 'DROP TABLE IF EXISTS  check_attribut_cles_etrangeres';
	EXECUTE 'CREATE TABLE check_attribut_cles_etrangeres(  def text,  attribut text)';
	FOR var_req_execute in 
		SELECT distinct 
		    'INSERT INTO '||schem_input||'.check_attribut_cles_etrangeres ' || 
		    'select ''Attribut manquant dans '||ccu.column_name||'_'||ccu.table_name||
		    ' Mais present dans '||kcu.column_name||'_'||tc.table_name||''' as attribut_manquant,'||kcu.column_name||'::text as attribut'||
		    ' from '||schem_input||'.'||tc.table_name||' where '||kcu.column_name||' not in (select '||ccu.column_name||' from '||
		    schem_input||'.'||ccu.table_name||' union select '''') '||'and '||kcu.column_name|| ' is not null;' as erreur_tt_tl
		FROM information_schema.table_constraints tc
		JOIN information_schema.key_column_usage kcu ON tc.constraint_name = kcu.constraint_name
		JOIN information_schema.constraint_column_usage ccu ON ccu.constraint_name = tc.constraint_name
		WHERE constraint_type = 'FOREIGN KEY'
		AND tc.table_schema = ''||schem_mode_mcd||''
	LOOP
		-- RAISE NOTICE '%', var_req_execute.column_name;
		IF var_req_execute.erreur_tt_tl is not null then
			EXECUTE var_req_execute.erreur_tt_tl;
		END IF;
	END LOOP;
END;
$$ LANGUAGE plpgsql;
--select * from function_check_attribut_cles_entrangeres('schema_etude_input','schema_mcd_mod')

-- Parti Creation des erreurs de cles etrangere rapport au Modele MCD
DROP FUNCTION If EXISTS function_check_duplicate_index(text,text);
CREATE OR REPLACE FUNCTION function_check_duplicate_index(schem_input text,schem_mode_mcd text) RETURNS void AS
$$
DECLARE
var_req_execute record;
BEGIN
	FOR var_req_execute in 
		select
		't_love' as tablename,lv_nd_code||'_'||lv_cb_code as attribut,count(*) as nombre
		from t_love
		group by lv_nd_code, lv_cb_code
		HAVING count(*)>1
	LOOP
		-- RAISE NOTICE '%', var_req_execute.column_name;
		IF var_req_execute.erreur_tt_tl is not null then
			EXECUTE 'INSERT INTO check_attribut_duplique(table_name, attribut, nombre) VALUES ('||
	 		quote_literal(var_req_execute.tablename)||','||
	 		quote_literal(var_req_execute.attribut)||','||
	 		quote_literal(var_req_execute.nombre)||')';
		END IF;
	END LOOP;
END;
$$ LANGUAGE plpgsql;

--select * from function_check_duplicate_index('schema_etude_input','schema_mcd_mod')
select * from function_check_tables_references('schema_etude_input','schema_mcd_mod');
select * from function_update_values_Null('schema_etude_input');
select * from function_check_tables_manquantes('schema_etude_input','schema_mcd_mod');
select * from function_check_champs_plus('schema_etude_input','schema_mcd_mod');
select * from function_check_champs_moins('schema_etude_input','schema_mcd_mod');
select * from function_check_attribut_not_null('schema_etude_input','schema_mcd_mod');
select * from function_check_attribut_double('schema_etude_input','schema_mcd_mod');
select * from function_check_attribut_cles_entrangeres('schema_etude_input','schema_mcd_mod');
select * from function_check_duplicate_index('schema_etude_input','schema_mcd_mod');