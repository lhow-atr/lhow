SET search_path TO schemacheck, public;


BEGIN;
/*Insertion données l_ct_exe*/
INSERT INTO l_ct_exe VALUES ('O','Obligatoire','Obligatoire quelles que soient les circonstances');
INSERT INTO l_ct_exe VALUES ('C', 'Conditionnel', 'Obligatoire si la condition est remplie');
INSERT INTO l_ct_exe VALUES ('N','Non','Donnée inutile dans ce contexte ou à ce stade du projet');
INSERT INTO l_ct_exe VALUES ('F','Facultatif','Non obligatoire sauf contexte particulier a determiner et contractualiser');
INSERT INTO l_ct_exe VALUES ('NO','Obligatoire non execute','Non execution de Obligatoire quelles que soient les circonstances');
INSERT INTO l_ct_exe VALUES ('NC', 'Conditionnel', 'Non execution de Obligatoire si la condition est remplie');
INSERT INTO l_ct_exe VALUES ('EN','Execution Non','Donnée inutile dans ce contexte ou à ce stade du projet');
INSERT INTO l_ct_exe VALUES ('EF','Execution Facultatif','Execution point de controle Non obligatoire sauf contexte particulier a determiner et contractualiser');

INSERT INTO l_ct_fill VALUES ('O', 'Obligatoire','');
INSERT INTO l_ct_fill VALUES ('C', 'Condictionnel','');
INSERT INTO l_ct_fill VALUES ('', 'Facultatif',''); 
INSERT INTO l_ct_fill VALUES (' ', 'Facultatif',''); 
INSERT INTO l_ct_fill VALUES ('F', 'Facultatif',''); 
INSERT INTO l_ct_fill VALUES ('N', 'Non','');
INSERT INTO l_ct_type VALUES ('F','Anomalies de format de fichiers.','');
INSERT INTO l_ct_type VALUES ('T','Anomalies de structure de tables.','');
INSERT INTO l_ct_type VALUES ('L','Anomalies relationnelles.','');
INSERT INTO l_ct_type VALUES ('R','Anomalies d exhaustivite (grille de remplissage).','');
INSERT INTO l_ct_type VALUES ('G','Anomalies de saisie geometrique et topologique.','');
INSERT INTO l_ct_type VALUES ('S','Anomalies de saisie alphanumerique.','');
INSERT INTO l_ct_type VALUES ('M','Anomalies metier.','');
INSERT INTO l_ct_type VALUES ('E','Anomalies d evolution (avec la phase precedente).','');
INSERT INTO l_ct_type VALUES ('P','Anomalies specifiques a un contexte.','');
INSERT INTO l_ct_mode VALUES ('A','Automatique','');
INSERT INTO l_ct_mode VALUES ('S','Semi-automatique','');
INSERT INTO l_ct_mode VALUES ('M','Manuel','');
INSERT INTO l_ct_mode VALUES ('T','Terrain','');
INSERT INTO l_ct_sensibilite VALUES ('1','Bloquant','');
INSERT INTO l_ct_sensibilite VALUES ('2','Non valide','');
INSERT INTO l_ct_sensibilite VALUES ('3','A corriger','');
INSERT INTO l_ct_sensibilite VALUES ('4','Informatif','');
INSERT INTO l_ct_origine VALUES ('H','Reglementaire FTTH','');
INSERT INTO l_ct_origine VALUES ('C','CCTP','');
INSERT INTO l_ct_origine VALUES ('B','BLO','');
INSERT INTO l_ct_origine VALUES ('P','Contractuelle avec le proprietaire','');
INSERT INTO l_ct_origine VALUES ('G','GraceTHD-MCD','');
INSERT INTO l_ct_origine VALUES ('O','GraceTHD-MOD','');
INSERT INTO l_ct_statut VALUES ('0','HS','Hors service, voire hors sujet.'); 
INSERT INTO l_ct_statut VALUES ('1','Planifié','');
INSERT INTO l_ct_statut VALUES ('2','Conception','');
INSERT INTO l_ct_statut VALUES ('3','Alpha','');
INSERT INTO l_ct_statut VALUES ('4','Beta','');
INSERT INTO l_ct_statut VALUES ('5','RC','');
INSERT INTO l_ct_statut VALUES ('6','Release','');
COMMIT


