SET search_path TO var_lfd, public;
--GRANT ALL ON SCHEMA lfd TO adn_ing;
GRANT SELECT, INSERT, Update ON ALL TABLES IN SCHEMA var_lfd TO lfd_ing;
ALTER DEFAULT PRIVILEGES IN SCHEMA var_lfd GRANT SELECT, INSERT, UPDATE  ON TABLES TO lfd_ing;

--Module Pour les croises dynamiques
-- See the README.md file distributed with this project for documentation.
create or replace function colpivot(
    out_table varchar, in_query varchar,
    key_cols varchar[], class_cols varchar[],
    value_e varchar, col_order varchar
) returns void as $$
    declare
        in_table varchar;
        col varchar;
        ali varchar;
        on_e varchar;
        i integer;
        rec record;
        query varchar;
        -- This is actually an array of arrays but postgres does not support an array of arrays type so we flatten it.
        -- We could theoretically use the matrix feature but it's extremly cancerogenous and we would have to involve
        -- custom aggrigates. For most intents and purposes postgres does not have a multi-dimensional array type.
        clsc_cols text[] := array[]::text[];
        n_clsc_cols integer;
        n_class_cols integer;
    begin
        in_table := quote_ident('__' || out_table || '_in');
        execute ('create temp table ' || in_table || ' on commit drop as ' || in_query);
        -- get ordered unique columns (column combinations)
        query := 'select array[';
        i := 0;
        foreach col in array class_cols loop
            if i > 0 then
                query := query || ', ';
            end if;
            query := query || 'quote_literal(' || quote_ident(col) || ')';
            i := i + 1;

        end loop;
        query := query || '] x from ' || in_table;
        for j in 1..2 loop
            if j = 1 then
                query := query || ' group by ';
            else
                query := query || ' order by ';
                if col_order is not null then
                    query := query || col_order || ' ';
                    exit;
                end if;
            end if;
            i := 0;
            foreach col in array class_cols loop
                if i > 0 then
                    query := query || ', ';
                end if;
                query := query || quote_ident(col);
                i := i + 1;
            end loop;
        end loop;
        --raise notice '%', 'bababa';
        for rec in
		execute query
        loop
            clsc_cols := array_cat(clsc_cols, rec.x);
        end loop;
        n_class_cols := array_length(class_cols, 1);
        n_clsc_cols := array_length(clsc_cols, 1) / n_class_cols;
        -- build target query
        query := 'select ';
        i := 0;
        foreach col in array key_cols loop
            if i > 0 then
                query := query || ', ';
            end if;
            query := query || '_key.' || quote_ident(col) || ' ';
            i := i + 1;

        end loop;
        for j in 1..n_clsc_cols loop
            query := query || ', ';
            col := '';
            for k in 1..n_class_cols loop
                if k > 1 then
                    col := col || ', ';
                end if;
                col := col || clsc_cols[(j - 1) * n_class_cols + k];

            end loop;
            ali := '_clsc_' || j::text;
            query := query || '(' || replace(value_e, '#', ali) || ')' || ' as ' || quote_ident(col) || ' ';
            --raise notice '%', replace(value_e, '#', ali);
        end loop;

        query := query || ' from (select distinct ';
        i := 0;
        foreach col in array key_cols loop
            if i > 0 then
                query := query || ', ';
            end if;
            query := query || quote_ident(col) || ' ';
            i := i + 1;
        end loop;
        query := query || ' from ' || in_table || ') _key ';
        for j in 1..n_clsc_cols loop
            ali := '_clsc_' || j::text;
            on_e := '';
            i := 0;
            foreach col in array key_cols loop
                if i > 0 then
                    on_e := on_e || ' and ';
                end if;
                on_e := on_e || ali || '.' || quote_ident(col) || ' = _key.' || quote_ident(col) || ' ';
                i := i + 1;
            end loop;
            for k in 1..n_class_cols loop
                on_e := on_e || ' and ';
                on_e := on_e || ali || '.' || quote_ident(class_cols[k]) || ' = ' || clsc_cols[(j - 1) * n_class_cols + k];
            end loop;
            query := query || 'left join ' || in_table || ' as ' || ali || ' on ' || on_e || ' ';
        end loop;
        --raise notice '%', query;
        -- raise notice '%', out_table;
        execute ('create temp table ' || quote_ident(out_table) || ' on commit drop as ' || query);
        -- cleanup temporary in_table before we return
        execute ('drop table ' || in_table)
        return;
    end;
$$ language plpgsql volatile;

---Construction des tables avec geometry
--Requete IPON
DROP TABLE IF EXISTS requete_ipon;
CREATE TABLE requete_ipon as
select
	ip.*,
	ST_Transform(ST_SetSRID(ST_MakePoint(ao.coord_x::double precision,ao.coord_y::double precision),27572),2154) as geom_ipon,
	o.id_processus_particulier as id_processus_particulier
from ipon ip
join "Adresses_Optimum" as ao on ao.num_dossier_site = ip.nom_site_pf_pb
join "Couverture_FTTH_Phase2" as ct on
	st_intersects(
	ct.geom,
	ST_Transform(ST_SetSRID(ST_MakePoint(ao.coord_x::double precision,ao.coord_y::double precision),27572),2154)
	)
left join "Optimum" as o on o.num_dossier_site = ao.num_dossier_site;

--Requete Optimum
DROP TABLE IF EXISTS requete_optimum;
CREATE TABLE requete_optimum as
select
	o.*
from "Optimum" as o
	join "Adresses_Optimum" as ao on ao.num_dossier_site = o.num_dossier_site;
--Requete GEOFIBRE
--ftth_site_immeuble.shp t_adresse_gfi
DROP TABLE IF EXISTS t_adresse_gfi;
CREATE TABLE t_adresse_gfi as
select im.* from ftth_site_immeuble im
join ftth_zone_eligibilite as zn on st_contains(zn.geom,im.geom);

--ftth_pf.shp t_ebp_gfi
DROP TABLE IF EXISTS t_ebp_gfi;
CREATE TABLE t_ebp_gfi as
select pf.* from ftth_pf pf
join ftth_zone_eligibilite as zn on st_contains(zn.geom,pf.geom);

-- Creation des index pour adresse gfi et "63_RBAL_Phase2"
DROP INDEX IF EXISTS adresse_gfi;
CREATE INDEX adresse_gfi ON "t_adresse_gfi" USING GIST (geom);
DROP INDEX IF EXISTS RBAL_Phase2;
CREATE INDEX RBAL_Phase2 ON "63_RBAL_Phase2" USING GIST (geom);

---TR01.1
/*
select colpivot('_test_pivoted', 'select
	''test''::text as uniq,localite_site,
	sum(nombre_de_logements::int) as sum
from requete_optimum
group by localite_site;',
    array['uniq'], array['localite_site'], '#.sum', null);
select * from _test_pivoted;*/

create or replace function "TR01.1"(
) returns void as $$
    declare
        requete text;
        col_uniq text;
        col_transpose text;
        col_value_transpose text;
        var_req_execute record;
    begin

	EXECUTE 'DROP TABLE IF EXISTS "inter_TR01.1"';
	EXECUTE 'CREATE TABLE "inter_TR01.1" as
	select
		''test''::text as uniq,localite_site,
		sum(nombre_de_logements::int) as sum
	from requete_optimum
	group by localite_site';

	requete := quote_literal(e'select * from "inter_TR01.1"');
	col_uniq := quote_literal(e'uniq');
	col_transpose := quote_literal(e'localite_site');
	col_value_transpose := quote_literal(e'#.sum');

	/*EXECUTE 'DROP TABLE IF EXISTS "TR01.1"';
	EXECUTE 'select colpivot(''_test_pivoted'', '||
		requete||',array['||col_uniq||'], array['||col_transpose||'], '||col_value_transpose||', null)';
	EXECUTE 'CREATE TABLE "TR01.1" as ' || 'select * from _test_pivoted';*/

	FOR var_req_execute in select count(*)::int as len from "inter_TR01.1" limit 1
		LOOP
			if var_req_execute.len > 0 then

				EXECUTE 'DROP TABLE IF EXISTS "TR01.1"';
				EXECUTE 'select colpivot(''_test_pivoted'', '||
					requete||',array['||col_uniq||'], array['||col_transpose||'], '||col_value_transpose||', null)';
				EXECUTE 'CREATE TABLE "TR01.1" as ' || 'select * from _test_pivoted';
			else
				EXECUTE 'DROP TABLE IF EXISTS "TR01.1"';
				EXECUTE 'CREATE TABLE "TR01.1" (vide text)';
			end if;
		END LOOP;

    end;
$$ language plpgsql volatile;

select * from "TR01.1"();


---TR02.1
create or replace function "TR02.1"(
) returns void as $$
    declare
        requete text;
        col_uniq text;
        col_transpose text;
        col_value_transpose text;
        var_req_execute record;
    begin
	EXECUTE 'DROP TABLE IF EXISTS _test_pivoted';
	EXECUTE 'DROP TABLE IF EXISTS "inter_TR02.1"';
	EXECUTE 'CREATE TABLE "inter_TR02.1" as
	select
		''test''::text as uniq,
		localite_site,
		sum(nombre_de_logements::int) as sum,
		array_agg(date_pose_pb)
	from requete_optimum
	where date_pose_pb != NULL or date_pose_pb != ''''
	group by localite_site';

	requete := quote_literal(e'select * from "inter_TR02.1"');
	col_uniq := quote_literal(e'uniq');
	col_transpose := quote_literal(e'localite_site');
	col_value_transpose := quote_literal(e'#.sum');
	FOR var_req_execute in select count(*)::int as len from "inter_TR02.1" limit 1
		LOOP
			if var_req_execute.len > 0 then
				EXECUTE 'DROP TABLE IF EXISTS "TR02.1"';
				EXECUTE 'select colpivot(''_test_pivoted'', '||
					requete||',array['||col_uniq||'], array['||col_transpose||'], '||col_value_transpose||', null)';
				EXECUTE 'CREATE TABLE "TR02.1" as ' || 'select * from _test_pivoted';
			else
					EXECUTE 'DROP TABLE IF EXISTS "TR02.1"';
					EXECUTE 'CREATE TABLE "TR02.1" (vide text)';

			end if;
		END LOOP;
    end;
$$ language plpgsql volatile;

select * from "TR02.1"();

---TR03.1
create or replace function "TR03.1"(
) returns void as $$
    declare
        requete text;
        col_uniq text;
        col_transpose text;
        col_value_transpose text;
        var_req_execute record;
    begin
	EXECUTE 'DROP TABLE IF EXISTS _test_pivoted';
	EXECUTE 'DROP TABLE IF EXISTS "inter_TR03.1"';
	EXECUTE 'CREATE TABLE "inter_TR03.1" as
	select
		''tr01''::text as uniq,
		ro.localite_site,
		count(*) as count,
		max(tr2.sum) as tr01,
		/*max(tr2.sum) as tr02,*/
		round((100/sum(tr2.sum))*sum(tr.sum),0) as percent
	from requete_optimum as ro
	join "inter_TR01.1" as tr2 on tr2.localite_site = ro.localite_site
	join "inter_TR02.1" as tr on tr.localite_site = ro.localite_site
	group by ro.localite_site
	union all
	select
		''tr02''::text as uniq,
		ro.localite_site,
		count(*) as count,
		max(tr.sum) as tr02,
		/*max(tr2.sum) as tr01,*/
		round((100/sum(tr2.sum))*sum(tr.sum),0) as percent
	from requete_optimum as ro
	join "inter_TR02.1" as tr on tr.localite_site = ro.localite_site
	join "inter_TR01.1" as tr2 on tr2.localite_site = ro.localite_site
	group by ro.localite_site';

	requete := quote_literal(e'select * from "inter_TR03.1"');
	col_uniq := quote_literal(e'uniq');
	col_transpose := quote_literal(e'localite_site')||','||quote_literal(e'percent');
	col_value_transpose := quote_literal(e'#.tr01');
	FOR var_req_execute in select count(*)::int as len from "inter_TR03.1" limit 1
		LOOP
			if var_req_execute.len > 0 then
				EXECUTE 'DROP TABLE IF EXISTS "TR03.1"';
				EXECUTE 'select colpivot(''_test_pivoted'', '||
					requete||',array['||col_uniq||'], array['||col_transpose||'], '||col_value_transpose||', null)';
				EXECUTE 'CREATE TABLE "TR03.1" as ' || 'select * from _test_pivoted';
			else
					EXECUTE 'DROP TABLE IF EXISTS "TR03.1"';
					EXECUTE 'CREATE TABLE "TR03.1" (vide text)';
			end if;
		END LOOP;
    end;
$$ language plpgsql volatile;

select * from "TR03.1"();

--TR04.1
create or replace function "TR04.1"(
) returns void as $$
    declare
        requete text;
        col_uniq text;
        col_transpose text;
        col_value_transpose text;
        var_req_execute record;
    begin
	EXECUTE 'DROP TABLE IF EXISTS _test_pivoted';
	EXECUTE 'DROP TABLE IF EXISTS "inter_TR04.1"';
	EXECUTE 'CREATE TABLE "inter_TR04.1" as
	select
		''NON_COLLECTIF''::text as uniq,
		ro.localite_site,
		sum(nombre_de_logements::int) as sum
	from requete_optimum as ro
	where (date_pose_pb != NULL or date_pose_pb != '''') and nombre_de_logements::int < 4
	group by ro.localite_site';

	requete := quote_literal(e'select * from "inter_TR04.1"');
	col_uniq := quote_literal(e'uniq');
	col_transpose := quote_literal(e'localite_site');
	col_value_transpose := quote_literal(e'#.sum');
	FOR var_req_execute in select count(*)::int as len from "inter_TR04.1" limit 1
		LOOP
			if var_req_execute.len > 0 then
				EXECUTE 'DROP TABLE IF EXISTS "TR04.1"';
				EXECUTE 'select colpivot(''_test_pivoted'', '||
					requete||',array['||col_uniq||'], array['||col_transpose||'], '||col_value_transpose||', null)';
				EXECUTE 'CREATE TABLE "TR04.1" as ' || 'select * from _test_pivoted';
			else
					EXECUTE 'DROP TABLE IF EXISTS "TR04.1"';
					EXECUTE 'CREATE TABLE "TR04.1" (vide text)';
			end if;
		END LOOP;
    end;
$$ language plpgsql volatile;

select * from "TR04.1"();

--TR05.1
create or replace function "TR05.1"(
) returns void as $$
    declare
        requete text;
        col_uniq text;
        col_transpose text;
        col_value_transpose text;
        var_req_execute record;
    begin
	EXECUTE 'DROP TABLE IF EXISTS _test_pivoted';
	EXECUTE 'DROP TABLE IF EXISTS "inter_TR05.1"';
	EXECUTE 'CREATE TABLE "inter_TR05.1" as
	select
		''COLLECTIF''::text as uniq,
		ro.localite_site,
		sum(nombre_de_logements::int) as sum
	from requete_optimum as ro
	where (date_pose_pb != NULL or date_pose_pb != '''') and
		nombre_de_logements::int > 3
	group by ro.localite_site';

	requete := quote_literal(e'select * from "inter_TR05.1"');
	col_uniq := quote_literal(e'uniq');
	col_transpose := quote_literal(e'localite_site');
	col_value_transpose := quote_literal(e'#.sum');
	FOR var_req_execute in select count(*)::int as len from "inter_TR05.1" limit 1
		LOOP
			if var_req_execute.len > 0 then
				EXECUTE 'DROP TABLE IF EXISTS "TR05.1"';
				EXECUTE 'select colpivot(''_test_pivoted'', '||
					requete||',array['||col_uniq||'], array['||col_transpose||'], '||col_value_transpose||', null)';
				EXECUTE 'CREATE TABLE "TR05.1" as ' || 'select * from _test_pivoted';
			else
					EXECUTE 'DROP TABLE IF EXISTS "TR05.1"';
					EXECUTE 'CREATE TABLE "TR05.1" (vide text)';
			end if;
		END LOOP;
    end;
$$ language plpgsql volatile;

select * from "TR05.1"();

--TR06.1
create or replace function "TR06.1"(
) returns void as $$
    declare
        requete text;
        col_uniq text;
        col_transpose text;
        col_value_transpose text;
        var_req_execute record;
    begin
	EXECUTE 'DROP TABLE IF EXISTS _test_pivoted';
	EXECUTE 'DROP TABLE IF EXISTS "inter_TR06.1"';
	EXECUTE 'CREATE TABLE "inter_TR06.1" as
		select
		''SIGNE''::text as uniq,
		ro.localite_site,
		sum(nombre_de_logements::int) as sum
	from requete_optimum as ro
	where (date_pose_pb != NULL or date_pose_pb != '''') and
		nombre_de_logements::int > 3 and libelle_site_etat_negociation_syndic like ''%REFUS%''
	group by ro.localite_site';

	requete := quote_literal(e'select * from "inter_TR06.1"');
	col_uniq := quote_literal(e'uniq');
	col_transpose := quote_literal(e'localite_site');
	col_value_transpose := quote_literal(e'#.sum');
	--LOOP
	FOR var_req_execute in select count(*)::int as len from "inter_TR06.1" limit 1
		LOOP
			if var_req_execute.len > 0 then

				EXECUTE 'DROP TABLE IF EXISTS "TR06.1"';
				EXECUTE 'select colpivot(''_test_pivoted'', '||
					requete||',array['||col_uniq||'], array['||col_transpose||'], '||col_value_transpose||', null)';
				EXECUTE 'CREATE TABLE "TR06.1" as ' || 'select * from _test_pivoted';
			else
				EXECUTE 'DROP TABLE IF EXISTS "TR06.1"';
				EXECUTE 'CREATE TABLE "TR06.1" (vide text)';
			end if;
		END LOOP;
	--end loop
    end;
$$ language plpgsql volatile;

select * from "TR06.1"();

--TR07.1
create or replace function "TR07.1"(
) returns void as $$
    declare
        requete text;
        col_uniq text;
        col_transpose text;
        col_value_transpose text;
        var_req_execute record;
    begin
	EXECUTE 'DROP TABLE IF EXISTS _test_pivoted';
	EXECUTE 'DROP TABLE IF EXISTS "inter_TR07.1"';
	EXECUTE 'CREATE TABLE "inter_TR07.1" as
		select
			''SOMME_PRISES''::text as uniq,
			ca.nom_commune as nom_commune,
			sum(total_indicatif_prises_raccordables::int) as sum
		from "Calendrier" as ca
		--nro_de_rattachement Option Request
		group by nom_commune';

	requete := quote_literal(e'select * from "inter_TR07.1"');
	col_uniq := quote_literal(e'uniq');
	col_transpose := quote_literal(e'nom_commune');
	col_value_transpose := quote_literal(e'#.sum');
	--LOOP
	FOR var_req_execute in select count(*)::int as len from "inter_TR07.1" limit 1
		LOOP
			if var_req_execute.len > 0 then

				EXECUTE 'DROP TABLE IF EXISTS "TR07.1"';
				EXECUTE 'select colpivot(''_test_pivoted'', '||
					requete||',array['||col_uniq||'], array['||col_transpose||'], '||col_value_transpose||', null)';
				EXECUTE 'CREATE TABLE "TR07.1" as ' || 'select * from _test_pivoted';
			else
				EXECUTE 'DROP TABLE IF EXISTS "TR07.1"';
				EXECUTE 'CREATE TABLE "TR07.1" (vide text)';
			end if;
		END LOOP;
	--end loop
    end;
$$ language plpgsql volatile;

select * from "TR07.1"();

--TR08.1
create or replace function "TR08.1"(
) returns void as $$
    declare
        requete text;
        col_uniq text;
        col_transpose text;
        col_value_transpose text;
        var_req_execute record;
    begin
	EXECUTE 'DROP TABLE IF EXISTS _test_pivoted';
	EXECUTE 'DROP TABLE IF EXISTS "inter_TR08.1"';
	EXECUTE 'CREATE TABLE "inter_TR08.1" as
		select
			''PB_POSE''::text as uniq,
			ro.localite_site as localite_site,
			sum(nombre_de_logements::int) as sum
		from requete_optimum as ro
		where (date_pose_pb != NULL or date_pose_pb != '''')
		group by ro.localite_site';

	requete := quote_literal(e'select * from "inter_TR08.1"');
	col_uniq := quote_literal(e'uniq');
	col_transpose := quote_literal(e'localite_site');
	col_value_transpose := quote_literal(e'#.sum');
	--LOOP
	FOR var_req_execute in select count(*)::int as len from "inter_TR08.1" limit 1
		LOOP
			if var_req_execute.len > 0 then

				EXECUTE 'DROP TABLE IF EXISTS "TR08.1"';
				EXECUTE 'select colpivot(''_test_pivoted'', '||
					requete||',array['||col_uniq||'], array['||col_transpose||'], '||col_value_transpose||', null)';
				EXECUTE 'CREATE TABLE "TR08.1" as ' || 'select * from _test_pivoted';
			else
				EXECUTE 'DROP TABLE IF EXISTS "TR08.1"';
				EXECUTE 'CREATE TABLE "TR08.1" (vide text)';
			end if;
		END LOOP;
	--end loop
    end;
$$ language plpgsql volatile;

select * from "TR08.1"();

--TR09.1
create or replace function "TR09.1"(
) returns void as $$
    declare
        requete text;
        col_uniq text;
        col_transpose text;
        col_value_transpose text;
        var_req_execute record;
    begin
	EXECUTE 'DROP TABLE IF EXISTS _test_pivoted';
	EXECUTE 'DROP TABLE IF EXISTS "inter_TR09.1"';
	EXECUTE 'CREATE TABLE "inter_TR09.1" as
	select
		''Somme_de_prises_raccordables_(TR07.1)''::text as uniq,
		ro.localite_site,
		sum(ro.nombre_de_logements::int) as sum,
		max(tr.sum) as tr07,
		((100::int)/sum(tr.sum))*sum(tr2.sum) as percent
	from requete_optimum as ro
	join "inter_TR07.1" as tr on tr.nom_commune = ro.localite_site
	join "inter_TR08.1" as tr2 on tr2.localite_site = ro.localite_site
	where (date_pose_pb != NULL or date_pose_pb != '''')
	group by ro.localite_site
	union all
	select
		''Somme_de_prises_PB_POSE_(TR08.1)''::text as uniq,
		ro.localite_site,
		sum(ro.nombre_de_logements::int) as sum,
		max(tr2.sum) as tr08,
		((100::int)/sum(tr.sum))*sum(tr2.sum) as percent
	from requete_optimum as ro
	join "inter_TR07.1" as tr on tr.nom_commune = ro.localite_site
	join "inter_TR08.1" as tr2 on tr2.localite_site = ro.localite_site
	where (date_pose_pb != NULL or date_pose_pb != '''')
	group by ro.localite_site';

	requete := quote_literal(e'select * from "inter_TR09.1"');
	col_uniq := quote_literal(e'uniq');
	col_transpose := quote_literal(e'localite_site')||','||quote_literal(e'percent');
	col_value_transpose := quote_literal(e'#.tr07');

	FOR var_req_execute in select count(*)::int as len from "inter_TR09.1" limit 1
		LOOP
			if var_req_execute.len > 0 then

				EXECUTE 'DROP TABLE IF EXISTS "TR09.1"';
				EXECUTE 'select colpivot(''_test_pivoted'', '||
					requete||',array['||col_uniq||'], array['||col_transpose||'], '||col_value_transpose||', null)';
				EXECUTE 'CREATE TABLE "TR09.1" as ' || 'select * from _test_pivoted';
			else
				EXECUTE 'DROP TABLE IF EXISTS "TR09.1"';
				EXECUTE 'CREATE TABLE "TR09.1" (vide text)';
			end if;
		END LOOP;
    end;
$$ language plpgsql volatile;

select * from "TR09.1"();

--TE01.1
create or replace function "TE01.1"(
) returns void as $$
    declare
        requete text;
        col_uniq text;
        col_transpose text;
        col_value_transpose text;
        var_req_execute record;
    begin


	EXECUTE 'DROP TABLE IF EXISTS _test_pivoted';
	EXECUTE 'DROP TABLE IF EXISTS "inter_TE01.1"';
	EXECUTE 'CREATE TABLE "inter_TE01.1" as
		select
			''id_processus_particulier''::text as uniq,
			localite_site as localite_site,
			array_agg(num_dossier_site) as num_dossier_site,
			array_agg(date_pose_pb) as date_pose_pb,
			count(id_processus_particulier) as id_processus_particulier
		from requete_optimum as ro
		where (date_pose_pb != NULL or date_pose_pb != '''') and
			id_processus_particulier like ''%DSP_ATHD_PHASE2_PER_RAC%'' and nombre_de_logements::int < 4
			---Avoir avec la condition
		group by ro.localite_site';
	requete := quote_literal(e'select * from "inter_TE01.1"');
	col_uniq := quote_literal(e'uniq');
	col_transpose := quote_literal(e'localite_site');
	col_value_transpose := quote_literal(e'#.id_processus_particulier');

	FOR var_req_execute in select count(*)::int as len from "inter_TE01.1" limit 1
		LOOP
			if var_req_execute.len > 0 then

				EXECUTE 'DROP TABLE IF EXISTS "TE01.1"';
				EXECUTE 'select colpivot(''_test_pivoted'', '||
					requete||',array['||col_uniq||'], array['||col_transpose||'], '||col_value_transpose||', null)';
				EXECUTE 'CREATE TABLE "TE01.1" as ' || 'select * from _test_pivoted';
			else
				EXECUTE 'DROP TABLE IF EXISTS "TE01.1"';
				EXECUTE 'CREATE TABLE "TE01.1" (vide text)';
			end if;
		END LOOP;
    end;
$$ language plpgsql volatile;

select * from "TE01.1"();

--TE02.1
create or replace function "TE02.1"(
) returns void as $$
    declare
        requete text;
        col_uniq text;
        col_transpose text;
        col_value_transpose text;
        var_req_execute record;
    begin


	EXECUTE 'DROP TABLE IF EXISTS _test_pivoted';
	EXECUTE 'DROP TABLE IF EXISTS "inter_TE02.1"';
	EXECUTE 'CREATE TABLE "inter_TE02.1" as
		select
			''unique''::text as uniq,
			ca.nom_commune as nom_commune,
			case when min(tr.percent) > 85 then ''OK'' else ''KO'' end as percent
		from "Calendrier" as ca
		left join "inter_TR09.1" as tr on tr.localite_site = ca.nom_commune
		group by ca.nom_commune';
	requete := quote_literal(e'select * from "inter_TE02.1"');
	col_uniq := quote_literal(e'uniq');
	col_transpose := quote_literal(e'nom_commune');
	col_value_transpose := quote_literal(e'#.percent');

	FOR var_req_execute in select count(*)::int as len from "inter_TE02.1" limit 1
		LOOP
			if var_req_execute.len > 0 then

				EXECUTE 'DROP TABLE IF EXISTS "TE02.1"';
				EXECUTE 'select colpivot(''_test_pivoted'', '||
					requete||',array['||col_uniq||'], array['||col_transpose||'], '||col_value_transpose||', null)';
				EXECUTE 'CREATE TABLE "TE02.1" as ' || 'select * from _test_pivoted';
			else
				EXECUTE 'DROP TABLE IF EXISTS "TE02.1"';
				EXECUTE 'CREATE TABLE "TE02.1" (vide text)';
			end if;
		END LOOP;
    end;
$$ language plpgsql volatile;

select * from "TE02.1"();


--TE03.1
create or replace function "TE03.1"(
) returns void as $$
    declare
        requete text;
        col_uniq text;
        col_transpose text;
        col_value_transpose text;
        var_req_execute record;
    begin


	EXECUTE 'DROP TABLE IF EXISTS _test_pivoted';
	EXECUTE 'DROP TABLE IF EXISTS "inter_TE03.1"';
	EXECUTE 'CREATE TABLE "inter_TE03.1" as
		select
			''unique''::text as uniq,
			localite_site as localite_site,
			sum(nombre_de_logements::int) sum
		from "Extraction MESC ARCEP"
		where (mesc_arcep_site != NULL or mesc_arcep_site != '''')
		group by localite_site';
	requete := quote_literal(e'select * from "inter_TE03.1"');
	col_uniq := quote_literal(e'uniq');
	col_transpose := quote_literal(e'localite_site');
	col_value_transpose := quote_literal(e'#.sum');

	FOR var_req_execute in select count(*)::int as len from "inter_TE03.1" limit 1
		LOOP
			if var_req_execute.len > 0 then

				EXECUTE 'DROP TABLE IF EXISTS "TE03.1"';
				EXECUTE 'select colpivot(''_test_pivoted'', '||
					requete||',array['||col_uniq||'], array['||col_transpose||'], '||col_value_transpose||', null)';
				EXECUTE 'CREATE TABLE "TE03.1" as ' || 'select * from _test_pivoted';
			else
				EXECUTE 'DROP TABLE IF EXISTS "TE03.1"';
				EXECUTE 'CREATE TABLE "TE03.1" (vide text)';
			end if;
		END LOOP;
    end;
$$ language plpgsql volatile;

select * from "TE03.1"();


--MANUEL
DROP TABLE IF EXISTS "MANUEL";
CREATE TABLE "MANUEL" as
select
	commune,semaine
from "Raccordement"
where (semaine = '% dÃ©chec sur 8S glissantes');

--TE04.1
create or replace function "TE04.1"(
) returns void as $$
    declare
        requete text;
        col_uniq text;
        col_transpose text;
        col_value_transpose text;
        var_req_execute record;
    begin
	EXECUTE 'DROP TABLE IF EXISTS _test_pivoted';
	EXECUTE 'DROP TABLE IF EXISTS "inter_TE04.1"';
	EXECUTE 'CREATE TABLE "inter_TE04.1" as
		select
			localite_site,
			array_agg(num_dossier_site) as num_dossier_site,
			--array_agg(localite_site) as localite_site,
			array_agg(date_pose_pb) as date_pose_pb,
			array_agg(id_processus_particulier) as id_processus_particulier,
			array_agg(libelle_site_etat_negociation_syndic) as libelle_site_etat_negociation_syndic
		from requete_optimum as ro
		where (date_pose_pb != NULL or date_pose_pb != '''') and
			id_processus_particulier like ''%DSP_ATHD_PHASE2_PER_RAC%'' and nombre_de_logements::int > 4 and
			libelle_site_etat_negociation_syndic not in  (''%DENONCE%'' ,''%REFUS SYNDIC%'',''%SIGNE%'')
		group by ro.localite_site';
	requete := quote_literal(e'select * from "inter_TE04.1"');
	col_uniq := quote_literal(e'uniq');
	col_transpose := quote_literal(e'localite_site');
	col_value_transpose := quote_literal(e'#.sum');

	FOR var_req_execute in select count(*)::int as len from "inter_TE04.1" limit 1
		LOOP
			if var_req_execute.len > 0 then

				EXECUTE 'DROP TABLE IF EXISTS "TE04.1"';
				EXECUTE 'CREATE TABLE "TE04.1" as ' || 'select * from "inter_TE04.1"';
			else
				EXECUTE 'DROP TABLE IF EXISTS "TE04.1"';
				EXECUTE 'CREATE TABLE "TE04.1" (vide text)';
			end if;
		END LOOP;
    end;
$$ language plpgsql volatile;

select * from "TE04.1"();

--TE04.2
create or replace function "TE04.2"(
) returns void as $$
    declare
        requete text;
        col_uniq text;
        col_transpose text;
        col_value_transpose text;
        var_req_execute record;
    begin
	EXECUTE 'DROP TABLE IF EXISTS _test_pivoted';
	EXECUTE 'DROP TABLE IF EXISTS "inter_TE04.2"';
	EXECUTE 'CREATE TABLE "inter_TE04.2" as
		select
			localite_site as localite_site,
			array_agg(num_dossier_site) as num_dossier_site,
			array_agg(date_pose_pb) as date_pose_pb,
			array_agg(id_processus_particulier) as id_processus_particulier,
			array_agg(libelle_site_etat_negociation_syndic) as libelle_site_etat_negociation_syndic
		from requete_optimum as ro
		where (date_pose_pb != NULL or date_pose_pb != '''') and
			id_processus_particulier not like ''%DSP_ATHD_PHASE2_PER_RAC%'' and nombre_de_logements::int > 4 and
			libelle_site_etat_negociation_syndic not in  (''%DENONCE%'' ,''%REFUS SYNDIC%'',''%SIGNE%'')
		group by ro.localite_site';
	requete := quote_literal(e'select * from "inter_TE04.2"');
	col_uniq := quote_literal(e'uniq');
	col_transpose := quote_literal(e'localite_site');
	col_value_transpose := quote_literal(e'#.sum');

	FOR var_req_execute in select count(*)::int as len from "inter_TE04.2" limit 1
		LOOP
			if var_req_execute.len > 0 then

				EXECUTE 'DROP TABLE IF EXISTS "TE04.2"';
				EXECUTE 'CREATE TABLE "TE04.2" as ' || 'select * from "inter_TE04.2"';
			else
				EXECUTE 'DROP TABLE IF EXISTS "TE04.2"';
				EXECUTE 'CREATE TABLE "TE04.2" (vide text)';
			end if;
		END LOOP;
    end;
$$ language plpgsql volatile;

select * from "TE04.2"();

--OC01.1
create or replace function "OC01.1"(
) returns void as $$
    declare
        requete text;
        col_uniq text;
        col_transpose text;
        col_value_transpose text;
        var_req_execute record;
    begin
	EXECUTE 'DROP TABLE IF EXISTS _test_pivoted';
	EXECUTE 'DROP TABLE IF EXISTS "inter_OC01.1"';
	EXECUTE 'CREATE TABLE "inter_OC01.1" as
		select
			*
		from "TR03.1"';
	requete := quote_literal(e'select * from "inter_OC01.1"');
	col_uniq := quote_literal(e'uniq');
	col_transpose := quote_literal(e'localite_site');
	col_value_transpose := quote_literal(e'#.sum');

	FOR var_req_execute in select count(*)::int as len from "inter_OC01.1" limit 1
		LOOP
			if var_req_execute.len > 0 then

				EXECUTE 'DROP TABLE IF EXISTS "OC01.1"';
				EXECUTE 'CREATE TABLE "OC01.1" as ' || 'select * from "inter_OC01.1"';
			else
				EXECUTE 'DROP TABLE IF EXISTS "OC01.1"';
				EXECUTE 'CREATE TABLE "OC01.1" (vide text)';
			end if;
		END LOOP;
    end;
$$ language plpgsql volatile;

select * from "OC01.1"();

--OC02.1
create or replace function "OC02.1"(
) returns void as $$
    declare
        requete text;
        col_uniq text;
        col_transpose text;
        col_value_transpose text;
        var_req_execute record;
    begin
	EXECUTE 'DROP TABLE IF EXISTS _test_pivoted';
	EXECUTE 'DROP TABLE IF EXISTS "inter_OC02.1"';
	EXECUTE 'CREATE TABLE "inter_OC02.1" as
		select
			st_difference(tr.geom, ro.geom),ro.*
		from "PDD_Zone-PER_Phase2" as ro
		join "Couverture_FTTH_Phase2" as tr on ST_DWithin(tr.geom, ro.geom,1)';

	requete := quote_literal(e'select * from "inter_OC02.1"');
	col_uniq := quote_literal(e'uniq');
	col_transpose := quote_literal(e'localite_site');
	col_value_transpose := quote_literal(e'#.sum');

	FOR var_req_execute in select count(*)::int as len from "inter_OC02.1" limit 1
		LOOP
			if var_req_execute.len > 0 then

				EXECUTE 'DROP TABLE IF EXISTS "OC02.1"';
				EXECUTE 'CREATE TABLE "OC02.1" as ' || 'select * from "inter_OC02.1"';
			else
				EXECUTE 'DROP TABLE IF EXISTS "OC02.1"';
				EXECUTE 'CREATE TABLE "OC02.1" (vide text)';
			end if;
		END LOOP;
    end;
$$ language plpgsql volatile;

select * from "OC02.1"();

--OC03.1
create or replace function "OC03.1"(
) returns void as $$
    declare
        requete text;
        col_uniq text;
        col_transpose text;
        col_value_transpose text;
        var_req_execute record;
    begin

	EXECUTE 'DROP TABLE IF EXISTS _test_pivoted';
	EXECUTE 'DROP TABLE IF EXISTS "inter_OC02.1"';
	EXECUTE 'CREATE TABLE "inter_OC02.1" as
		select
			*
		from "TR09.1" as ro';

	requete := quote_literal(e'select * from "inter_OC02.1"');
	col_uniq := quote_literal(e'uniq');
	col_transpose := quote_literal(e'localite_site');
	col_value_transpose := quote_literal(e'#.sum');

	FOR var_req_execute in select count(*)::int as len from "inter_OC02.1" limit 1
		LOOP
			if var_req_execute.len > 0 then

				EXECUTE 'DROP TABLE IF EXISTS "OC03.1"';
				EXECUTE 'CREATE TABLE "OC03.1" as ' || 'select * from "inter_OC02.1"';
			else
				EXECUTE 'DROP TABLE IF EXISTS "OC03.1"';
				EXECUTE 'CREATE TABLE "OC03.1" (vide text)';
			end if;
		END LOOP;
    end;
$$ language plpgsql volatile;

select * from "OC03.1"();

---IG01.1
DROP TABLE IF EXISTS "IG01.1";
CREATE TABLE "IG01.1" as
with intermediare as (select
	ip.nom_site_pf_pb,
	count(ip.nom_du_pt_pb)::int,
	array_agg(ip.nom_du_pt_pb)
from requete_ipon ip
group by ip.nom_site_pf_pb)
select * from intermediare where count >2;

---IG02.1
DROP TABLE IF EXISTS "IG02.1";
CREATE TABLE "IG02.1" as
with intermediare as (select
	ip.nom_site_pf_pb,
	count(ip.nature_travaux)::int count,
	array_agg(ip.nom_du_pt_pb) nom_du_pt_pb,
	array_agg(ip.position_d_equipement_pt_pb) position_d_equipement_pt_pb
from requete_ipon ip
where position_d_equipement_pt_pb like '%CH:en chambre%' and nature_travaux like '%faÃ§ade%'
group by ip.nom_site_pf_pb)
select * from intermediare;

---IG03.1
create or replace function "IG03.1"(
) returns void as $$
    declare
        requete text;
        col_uniq text;
        col_transpose text;
        col_value_transpose text;
        var_req_execute record;
    begin

	EXECUTE 'DROP TABLE IF EXISTS _test_pivoted';
	EXECUTE 'DROP TABLE IF EXISTS "inter_IG03.1"';
	EXECUTE 'CREATE TABLE "inter_IG03.1" as
		select
			 ad.*,st_distance(bp.geom,ad.geom) as distance,bp.id_metier_ as bp_id_metier_,zn.id_metier_ as zn_id_metier
		from t_adresse_gfi ad
		join ftth_zone_eligibilite zn on st_contains(zn.geom,ad.geom)
		join t_ebp_gfi bp on st_contains(zn.geom,bp.geom)
		where st_distance(bp.geom,ad.geom) > 250';

	requete := quote_literal(e'select * from "inter_IG03.1"');
	col_uniq := quote_literal(e'uniq');
	col_transpose := quote_literal(e'localite_site');
	col_value_transpose := quote_literal(e'#.sum');

	FOR var_req_execute in select count(*)::int as len from "inter_IG03.1" limit 1
		LOOP
			if var_req_execute.len > 0 then

				EXECUTE 'DROP TABLE IF EXISTS "IG03.1"';
				EXECUTE 'CREATE TABLE "IG03.1" as ' || 'select * from "inter_IG03.1"';
			else
				EXECUTE 'DROP TABLE IF EXISTS "IG03.1"';
				EXECUTE 'CREATE TABLE "IG03.1" (vide text)';
			end if;
		END LOOP;
    end;
$$ language plpgsql volatile;

select * from "IG03.1"();


---IG04.1
create or replace function "IG04.1"(
) returns void as $$
    declare
        requete text;
        col_uniq text;
        col_transpose text;
        col_value_transpose text;
        var_req_execute record;
    begin
	EXECUTE 'DROP TABLE IF EXISTS _test_pivoted';
	EXECUTE 'DROP TABLE IF EXISTS "inter_IG04.1"';
	EXECUTE 'CREATE TABLE "inter_IG04.1" as
		select
			''Somme_de_Nombre_de_logements''::text as uniq,
			op.localite_site as localite_site,
			sum(op.nombre_de_logements::int) as sum
		from requete_optimum op
		group by op.localite_site';

	requete := quote_literal(e'select * from "inter_IG04.1"');
	col_uniq := quote_literal(e'uniq');
	col_transpose := quote_literal(e'localite_site');
	col_value_transpose := quote_literal(e'#.sum');
	FOR var_req_execute in select count(*)::int as len from "inter_IG04.1" limit 1
		LOOP
			if var_req_execute.len > 0 then
				EXECUTE 'DROP TABLE IF EXISTS "IG04.1"';
				EXECUTE 'select colpivot(''_test_pivoted'', '||
					requete||',array['||col_uniq||'], array['||col_transpose||'], '||col_value_transpose||', null)';
				EXECUTE 'CREATE TABLE "IG04.1" as ' || 'select * from _test_pivoted';
			else
					EXECUTE 'DROP TABLE IF EXISTS "IG04.1"';
					EXECUTE 'CREATE TABLE "IG04.1" (vide text)';

			end if;
		END LOOP;
    end;
$$ language plpgsql volatile;

select * from "IG04.1"();

---IG06.1
DROP TABLE IF EXISTS "IG06.1";
CREATE TABLE "IG06.1" as
select
	ip.nom_du_pt_pb ,array_agg(distinct(description_pf_pb)),
	sum(replace(ip.nb_el_du_code_immeuble, Null, '0')::int) nb_el_du_code_immeuble,
	array_to_string(array_agg(DISTINCT (ip.nom_site_pf_pb)),';') nom_site_pf_pb,
	array_to_string(array_agg(DISTINCT (ip.position_d_equipement_pt_pb)),';') position_d_equipement_pt_pb
from requete_ipon ip
--where ip.nb_el_du_code_immeuble != ''
group by ip.nom_du_pt_pb;


----select COALESCE(ip.nb_el_du_code_immeuble::int,0) from requete_ipon ip


--select unnest(position_d_equipement_pt_pb),* from "IG06.1";


---IG07.1
DROP TABLE IF EXISTS "IG07.1";
CREATE TABLE "IG07.1" as
select
	ip.description_du_site_pa ,
	sum(replace(ip.nb_el_du_code_immeuble, Null, '0')::int) nb_el_du_code_immeuble,
	array_to_string(array_agg(DISTINCT (ip.nom_site_pf_pb)),';') nom_site_pf_pa,
	array_to_string(array_agg(DISTINCT (ip.position_d_equipement_pt_pa)),';') position_d_equipement_pt_pa
from requete_ipon ip
group by ip.description_du_site_pa;


---SI02.1
DROP TABLE IF EXISTS "SI02.1";
CREATE TABLE "SI02.1" as
select
	*
from t_adresse_gfi ad
join requete_optimum as ro on ro.num_dossier_site = ad.id_metier_;

---SI03.1
DROP TABLE IF EXISTS "SI03.1";
CREATE TABLE "SI03.1" as
select
	*
from t_ebp_gfi bp
where statut_ftt not like '%D%';

--SI04.1
create or replace function "SI04.1"(
) returns void as $$
    declare
        requete text;
        col_uniq text;
        col_transpose text;
        col_value_transpose text;
        var_req_execute record;
    begin

	EXECUTE 'DROP TABLE IF EXISTS _test_pivoted';
	EXECUTE 'DROP TABLE IF EXISTS "inter_OC02.1"';
	EXECUTE 'CREATE TABLE "inter_OC02.1" as
		select
			*
		from "Optimum" as ro
		where nombre_de_logements::int >3';

	requete := quote_literal(e'select * from "inter_OC02.1"');
	col_uniq := quote_literal(e'uniq');
	col_transpose := quote_literal(e'localite_site');
	col_value_transpose := quote_literal(e'#.sum');

	FOR var_req_execute in select count(*)::int as len from "inter_OC02.1" limit 1
		LOOP
			if var_req_execute.len > 0 then

				EXECUTE 'DROP TABLE IF EXISTS "SI04.1"';
				EXECUTE 'CREATE TABLE "SI04.1" as ' || 'select * from "inter_OC02.1"';
			else
				EXECUTE 'DROP TABLE IF EXISTS "SI04.1"';
				EXECUTE 'CREATE TABLE "SI04.1" (vide text)';
			end if;
		END LOOP;
    end;
$$ language plpgsql volatile;

select * from "SI04.1"();

---SI05.1
DROP TABLE IF EXISTS "SI05.1";
CREATE TABLE "SI05.1" as
select
	ip.nom_commune_pm,
	ip.nom_du_pm_reg,
	ip.nom_du_pa_reg,
	ip.nom_du_pf_pb,
	ip.position_d_equipement_pt_pb,
	ip.hauteur_par_rapport_au_sol_pt_pb
from requete_ipon ip
where (ip.hauteur_par_rapport_au_sol_pt_pb is NULL or ip.hauteur_par_rapport_au_sol_pt_pb = '') or
	(ip.position_d_equipement_pt_pb = 'CH:en chambre' and ip.hauteur_par_rapport_au_sol_pt_pb not like '%HH : h inf  1,8 m%') or
	(ip.position_d_equipement_pt_pb = 'GT:gaine technique' and ip.hauteur_par_rapport_au_sol_pt_pb not like '%HH : h inf  1,8 m%');

---SI06.1
DROP TABLE IF EXISTS "SI06.1";
CREATE TABLE "SI06.1" as
select
	ad.*
from t_adresse_gfi ad
join "63_RBAL_Phase2" rb on ST_DWithin(ad.geom,rb.geom,1);

---SI08.1
create or replace function "SI08.1"(
) returns void as $$
    declare
        requete text;
        col_uniq text;
        col_transpose text;
        col_value_transpose text;
        var_req_execute record;
    begin

	EXECUTE 'DROP TABLE IF EXISTS _test_pivoted';
	EXECUTE 'DROP TABLE IF EXISTS "inter_SI08.1"';
	EXECUTE 'CREATE TABLE "inter_SI08.1" as
		select
			ip.*
		from requete_ipon ip
		where ip.id_processus_particulier = ''DSP_ATHD_PHASE2_PER_RA'' or
			(ip.etat_production_pf_pb not like ''%DÃƒÂ©ployÃƒÂ©%'' or ip.etat_production_pf_pb not like ''%Actif%'');';

	requete := quote_literal(e'select * from "inter_SI08.1"');
	col_uniq := quote_literal(e'uniq');
	col_transpose := quote_literal(e'localite_site');
	col_value_transpose := quote_literal(e'#.sum');

	FOR var_req_execute in select count(*)::int as len from "inter_SI08.1" limit 1
		LOOP
			if var_req_execute.len > 0 then

				EXECUTE 'DROP TABLE IF EXISTS "SI08.1"';
				EXECUTE 'CREATE TABLE "SI08.1" as ' || 'select * from "inter_SI08.1"';
			else
				EXECUTE 'DROP TABLE IF EXISTS "SI08.1"';
				EXECUTE 'CREATE TABLE "SI08.1" (vide text)';
			end if;
		END LOOP;
    end;
$$ language plpgsql volatile;

select * from "SI08.1"();

--SI10.1
create or replace function "SI10.1"(
) returns void as $$
    declare
        requete text;
        col_uniq text;
        col_transpose text;
        col_value_transpose text;
        var_req_execute record;
    begin

	EXECUTE 'DROP TABLE IF EXISTS _test_pivoted';
	EXECUTE 'DROP TABLE IF EXISTS "inter_OC02.1"';
	EXECUTE 'CREATE TABLE "inter_OC02.1" as
		select
			*
		from requete_optimum as ro
		where bloque like ''%1%'';';

	requete := quote_literal(e'select * from "inter_OC02.1"');
	col_uniq := quote_literal(e'uniq');
	col_transpose := quote_literal(e'localite_site');
	col_value_transpose := quote_literal(e'#.sum');

	FOR var_req_execute in select count(*)::int as len from "inter_OC02.1" limit 1
		LOOP
			if var_req_execute.len > 0 then

				EXECUTE 'DROP TABLE IF EXISTS "SI10.1"';
				EXECUTE 'CREATE TABLE "SI10.1" as ' || 'select * from "inter_OC02.1"';
			else
				EXECUTE 'DROP TABLE IF EXISTS "SI10.1"';
				EXECUTE 'CREATE TABLE "SI10.1" (vide text)';
			end if;
		END LOOP;
    end;
$$ language plpgsql volatile;

select * from "SI10.1"();

---SI11.1
DROP TABLE IF EXISTS "SI11.1";
CREATE TABLE "SI11.1" as
select
	ip.nom_du_pf_pb,
	ip.position_d_equipement_pt_pb,
	ip.adresse_ou_sous_adresse_site_pf_pb
from requete_ipon ip
where ip.position_d_equipement_pt_pb like '%FR:faÃ§ade cÃ´tÃ© rue%' or ip.position_d_equipement_pt_pb like '%FC:faÃ§ade cÃ´tÃ© cour%';

-- Grant pour les tables creees par le script
--GRANT ALL ON SCHEMA lfd TO adn_ing;

/*
SELECT
	'ALTER TABLE lfd.'||'"'||table_name||'" OWNER TO '||'adn_ing;'
	table_name
FROM information_schema.tables
WHERE table_schema = 'lfd'*/