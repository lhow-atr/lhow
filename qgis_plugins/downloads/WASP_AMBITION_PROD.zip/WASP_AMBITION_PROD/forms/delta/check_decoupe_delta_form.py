# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'Dialog_IMPORT_BDD2.ui'
#
# Created by: PyQt5 UI code generator 5.11.3
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets
import datetime
from pathlib import Path
from ...params_connexion import *

folder_plugin = str(Path(__file__).parent.parent.parent)


class Ui_check_DecoupeDelta_dialog(object):
	def setupUi(self, check_DecoupeDelta_dialog):
		check_DecoupeDelta_dialog.setObjectName("check_DecoupeDelta_dialog")
		check_DecoupeDelta_dialog.setWindowModality(QtCore.Qt.ApplicationModal)
		check_DecoupeDelta_dialog.setEnabled(True)
		check_DecoupeDelta_dialog.resize(800, 800)#1305, 882
		check_DecoupeDelta_dialog.setMouseTracking(False)

		self.verticalLayoutWidget = QtWidgets.QWidget(check_DecoupeDelta_dialog)
		self.verticalLayoutWidget.setGeometry(QtCore.QRect(30, 30, 700, 700))#1161, 731
		self.verticalLayoutWidget.setObjectName("verticalLayoutWidget")

		self.verticalLayout = QtWidgets.QVBoxLayout(self.verticalLayoutWidget)
		self.verticalLayout.setContentsMargins(0, 0, 0, 0)
		self.verticalLayout.setObjectName("verticalLayout")

		self.gridLayout = QtWidgets.QGridLayout()
		self.gridLayout.setObjectName("gridLayout")

		self.label_12 = QtWidgets.QLabel(self.verticalLayoutWidget)
		self.label_12.setObjectName("label_12")
		self.gridLayout.addWidget(self.label_12, 0, 0, 1, 1)

		self.label_2 = QtWidgets.QLabel(self.verticalLayoutWidget)
		self.label_2.setObjectName("label_2")
		self.gridLayout.addWidget(self.label_2, 0, 1, 1, 1)

		self.label = QtWidgets.QLabel(self.verticalLayoutWidget)
		self.label.setObjectName("label")
		self.gridLayout.addWidget(self.label, 0, 2, 1, 1)

		self.name_pr_depart = QgsCheckableComboBox(self.verticalLayoutWidget)
		self.name_pr_depart.setMinimumSize(QtCore.QSize(106, 0))
		self.name_pr_depart.setObjectName("name_pr_depart")
		self.gridLayout.addWidget(self.name_pr_depart, 1, 0, 1, 1)	

		self.name_pr_arrive = QgsCheckableComboBox(self.verticalLayoutWidget)
		self.name_pr_arrive.setMinimumSize(QtCore.QSize(106, 0))
		self.name_pr_arrive.setObjectName("name_pr_arrive")
		self.gridLayout.addWidget(self.name_pr_arrive, 1, 1, 1, 1)	

		self.name_schema_decoupe = QtWidgets.QLineEdit(self.verticalLayoutWidget)
		self.name_schema_decoupe.setMinimumSize(QtCore.QSize(111, 0))
		self.name_schema_decoupe.setObjectName("name_schema_decoupe")
		self.gridLayout.addWidget(self.name_schema_decoupe, 1, 2, 1, 1)

		self.verticalLayout.addLayout(self.gridLayout)

		self.textBrowser = QtWidgets.QTextBrowser(self.verticalLayoutWidget)
		self.textBrowser.setObjectName("textBrowser")
		self.verticalLayout.addWidget(self.textBrowser)

		self.button_box = QtWidgets.QDialogButtonBox(self.verticalLayoutWidget)
		self.button_box.setOrientation(QtCore.Qt.Horizontal)
		self.button_box.setStandardButtons(QtWidgets.QDialogButtonBox.Cancel|QtWidgets.QDialogButtonBox.Ok)
		self.button_box.setObjectName("button_box")
		self.verticalLayout.addWidget(self.button_box)

		self.retranslateUi(check_DecoupeDelta_dialog)
		self.button_box.accepted.connect(check_DecoupeDelta_dialog.accept)
		self.button_box.rejected.connect(check_DecoupeDelta_dialog.reject)
		QtCore.QMetaObject.connectSlotsByName(check_DecoupeDelta_dialog)

	def retranslateUi(self, check_DecoupeDelta_dialog):
		_translate = QtCore.QCoreApplication.translate
		check_DecoupeDelta_dialog.setWindowTitle(_translate("check_DecoupeDelta_dialog", "DESIGN v0.01 - Importation des donnees dans la BDD"))
		self.label_12.setText(_translate("check_DecoupeDelta_dialog", "Nom du Schema Départ"))
		self.label_2.setText(_translate("check_DecoupeDelta_dialog", "Nom du Schema Arrivé"))
		self.label.setText(_translate("check_DecoupeDelta_dialog", "Nom du Schema Decoupe à créer"))
		self.name_schema_decoupe.setText(_translate("check_DecoupeDelta_dialog", "pr_decoupe_depart"))
		self.textBrowser.setHtml(_translate("check_DecoupeDelta_dialog", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
		"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
		"p, li { white-space: pre-wrap; }\n"
		"p { margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:8pt }\n"
		"</style></head><body style=\" font-family:\'MS Shell Dlg 2\'; font-size:8.25pt; font-weight:400; font-style:normal;\">\n"
		"<h2>Objectifs: </h2>\n"
		"<div > Ce module permet de découper à l'echelle d'une ZSRO toutes les tables d'un schéma donné à l'echelle d'une PR,  en fonction de la table t_zsro de ce dernier. </div>\n"
		"<h2>Données en entrée: </h2>\n"
		"<div > Les données d'entrée correspondent à trois noms de schémas (schema_depart, schema_arrivé et schema_decoupe) d’un même « PR ». Par exemple, pour le PR 3_4, le schéma de départ est : « pr_3_4_exe_v_20191024 », le et le schéma d'arrivé est : « pr_3_4_exe_v_20191024 » et le schéma de découpe est : « decoupe_depart ». </div>\n"
		"<h2 >Résultat: </h2>\n"
		"<div> Les résultats correspondent à une création du schema  « decoupe_depart » avec la creation de toutes les tables par rapport au schéma de départ. </div>\n"
		"<h2 >Contraintes: </h2>\n"
		"<div > Il faut que la table t_zsro du schéma arrivé soit dans la meme zone que celles des données de toutes les tables dans du schéma départ. La maniére de découpage est géométrique. </div>\n"
		"</body></html>"))

from qgscheckablecombobox import QgsCheckableComboBox
from qgsdatetimeedit import QgsDateTimeEdit


import os.path
from qgis.core import *
from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5.QtWidgets import *

	
# import psycopg2
# import datetime
# import importlib
# import sys

from ...scripts_python.delta.creation_decoupe_zsro import *

# ------------------------------------------------------------------------------
#    class_general_dialog - base class for MMQGIS dialogs containing utility functions
# ------------------------------------------------------------------------------


class class_general_dialog(QtWidgets.QDialog):

	
	def __init__(self, iface, var_connection):
		QtWidgets.QDialog.__init__(self)
		self.iface = iface
		self.connection = var_connection
		
	# Function pour executer une requete sql dans la base
	def function_execute_requete(self, requete_execute, req_fetch):
		curs=self.connection.cursor()
		try:
			curs.execute(requete_execute)
			if req_fetch:
				data_req=[row for row in curs.fetchall()]
				if data_req:
					return data_req
		except(Exception, psycopg2.DatabaseError) as error:
			QMessageBox.critical(self.iface.mainWindow(), "Message dexecution de requete", 'Requete Non Executer : '+str(error)+' ; '+str(requete_execute))
			# print("Message dexecution de requete", 'Requete Non Executer : '+str(error)+' ; '+str(requete_execute))
		curs.close()

	def get_all_schema_name(self, list_widget):
		req_get_schema = """select 
			schema_name
		from information_schema.schemata
		where schema_name like 'pr%' order by schema_name;"""
		
		list_schema_name = self.function_execute_requete(req_get_schema, 'bab')
		
		for index, name_schema in enumerate(list_schema_name):
			if name_schema:
				list_widget.addItem("")
				list_widget.setItemText(index, name_schema[0])
	
	def get_version_plugin(self):
		# folder_plugin = os.path.dirname(os.path.abspath(__file__))
		folder_metada  = open(folder_plugin + "\metadata.txt")#open(folder_plugin.replace("forms\delta", "\metadata.txt"))
		for line in folder_metada :
			if str(line)[:7] == 'version':
				get_version = line.split('=')[1]
				return get_version
		folder_metada .close()


class class_checkDecoupeDelta_dialog(class_general_dialog, Ui_check_DecoupeDelta_dialog):
	def __init__(self, iface):
		self.var_connection = function_connexion()
		class_general_dialog.__init__(self, iface, self.var_connection)
		self.setupUi(self)
		self.get_all_schema_name(self.name_pr_depart)
		self.get_all_schema_name(self.name_pr_arrive)
		self.setWindowTitle("DESIGN " + str(self.get_version_plugin()) + " - Découpage d'un livrable à la ZSRO")
		self.var_connection.close()
		self.button_box.button(QtWidgets.QDialogButtonBox.Ok).clicked.connect(self.run)

	def run(self):
		list_name_pr_depart = self.name_pr_depart
		text_name_pr_depart = [x for x in list_name_pr_depart.currentText().split(',') if x]

		list_name_pr_arrive = self.name_pr_arrive
		text_name_pr_arrive = [x for x in list_name_pr_arrive.currentText().split(',') if x]

		if len(text_name_pr_depart) != 1 or len(text_name_pr_arrive) != 1:
			QMessageBox.critical(self.iface.mainWindow(), "Message Du Choix",
								 'Veillez cocher un seul schema Arrivé et un seul schema Départ')
		else:
			schema_depart = "".join(text_name_pr_depart)
			schema_arrive = "".join(text_name_pr_arrive)
			schema_decoupe = self.name_schema_decoupe.text()
			function_decoupe_zsro_general(schema_depart,schema_decoupe,schema_arrive)
			self.function_close_requete_cache()
