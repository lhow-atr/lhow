# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'Dialog_IMPORT_BDD2.ui'
#
# Created by: PyQt5 UI code generator 5.11.3
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets
import datetime
from pathlib import Path
from ...params_connexion import *

folder_plugin = str(Path(__file__).parent.parent.parent)
class Ui_decoupe_ligne(object):
    def setupUi(self, decoupe_ligne):
        decoupe_ligne.setObjectName("decoupe_ligne")
        decoupe_ligne.setWindowModality(QtCore.Qt.ApplicationModal)
        decoupe_ligne.setEnabled(True)
        decoupe_ligne.resize(800, 800)  # 1305, 882
        decoupe_ligne.setMouseTracking(False)

        self.verticalLayoutWidget = QtWidgets.QWidget(decoupe_ligne)
        self.verticalLayoutWidget.setGeometry(QtCore.QRect(30, 30, 700, 700))  # 1161, 731
        self.verticalLayoutWidget.setObjectName("verticalLayoutWidget")

        self.verticalLayout = QtWidgets.QVBoxLayout(self.verticalLayoutWidget)
        self.verticalLayout.setContentsMargins(0, 0, 0, 0)
        self.verticalLayout.setObjectName("verticalLayout")

        self.gridLayout = QtWidgets.QGridLayout()
        self.gridLayout.setObjectName("gridLayout")

        self.label_12 = QtWidgets.QLabel(self.verticalLayoutWidget)
        self.label_12.setObjectName("label_12")
        self.gridLayout.addWidget(self.label_12, 0, 0, 1, 1)

        self.label_2 = QtWidgets.QLabel(self.verticalLayoutWidget)
        self.label_2.setObjectName("label_2")
        self.gridLayout.addWidget(self.label_2, 0, 1, 1, 1)

        self.Layer_Ligne = QtWidgets.QComboBox(self.verticalLayoutWidget)
        self.Layer_Ligne.setObjectName("Layer_Ligne")
        self.gridLayout.addWidget(self.Layer_Ligne, 1, 0, 1, 1)
        #self.verticalLayout.addLayout(self.gridLayout)

        self.Layer_Point = QtWidgets.QComboBox(self.verticalLayoutWidget)
        self.Layer_Point.setObjectName("Layer_Point")
        self.gridLayout.addWidget(self.Layer_Point, 1, 1, 1, 1)
        self.verticalLayout.addLayout(self.gridLayout)

        self.textBrowser = QtWidgets.QTextBrowser(self.verticalLayoutWidget)
        self.textBrowser.setObjectName("textBrowser")
        self.verticalLayout.addWidget(self.textBrowser)

        self.button_box = QtWidgets.QDialogButtonBox(self.verticalLayoutWidget)
        self.button_box.setOrientation(QtCore.Qt.Horizontal)
        self.button_box.setStandardButtons(QtWidgets.QDialogButtonBox.Cancel | QtWidgets.QDialogButtonBox.Ok)
        self.button_box.setObjectName("button_box")
        self.verticalLayout.addWidget(self.button_box)

        self.retranslateUi(decoupe_ligne)
        self.button_box.accepted.connect(decoupe_ligne.accept)
        self.button_box.rejected.connect(decoupe_ligne.reject)
        QtCore.QMetaObject.connectSlotsByName(decoupe_ligne)

    def retranslateUi(self, decoupe_ligne):
        _translate = QtCore.QCoreApplication.translate
        decoupe_ligne.setWindowTitle(
            _translate("decoupe_ligne", "DESIGN v0.01 - Importation des donnees dans la BDD"))
        self.label_12.setText(_translate("decoupe_ligne", "Shape Ligne"))
        self.label_2.setText(_translate("decoupe_ligne", "Shape Point"))
        self.textBrowser.setHtml(_translate("decoupe_ligne",
            "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
            "<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
            "p, li { white-space: pre-wrap; }\n"
            "p { margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:8pt }\n"
            "</style></head><body style=\" font-family:\'MS Shell Dlg 2\'; font-size:8.25pt; font-weight:400; font-style:normal;\">\n"
            "<h2>Objectifs: </h2>\n"
            "<div > Ce module permet de decouper des lignes en fonction des points. </div>\n"
            "<h2>Données en entrée: </h2>\n"
            "<div > L’utilisateur sélectionne dans la liste déroulante deux shapes : lignes et points </div>\n"
            "<h2 >Résultat: </h2>\n"
            "<div> Un shape de decoupe est remonté dans Qgis</div>\n"
            "<h2 >Contraintes: </h2>\n"
            "<div > La topologie du livrable doit être cohérente, les règles d'accrochage entre les objets doivent respectées </div>\n"
            "</body></html>"))

from qgscheckablecombobox import QgsCheckableComboBox
from qgsdatetimeedit import QgsDateTimeEdit

import os.path
from qgis.core import *
from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5.QtWidgets import *

import psycopg2
import datetime
import importlib
import sys

from ...scripts_python.design.dimensionnement_cables import *

# ------------------------------------------------------------------------------
#    class_general_dialog - base class for dialogs containing utility functions
# ------------------------------------------------------------------------------

class class_general_dialog(QtWidgets.QDialog):
    def __init__(self, iface):
        QtWidgets.QDialog.__init__(self)
        self.iface = iface

    def get_version_plugin(self):
        # folder_plugin = os.path.dirname(os.path.abspath(__file__))
        folder_metada = open(
            folder_plugin + "\metadata.txt")  # open(folder_plugin.replace("forms\design", "\metadata.txt"))
        for line in folder_metada:
            if str(line)[:7] == 'version':
                get_version = line.split('=')[1]
                return get_version
        folder_metada.close()

    def combo_box_with_vector_layers(self, combo_box):
        # Add layers not in the combo box
        for layer in self.iface.mapCanvas().layers():
            if layer.type() == QgsMapLayer.VectorLayer:
                if combo_box.findText(layer.name()) < 0:
                    combo_box.addItem(layer.name())
                    if layer in self.iface.layerTreeView().selectedLayers():
                        combo_box.setCurrentIndex(combo_box.count() - 1)
        # Remove layers no longer on the map
        removed = []
        for index in range(combo_box.count()):
            found = False
            for layer in self.iface.mapCanvas().layers():
                if layer.name() == combo_box.itemText(index):
                    found = True
                    break
            if not found:
                removed.append(index)
        removed.reverse()
        for index in removed:
            combo_box.removeItem(index)

    def find_layer(self, layer_name):
        if not layer_name:
            return None
        layers = QgsProject.instance().mapLayersByName(layer_name)
        if (len(layers) >= 1):
            return layers[0]
        return None

    def get_layer(self, combo_box, vector_layer_name):
        vector_layer = self.find_layer(vector_layer_name.currentText())
        if not vector_layer:
            return
        combo_box.clear()
        for field in vector_layer.fields():
            combo_box.addItem(field.name())


class class_decoupe_dialog(class_general_dialog, Ui_decoupe_ligne):
    def __init__(self, iface):
        class_general_dialog.__init__(self, iface)
        self.setupUi(self)
        self.button_box.button(QtWidgets.QDialogButtonBox.Ok).clicked.connect(self.run)
        self.setWindowTitle("DESIGN " + str(self.get_version_plugin()) + " - Decoupe des Lignes par des Points")

        self.combo_box_with_vector_layers(self.Layer_Ligne)
        self.combo_box_with_vector_layers(self.Layer_Point)

    def refresh_layers(self):
        self.combo_box_with_vector_layers(self.Layer_Ligne)
        self.combo_box_with_vector_layers(self.Layer_Point)

    def run(self):
        ligne_layer = self.find_layer(self.Layer_Ligne.currentText())
        point_layer = self.find_layer(self.Layer_Point.currentText())
        # Declaration Class Principale de Decoupe
        var_Class_Decoup_Line_Points = Class_Decoup_Line_Points()
        var_Class_Decoup_Line_Points.function_create_ligne_decoupe(ligne_layer,point_layer,'','')#var_cb_typelog,var_RAC
        self.function_close_requete_cache()
        QMessageBox.information(self.iface.mainWindow(), "Message dexecution de requete", 'Execution Terminee')