# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'Dialog_IMPORT_BDD2.ui'
#
# Created by: PyQt5 UI code generator 5.11.3
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets
import datetime
from pathlib import Path
from ...params_connexion import *

folder_plugin = str(Path(__file__).parent.parent.parent)


class Ui_check_cable_dialog(object):
    def setupUi(self, check_cable_dialog):
        check_cable_dialog.setObjectName("check_cable_dialog")
        check_cable_dialog.setWindowModality(QtCore.Qt.ApplicationModal)
        check_cable_dialog.setEnabled(True)
        check_cable_dialog.resize(800, 800)  # 1305, 882
        check_cable_dialog.setMouseTracking(False)

        self.verticalLayoutWidget = QtWidgets.QWidget(check_cable_dialog)
        self.verticalLayoutWidget.setGeometry(QtCore.QRect(30, 30, 700, 700))  # 1161, 731
        self.verticalLayoutWidget.setObjectName("verticalLayoutWidget")

        self.verticalLayout = QtWidgets.QVBoxLayout(self.verticalLayoutWidget)
        self.verticalLayout.setContentsMargins(0, 0, 0, 0)
        self.verticalLayout.setObjectName("verticalLayout")

        self.gridLayout = QtWidgets.QGridLayout()
        self.gridLayout.setObjectName("gridLayout")

        self.label_12 = QtWidgets.QLabel(self.verticalLayoutWidget)
        self.label_12.setObjectName("label_12")
        self.gridLayout.addWidget(self.label_12, 0, 0, 1, 1)

        self.label_2 = QtWidgets.QLabel(self.verticalLayoutWidget)
        self.label_2.setObjectName("label_2")
        self.gridLayout.addWidget(self.label_2, 0, 1, 1, 1)

        self.name_pr = QgsCheckableComboBox(self.verticalLayoutWidget)
        self.name_pr.setMinimumSize(QtCore.QSize(106, 0))
        self.name_pr.setObjectName("name_pr")
        self.gridLayout.addWidget(self.name_pr, 1, 0, 1, 1)

        self.name_statut = QgsCheckableComboBox(self.verticalLayoutWidget)
        self.name_statut.setMinimumSize(QtCore.QSize(106, 0))
        self.name_statut.setObjectName("name_statut")
        self.name_statut.addItem("AOR")
        self.name_statut.addItem("DEO")
        self.name_statut.addItem("DEP")
        self.name_statut.addItem("DIU")
        self.name_statut.addItem("DOE")
        self.name_statut.addItem("DET")
        self.name_statut.addItem("EXE")
        self.name_statut.addItem("MCO")
        self.name_statut.addItem("PRO")
        self.gridLayout.addWidget(self.name_statut, 1, 1, 1, 1)

        self.verticalLayout.addLayout(self.gridLayout)

        self.textBrowser = QtWidgets.QTextBrowser(self.verticalLayoutWidget)
        self.textBrowser.setObjectName("textBrowser")
        self.verticalLayout.addWidget(self.textBrowser)

        self.button_box = QtWidgets.QDialogButtonBox(self.verticalLayoutWidget)
        self.button_box.setOrientation(QtCore.Qt.Horizontal)
        self.button_box.setStandardButtons(QtWidgets.QDialogButtonBox.Cancel | QtWidgets.QDialogButtonBox.Ok)
        self.button_box.setObjectName("button_box")
        self.verticalLayout.addWidget(self.button_box)

        self.retranslateUi(check_cable_dialog)
        self.button_box.accepted.connect(check_cable_dialog.accept)
        self.button_box.rejected.connect(check_cable_dialog.reject)
        QtCore.QMetaObject.connectSlotsByName(check_cable_dialog)

    def retranslateUi(self, check_cable_dialog):
        _translate = QtCore.QCoreApplication.translate
        check_cable_dialog.setWindowTitle(
            _translate("check_cable_dialog", "DESIGN v0.01 - Importation des donnees dans la BDD"))
        self.label_12.setText(_translate("check_cable_dialog", "Nom du pr"))
        self.label_2.setText(_translate("check_cable_dialog", "STATUT"))
        self.textBrowser.setHtml(_translate("check_cable_dialog",
            "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
            "<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
            "p, li { white-space: pre-wrap; }\n"
            "p { margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:8pt }\n"
            "</style></head><body style=\" font-family:\'MS Shell Dlg 2\'; font-size:8.25pt; font-weight:400; font-style:normal;\">\n"
            "<h2>Objectifs: </h2>\n"
            "<div > Ce module permet de contrôler le dimensionnement des cables. </div>\n"
            "<h2>Données en entrée: </h2>\n"
            "<div > L’utilisateur sélectionne dans la liste déroulante le livrable qu'il souhaite contrôler sur les points suivants, </div>\n"
            "<div> C01_1 - Calcul du cm_fo_util de la table cheminement àpartir du decoupe des lignes par des points,</div>\n"
            "<div> C02_1 - Verifier que la capacite du cable est coherente avec la capacite utile,</div>\n"
            "<div> C03_1 - Verifier loptimisation des changements de cable,</div>\n"
            "<div> C05_1 - Verifier qu'il n'y a pas de CFI raccordes a des PBO,</div>\n"
            "<div> C06_1_2 - Verifier qu'il n'y a pas de cables de forte capacite inferieurs a 300m + zone radiale,</div>\n"
            "<h2 >Résultat: </h2>\n"
            "<div> La liste des erreurs est remontée, au format de la couche echange, dans la couche audit du schéma sélectionné. </div>\n"
            "<h2 >Contraintes: </h2>\n"
            "<div > La topologie du livrable doit être cohérente, les règles d'accrochage entre les objets doivent respectées </div>\n"
            "</body></html>"))


from qgscheckablecombobox import QgsCheckableComboBox
from qgsdatetimeedit import QgsDateTimeEdit

import os.path
from qgis.core import *
from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5.QtWidgets import *

import psycopg2
import datetime
import importlib
import sys

from ...scripts_python.design.dimensionnement_cables import *


# sys.path.append(os.path.dirname(os.path.abspath(__file__)) + "/forms")# Initialisation du dossier des fichiers de boites de dialogs


# ------------------------------------------------------------------------------
#    class_general_dialog - base class for MMQGIS dialogs containing utility functions
# ------------------------------------------------------------------------------

class class_general_dialog(QtWidgets.QDialog):
    def __init__(self, iface, var_connection):
        QtWidgets.QDialog.__init__(self)
        self.iface = iface
        self.connection = var_connection

    # Function Get layer dans Qgis
    def function_getlayer_QGis(self, layer_name):
        layers = [tree_layer.layer() for tree_layer in QgsProject.instance().layerTreeRoot().findLayers()]
        for layer in layers:
            layerType = layer.type()
            if layerType == QgsMapLayer.VectorLayer:
                if layer.name() == layer_name:
                    return layer

    # Function pour  Get layer dans la BD
    def function_getLayer_bdd(self, schema, table_name, key, rename_table, column_geom):
        # import qgis.core
        uri = QgsDataSourceUri()
        uri.setConnection(host, port, DB, user, MP)#self.host, self.port, self.DB, self.user, self.MP
        uri.setDataSource(schema, table_name, column_geom, '', key)
        layer = QgsVectorLayer(uri.uri(False), rename_table, "postgres")
        if layer.isValid():
            # QgsProject.instance().addMapLayer(layer)
            return layer
        else:
            QMessageBox.critical(self.iface.mainWindow(), "Message", 'Erreur de recuperation de la table : ' + str(table_name))

    # Function pour executer une requete sql dans la base
    def function_execute_requete(self, requete_execute, req_fetch):
        curs = self.connection.cursor()
        try:
            curs.execute(requete_execute)
            if req_fetch:
                data_req = [row for row in curs.fetchall()]
                if data_req:
                    return data_req
        except(Exception, psycopg2.DatabaseError) as error:
            QMessageBox.critical(self.iface.mainWindow(), "Message dexecution de requete",
                                 'Requete Non Executer : ' + str(error) + ' ; ' + str(requete_execute))
        # print("Message dexecution de requete", 'Requete Non Executer : '+str(error)+' ; '+str(requete_execute))
        curs.close()
        # self.connection.commit()

    def get_all_schema_name(self, list_widget):
        req_get_schema = """select 
        schema_name
        from information_schema.schemata
        where schema_name like 'pr%' order by schema_name;"""
        list_schema_name = self.function_execute_requete(req_get_schema, 'bab')
        for index, name_schema in enumerate(list_schema_name):
            if name_schema:
                list_widget.addItem("")
                list_widget.setItemText(index, name_schema[0])

    # Function pour supprimer les requetes en caches dans la BDD
    def function_close_requete_cache(self):
        requete = """--- Function pour supprimer les requetes en caches dans la BDD
                create or replace function delete_req_cache(bdd_name text) returns void as $$
                    declare
                        var_req_execute record;
                    begin
                    FOR var_req_execute in 
                        select 
                            *, 'select pg_terminate_backend('||pid||');' as req_cache
                        from pg_stat_activity 
                        where (state like '%idle in transaction%' or state like '%idle%') and application_name = '' and datname = $1 and client_addr = (select inet_client_addr()) and datname = $1 order by xact_start
                        LOOP
                            if var_req_execute.req_cache is not null then
                                EXECUTE var_req_execute.req_cache;
                            end if;
    
                        END LOOP;
                    end;
                $$ language plpgsql volatile;
                select * from delete_req_cache('MCD_ADN_sans_ct');"""
        self.function_execute_requete(requete, '', self.connection)

    def get_version_plugin(self):
        # folder_plugin = os.path.dirname(os.path.abspath(__file__))
        folder_metada = open(
            folder_plugin + "\metadata.txt")  # open(folder_plugin.replace("forms\design", "\metadata.txt"))
        for line in folder_metada:
            if str(line)[:7] == 'version':
                get_version = line.split('=')[1]
                return get_version
        folder_metada.close()


class class_checkcable_dialog(class_general_dialog, Ui_check_cable_dialog):
    def __init__(self, iface):
        self.var_connection = function_connexion()
        class_general_dialog.__init__(self, iface, self.var_connection)
        self.setupUi(self)
        self.get_all_schema_name(self.name_pr)
        self.setWindowTitle("DESIGN " + str(self.get_version_plugin()) + " - Contrôle des cables")
        self.var_connection.close()
        self.button_box.button(QtWidgets.QDialogButtonBox.Ok).clicked.connect(self.run)

    def run(self):
        list_statut = self.name_statut
        text_statut = [x for x in list_statut.currentText().split(',') if x]
        list_namePR = self.name_pr
        text_namePR = [x for x in list_namePR.currentText().split(',') if x]
        if len(text_statut) != 1 or len(text_namePR) != 1:  # len(text_titulaire) != 1 or  un seul MOE et 
            QMessageBox.critical(self.iface.mainWindow(), "Message Du Choix",
                                 'Veillez cocher un seul STATUT et un seul PR')
        else:
            nom_moe = 'MOE'  # "".join(text_titulaire)
            nom_pr = "".join(text_namePR)
            nom_phase = str("".join(text_statut)).upper()

            var_capaUtile = 'capaUtile'
            var_cb_etiquet = 'cb_etiquet'
            var_CFI = 'CFI'
            var_bp_typelog = 'bp_typelog'
            var_PBO = 'PBO'
            var_bp_etiquet = 'bp_etiquet'
            var_BFI = 'BFI'

            # Variables pour Insert resultats dans t_echange
            schema = nom_pr
            var_MOE = 'MOE'
            var_PR = nom_pr
            var_phase = nom_phase

            # listing_error_control_ADN = []

            # features_cable = self.function_getLayer_bdd(schema, 'vs_elem_cl_cb', 'cb_code', 'vs_elem_cl_cb','geom')
            # features_cable_decoupe_pt = self.function_getLayer_bdd(schema, 'vs_elem_cl_cb', 'cb_code', 'vs_elem_cl_cb','geom')
            # features_boite = self.function_getLayer_bdd(schema, 'vs_elem_bp_pt_nd', 'bp_code', 'vs_elem_bp_pt_nd','geom')
            # features_chem = self.function_getLayer_bdd(schema, 't_cheminement', 'cm_code', 't_cheminement','geom')

            features_cable = self.function_getlayer_QGis('vs_elem_cl_cb')
            features_cable_decoupe_pt = self.function_getlayer_QGis('cable_decoupe')
            features_boite = self.function_getlayer_QGis('vs_elem_bp_pt_nd')
            features_chem = self.function_getlayer_QGis('t_cheminement')

            var_Dimensionnement_Cabless = Dimensionnement_Cables()
            var_Dimensionnement_Cabless.function_C01_1(features_chem, features_cable_decoupe_pt,features_cable,var_capaUtile)
            var_Dimensionnement_Cabless.function_C02_1(features_cable)
            var_Dimensionnement_Cabless.function_C05_1(features_cable, features_boite,var_cb_etiquet, var_CFI, var_bp_typelog, var_PBO, var_bp_etiquet, var_BFI)
            var_Dimensionnement_Cabless.function_C06_1_2(features_cable)
            var_Dimensionnement_Cabless.function_create_tab_shape_erreur_control_design(schema,var_MOE,var_PR,var_phase)
            self.function_close_requete_cache()
            QMessageBox.information(self.iface.mainWindow(), "Message dexecution de requete", 'Execution Terminee')