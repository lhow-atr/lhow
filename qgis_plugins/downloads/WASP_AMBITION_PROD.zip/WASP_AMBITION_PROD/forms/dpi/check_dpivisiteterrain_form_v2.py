# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'Dialog_IMPORT_BDD2.ui'
#
# Created by: PyQt5 UI code generator 5.11.3
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets
import datetime
from pathlib import Path
from ...params_connexion import *

folder_plugin = str(Path(__file__).parent.parent.parent)


class Ui_check_dpivisiteterrain_dialog(object):
	def setupUi(self, check_dpivisiteterrain_dialog):
		check_dpivisiteterrain_dialog.setObjectName("check_dpivisiteterrain_dialog")
		check_dpivisiteterrain_dialog.setWindowModality(QtCore.Qt.ApplicationModal)
		check_dpivisiteterrain_dialog.setEnabled(True)
		check_dpivisiteterrain_dialog.resize(800, 800)#1305, 882
		check_dpivisiteterrain_dialog.setMouseTracking(False)

		self.verticalLayoutWidget = QtWidgets.QWidget(check_dpivisiteterrain_dialog)
		self.verticalLayoutWidget.setGeometry(QtCore.QRect(30, 30, 700, 700))#1161, 731
		self.verticalLayoutWidget.setObjectName("verticalLayoutWidget")

		self.verticalLayout = QtWidgets.QVBoxLayout(self.verticalLayoutWidget)
		self.verticalLayout.setContentsMargins(0, 0, 0, 0)
		self.verticalLayout.setObjectName("verticalLayout")

		self.gridLayout = QtWidgets.QGridLayout()
		self.gridLayout.setObjectName("gridLayout")

		self.label_12 = QtWidgets.QLabel(self.verticalLayoutWidget)
		self.label_12.setObjectName("label_12")
		self.gridLayout.addWidget(self.label_12, 0, 0, 1, 1)

		self.label_2 = QtWidgets.QLabel(self.verticalLayoutWidget)
		self.label_2.setObjectName("label_2")
		self.gridLayout.addWidget(self.label_2, 0, 1, 1, 1)

		self.name_pr = QgsCheckableComboBox(self.verticalLayoutWidget)
		self.name_pr.setMinimumSize(QtCore.QSize(106, 0))
		self.name_pr.setObjectName("name_pr")
		self.gridLayout.addWidget(self.name_pr, 1, 0, 1, 1)

		self.vt_directory = gui.QgsFileWidget(check_dpivisiteterrain_dialog)
		self.vt_directory.setObjectName("vt_directory")
		self.gridLayout.addWidget(self.vt_directory, 1, 1, 1, 1)

		self.verticalLayout.addLayout(self.gridLayout)

		self.textBrowser = QtWidgets.QTextBrowser(self.verticalLayoutWidget)
		self.textBrowser.setObjectName("textBrowser")
		self.verticalLayout.addWidget(self.textBrowser)

		self.button_box = QtWidgets.QDialogButtonBox(self.verticalLayoutWidget)
		self.button_box.setOrientation(QtCore.Qt.Horizontal)
		self.button_box.setStandardButtons(QtWidgets.QDialogButtonBox.Cancel|QtWidgets.QDialogButtonBox.Ok)
		self.button_box.setObjectName("button_box")
		self.verticalLayout.addWidget(self.button_box)

		self.retranslateUi(check_dpivisiteterrain_dialog)
		self.button_box.accepted.connect(check_dpivisiteterrain_dialog.accept)
		self.button_box.rejected.connect(check_dpivisiteterrain_dialog.reject)
		QtCore.QMetaObject.connectSlotsByName(check_dpivisiteterrain_dialog)

	def retranslateUi(self, check_dpivisiteterrain_dialog):
		_translate = QtCore.QCoreApplication.translate
		check_dpivisiteterrain_dialog.setWindowTitle(_translate("check_dpivisiteterrain_dialog", "DESIGN v0.01 - Importation des donnees dans la BDD"))
		self.label_12.setText(_translate("check_dpivisiteterrain_dialog", "Nom du pr"))
		self.label_2.setText(_translate("check_dpivisiteterrain_dialog", "Dossier Shape Terrain"))
		self.textBrowser.setHtml(_translate("check_dpivisiteterrain_dialog", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
	"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
	"p, li { white-space: pre-wrap; }\n"
	"p { margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:8pt }\n"
	"</style></head><body style=\" font-family:\'MS Shell Dlg 2\'; font-size:8.25pt; font-weight:400; font-style:normal;\">\n"
	"<h2>Objectifs: </h2>\n"
	"<div > Ce module permet d'intégrer en base de données les informations issues du contre-relevé terrain, et de les comparer avec les informations renseignées dans les études aériennes réalisées par l'entreprise. </div>\n"
	"<h2>Données en entrée: </h2>\n"
	"<div > L'utilisateur selectionne le livrable pour lequel il souhaite intégrer les informations terrain, ainsi que le chemin du répertoire dans lequel il souhaite exporter les shapefiles qui identifie les incohérences. </div>\n"
	"<h2 >Résultat: </h2>\n"
	"<div> Les couches a_appuibt_delta et a_appuift_delta sont enregistrées en base de données, et exportées au format Shapefiles dans le dossier cible. </div>\n"
	"<div> Les appuis considérés comme NOK sont les appuis jugés 'non utilisable' dans la fiche appuis, dont l'état est 'ME' dans le MCD,  dont l'état est 'ME', ou  'HS' dans le MCD avec un câble et dont la capacité est supérieure. ou égale à 48FO.</div>\n"
	"<h2 >Contraintes: </h2>\n"
	"<div > Le format des Shapefiles doit etre identique à celui exporter avec le module d'intégration des caractéristiques d'appuis. </div>\n"
	"</body></html>"))

from qgscheckablecombobox import QgsCheckableComboBox
from qgsdatetimeedit import QgsDateTimeEdit
from qgis import gui


import os.path
from qgis.core import *
from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5.QtWidgets import *

	
# import psycopg2
# import datetime
# import importlib
# import sys

from ...scripts_python.dpi.analyse_fiche_dpi_v3 import *


# ------------------------------------------------------------------------------
#    class_general_dialog - base class for dialogs containing utility functions
# ------------------------------------------------------------------------------

class class_general_dialog(QtWidgets.QDialog):
	def __init__(self, iface, var_connection):
		QtWidgets.QDialog.__init__(self)
		self.iface = iface
		self.connection = var_connection

	# Function pour executer une requete sql dans la base
	def function_execute_requete(self, requete_execute, req_fetch):
		curs = self.connection.cursor()
		try:
			curs.execute(requete_execute)
			if req_fetch:
				data_req=[row for row in curs.fetchall()]
				if data_req:
					return data_req
		except(Exception, psycopg2.DatabaseError) as error:
			QMessageBox.critical(self.iface.mainWindow(), "Message dexecution de requete",
								 'Requete Non Executer : '+str(error)+' ; '+str(requete_execute))
			self.connection.commit()
		curs.close()

	def get_all_schema_name(self, list_widget):
		req_get_schema = """select 
			schema_name
		from information_schema.schemata
		where schema_name like 'pr%' order by schema_name;"""
		
		list_schema_name = self.function_execute_requete(req_get_schema, 'bab')
		
		for index, name_schema in enumerate(list_schema_name):
			if name_schema:
				list_widget.addItem("")
				list_widget.setItemText(index, name_schema[0])

	def get_version_plugin(self):
		# folder_plugin = os.path.dirname(os.path.abspath(__file__))
		folder_metada  = open(folder_plugin + "\metadata.txt")#open(folder_plugin.replace("forms\dpi", "\metadata.txt"))
		for line in folder_metada :
			if str(line)[:7] == 'version':
				get_version = line.split('=')[1]
				return get_version
		folder_metada .close()


class class_checkdpiVt_dialog_v2(class_general_dialog, Ui_check_dpivisiteterrain_dialog):
	def __init__(self, iface):
		self.var_connection = function_connexion()
		class_general_dialog.__init__(self, iface, self.var_connection)
		self.setupUi(self)
		self.get_all_schema_name(self.name_pr)
		self.setWindowTitle("DESIGN " + str(self.get_version_plugin()) + " - Intégration des contre-relevés terrain")
		self.vt_directory.setStorageMode(gui.QgsFileWidget.GetDirectory)
		self.var_connection.close()
		self.button_box.button(QtWidgets.QDialogButtonBox.Ok).clicked.connect(self.run)

	def run(self):
		list_namePR = self.name_pr
		text_namePR = [x for x in list_namePR.currentText().split(',') if x]

		if len(text_namePR) != 1:
			QMessageBox.critical(self.iface.mainWindow(), "Message Du Choix", 'Veillez cocher un seul PR')
		else:
			schema = "".join(text_namePR)
			path_folder_vT = str(self.vt_directory.filePath())
			# function_retour_vt(schema, path_folder_vT)
			# function_execute_retourvt(schema, path_folder_vT)
			function_execute_retourvt(schema, path_folder_vT)

