#pyuic5 test_ui.ui -o test_ui.py
def classFactory(iface):
	from .class_file_general_menu import class_generale_menu
	return class_generale_menu(iface)
