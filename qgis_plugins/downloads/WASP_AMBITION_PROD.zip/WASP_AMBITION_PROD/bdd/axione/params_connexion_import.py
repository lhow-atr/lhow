# # Server Axione
# DB = 'axione_siea'
# user = 'admambigroup'
# MP = 'secure'
# host = '213.32.75.108'
# port = '5432'


# Server Axione ATR
DB = 'axione_siea'
user = 'ATR'
MP = '6570IRjg0qf$'
host = '213.32.75.108'
port = '5432'


# # Server Axione CDP
# DB = 'axione_siea'
# user = 'CDP'
# MP = '6570IRjg0qf$'
# host = '213.32.75.108'
# port = '5432'
