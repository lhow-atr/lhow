from .class_file_global_menu import *
from .vidange_cache_qgis import *
from .forms.check_appview_form import *
from .forms.check_boite_form import *
from .forms.check_cables_form import *
from .forms.check_design_form import *
from .forms.check_formalisme_form import *
from .forms.check_upnview_form import *
from .forms.creation_model import *
from .forms.decoupe_ligne_point import *
from .forms.form_import_bdd import *
from .forms.importBDD_form import class_import_dialog


class ClassGeneraleMenu:
    def __init__(self, iface):
        self.iface = iface
        self.name_menu_projet = var_class_init_custom_menu_bar.funct_add_submenu_projet_to_global(ambition_menu, 'ADN')
        self.name_groupe_design = "A.1. Contrôle DESIGN"
        self.name_groupe_modelisation = "A.4. Modélisation"

    def initGui(self):
        res_vidange = function_delete_cache_qgis()
        if res_vidange[1] is False:
            QMessageBox.warning(QWidget(), "Message dexecution de requete", 'Le cache nest pas vide ... ' +
                                str(res_vidange))
        self.controle_design = var_class_init_custom_menu_bar.func_add_submenu_group_to_projet(self.name_menu_projet,
                                                                                               self.name_groupe_design)
        var_class_init_custom_menu_bar.func_add_action_menu(self.controle_design,
                                                            "A.1.1 Import des données", self.exe_import_bdd_class)
        var_class_init_custom_menu_bar.func_add_action_menu(self.controle_design,
                                                            "A.1.2 Contrôle des DESIGN",
                                                            self.exe_class_checkdesignD0_dialog)
        var_class_init_custom_menu_bar.func_add_action_menu(self.controle_design,
                                                            "A.1.3 Contrôle des BOITES",
                                                            self.exe_class_checkboite_dialog)
        var_class_init_custom_menu_bar.func_add_action_menu(self.controle_design,
                                                            "A.1.4 Contrôle du FORMAT",
                                                            self.exe_class_checkformalisme_dialog)
        var_class_init_custom_menu_bar.func_add_action_menu(self.controle_design,
                                                            "A.1.5 Contrôle des CABLES",
                                                            self.exe_class_checkcable_dialog)
        var_class_init_custom_menu_bar.func_add_action_menu(self.controle_design,
                                                            "A.1.6 Génération du projet QGIS",
                                                            self.exe_class_checkappview_dialog)
        var_class_init_custom_menu_bar.func_add_action_menu(self.controle_design,
                                                            "A.1.7 Spatialisation UPNVIEW (abandonné)",
                                                            self.exe_class_checkupnview_dialog)

        # # ADN Menu MODELISATION
        self.modelisation_menu = var_class_init_custom_menu_bar.func_add_submenu_group_to_projet(self.name_menu_projet,
                                                                                     self.name_groupe_modelisation)
        var_class_init_custom_menu_bar.func_add_action_menu(self.modelisation_menu,
                                                            "A.4.1. Modélisation du réseau",
                                                            self.exe_class_create_mode_dialog)
        var_class_init_custom_menu_bar.func_add_action_menu(self.modelisation_menu,
                                                            "A.4.2 Découpe des lignes en fonction des points",
                                                            self.exe_class_decoupe_dialog)
        var_class_init_custom_menu_bar.func_add_action_menu(self.modelisation_menu,
                                                            "A.4.3. Import des shapefiles dans la BDD",
                                                            self.exe_class_impor_bbd_shp_dialog)

    def unload(self):
        self.iface.removePluginMenu(self.name_groupe_design, self.controle_design.menuAction())
        self.iface.removePluginMenu(self.name_groupe_modelisation, self.modelisation_menu.menuAction())

    def exe_import_bdd_class(self):
        self.baba_dialog = class_import_dialog(self.iface)
        self.baba_dialog.exec_()

    def exe_class_checkdesignD0_dialog(self):
        self.execheckdesign = class_checkdesignD0_dialog(self.iface)
        self.execheckdesign.exec_()

    def exe_class_checkupnview_dialog(self):
        self.execheckupnview = class_checkupnview_dialog(self.iface)
        self.execheckupnview.exec_()

    def exe_class_checkboite_dialog(self):
        self.execheckboite = class_checkboite_dialog(self.iface)
        self.execheckboite.exec_()

    def exe_class_checkformalisme_dialog(self):
        self.execheckformalisme = class_checkformalisme_dialog(self.iface)
        self.execheckformalisme.exec_()

    def exe_class_checkappview_dialog(self):
        self.execheckappview = class_checkappview_dialog(self.iface)
        self.execheckappview.exec_()

    # Modelisation du reseau
    def exe_class_create_mode_dialog(self):
        self.exemodel = class_create_mode_dialog(self.iface)
        self.exemodel.exec_()

    # Decoupe des lignes en fonction des points
    def exe_class_decoupe_dialog(self):
        try:
            self.exedecoupe.refresh_layers()
        except:
            self.exedecoupe = class_decoupe_dialog(self.iface)
        self.exedecoupe.exec_()

    # Import des shapefiles dans la BDD
    def exe_class_impor_bbd_shp_dialog(self):
        self.execlass_impor_bbd_shp_dialog = class_impor_bbd_shp_dialog(self.iface)
        self.execlass_impor_bbd_shp_dialog.exec_()

    # Controle des cables
    def exe_class_checkcable_dialog(self):
        self.execable = class_checkcable_dialog(self.iface)
        self.execable.exec_()
