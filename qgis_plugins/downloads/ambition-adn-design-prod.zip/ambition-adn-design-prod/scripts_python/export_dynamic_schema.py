import psycopg2
import xlwt
from qgis.PyQt.QtCore import *
from qgis.PyQt.QtGui import *
from qgis.PyQt.QtWidgets import *
from qgis.utils import iface, Qgis

# Server Prod
DB = 'MCD_ADN_sans_ct'
user = 'adn_ing'
MP = 'password'
host = '192.168.30.194'
port = '5432'


# Class pour les fonctions generales
class GeneralFunctions:
    w = QWidget()

    # Function pour la progession bar1
    def progress_bar(self, name_etape):
        prog = QProgressDialog(name_etape + ' : Veillez Patienter', 'Cancel', 0, 100)
        prog.setWindowModality(Qt.WindowModal)
        prog.setMinimumDuration(1)
        return prog

    # Function pour la progession bar2
    def progress_processing(self, index, count_entite, progress_dialog):
        f = int(index + 1)
        pcnt = int(f / count_entite * 100 / 1)
        progress_dialog.setValue(pcnt)

    # Function pour executer une requete sql dans la base
    def function_execute_requete(self, requete_execute, req_fetch, connection):
        curs = connection.cursor()
        try:
            curs.execute(requete_execute)
            if req_fetch:
                data_req = [row for row in curs.fetchall()]
                if data_req:
                    return data_req
        except(Exception, psycopg2.DatabaseError) as error:
            QMessageBox.warning(self.w, "Message dexecution de requete",
                                'Requete Non Executer : ' + str(error) + ' ; ' + str(requete_execute))
        curs.close()

    # Function pour ajouter des feuilles dans EXCEl
    def function_create_sheet(self, wb, list_user_export, header, ws_workbook):
        # Execution de la bar
        bar_progress = self.progress_bar('Export des erreurs de Controls')
        # ws_workbook = wb.add_sheet('test', cell_overwrite_ok=True)
        if list_user_export:
            for index_liste, k in enumerate(list_user_export):
                for colx, value in enumerate(k):
                    ws_workbook.write(index_liste + 1, colx, str(value))
                self.progress_processing(index_liste, len(list_user_export), bar_progress)
                if bar_progress.wasCanceled():
                    iface.messageBar().pushMessage('Info', 'Action Cancelled', level=Qgis.Info)
                    break
        colIdx = 0  # Start from Column 0
        font_style = xlwt.XFStyle()
        font_style.font.bold = True
        for indData in header:
            col = ws_workbook.col(colIdx)
            col.width = 256 * 20
            ws_workbook.write(0, colIdx, indData, font_style)  # Insert in First Row ( Row 0)
            colIdx = colIdx + 1

    # Function pour exporter les fichiers de mauavis format
    def function_export_error_fichier(self, var_list_erreur, var_folder_export_error_fichier, var_name_file):
        if var_list_erreur:
            xlsfile_res = var_folder_export_error_fichier + "/" + var_name_file + ".xls"
            wb = xlwt.Workbook(encoding="UTF-8")
            ws_workbook = wb.add_sheet('test', cell_overwrite_ok=True)
            # for index_erreur in range(0, len(var_list_erreur)):
            self.function_create_sheet(wb, var_list_erreur, ['Colonne'], ws_workbook)
            wb.save(xlsfile_res)

    # Function pour ajouter des feuilles dans EXCEl
    def function_export_res_excel_feuille(self, list_user_export, Header, ws_workbook):
        # Execution de la bar
        bar_progress = self.progress_bar('Export des erreurs de Controls')
        # ws_workbook = wb.add_sheet(sheet_name, cell_overwrite_ok=True)
        if list_user_export:
            if len(list_user_export) > 65535:
                QMessageBox.information(self.w, "Message dexport du resultat",
                                        'Le sheet ' + 'test' + ' a des valeurs superieurs a ' + '65535, '
                                                                                                'donc on importe une impartie des resultats dans la base')
            for index_liste, k in enumerate(list_user_export[:65535]):  # list_cable_finale list_pb_user
                for colx, value in enumerate(k):
                    ws_workbook.write(index_liste + 1, colx, str(value)[:32766])
                    self.progress_processing(index_liste, len(list_user_export), bar_progress)
                    if bar_progress.wasCanceled():
                        iface.messageBar().pushMessage('Info', 'Action Cancelled', level=Qgis.Info)
                        break

        colIdx = 0  # Start from Column 0
        font_style = xlwt.XFStyle()
        font_style.font.bold = True
        for indData in Header:
            col = ws_workbook.col(colIdx)
            col.width = 256 * 20
            ws_workbook.write(0, colIdx, indData, font_style)  # Insert in First Row ( Row 0)
            colIdx = colIdx + 1


class ExportDynamicSchema(GeneralFunctions):
    # Constructeur des variables qui change
    def __init__(self, var_connection):
        self.connection = var_connection

    def function_export_dynamic_schema(self):
        req = """Create or replace Function export_dynamic_schema()
            Returns table (table_schema_cm text, table_name_cm text, schem_name_zs text, 
                table_name_zs text, req text) as 
        $$
        begin Return Query execute
            'select 
                chem.table_schema::text as table_schema_cm,
                chem.table_name::text as table_name_cm,
                zsro.table_schema::text as schem_name_zs,
                zsro.table_name::text as table_name_zs,
                ''select 
                    cm.*,
                    left(''''''||chem.table_schema||'''''', 7) as atr_pr, 
                    zs.zs_refpm as zs_refpm,
                    zs.zs_nblogmt as atr_zsro_lgt,
                    st_length(cm.geom) as atr_long 
                from ''||chem.table_schema||''.t_cheminement cm 
                    left join ''||chem.table_schema||''.t_zsro zs on st_dwithin(cm.geom, zs.geom, 0.1)''::text as req
                
            from information_schema.tables as chem
                left join (select 
                        table_schema,
                        table_name
                    from information_schema.tables 
                    where table_schema like ''%exe%'' and table_name = ''t_zsro'' and (LENGTH(table_schema) = 22 or LENGTH(table_schema) = 21)
                    order by table_schema desc) as zsro on zsro.table_schema = chem.table_schema
            where chem.table_schema like ''%exe%'' and chem.table_name = ''t_cheminement'' and (LENGTH(chem.table_schema) = 22 or LENGTH(chem.table_schema) = 21)
            order by chem.table_schema desc';
        End;
        $$ language plpgsql;
        
        -- select * from export_dynamic_schema();
        
        CREATE OR REPLACE FUNCTION execute_export_dynamic_schema()
         RETURNS void AS
        $$
        DECLARE
            -----Declaration du variable cursor
            row record;
            qry varchar := '';
        BEGIN
            FOR row IN select req  from export_dynamic_schema()
            LOOP
                -- RAISE NOTICE '%' , row.req;
                IF length(qry) > 0 THEN
                  qry := qry|| ' UNION ALL ';
                END IF;
                qry := qry || row.req;
            END LOOP;
            RAISE NOTICE '%' , qry;
            EXECUTE 'CREATE TABLE public.export_dynamic_schema_res as '|| qry;
        END;
        $$
        LANGUAGE plpgsql;
        
        select * from execute_export_dynamic_schema()
        
        -- \COPY public.export_dynamic_schema_res TO '\Users\babacar.fassa\Desktop\LFD\BDD\folder_import_test\export\export_res.csv' DELIMITER ';' CSV HEADER ENCODING 'UTF8';
        """

        res_requete = self.function_execute_requete(req, 'res', self.connection)
        var_folder_export_error_fichier = r'C:\Users\babacar.fassa\Desktop\LFD\BDD\folder_import_test\export\export_schema_dynamic.xls'
        var_name_file = 'export_schema_dynamic'
        list_export_resultat = []
        Header_cm_pt_or_ex = []
        wb = xlwt.Workbook(encoding="UTF-8")
        ws_workbook = wb.add_sheet('test_sheet', cell_overwrite_ok=True)
        for index_export in range(len(res_requete)):
            requete_chem_zsro = res_requete[index_export][4]
            res_requete_chem_zsro = self.function_execute_requete(requete_chem_zsro, 'res', self.connection)
            # self.function_export_res_excel_feuille(res_requete_chem_zsro, Header_cm_pt_or_ex, ws_workbook)
            # list_export_resultat.append(res_requete_chem_zsro)
            # break
            # print(res_requete_chem_zsro)
            # break
        # print(list_export_resultat)
        # self.function_export_error_fichier(list_export_resultat, var_folder_export_error_fichier, var_name_file)

        # for feat in list_export_resultat:
        #     self.function_export_res_excel_feuille(feat, Header_cm_pt_or_ex, ws_workbook)
        wb.save(var_folder_export_error_fichier)


def function_execute_exportdynamicschema():
    global DB, user, MP, host, port
    w = QWidget()
    # Connexion a la base
    try:
        connection = psycopg2.connect(user=user, password=MP, host=host, port=port, database=DB)
    except(Exception, psycopg2.DatabaseError) as error:
        return QMessageBox.warning(w, "Message de connexion de la base", 'Erreur de connexion de la base')

    var_exportdynamicschema = ExportDynamicSchema(connection)
    var_exportdynamicschema.function_export_dynamic_schema()

# function_execute_exportdynamicschema()
