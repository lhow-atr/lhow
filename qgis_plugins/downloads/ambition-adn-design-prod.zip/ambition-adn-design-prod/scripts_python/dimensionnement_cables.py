# -*- coding: utf-8 -*-
import datetime
from collections import defaultdict

import networkx as nx
from qgis.PyQt.QtCore import *
from qgis.PyQt.QtGui import *
from qgis.PyQt.QtWidgets import *
from qgis.core import *
from qgis.utils import *
from shapely.geometry import Point, LineString

from bdd.params_connexion import *

global DB, user, MP, host, port

# Connexion a la base
w = QWidget()

try:
    connection = psycopg2.connect(user=user, password=MP, host=host, port=port, database=DB)
except(Exception, psycopg2.DatabaseError) as error:  # psycop2
    QMessageBox.warning(w, "Message de connexion de la base", 'Erreur de connexion de la base')


class Modelisation_Reseau():
    def __init__(self, var_schema, var_type_sitetech_depart, var_t_noeud,
                 var_vs_elem_cl_cb, var_vs_elem_st_nd,
                 var_st_typelog, var_nd_code, var_cb_code, var_geom, var_distance_buffer, var_st_nom,
                 var_list_shape_cable, var_listshape_noeud, var_vs_elem_sf_nd, var_sfndcode, var_cbcapafo,
                 var_cbtypelog,
                 var_sfcode, var_ptcode, var_vs_elem_pt_nd, var_t_cheminement, var_name_boites, var_atr_bpcode):

        self.schema = var_schema
        self.type_sitetech_depart = var_type_sitetech_depart  # 'NRO+SROL'
        self.name_point = var_t_noeud  # 't_noeud'
        self.name_line = var_vs_elem_cl_cb  # 'vs_elem_cl_cb'
        self.name_sro = var_vs_elem_st_nd  # 'vs_elem_st_nd'
        self.name_point_technique = var_vs_elem_pt_nd  # 'vs_elem_pt_nd'
        self.name_cheminement = var_t_cheminement
        self.name_boites = var_name_boites
        self.var_atr_bpcode = var_atr_bpcode
        # self.name_cable = var_correction_daccrochge#'correction_daccrochage'
        self.var_atr_typelog = var_st_typelog  # 'st_typelog'
        self.name_point_attribut = var_nd_code  # 'nd_code'
        self.name_line_attribut = var_cb_code  # 'cb_code'
        self.geom_attribut = var_geom  # 'geom'
        self.name_sro_attribut = var_st_nom  # 'st_nom'
        self.distance_buffer = var_distance_buffer  # '0.1'
        self.list_shape_cable = var_list_shape_cable
        self.listshape_noeud = var_listshape_noeud
        self.name_suf = var_vs_elem_sf_nd  # 'vs_elem_sf_nd'
        self.var_atr_sfndcode = var_sfndcode  # 'sf_nd_code'
        self.var_atr_capacite = var_cbcapafo  # 'cb_capafo'
        self.var_atr_cbtypelog = var_cbtypelog  # 'cb_capafo'
        self.var_atr_sfcode = var_sfcode  # 'var_sfcode'
        self.var_atr_ptcode = var_ptcode  # 'p_tcode'
        # self.CreateGroupName = var_ResultatsTraitement#'var_sfcode'
        # self.CreateGroupNameName = var_ResultatsTraitement2#'var_sfcode'

        self.createExtremite = "Extremite"
        self.createOrigine = "Origine"
        # self.CreateGroupName = 'ResultatsTraitement'

        self.ErreurSensAccroche = "Erreur_Sens_Accroche"
        self.CreatePoint_Network = "Point_Network"

    w = QWidget()

    # Function pour la progession bar1
    def progress_bar(self, name_etape):
        prog = QProgressDialog(name_etape + ' : Veillez Patienter', 'Cancel', 0, 100)
        prog.setWindowModality(Qt.WindowModal)
        prog.setMinimumDuration(1)
        return prog

    # Function pour la progession bar2
    def progress_processing(self, index, count_entite, progress_dialog):
        f = int(index + 1)
        pcnt = int(f / count_entite * 100 / 1)
        progress_dialog.setValue(pcnt)

    # Function pour  Get layer dans la BD
    def function_getLayer_bdd(self, schema, table_name, key, rename_table, column_geom):
        # import qgis.core
        global DB, user, MP, host, port
        uri = QgsDataSourceUri()
        uri.setConnection(host, port, DB, user, MP)
        uri.setDataSource(schema, table_name, column_geom, '', key)
        layer = QgsVectorLayer(uri.uri(False), rename_table, "postgres")
        if layer.isValid():
            # QgsProject.instance().addMapLayer(layer)
            return layer

    # Function Get layer dans Qgis
    def function_getlayer_QGis(self, layer_name):
        layers = [tree_layer.layer() for tree_layer in QgsProject.instance().layerTreeRoot().findLayers()]  # Pyqgis3
        for layer in layers:
            layerType = layer.type()
            if layerType == QgsMapLayer.VectorLayer:
                if layer.name() == layer_name:
                    return layer

    # Function GetLayer In Group
    def GetLayerByGroup(self, nameGroup, nameLayer):
        root = QgsProject.instance().layerTreeRoot()
        group = root.findGroup(nameGroup)
        layers = [tree_layer.layer() for tree_layer in root.findLayers()]
        if not group is None:
            for child in group.children():
                layer_name = child.name()
                if layer_name == nameLayer:
                    return self.function_getlayer_QGis(nameLayer)

    # Funciton de creations des noms des groups
    def function_create_groupe_name(self, name_groupe):
        root = QgsProject.instance().layerTreeRoot()
        group = root.findGroup(name_groupe)
        if group is not None:
            for child in group.children():
                QgsProject.instance().removeMapLayer(child.layerId())
        root.removeChildNode(group)
        shapeGroup = root.addGroup(name_groupe)
        return shapeGroup

    # Function pour ajouter les tables dans leur groupe respectif
    def function_add_layer_group(self, layer_to_add, groupe_name):
        notre_entite = len(list(layer_to_add.getFeatures()))
        if notre_entite > 0:
            QgsProject.instance().addMapLayer(layer_to_add, False)
            groupe_name.insertChildNode(0, QgsLayerTreeLayer(layer_to_add))

    # Function pour corriger les erreurs d'accrochage ligne et point
    def function_accrochage_lines_to_point(self):

        bar_progress = self.progress_bar('Correction Accrochage Line et Point')

        layershape_point_technique = self.function_getLayer_bdd(self.schema, self.name_point, self.name_point_attribut,
                                                                self.name_point, self.geom_attribut)
        layershape_support = self.function_getLayer_bdd(self.schema, self.name_line, self.name_line_attribut,
                                                        self.name_line, self.geom_attribut)

        correction_daccrochage = QgsVectorLayer("LineString?crs=epsg:2154", layershape_support.name(), "memory")
        correction_daccrochage_pr2 = correction_daccrochage.dataProvider()
        correction_daccrochage_attr2 = layershape_support.dataProvider().fields().toList()
        correction_daccrochage_pr2.addAttributes(correction_daccrochage_attr2)
        correction_daccrochage.updateFields()

        geoms_point = {}  # dict()
        index_point = QgsSpatialIndex()
        for current, f in enumerate(layershape_point_technique.getFeatures()):
            geom_point = f.geometry()
            if geom_point != NULL or geom_point.isGeosValid():
                geoms_point[f.id()] = geom_point
                index_point.insertFeature(f)

        layershape_support_count = layershape_support.featureCount()
        for index_shape_support, shape_support in enumerate(layershape_support.getFeatures()):

            res_originee = 'KO'
            res_extremitee = 'KO'

            geom_support = shape_support.geometry()

            if geom_support != NULL or geom_support.isGeosValid():

                if geom_support.wkbType() == QgsWkbTypes.MultiLineString:
                    geom_support_type = geom_support.asMultiPolyline()
                    support_origine = geom_support_type[0][0]
                    support_extremite = geom_support_type[-1][-1]

                if geom_support.wkbType() == QgsWkbTypes.LineString:
                    geom_support_type = geom_support.asPolyline()
                    support_origine = geom_support_type[0]
                    support_extremite = geom_support_type[-1]

                point_features = index_point.intersects(geom_support.boundingBox())
                if point_features:
                    for candidate_id in point_features:
                        geomPointIntersects = geoms_point[candidate_id]
                        if geomPointIntersects != NULL or geomPointIntersects.isGeosValid():

                            if (QgsGeometry.fromPointXY(QgsPointXY(support_origine))).equals(geomPointIntersects):
                                res_originee = 'OK'
                            if (QgsGeometry.fromPointXY(QgsPointXY(support_extremite))).equals(geomPointIntersects):
                                res_extremitee = 'OK'

                if res_originee == 'KO' or res_extremitee == 'KO':
                    if point_features:
                        for candidate_id2 in point_features:
                            geomPointIntersects2 = geoms_point[candidate_id2]
                            if geomPointIntersects2 != NULL or geomPointIntersects2.isGeosValid():
                                geom_pt_type = geomPointIntersects2.asPoint()
                                if (QgsGeometry.fromPointXY(QgsPointXY(support_origine))).within(
                                        geomPointIntersects2.buffer((float(self.distance_buffer)),
                                                                    (float(self.distance_buffer)))):
                                    # geom_support_type.insert(0,geom_pt_type) #Mode accrochage avec ajout de vertext
                                    for i, geom_vertex_lines in enumerate(geom_support_type):
                                        if geom_vertex_lines == support_origine:
                                            geom_support_type[i] = geom_pt_type
                                if (QgsGeometry.fromPointXY(QgsPointXY(support_extremite))).within(
                                        geomPointIntersects2.buffer((float(self.distance_buffer)),
                                                                    (float(self.distance_buffer)))):
                                    # geom_support_type.append(geom_pt_type) #Mode accrochage avec ajout de vertext
                                    for i, geom_vertex_lines in enumerate(geom_support_type):
                                        if geom_vertex_lines == support_extremite:
                                            geom_support_type[i] = geom_pt_type

                ft = QgsFeature()
                if geom_support.wkbType() in [QgsWkbTypes.MultiLineString, QgsWkbTypes.LineString]:
                    polyline = QgsGeometry.fromPolylineXY(geom_support_type)
                    ft.setAttributes(shape_support.attributes())
                    ft.setGeometry(polyline)
                    correction_daccrochage_pr2.addFeatures([ft])

            self.progress_processing(index_shape_support, layershape_support_count, bar_progress)
            if bar_progress.wasCanceled():
                iface.messageBar().pushMessage('Info', 'Action Cancelled', level=Qgis.Info)
                break

        # QgsProject.instance().addMapLayer(correction_daccrochage)

        return correction_daccrochage

    # Function Delete Duplicate geometry
    def function_delete_duplicate_geom(self):
        source = self.function_accrochage_lines_to_point()
        features = source.getFeatures(QgsFeatureRequest().setSubsetOfAttributes([]))

        features_single_geom = QgsVectorLayer("LineString?crs=epsg:2154", source.name(), "memory")
        features_single_geom_pr2 = features_single_geom.dataProvider()
        features_single_geom_attr2 = source.dataProvider().fields().toList()
        features_single_geom_pr2.addAttributes(features_single_geom_attr2)
        features_single_geom.updateFields()

        geoms = dict()
        null_geom_features = set()
        index = QgsSpatialIndex()
        for current, f in enumerate(features):

            if not f.hasGeometry():
                null_geom_features.add(f.id())
                continue

            geoms[f.id()] = f.geometry()
            index.addFeature(f)

        unique_features = dict(geoms)

        for feature_id, geometry in geoms.items():

            if feature_id not in unique_features:
                # feature was already marked as a duplicate
                continue

            candidates = index.intersects(geometry.boundingBox())
            candidates.remove(feature_id)

            for candidate_id in candidates:
                if candidate_id not in unique_features:
                    continue

                if geometry.isGeosEqual(geoms[candidate_id]):
                    # candidate is a duplicate of feature
                    del unique_features[candidate_id]

        distinct_geoms = set(unique_features.keys())
        output_feature_ids = distinct_geoms.union(null_geom_features)

        request = QgsFeatureRequest().setFilterFids(list(output_feature_ids)).setFlags(QgsFeatureRequest.NoGeometry)
        for current, f in enumerate(source.getFeatures(request)):
            if f.id() not in null_geom_features:
                f.setGeometry(unique_features[f.id()])
            features_single_geom_pr2.addFeature(f)

        return features_single_geom

    # Return Not Null Value attribut
    def return_Not_Null(self, field):
        if field == NULL:
            return 'Identifiant NULL pour cette entite'
        else:
            return field

    # Function Parcours sens du cable
    def function_cable_parcours_sens(self, depart_origine_support, pt_amont, ordre, niveau, distance):
        pt_aval = ""
        if niveau < 100000:
            for index_shape_cable, shape_cable in enumerate(self.list_shape_cable):
                # On ne prend que les supports non parcourus dont lorigine est le point dorigine est depart_origine_support
                if (shape_cable[1] == depart_origine_support) and (shape_cable[3] == 0):
                    # le support est dans le bon sens
                    shape_cable[3] = 1
                    # on verifie si il y a un point technique en extremite de ce support
                    ptextremite_good_sens = 0
                    for shape_noeud in self.listshape_noeud:
                        if shape_cable[2] == shape_noeud[1]:
                            # print (shape_cable[0],';',shape_noeud[1],shape_cable[2])
                            # si il y a un point technique en extremite, on recommence la reursion a partir de ce point
                            ptextremite_good_sens = 1
                            self.function_cable_parcours_sens(shape_cable[2], shape_noeud[0], ordre, niveau + 1,
                                                              shape_cable[10] + distance)
                            pt_aval = self.return_Not_Null(shape_noeud[0])
                            shape_noeud[5] = distance

                    shape_cable[4] = self.return_Not_Null(pt_amont)
                    shape_cable[5] = self.return_Not_Null(pt_aval)

                # On ne prend que les supports non parcourus dont l'extremite est le point dorigine est depart_origine_support
                elif (shape_cable[2] == depart_origine_support) and (shape_cable[3] == 0):
                    # le support nest pas dans le bon sens
                    shape_cable[3] = -1
                    # on verifie si il y a un point technique en extremite en fait origine) de ce support
                    ptextremite_bad_sens = 0
                    for shape_noeud in self.listshape_noeud:
                        if shape_cable[1] == shape_noeud[1]:
                            # si il y a un point technique en extremite (en fait origine), on recommence la recursion a partir de ce point
                            ptextremite_bad_sens = 1
                            self.function_cable_parcours_sens(shape_cable[1], shape_noeud[0], 1, niveau + 1,
                                                              shape_cable[10] + distance)
                            pt_aval = self.return_Not_Null(shape_noeud[0])
                            shape_noeud[5] = distance

                    shape_cable[4] = self.return_Not_Null(pt_amont)
                    shape_cable[5] = self.return_Not_Null(pt_aval)

            if pt_aval == "" or pt_aval == NULL:
                pt_aval = 'Erreur pas de noeud Extremite'
                for shape_noeud in self.listshape_noeud:
                    if depart_origine_support == shape_noeud[1]:
                        pt_aval = shape_noeud[0]
            return pt_aval

    # Function pour identifier les doublons didentifiant
    def get_doublon(self, count_doublon_list):
        counts = {}
        result_double_list = []
        for i in count_doublon_list:
            counts[i[1]] = counts.get(i[1], 0) + 1
        for key, value in counts.items():
            if value > 1:
                for i in count_doublon_list:
                    if i[1] == key:
                        result_double_list.append([i[0], key])
        return result_double_list

    # Rectification du sens de dessin Qgis
    def function_RectifSensDessin(self):

        # self.function_getlayer_QGis(self.name_point)
        # self.function_getlayer_QGis(self.name_sro)
        #
        shape_point = self.function_getLayer_bdd(self.schema, self.name_point, self.name_point_attribut,
                                                 self.name_point, self.geom_attribut)
        shape_sro = self.function_getLayer_bdd(self.schema, self.name_sro, self.name_sro_attribut, self.name_sro,
                                               self.geom_attribut)  # function_getlayer_QGis(name_sro)
        shape_ligne = self.function_delete_duplicate_geom()

        layer_provider_shape_ligne = shape_ligne.dataProvider()
        layer_provider_shape_ligne.addAttributes(
            [QgsField("Origine", QVariant.String), QgsField("Extremite", QVariant.String)])
        shape_ligne.updateFields()

        indexe_cb_origine = shape_ligne.fields().indexFromName("Origine")
        indexe_cb_extremite = shape_ligne.fields().indexFromName("Extremite")

        layershape_sro = [i for i in shape_sro.getFeatures()]
        layershape_noeud = [i for i in shape_point.getFeatures()]
        layershape_cable = [i for i in shape_ligne.getFeatures()]

        listshape_noeud = []
        list_noeud_superpose = []

        geoms_noeud_dup = {}
        index_noeud_dup = QgsSpatialIndex()
        for current, f in enumerate(layershape_noeud):
            geom_noeud_dup = f.geometry()
            if geom_noeud_dup != NULL or geom_noeud_dup.isGeosValid():
                geoms_noeud_dup[f.id()] = geom_noeud_dup
                index_noeud_dup.insertFeature(f)

        for feature_id, shape_noeuds in enumerate(layershape_noeud):

            geom_noeud = shape_noeuds.geometry()
            noeud_id = shape_noeuds[0]
            shape_noeud = [noeud_id, geom_noeud.asWkt(2), -1, -1, -1, -1]
            listshape_noeud.append(shape_noeud)

            # identifier les noeud qui se superposent
            if geom_noeud != NULL or geom_noeud.isGeosValid():
                res_noeud_dup = 'False'
                candidates = index_noeud_dup.intersects(geom_noeud.boundingBox())
                if candidates:
                    for candidate_id in candidates:
                        geom_noeud_dup = geoms_noeud_dup[candidate_id]
                        if geom_noeud_dup.within(geom_noeud.buffer(0.1, 0.1)) and shape_noeuds.id() != candidate_id:
                            res_noeud_dup = 'True'
                    # print (geometry[0],';',geometry.id(),';',candidate_id)
                if res_noeud_dup == 'True':
                    # print (noeud_id,';',shape_noeuds.id())
                    list_noeud_superpose.append(noeud_id)

        listshape_sro = []

        for shape_sro in layershape_sro:
            if shape_sro[self.var_atr_typelog] == self.type_sitetech_depart:  # var_atr_typelog #shape_sro[4]
                shape_sros = shape_sro.geometry().asWkt(2)
                listshape_sro.append(shape_sros)
        # print ('babab : ', shape_sro[0],';',shape_sro[self.var_atr_typelog],';',shape_sros)

        list_shape_cable = []
        for shape_cable in layershape_cable:
            geom_cable_lines = shape_cable.geometry()
            cable_id = shape_cable[0]
            cable_etiquet = shape_cable['cb_etiquet']
            cable_type = shape_cable['cb_typelog']
            cable_capa = shape_cable['cb_capafo']
            geom_cable_wkt = geom_cable_lines.asWkt()
            geom_cable_lines_lenth = geom_cable_lines.length()

            cable_nd1 = shape_cable['cb_nd1']
            cable_nd2 = shape_cable['cb_nd2']

            res_origine = 'KO'
            res_extremite = 'KO'

            geom_cable = geom_cable_lines
            if geom_cable.wkbType() == QgsWkbTypes.MultiLineString:
                geom_cable_type = geom_cable.asMultiPolyline()
                cable_origine = geom_cable_type[0][0]
                cable_extremite = geom_cable_type[-1][-1]

            if geom_cable.wkbType() == QgsWkbTypes.LineString:
                geom_cable_type = geom_cable.asPolyline()
                cable_origine = geom_cable_type[0]
                cable_extremite = geom_cable_type[-1]

            shape_cables_origine = (QgsGeometry.fromPointXY(QgsPointXY(cable_origine))).asWkt(2)
            shape_cables_extremite = (QgsGeometry.fromPointXY(QgsPointXY(cable_extremite))).asWkt(2)
            list_shape_cable.append(
                [cable_id, shape_cables_origine, shape_cables_extremite, 0, -1, -1, cable_etiquet, cable_type,
                 cable_capa, geom_cable_wkt, geom_cable_lines_lenth, cable_nd1, cable_nd2])

        self.list_shape_cable = list_shape_cable
        self.listshape_noeud = listshape_noeud

        res_choose_depart = 'true'
        if listshape_sro:
            point_depart_sro = str(min(listshape_sro)).replace('[', '').replace(']', '').replace('u', '').replace("'",
                                                                                                                  '')
            atest = self.function_cable_parcours_sens(point_depart_sro, 'NRO', 1, 1, 0)
        else:
            res_choose_depart = 'false'
            return res_choose_depart
        # return QMessageBox.warning(self.w, "Message de Parcours", 'Erreur de Choix du Point de Depart, Initule de continuer le traitement')

        list_shape_cable = self.list_shape_cable
        listshape_noeud = self.listshape_noeud

        # Creation shape vide erreur Sens Accrochage
        Erreur_Sens_Accroche = QgsVectorLayer("LineString?crs=epsg:2154", self.ErreurSensAccroche, "memory")
        Erreur_Sens_Accroche_pr2 = Erreur_Sens_Accroche.dataProvider()
        Erreur_Sens_Accroche_pr2.addAttributes(
            [QgsField('cb_code', QVariant.String), QgsField('cb_etiquet', QVariant.String), \
             QgsField('mes_error', QVariant.String)])
        Erreur_Sens_Accroche.updateFields()
        Erreur_Sens_Accroche.commitChanges()

        bar_progress = self.progress_bar('Execution de la verification Sens du dessin, Accrochage')
        message_cb_nd1 = 'S07_2'  # 'Incoherence entre cb_nd1 et cb_nd1 reel'
        message_cb_nd2 = 'S07_3'  # 'Incoherence entre cb_nd12 et cb_nd12 reel'
        for index_cable, cable in enumerate(list_shape_cable):
            geom = cable[9]
            geom_cable = QgsGeometry.fromWkt(geom)
            valide_cb_nd1 = message_cb_nd1
            valide_cb_nd2 = message_cb_nd2
            buffer_geom_cable = geom_cable.buffer(0.1, 0.1).asWkt()

            if cable[3] != 1:
                message = 'False'
                # outFeat = QgsFeature()
                if cable[3] == 0:
                    message_accroche = 'Z01_1'  # 'Cable avec probleme daccrochage ou deconnecter du reseau'
                    attrs = [cable[0], cable[6], message_accroche]
                    outFeat_acc = QgsFeature()
                    outFeat_acc.setGeometry(geom_cable)
                    outFeat_acc.setAttributes(attrs)
                    Erreur_Sens_Accroche_pr2.addFeatures([outFeat_acc])

                # Inverser le sens
                if cable[3] == -1:
                    message_sens = 'Z01_2'  # 'Cable dessine dans le mauvais sens'
                    geom_line_Rec = None
                    if geom_cable.isGeosValid():
                        if geom_cable.wkbType() == QgsWkbTypes.MultiLineString:
                            mls = QgsMultiLineString()
                            for line in geom_cable.asGeometryCollection():
                                mls.addGeometry(line.constGet().reversed())
                            geom_line_Rec = QgsGeometry(mls)

                        elif geom_cable.wkbType() == QgsWkbTypes.LineString:
                            geom_line_Rec = QgsGeometry(geom_cable.constGet().reversed())
                    shape_ligne.startEditing()
                    for shape_cable_shape in layershape_cable:
                        if cable[0] == shape_cable_shape[0]:
                            shape_ligne.changeGeometry(shape_cable_shape.id(), geom_line_Rec)

                    attrs = [cable[0], cable[6], message_sens]
                    outFeat_sens = QgsFeature()
                    outFeat_sens.setGeometry(geom_cable)
                    outFeat_sens.setAttributes(attrs)
                    Erreur_Sens_Accroche_pr2.addFeatures([outFeat_sens])

            # Filtrer les suf qui se superposent
            for noeud_dup in list_noeud_superpose:
                if cable[11] == noeud_dup:
                    valide_cb_nd1 = 'True'
                if cable[12] == noeud_dup:
                    valide_cb_nd2 = 'True'

            #            for index_sro, sro in enumerate(layershape_sro):
            #                if cable[4] == sro['st_nd_code']:
            #                    cable[4] = sro['st_nom']
            #                if cable[5] == sro['st_nd_code']:
            #                    cable[5] = sro['st_nom']
            shape_ligne.startEditing()
            for index_cable, i_cable in enumerate(shape_ligne.getFeatures()):
                if i_cable[0] == cable[0]:
                    shape_ligne.changeAttributeValue(i_cable.id(), indexe_cb_origine, str(cable[4]))
                    shape_ligne.changeAttributeValue(i_cable.id(), indexe_cb_extremite, str(cable[5]))

            self.progress_processing(index_cable, len(list_shape_cable), bar_progress)
            if bar_progress.wasCanceled():
                iface.messageBar().pushMessage('Info', 'Action Cancelled', level=Qgis.Info)
                break

        shape_ligne.commitChanges()
        QgsProject.instance().addMapLayer(shape_ligne)
        QgsProject.instance().addMapLayer(Erreur_Sens_Accroche)
        QgsProject.instance().addMapLayer(shape_point)

    # self.function_add_layer_group(shape_ligne, self.CreateGroupName)
    # self.function_add_layer_group(Erreur_Sens_Accroche, self.CreateGroupName)
    # self.function_add_layer_group(shape_point, self.CreateGroupName)
    # return shape_ligne, shape_point, Erreur_Sens_Accroche

    # Function pour Verifier la detection des origines extremites
    def function_check_detection(self):
        shape_ligne_Colonne_Nom = self.name_line_attribut
        shape_point_Colonne_Nom = self.name_point_attribut

        if self.function_RectifSensDessin() != 'false':
            shape_ligne = self.function_getlayer_QGis(
                self.name_line)  # self.function_RectifSensDessin()[0]#self.function_getlayer_QGis(self.name_line)
            shape_point = self.function_getlayer_QGis(
                self.name_point)  # self.function_RectifSensDessin()[1]#self.function_getlayer_QGis(self.name_point)
            # shape_erreur_sens = self.GetLayerByGroup(self.CreateGroupName, self.ErreurSensAccroche)#self.function_RectifSensDessin()[2]

            # Creation des listes pour checker les doublons
            List_Check_Ligne_ID = []
            List_Check_Ligne_EXTREMITE = []
            List_Check_Ligne_ORIGINE_EXTREMITE = []
            List_Check_Point_ID = []
            List_Check_Point_IdAbsentExtremiteLigne = []

            # Creation de shapefile pour le resultat des erreurs de verification de la detection des origines extremites
            check_detection = QgsVectorLayer("LineString?crs=epsg:2154", "erreur_detection_ligne", "memory")
            check_detection_pr = check_detection.dataProvider()
            check_detection_pr.addAttributes(
                [QgsField('id_code', QVariant.String), QgsField('erreur', QVariant.String)])
            check_detection.updateFields()
            check_detection.commitChanges()

            # Creation de shapefile pour le resultat des erreurs de verification pour Point
            check_detection_point = QgsVectorLayer("Point?crs=epsg:2154", "erreur_detection_point", "memory")
            check_detection_point_pr = check_detection_point.dataProvider()
            check_detection_point_pr.addAttributes(
                [QgsField('id_code', QVariant.String), QgsField('erreur', QVariant.String)])
            check_detection_point.updateFields()
            check_detection_point.commitChanges()

            # Parcours LIgne
            for index_cable, cable in enumerate(shape_ligne.getFeatures()):
                geom_wkt_ligne = cable.geometry().asWkt(2)

                # Append List ID Ligne
                attribute_ligne_ID = [geom_wkt_ligne, cable[shape_ligne_Colonne_Nom]]
                List_Check_Ligne_ID.append(attribute_ligne_ID)

                # Append List Extremite Ligne
                attribute_ligne_Extremite = [geom_wkt_ligne, cable["Extremite"]]
                List_Check_Ligne_EXTREMITE.append(attribute_ligne_Extremite)

                # Append List Origine egale Extremite Ligne
                if cable["Origine"] == cable["Extremite"]:
                    attribute_ligne_ORIGINE_Extremite = [geom_wkt_ligne, cable[shape_ligne_Colonne_Nom]]
                    List_Check_Ligne_ORIGINE_EXTREMITE.append(attribute_ligne_ORIGINE_Extremite)

            # Parcours Points
            for index_point, point in enumerate(shape_point.getFeatures()):
                geom_wkt_point = point.geometry().asWkt(2)

                # Append List ID Point
                attribute_Point_ID = [geom_wkt_point, point[shape_point_Colonne_Nom]]
                List_Check_Point_ID.append(attribute_Point_ID)

                # Append List ID Point absent extremite cable
                PointIn_extremiteLigne = 'nok'
                for index_extremite, extremite in enumerate(List_Check_Ligne_EXTREMITE):
                    if point[shape_point_Colonne_Nom] == extremite[1]:
                        PointIn_extremiteLigne = 'ok'
                if PointIn_extremiteLigne == 'nok':
                    attribute_Point_IdAbsentExtremiteLigne = [geom_wkt_point, point[shape_point_Colonne_Nom]]
                    List_Check_Point_IdAbsentExtremiteLigne.append(attribute_Point_IdAbsentExtremiteLigne)

            # identification des doublons didentifiant de Ligne
            Erreur_doublon_ID_ligne = 'Erreur : Cette Entite est presente plus dune fois dans ID_CODE du shape Ligne'
            for ligne_double in self.get_doublon(List_Check_Ligne_ID):
                attrs = [ligne_double[1], Erreur_doublon_ID_ligne]
                elem = QgsFeature()
                elem.setGeometry(QgsGeometry.fromWkt(ligne_double[0]))
                elem.setAttributes(attrs)
                check_detection_pr.addFeatures([elem])

            # identification des doublons extremites de Ligne
            Erreur_doublon_extremite_ligne = 'Erreur : Cette Entite est presente plus dune fois dans Extremite du shape Ligne'
            for ligne_double_extremite in self.get_doublon(List_Check_Ligne_EXTREMITE):
                attrs = [ligne_double_extremite[1], Erreur_doublon_extremite_ligne]
                elem = QgsFeature()
                elem.setGeometry(QgsGeometry.fromWkt(ligne_double_extremite[0]))
                elem.setAttributes(attrs)
                check_detection_pr.addFeatures([elem])

            # identification des origines egal extremite de Ligne
            Erreur_origine_extremite_ligne = 'ERREUR: Cette Entite a un ID_CODE qui est a la fois origine et extemite'
            for ligne_origine_extremite in List_Check_Ligne_ORIGINE_EXTREMITE:
                attrs = [ligne_origine_extremite[1], Erreur_origine_extremite_ligne]
                elem = QgsFeature()
                elem.setGeometry(QgsGeometry.fromWkt(ligne_origine_extremite[0]))
                elem.setAttributes(attrs)
                check_detection_pr.addFeatures([elem])

            # identification des doublons didentifiant de Point
            Erreur_doublon_ID_point = 'Erreur : Cette Entite est presente plus dune fois dans le shape Point'
            for point_double in self.get_doublon(List_Check_Point_ID):
                attrs = [point_double[1], Erreur_doublon_ID_point]
                elem = QgsFeature()
                elem.setGeometry(QgsGeometry.fromWkt(point_double[0]))
                elem.setAttributes(attrs)
                check_detection_point_pr.addFeatures([elem])

            # identification des Point ID absents dans extremites du Ligne
            Erreur_IdAbsentExtremiteLigne = 'ERREUR: Cette Entite nest pas presente dans extremite du shape Ligne'
            for IdAbsentExtremiteLigne in List_Check_Point_IdAbsentExtremiteLigne:
                attrs = [IdAbsentExtremiteLigne[1], Erreur_IdAbsentExtremiteLigne]
                elem = QgsFeature()
                elem.setGeometry(QgsGeometry.fromWkt(IdAbsentExtremiteLigne[0]))
                elem.setAttributes(attrs)
                check_detection_point_pr.addFeatures([elem])

            QgsProject.instance().addMapLayer(check_detection)
            # QgsProject.instance().addMapLayer(self.ErreurSensAccroche)
            QgsProject.instance().addMapLayer(check_detection_point)
            return check_detection, check_detection_point
        # QgsProject.instance().addMapLayer(Point_Network)

        # Chargement des couches dans Qgis
        #            #QgsProject.instance().addMapLayer(shape_ligne)
        #            #QgsProject.instance().addMapLayer(shape_point)

        # self.function_add_layer_group(check_detection, self.CreateGroupName)
        # self.function_add_layer_group(check_detection_point, self.CreateGroupName)
        # return shape_ligne, shape_point
        else:
            QMessageBox.warning(self.w, "Message de Parcours",
                                'Erreur de Choix du Point de Depart, Initule de continuer le traitement')

    # Function Parcours avec Point
    def function_calculeFibre_noeud(self, noeud, niveau):
        somme_fo = 0
        nbre_prise = 0
        somme_fo_sans_modulo = 0
        bar_progress = self.progress_bar('Execution Du calcul du Nbre de Fibre')
        len_list_ligne = len(self.list_shape_cable)
        if niveau < 1000:
            len_list_ligne = len(self.list_shape_cable)
            for index_ligne, Var_Shape_Ligne in enumerate(self.list_shape_cable):
                if Var_Shape_Ligne[1] == noeud:
                    somme_fo_aval, nbre_prises_aval, somme_fo_SM = self.function_calculeFibre_noeud(Var_Shape_Ligne[2],
                                                                                                    niveau + 1)
                    somme_fo = somme_fo + somme_fo_aval

                self.progress_processing(index_ligne, len_list_ligne, bar_progress)
                if bar_progress.wasCanceled():
                    iface.messageBar().pushMessage('Info', 'Action Cancelled', level=Qgis.Info)
                    break

            for Var_Shape_Point in self.listshape_noeud:
                if Var_Shape_Point[0] == noeud:
                    nbre_fo = Var_Shape_Point[1] * 2
                    somme_fo = somme_fo + (nbre_fo)
                    Var_Shape_Point[2] = nbre_fo
                    Var_Shape_Point[3] = somme_fo

        return somme_fo, nbre_prise, somme_fo_sans_modulo

    # return 0,0

    # Function count Suf
    def function_count_suf(self):
        shape_ligne = self.function_getlayer_QGis(
            self.name_line)  # self.function_check_detection()[0]#self.function_getlayer_QGis(self.name_line)
        shape_suf = self.function_getLayer_bdd(self.schema, self.name_suf, self.var_atr_sfcode, self.name_suf,
                                               self.geom_attribut)  # self.function_getlayer_QGis(self.name_suf)
        shape_point = self.function_getlayer_QGis(
            self.name_point)  # self.function_check_detection()[1]#self.function_getlayer_QGis(self.name_point)
        # Point_Network = self.function_getlayer_QGis(self.CreatePoint_Network)
        # Declaration des attributs pour les shapes declares
        Var_attribut_code_point = self.name_point_attribut
        Var_attribut_extremite_ligne = self.createExtremite
        Var_attribut_origine_ligne = self.createOrigine

        # Declaration des attributs a creer
        attribut_nd_code = self.name_point_attribut  # 'nd_code'
        attribut_nbre_suf = "nbresuf"
        attribut_nbre_fo = "nbreFo"
        attribut_nbre_SufSum = "nbreFoSum"
        # Creation du shape des Noeuds du reseau
        Point_Network = QgsVectorLayer("Point?crs=epsg:2154", self.CreatePoint_Network, "memory")
        Point_Network_pr = Point_Network.dataProvider()
        Point_Network_pr.addAttributes(
            [QgsField(attribut_nd_code, QVariant.String), QgsField(attribut_nbre_suf, QVariant.Int),
             QgsField(attribut_nbre_fo, QVariant.Int), QgsField(attribut_nbre_SufSum, QVariant.Int)])
        Point_Network.updateFields()
        Point_Network.commitChanges()

        # Ajout des attributs dans le shape Cable
        layer_provider_shape_ligne = shape_ligne.dataProvider()
        layer_provider_shape_ligne.addAttributes([QgsField(attribut_nbre_suf, QVariant.Int),
                                                  QgsField(attribut_nbre_fo, QVariant.Int),
                                                  QgsField(attribut_nbre_SufSum, QVariant.Int)])
        shape_ligne.updateFields()

        # Declaration des index
        indexe_cb_NbreSuf = shape_ligne.fields().indexFromName(attribut_nbre_suf)
        indexe_cb_Nbrefo = shape_ligne.fields().indexFromName(attribut_nbre_fo)
        indexe_cb_NbreSufSum = shape_ligne.fields().indexFromName(attribut_nbre_SufSum)

        indexe_noeud_NbreSuf = Point_Network.fields().indexFromName(attribut_nbre_suf)
        indexe_noeud_NbreFo = Point_Network.fields().indexFromName(attribut_nbre_fo)
        indexe_noeud_NbreFoSum = Point_Network.fields().indexFromName(attribut_nbre_SufSum)

        # Creation des listes pour des utilisations ulterieurs
        listshape_noeud_ligne = []
        listshape_ligne = []
        listshape_Origine_ligne = []
        listshape_point = []

        for var_point in shape_point.getFeatures():
            listshape_point.append([var_point[Var_attribut_code_point], var_point.geometry().asWkt()])

        # Create a dictionary of all features SUF
        feature_suf_dict = {f.id(): f for f in shape_suf.getFeatures()}
        index_suf = QgsSpatialIndex()
        for current, f in enumerate(feature_suf_dict.values()):
            geom_point = f.geometry()
            if geom_point != NULL or geom_point.isGeosValid():
                index_suf.insertFeature(f)

        # Create a dictionary of all features Noeud
        feature_noeud_dict = {f.id(): f for f in shape_point.getFeatures()}
        index_noeud = QgsSpatialIndex()
        for current, Var_noeud in enumerate(feature_noeud_dict.values()):
            geom_noeud = Var_noeud.geometry()
            if geom_noeud != NULL or geom_noeud.isGeosValid():
                index_noeud.insertFeature(Var_noeud)

        # Ajout des elements dans les listes crees cidessous
        bar_progress = self.progress_bar('Execution De la Prepartion des Listes pour lutilisation du parcours')
        shape_ligne_count = shape_ligne.featureCount()
        shape_ligne.startEditing()
        for index_ligne, ligne in enumerate(shape_ligne.getFeatures()):
            geom_ligne = ligne.geometry()
            count = 0
            count_noeud = 0
            sf_code = []
            suf_features = index_suf.intersects(geom_ligne.boundingBox())
            geom_point = ''
            if suf_features:
                for candidate_id in suf_features:
                    geomSufIntersects = feature_suf_dict[candidate_id]
                    if geomSufIntersects != NULL or geomSufIntersects.isGeosValid():
                        if ligne[Var_attribut_extremite_ligne] == geomSufIntersects[self.var_atr_sfndcode]:
                            count += 1
                            geom_point = geomSufIntersects.geometry().asWkt()
                    # sf_code.append(geomSufIntersects['sf_code'])

            noeud_features = index_noeud.intersects(geom_ligne.boundingBox())
            if noeud_features:
                for Var_noeud_features in noeud_features:
                    geomNoeudIntersects = feature_noeud_dict[Var_noeud_features]
                    if geomNoeudIntersects != NULL or geomNoeudIntersects.isGeosValid():
                        noeud_code = geomNoeudIntersects[Var_attribut_code_point]
                        if noeud_code == ligne[Var_attribut_origine_ligne]:
                            count_noeud += (count)
                            geom_point = geomNoeudIntersects.geometry().asWkt()

            listshape_noeud_ligne.append([ligne[Var_attribut_origine_ligne], count_noeud])

            if ligne[Var_attribut_origine_ligne] not in listshape_Origine_ligne:
                listshape_Origine_ligne.append(ligne[Var_attribut_origine_ligne])

            if ligne[Var_attribut_extremite_ligne] not in listshape_Origine_ligne:
                listshape_Origine_ligne.append(ligne[Var_attribut_extremite_ligne])

            shape_ligne.changeAttributeValue(ligne.id(), indexe_cb_NbreSuf, count)
            shape_ligne.changeAttributeValue(ligne.id(), indexe_cb_Nbrefo, count * 2)

            attribut_liste_ligne = [ligne[self.name_line_attribut], ligne[self.createOrigine],
                                    ligne[self.createExtremite], \
                                    ligne[self.var_atr_capacite], -1, -1, -1, -1, -1]
            listshape_ligne.append(attribut_liste_ligne)

            self.progress_processing(index_ligne, shape_ligne_count, bar_progress)
            if bar_progress.wasCanceled():
                iface.messageBar().pushMessage('Info', 'Action Cancelled', level=Qgis.Info)
                break
        shape_ligne.commitChanges()

        # Creation du shape noeud du reseau
        listNoeudPrise = []
        bar_progress_noeud = self.progress_bar('Execution Creation du Shape Noeud')
        elem = QgsFeature()
        for index, org in enumerate(listshape_Origine_ligne):
            count = 0
            geom_wkt_point = ''
            for or_suf in listshape_noeud_ligne:
                if org == or_suf[0]:
                    count += or_suf[1]
            listNoeudPrise.append([org, count, -1, -1])

            for var_point in listshape_point:
                if org == var_point[0]:
                    geom_wkt_point = var_point[1]  # .geometry().asWkt()

            if geom_wkt_point != '':
                attrs = [org, count]
                elem.setGeometry(QgsGeometry.fromWkt(geom_wkt_point))
                elem.setAttributes(attrs)
                Point_Network_pr.addFeatures([elem])
            self.progress_processing(index, len(listshape_Origine_ligne), bar_progress_noeud)
            if bar_progress.wasCanceled():
                iface.messageBar().pushMessage('Info', 'Action Cancelled', level=Qgis.Info)
                break

        # Mise a jour des Listes pour une utilisation dans le parcours
        self.list_shape_cable = listshape_ligne
        self.listshape_noeud = listNoeudPrise

        # Parcours pour le calcul des Fo, FOSum
        execute_parcours = self.function_calculeFibre_noeud('NRO', 0)

        # Mise a jour des listes pour une utilisation dans le remplissage des Shape
        listshape_ligne = self.list_shape_cable
        listNoeudPrise = self.listshape_noeud

        # Ajout des resultats dans le shape Noeud Reseau
        bar_progress_res_noeud = self.progress_bar('Execution Ajout des resultats dans le Shape Point Network')
        Point_Network_count = Point_Network.featureCount()
        Point_Network.startEditing()
        for index_point, point in enumerate(Point_Network.getFeatures()):
            nbresuf = 0
            nbreFo = 0
            nbreFOsum = 0
            for noeud in listNoeudPrise:
                if point[attribut_nd_code] == noeud[0]:
                    nbreFo = noeud[2]
                    nbreFOsum = noeud[3]
            Point_Network.changeAttributeValue(point.id(), indexe_noeud_NbreFo, int(nbreFo))
            Point_Network.changeAttributeValue(point.id(), indexe_noeud_NbreFoSum, int(nbreFOsum))

            self.progress_processing(index_point, Point_Network_count, bar_progress_res_noeud)
            if bar_progress.wasCanceled():
                iface.messageBar().pushMessage('Info', 'Action Cancelled', level=Qgis.Info)
                break
        Point_Network.commitChanges()
        QgsProject.instance().addMapLayer(Point_Network)

        # Liste Pour le calcul de la capacite Optimisee et Utile
        listshape_ligne_capaOptimisee = []

        # Ajout des resultats dans le shape Ligne
        bar_progress_res_ligne = self.progress_bar('Execution Ajout des resultats dans le Shape Ligne')
        shape_ligne_count = shape_ligne.featureCount()
        shape_ligne.startEditing()
        for index_ligne, ligne in enumerate(shape_ligne.getFeatures()):
            nbresuf = 0
            nbreFo = 0
            nbreFOsum = 0
            for noeud in listNoeudPrise:
                if ligne[Var_attribut_extremite_ligne] == noeud[0]:
                    nbresuf = noeud[1]
                    nbreFo = noeud[2]
                    nbreFOsum = noeud[3]
            shape_ligne.changeAttributeValue(ligne.id(), indexe_cb_NbreSuf, nbresuf)
            shape_ligne.changeAttributeValue(ligne.id(), indexe_cb_Nbrefo, nbreFo)
            shape_ligne.changeAttributeValue(ligne.id(), indexe_cb_NbreSufSum, nbreFOsum)

            attribut_liste_ligne = [ligne[self.name_line_attribut], ligne[self.createOrigine],
                                    ligne[self.createExtremite], \
                                    ligne[self.var_atr_capacite], nbresuf, nbreFo, nbreFOsum, -1, -1, -1]
            listshape_ligne_capaOptimisee.append(attribut_liste_ligne)

            self.progress_processing(index_ligne, shape_ligne_count, bar_progress_res_ligne)
            if bar_progress.wasCanceled():
                iface.messageBar().pushMessage('Info', 'Action Cancelled', level=Qgis.Info)
                break

        shape_ligne.commitChanges()

    # QgsProject.instance().addMapLayer(Point_Network)
    # self.function_add_layer_group(Point_Network, self.CreateGroupName)
    # iface.mapCanvas().refreshAllLayers()

    # Function pour les calcul recursifs des Fo Co CU Section
    def function_calcul_Derivation(self, noeud, niveau, capa_rentrant, List_Noeud_Sro, list_section, list_type_cable):

        bar_progress = self.progress_bar('Execution Du calcul FU de Derivation dans les boites')
        len_list_ligne = len(self.list_shape_cable)
        dict_capa_deriv = defaultdict(list)
        dict_nbrfo_deriv = defaultdict(list)
        dict_cb_nom = defaultdict(list)

        reserve = 1
        if niveau < 1000:
            for index_shape_ligne, shape_ligne in enumerate(self.list_shape_cable):
                DictListForTrie = {}
                if shape_ligne[1] == noeud:
                    self.function_calcul_Derivation(shape_ligne[2], niveau + 1, shape_ligne[3], List_Noeud_Sro, \
                                                    list_section, list_type_cable)
                    cb_nom = shape_ligne[0]
                    capa_sortant = shape_ligne[3]
                    nbreFo_sortant = int(shape_ligne[6])
                    for list_boite in self.listshape_noeud:
                        if list_boite[0] == noeud:
                            if str(capa_rentrant) != str(capa_sortant):
                                dict_cb_nom[list_boite[0]].append(cb_nom)
                                dict_capa_deriv[list_boite[0]].append(capa_sortant)
                                dict_nbrfo_deriv[list_boite[0]].append(nbreFo_sortant)

                    # Partie Sortie SRO et SRO Colocalise avec que des lignes Distribution et Raccordement
                    for var_Sro in List_Noeud_Sro:
                        if var_Sro == noeud:
                            section = str(capa_sortant)
                            if section not in list_section and shape_ligne[10] in list_type_cable:  # ('DI','RA')
                                list_section.append(section)
                self.progress_processing(index_shape_ligne, len_list_ligne, bar_progress)
                if bar_progress.wasCanceled():
                    iface.messageBar().pushMessage('Info', 'Action Cancelled', level=Qgis.Info)
                    break

        for index_noeud, noeud in enumerate(self.listshape_noeud):

            for i, (key, cb_deriv) in enumerate(dict_cb_nom.items()):
                if key == noeud[0]:
                    noeud[4] = ','.join(cb_deriv)

            for i, (key, ca_deriv) in enumerate(dict_capa_deriv.items()):
                if key == noeud[0]:
                    noeud[5] = ','.join(ca_deriv)

            for i, (key, fo_deriv) in enumerate(dict_nbrfo_deriv.items()):
                if key == noeud[0]:
                    noeud[6] = sum(fo_deriv)

            self.progress_processing(index_noeud, len(self.listshape_noeud), bar_progress)
            if bar_progress.wasCanceled():
                iface.messageBar().pushMessage('Info', 'Action Cancelled', level=Qgis.Info)
                break

    # Function pour calcul capaO capaU Seclen
    def function_calcul_capaOpt_capaUtile_Seclen(self):

        shape_ligne = self.function_getlayer_QGis(self.name_line)  # GetLayerByGroup('Dev_Data', 'cable')
        # Point_Network = self.function_getlayer_QGis(self.CreatePoint_Network)#GetLayerByGroup('Dev_Data', 'Point_Network')

        ##Declaration des attributs dans le shape Cable
        Var_attribut_extremite_ligne = self.createExtremite  # 'Extremite'
        Var_attribut_origine_ligne = self.createOrigine  # 'Origine'
        Var_attribut_code_ligne = self.name_line_attribut  # 'cb_code'
        Var_attribut_capacite_ligne = self.var_atr_capacite  # 'cb_capafo'
        Var_attribut_typelog_ligne = self.var_atr_cbtypelog  # 'cb_typelog'

        ##Ajout des attributs dans le shape Cable
        attribut_capaOptimisee = 'capaOpt'
        attribut_capaUtilee = 'capaUtile'
        attribut_length = 'Seclen'
        attribut_nbre_fo = "nbreFo"
        attribut_nbre_suf = "nbresuf"
        attribut_nbre_SufSum = "nbreFoSum"

        attribut_depart_graph = 'NRO'

        layer_provider_shape_ligne = shape_ligne.dataProvider()
        # List_Fields = [field.name() for field in shape_ligne.fields()]
        # List_Field_Add = [attribut_capaOptimisee,attribut_capaUtilee,attribut_length]
        layer_provider_shape_ligne.addAttributes([QgsField(attribut_capaOptimisee, QVariant.Int),
                                                  QgsField(attribut_capaUtilee, QVariant.Int),
                                                  QgsField(attribut_length, QVariant.Int)])
        # for field in List_Field_Add:
        # 	if field not in List_Fields:
        # 		layer_provider_shape_ligne.addAttributes([QgsField(field,QVariant.Int),
        # 			QgsField(field,QVariant.Int),QgsField(field,QVariant.Int)])
        shape_ligne.updateFields()
        indexe_cb_capaOptimisee = shape_ligne.fields().indexFromName(attribut_capaOptimisee)
        indexe_cb_capaUtilee = shape_ligne.fields().indexFromName(attribut_capaUtilee)
        indexe_cb_attribut_length = shape_ligne.fields().indexFromName(attribut_length)

        dico = {}
        shape_ligne_count = shape_ligne.featureCount()
        for index_ligne, ligne in enumerate(shape_ligne.getFeatures()):
            # if ligne['cb_typelog'] != 'RA':
            cb_code = ligne[Var_attribut_code_ligne]
            cb_origine = ligne[Var_attribut_origine_ligne]
            cb_extremite = ligne[Var_attribut_extremite_ligne]
            cb_capafo = ligne[Var_attribut_capacite_ligne]
            cb_nbresuf = ligne[attribut_nbre_suf]
            cb_nbrefo = ligne[attribut_nbre_fo]
            cb_nbrefosum = ligne[attribut_nbre_SufSum]
            cb_typelog = ligne[Var_attribut_typelog_ligne]
            cb_section = ''  # ligne['section']
            cb_lengh = ligne.geometry().length()
            dico[str(cb_code)] = [(str(cb_origine), str(cb_extremite)), str(cb_capafo), str(cb_nbresuf), str(cb_nbrefo),
                                  str(cb_nbrefosum), \
                                  str(cb_typelog), str(cb_section), str(cb_lengh)]

        cbs = {}  # gives {(origine,extrimity):(edge,section)}
        G = nx.DiGraph()
        origines = []  # list of all origins
        ext = []  # list of all extrimities
        danglings = []  # gives the sites at the boundaries, extrimity which is not in origines

        for key, v in dico.items():
            (cb_origine,
             cb_extremite), cb_capafo, cb_nbresuf, cb_nbrefo, cb_nbrefosum, cb_typelog, cb_section, cb_lengh = v
            origines.append(cb_origine)
            ext.append(cb_extremite)
            G.add_weighted_edges_from([(cb_origine, cb_extremite, cb_capafo)])

        for key, v in dico.items():
            (cb_origine,
             cb_extremite), cb_capafo, cb_nbresuf, cb_nbrefo, cb_nbrefosum, cb_typelog, cb_section, cb_lengh = v
            cbs[(cb_origine, cb_extremite)] = [key, cb_origine, cb_extremite, cb_capafo, cb_nbresuf, cb_nbrefo,
                                               cb_nbrefosum, cb_typelog, \
                                               cb_section, cb_lengh, 0, 0, 0]
            if cb_extremite not in origines:
                danglings.append(cb_extremite)

        all_paths = {}
        for dang in danglings:
            paths = nx.all_simple_paths(G, source=attribut_depart_graph, target=dang)
            out = []
            for each in map(nx.utils.pairwise, paths):  # this gives the edges
                out.append(list(each))
            edged = []
            for li in out:
                _li = []
                for elem in li:
                    _li.append(cbs[elem])
                edged.append(_li)
            all_paths[dang] = edged
        # print (all_paths)

        capaO = 0
        capaU = 0
        cmp = 0
        # cmp_index = 0
        List_Resultat_Calcul = []
        # cb_code,cb_origine,cb_extremite,cb_capafo,cb_nbresuf,cb_nbrefo,cb_nbrefosum,cb_typelog,cb_section,cb_lengh,0,0,0
        # 'CB000000000652', 'NRO', 'ND000000001360', '432', '0', '0', '888', 'DI', 'Sec_432', '9.97310383029009', 0, 0, 0
        for key, path in all_paths.items():
            # if key in ('ND000000000366','ND000000000014','ND000000001254'):
            for list_path in path:
                reversed_list_capa_users = list_path
                for index in range(0, len(reversed_list_capa_users)):
                    capaORIgine = reversed_list_capa_users[index][3]
                    current_section = reversed_list_capa_users[index][3]
                    old_current_section = reversed_list_capa_users[index - 1][3]
                    if current_section != old_current_section:
                        cmp = 0
                    # cmp_index = str(current_section) + '_' + str(index)
                    if cmp != 0:
                        reversed_list_capa_users[index][10] = capaO
                        reversed_list_capa_users[index][11] = capaU
                    cmp += 1
                    if cmp == 1:
                        capaO = int(reversed_list_capa_users[index][6])
                        capaU = int(reversed_list_capa_users[index][6])
                        reversed_list_capa_users[index][10] = capaO
                        reversed_list_capa_users[index][11] = capaU
                    else:
                        capaO = int(reversed_list_capa_users[index][10]) - int(
                            int(reversed_list_capa_users[index - 1][4]) + int(1))
                        capaU = int(reversed_list_capa_users[index][10]) - int(reversed_list_capa_users[index - 1][4])
                        reversed_list_capa_users[index][10] = capaO
                        reversed_list_capa_users[index][11] = capaU
                    attr_append = [reversed_list_capa_users[index][0], capaORIgine, capaO, capaU, \
                                   reversed_list_capa_users[index][9], reversed_list_capa_users[index][2], 0, 0]
                    if attr_append not in List_Resultat_Calcul:
                        List_Resultat_Calcul.append(attr_append)
        #                print(key,';',reversed_list_capa_users[index][0],';',capaORIgine,',',capaO,',',capaU,';',\
        #                    sum_section,';',reversed_list_capa_users[index][2],';',cmp_index)

        # Creation liedntifiant unique par section
        cmp_index = 0
        reversed_list_capa_users = List_Resultat_Calcul  # list()
        for index in range(0, len(reversed_list_capa_users)):

            current_section = reversed_list_capa_users[index][1]
            old_current_section = reversed_list_capa_users[index - 1][1]
            if current_section == old_current_section:
                pass
            elif current_section != old_current_section:
                cmp_index = str(current_section) + '_' + str(index)
            reversed_list_capa_users[index][6] = cmp_index
        # print (cmp_index,';',reversed_list_capa_users[index][0],';',reversed_list_capa_users[index][1])

        # Groupement des longueurs de section par identifiant unique
        reversed_list_capa_users = List_Resultat_Calcul  # list()
        dict_section_cab = {}
        for index in range(0, len(reversed_list_capa_users)):

            capaORIgine = reversed_list_capa_users[index][1]
            capaORIgine_sous = reversed_list_capa_users[index][4]

            current_section = reversed_list_capa_users[index][1]
            old_current_section = reversed_list_capa_users[index - 1][1]
            if current_section == old_current_section:
                dict_section_cab[str(reversed_list_capa_users[index][6])].append(float(capaORIgine_sous))
            elif current_section != old_current_section:
                dict_section_cab[str(reversed_list_capa_users[index][6])] = [float(capaORIgine_sous)]

        # Affectation de la longeur section
        for key, val in dict_section_cab.items():
            for var_val in List_Resultat_Calcul:
                if key == var_val[6]:
                    var_val[7] = sum(val)
        # print (key,';',val,';',sum(val))#,';',sum([val])

        # Mettre le resultat dans le shape
        bar_progress = self.progress_bar('Ajout des resultats CapaO, CapaU et Lengueur Section')
        shape_ligne.startEditing()
        for index_ligne, ligne in enumerate(shape_ligne.getFeatures()):  #
            capaOp = 99999999999999999
            CapaUt = 99999999999999999
            seclen = 99999999999999999
            for res_i in List_Resultat_Calcul:
                if res_i[0] == ligne[Var_attribut_code_ligne]:
                    capaOp = res_i[2]
                    CapaUt = res_i[3]
                    seclen = res_i[7]
            shape_ligne.changeAttributeValue(ligne.id(), indexe_cb_capaOptimisee, capaOp)
            shape_ligne.changeAttributeValue(ligne.id(), indexe_cb_capaUtilee, CapaUt)
            shape_ligne.changeAttributeValue(ligne.id(), indexe_cb_attribut_length, int(seclen))
            self.progress_processing(index_ligne, shape_ligne_count, bar_progress)
            if bar_progress.wasCanceled():
                iface.messageBar().pushMessage('Info', 'Action Cancelled', level=Qgis.Info)
                break
        shape_ligne.commitChanges()

    # Function pour le calcul des Fo Co CU des sorties SRO
    def function_calculeFibre_SRO(self, depart_origine_support, capaRentrant, niveau, List_Result_Capa, List_Section,
                                  List_Noeud_Sro):
        reserve = 1
        if niveau < 1000:
            len_list_ligne = len(self.list_shape_cable)
            # Parcours LIgne
            bar_progress = self.progress_bar('Execution Du calcul de la  Capacite Optimisee et Utile en sortie Sro')

            for index_shape_cable, shape_cable2 in enumerate(self.list_shape_cable):
                if shape_cable2[1] == depart_origine_support:

                    self.function_calculeFibre_SRO(shape_cable2[2], shape_cable2[3], niveau + 1, List_Result_Capa,
                                                   List_Section, List_Noeud_Sro)

                    capaSortant = shape_cable2[3]

                    if capaRentrant == capaSortant and shape_cable2[3] in List_Section:
                        for point in self.listshape_noeud:
                            if point[0] == depart_origine_support:
                                FibreUtile = int(capaRentrant) - int(point[2])
                                capaOptimisee = int(capaRentrant) - (point[1] + reserve) - point[6]
                                capaUtilee = int(capaRentrant) - point[1] - point[6]
                                attr_ap = [shape_cable2[0], FibreUtile, capaOptimisee, capaUtilee]
                                List_Result_Capa.append(attr_ap)

                self.progress_processing(index_shape_cable, len_list_ligne, bar_progress)
                if bar_progress.wasCanceled():
                    iface.messageBar().pushMessage('Info', 'Action Cancelled', level=Qgis.Info)
                    break

    # Function pour le remplissage des shapes suivant les calcul Fo CO Cu Section
    def function_ajout_calcul_Derivation(self):

        shape_ligne = self.function_getlayer_QGis(
            self.name_line)  # self.function_count_suf()[0]#self.function_getlayer_QGis('vs_elem_cl_cb_PropreAccroche_PropreDouble')
        Point_Network = self.function_getlayer_QGis(
            self.CreatePoint_Network)  # self.function_count_suf()[1]#self.function_getlayer_QGis('Point_Network')
        shape_point_techniques = self.function_getLayer_bdd(self.schema, self.name_point_technique, self.var_atr_ptcode,
                                                            self.name_point_technique, self.geom_attribut)
        shape_cheminement = self.function_getLayer_bdd(self.schema, self.name_cheminement, '', self.name_cheminement,
                                                       self.geom_attribut)
        shape_boites = self.function_getLayer_bdd(self.schema, self.name_boites, self.var_atr_bpcode,
                                                  self.name_boites, self.geom_attribut)
        shape_sro = self.function_getLayer_bdd(self.schema, self.name_sro, self.name_sro_attribut, self.name_sro,
                                               self.geom_attribut)  # function_getlayer_QGis(name_sro)

        features_point_techniques = QgsVectorLayer("Point?crs=epsg:2154", shape_point_techniques.name(), "memory")
        features_point_techniques_pr2 = features_point_techniques.dataProvider()
        features_point_techniques_attr2 = shape_point_techniques.dataProvider().fields().toList()
        features_point_techniques_pr2.addAttributes(features_point_techniques_attr2)
        features_point_techniques.updateFields()

        features_shape_cheminement = QgsVectorLayer("LineString?crs=epsg:2154", shape_cheminement.name(), "memory")
        features_shape_cheminement_pr2 = features_shape_cheminement.dataProvider()
        features_shape_cheminement_attr2 = shape_cheminement.dataProvider().fields().toList()
        features_shape_cheminement_pr2.addAttributes(features_shape_cheminement_attr2)
        features_shape_cheminement.updateFields()

        features_shape_boites = QgsVectorLayer("Point?crs=epsg:2154", shape_boites.name(), "memory")
        features_shape_boites_pr2 = features_shape_boites.dataProvider()
        features_shape_boites_attr2 = shape_boites.dataProvider().fields().toList()
        features_shape_boites_pr2.addAttributes(features_shape_boites_attr2)
        features_shape_boites.updateFields()

        for index_shape_support, shape_support in enumerate(shape_point_techniques.getFeatures()):
            features_point_techniques_pr2.addFeatures([shape_support])

        for index_shape_support, shape_support in enumerate(shape_cheminement.getFeatures()):
            features_shape_cheminement_pr2.addFeatures([shape_support])

        for index_shape_support, shape_support in enumerate(shape_boites.getFeatures()):
            features_shape_boites_pr2.addFeatures([shape_support])

        # Declaration des attributs pour les shapes declares
        Var_attribut_code_point = self.name_point_attribut  # self.name_point_attribut
        Var_attribut_extremite_ligne = self.createExtremite
        Var_attribut_origine_ligne = self.createOrigine
        Var_attribut_code_ligne = self.name_line_attribut
        Var_attribut_capacite_ligne = self.var_atr_capacite
        Var_attribut_typelog_ligne = self.var_atr_cbtypelog

        attribut_capaOptimisee = 'capaOpt'
        attribut_capaUtilee = 'capaUtile'

        attribut_cb_deriv = 'cb_deriv'
        attribut_ca_deriv = 'ca_deriv'
        attribut_fo_deriv = 'fo_deriv'

        attribut_nbre_fo = "nbreFo"
        attribut_nbre_suf = "nbresuf"
        attribut_nbre_SufSum = "nbreFoSum"

        ##Creation des Listes Pour le calcul de la capacite Optimisee, Utile, section
        listshape_ligne_capaOptimisee = []
        list_Point_Network = []

        ##Ajout des Listes Pour le calcul de la capacite Optimisee, Utile, section
        for index_ligne, ligne in enumerate(shape_ligne.getFeatures()):
            if ligne[Var_attribut_typelog_ligne] != 'RA':
                attribut_liste_ligne = [ligne[Var_attribut_code_ligne], ligne[Var_attribut_origine_ligne],
                                        ligne[Var_attribut_extremite_ligne], \
                                        ligne[Var_attribut_capacite_ligne], ligne[attribut_nbre_suf],
                                        ligne[attribut_nbre_fo], ligne[attribut_nbre_SufSum], 0, 0, 0,
                                        ligne[Var_attribut_typelog_ligne]]  # ligne['section']
                listshape_ligne_capaOptimisee.append(attribut_liste_ligne)

        for index_point, point in enumerate(Point_Network.getFeatures()):
            attr_app = [point[Var_attribut_code_point], point[attribut_nbre_suf], point[attribut_nbre_fo],
                        point[attribut_nbre_SufSum], 0, 0, 0, 0, 0]  # point[6]
            list_Point_Network.append(attr_app)

        ## Mise a Jour des Listes pour leur utilisation dans les parcours recursifs
        self.list_shape_cable = listshape_ligne_capaOptimisee
        self.listshape_noeud = list_Point_Network

        List_Noeud_Sro = ['NRO']  # List des noeuds SRO et SRO Colocalise 'ND000000001612',
        for shape_sro in shape_sro.getFeatures():
            if shape_sro[self.var_atr_typelog] != self.type_sitetech_depart:  # var_atr_typelog #shape_sro[4]
                List_Noeud_Sro.append(shape_sro['st_nd_code'])
        List_Section = []  # Liste de recuperation des sections des noeuds SRO et SRO Colocalise
        List_Type_Cable = ['DI', 'RA']  # Liste des types de cable Distribution et raccordement
        self.function_calcul_Derivation('NRO', 0, 0, List_Noeud_Sro, List_Section,
                                        List_Type_Cable)  # Execution de la function calcul Fo CO CU et Section

        # Partie Mise a Jour des Lignes
        ## Mise a Jour des Listes pour leur utilisation dans le remplissage des shapes
        listshape_ligne_capaOptimisee = self.list_shape_cable

        # Partie Mise a Jour Noeud
        ## Mise a Jour des Listes pour leur utilisation dans le remplissage des shapes
        list_Point_Network = self.listshape_noeud

        # Partie pour le remplissage des derivations des boites
        Point_Network_provider = Point_Network.dataProvider()
        # List_Fields = [field.name() for field in Point_Network.fields()]
        # List_Field_Add = [attribut_cb_deriv,attribut_ca_deriv,attribut_fo_deriv]
        Point_Network_provider.addAttributes([
            QgsField(attribut_cb_deriv, QVariant.String), QgsField(attribut_ca_deriv, QVariant.String),
            QgsField(attribut_fo_deriv, QVariant.String)])
        # for field in List_Field_Add:
        # 	if field not in List_Fields:
        # 		Point_Network_provider.addAttributes([QgsField(field,QVariant.String),QgsField(field,QVariant.String),
        # 			QgsField(field,QVariant.String)])
        Point_Network.updateFields()

        indexe_cb_deriv = Point_Network.fields().indexFromName(attribut_cb_deriv)
        indexe_ca_deriv = Point_Network.fields().indexFromName(attribut_ca_deriv)
        indexe_fo_deriv = Point_Network.fields().indexFromName(attribut_fo_deriv)

        Point_Network_count = Point_Network.featureCount()
        Point_Network.startEditing()
        bar_progress_Point_Networke = self.progress_bar(
            'Execution Ajout des resultats dans le Shape Point Pour la Derivation')
        for index_point, point in enumerate(Point_Network.getFeatures()):
            cb_deriv = 0
            capa_deriv = 0
            fo_deriv = 0

            for noeud in list_Point_Network:
                if point[Var_attribut_code_point] == noeud[0]:
                    cb_deriv = noeud[4]
                    capa_deriv = noeud[5]
                    fo_deriv = noeud[6]

            Point_Network.changeAttributeValue(point.id(), indexe_cb_deriv, cb_deriv)
            Point_Network.changeAttributeValue(point.id(), indexe_ca_deriv, capa_deriv)
            Point_Network.changeAttributeValue(point.id(), indexe_fo_deriv, fo_deriv)

            self.progress_processing(index_point, Point_Network_count, bar_progress_Point_Networke)
            if bar_progress_Point_Networke.wasCanceled():
                iface.messageBar().pushMessage('Info', 'Action Cancelled', level=Qgis.Info)
                break
        Point_Network.commitChanges()

        # Execution pour calcul capaO capaU Seclen
        self.function_calcul_capaOpt_capaUtile_Seclen()

        # Partie Mise a Jour des Sorties SRO
        ## Mise a Jour des Listes pour leur utilisation dans les parcours recursifs
        self.list_shape_cable = listshape_ligne_capaOptimisee

        List_Result_Capa = []
        # List_Noeud_Sro = ['ND000000001612','NRO']
        self.function_calculeFibre_SRO('NRO', 0, 0, List_Result_Capa, List_Section, List_Noeud_Sro)
        # print (List_Section)
        # print('----------------------------------------------')
        # print(List_Result_Capa)

        indexe_cb_FU = shape_ligne.fields().indexFromName(attribut_nbre_fo)
        indexe_cb_capaOptimisee = shape_ligne.fields().indexFromName(attribut_capaOptimisee)
        indexe_cb_capaUtilee = shape_ligne.fields().indexFromName(attribut_capaUtilee)

        bar_progress_res_ligneOptimisee = self.progress_bar(
            'Execution Ajout des resultats dans le Shape Ligne Pour la Capacite Optimisee')
        shape_ligneO_count = shape_ligne.featureCount()
        shape_ligne.startEditing()
        for index_ligne, ligne in enumerate(shape_ligne.getFeatures()):
            for ligneList in List_Result_Capa:
                if ligne[Var_attribut_code_ligne] == ligneList[0]:
                    Cb_FU = ligneList[1]
                    Cb_CO = ligneList[2]
                    Cb_CU = ligneList[3]
                    shape_ligne.changeAttributeValue(ligne.id(), indexe_cb_FU, Cb_FU)
                    shape_ligne.changeAttributeValue(ligne.id(), indexe_cb_capaOptimisee, Cb_CO)
                    shape_ligne.changeAttributeValue(ligne.id(), indexe_cb_capaUtilee, Cb_CU)

            self.progress_processing(index_ligne, shape_ligneO_count, bar_progress_res_ligneOptimisee)
            if bar_progress_res_ligneOptimisee.wasCanceled():
                iface.messageBar().pushMessage('Info', 'Action Cancelled', level=Qgis.Info)
                break
        shape_ligne.commitChanges()
        QgsProject.instance().addMapLayer(features_point_techniques)
        QgsProject.instance().addMapLayer(features_shape_cheminement)
        QgsProject.instance().addMapLayer(features_shape_boites)


# # Declaration des variables
# var_schema = 'pr_2_2_exe_v_20191112'#'pr_2_2_exe'#'pr_2_2_exe_v_20191112'
# var_type_sitetech_depart = 'NRO+SROL'#'NRO+SROL'#'NRO'
# var_t_noeud = 't_noeud'
# var_vs_elem_cl_cb = 'vs_elem_cl_cb'#'vs_elem_cl_cb_PropreAccroche_PropreDouble'#'vs_elem_cl_cb'#'correction_daccrochage'
# var_vs_elem_st_nd = 'vs_elem_st_nd'
# #var_correction_daccrochge = 'correction_daccrochage'
# var_st_typelog = 'st_typelog'
# var_st_nom = 'st_nom'
# var_nd_code = 'nd_code'
# var_cb_code = 'cb_code'
# var_geom = 'geom'
# var_distance_buffer = 0.1
# var_list_shape_cable = []
# var_listshape_noeud = []
#
# var_vs_elem_sf_nd = 'vs_elem_sf_nd'
# var_sfndcode = 'sf_nd_code'
# var_cbcapafo = 'cb_capafo'
# var_cbtypelog = 'cb_typelog'
# var_sfcode = 'sf_code'
#
#
# name_groupe = 'ResultatsTraitement'
# root = QgsProject.instance().layerTreeRoot()
# group = root.findGroup(name_groupe)
# if group is not None:
#    for child in group.children():
#        QgsProject.instance().removeMapLayer(child.layerId())
# root.removeChildNode(group)
# shapeGroup = root.addGroup(name_groupe)
# var_ResultatsTraitement = shapeGroup
# var_ResultatsTraitement2 = name_groupe
#
#
# # Declaration Class Principale
# Class_Modelisation_Reseau = Modelisation_Reseau(var_schema,var_type_sitetech_depart,var_t_noeud,\
#                    var_vs_elem_cl_cb,var_vs_elem_st_nd,\
#                    var_st_typelog, var_nd_code, var_cb_code,var_geom,var_distance_buffer,var_st_nom,\
#                    var_list_shape_cable,var_listshape_noeud,var_vs_elem_sf_nd,var_sfndcode,var_cbcapafo,var_cbtypelog,var_sfcode,\
#                    var_ResultatsTraitement,var_ResultatsTraitement2)
#
#
# Class_Modelisation_Reseau.function_check_detection()
# Class_Modelisation_Reseau.function_count_suf()
# Class_Modelisation_Reseau.function_ajout_calcul_Derivation()


# Class pour les fonctions generales
class General_Functions():
    w = QWidget()

    # Function pour la progession bar1
    def progress_bar(self, name_etape):
        prog = QProgressDialog(name_etape + ' : Veillez Patienter', 'Cancel', 0, 100)
        prog.setWindowModality(Qt.WindowModal)
        prog.setMinimumDuration(1)
        return prog

    # Function pour la progession bar2
    def progress_processing(self, index, count_entite, progress_dialog):
        f = int(index + 1)
        pcnt = int(f / count_entite * 100 / 1)
        progress_dialog.setValue(pcnt)

    # Function pour executer une requete sql dans la base
    def function_execute_requete(self, requete_execute, req_fetch, connection):
        curs = connection.cursor()
        try:
            curs.execute(requete_execute)
            if req_fetch:
                data_req = [row for row in curs.fetchall()]
                if data_req:
                    return data_req
        except(Exception, psycopg2.DatabaseError) as error:
            QMessageBox.warning(self.w, "Message dexecution de requete",
                                'Requete Non Executer : ' + str(error) + ' ; ' + str(requete_execute))
        curs.close()

    # Function pour  Get layer dans la BD
    def function_getLayer_bdd(self, schema, table_name, key, rename_table, column_geom):
        # import qgis.core
        global DB, user, MP, host, port
        uri = QgsDataSourceUri()
        uri.setConnection(host, port, DB, user, MP)
        uri.setDataSource(schema, table_name, column_geom, '', key)
        layer = QgsVectorLayer(uri.uri(False), rename_table, "postgres")
        if layer.isValid():
            # QgsProject.instance().addMapLayer(layer)
            return layer
        else:
            QMessageBox.warning(self.w, "Message", 'Erreur de recuperation de la table : ' + str(table_name))

    # Function Get layer dans Qgis
    def function_getlayer_QGis(self, layer_name):
        layers = [tree_layer.layer() for tree_layer in QgsProject.instance().layerTreeRoot().findLayers()]  # Pyqgis3
        for layer in layers:
            layerType = layer.type()
            if layerType == QgsMapLayer.VectorLayer:
                if layer.name() == layer_name:
                    return layer

    # Function GetLayer In Group
    def GetLayerByGroup(self, nameGroup, nameLayer):
        root = QgsProject.instance().layerTreeRoot()
        group = root.findGroup(nameGroup)
        if not group is None:
            for child in group.children():
                layer_name = child.name()
                if layer_name == nameLayer:
                    return self.function_getlayer_QGis(nameLayer)


# Class pour Importer les donnees dans la BDD
class Import_Shape_CSV_BDD():
    General_Functions = General_Functions()

    # Function pour la creation des tables
    def function_create_table(self, table_name, schema_name, var_geom, var_extension):
        features = self.General_Functions.function_getlayer_QGis(table_name)
        list_fieldname = []
        for index_cm, field_name in enumerate(features.fields()):
            fielname = field_name.name().replace(' ', '_').replace("'", '') + ' text '
            list_fieldname.append(fielname)
        if var_geom:
            list_fieldname.append(var_geom + ' geometry')
        tuple_fieldname = ','.join(list_fieldname)
        req_create_table = 'CREATE TABLE IF NOT EXISTS ' + schema_name + '.' + '"' + table_name + var_extension + '"' + '(' + tuple_fieldname + ')'  # .replace(' ','_').replace('-','_')
        req_drop_table = 'DROP TABLE IF EXISTS ' + schema_name + '.' + '"' + table_name + var_extension + '"'  # .replace(' ','_').replace('-','_')# + '_input'
        return req_drop_table, req_create_table, tuple_fieldname

    # Function pour les insertions des donnees chargees dans Qgis dans la BDD
    def function_insert_data_qgis_BDD(self, var_schema_input, var_create_schema, var_rename_layer):
        # Execution de la bar
        bar_progress = self.General_Functions.progress_bar(
            'Chargement des donnees dans Qgis, Creation du schema Input et Insertion')

        # Creation du Schema Ou seront importer les donnees
        if var_create_schema:
            create_schema_input = """DROP SCHEMA IF EXISTS """ + var_schema_input + """ CASCADE; CREATE SCHEMA """ + var_schema_input
            try:
                self.General_Functions.function_execute_requete(create_schema_input, '', connection)
            except(Exception) as error:
                QMessageBox.warning(self.General_Functions.w, "Message dexecution de requete",
                                    'Erreur dexecution :' + str(error))

        len_maplayer = len(QgsProject.instance().mapLayers().values())
        list_table_create = []
        for index_map, layers_name_mapLayers in enumerate(QgsProject.instance().mapLayers().values()):
            layer_name = layers_name_mapLayers.name()
            layer_features = layers_name_mapLayers.getFeatures()
            list_table_create.append(layer_name)
            layer_type = layers_name_mapLayers.geometryType()  # 1=Ligne, 2=polygon, 0=Point, 4=Sans Geom

            # On ne cree et supprime que les couches chargees dans qgis
            # Tables avec Geometries
            if str(layer_type) != '4':
                try:
                    req_create_table = \
                        self.function_create_table(layer_name, var_schema_input, 'geom', var_rename_layer)[
                            1]  # Requete pour la creation des tables
                    self.General_Functions.function_execute_requete(req_create_table, '',
                                                                    connection)  # Execution de la requete pour la creation des tables
                # print (req_create_table)
                except(Exception) as error:
                    QMessageBox.warning(self.General_Functions.w, "Message dexecution de requete",
                                        'Create des tables Non Executer' + layer_name)

            # Tables sans Geometrie
            elif str(layer_type) == '4':
                try:
                    req_create_table = self.function_create_table(layer_name, var_schema_input, '', var_rename_layer)[
                        1]  # Requete pour la creation des tables
                    # print (req_create_table)
                    self.General_Functions.function_execute_requete(req_create_table, '',
                                                                    connection)  # Execution de la requete pour la creation des tables
                except(Exception) as error:
                    QMessageBox.warning(self.General_Functions.w, "Message dexecution de requete",
                                        'Create des tables Non Executer' + layer_name)

            # Debut de limportations
            if layers_name_mapLayers.type() == QgsMapLayer.VectorLayer:  # and layer_name == 'Point_Network'
                layer_not_empty = len(list(layer_features))
                if layer_not_empty > 0:  # Ignorer linsertion des couches vides
                    layer_re_name = '"' + layer_name + var_rename_layer + '"'
                    list_fielname_sans_geom = \
                        self.function_create_table(layer_name, var_schema_input, '', var_rename_layer)[2].replace(
                            ' text ',
                            '')
                    list_fielname_geom = \
                        self.function_create_table(layer_name, var_schema_input, 'geom', var_rename_layer)[2].replace(
                            ' text ', '').replace('geometry', '')
                    req_insert_prepare = 'INSERT INTO ' + var_schema_input + '.' + layer_re_name + '(' + list_fielname_geom + ') values'
                    req_insert_prepare_sans_geom = 'INSERT INTO ' + var_schema_input + '.' + layer_re_name + '(' + list_fielname_sans_geom + ') values'
                    list_insert_entite = []
                    layer_features = layers_name_mapLayers.getFeatures()
                    insert_geom = ''
                    for index_layer, layer in enumerate(layer_features):
                        geome_text = layer.geometry().asWkt()
                        attr_insert = '-1'
                        replace_null_value = tuple(
                            [NULL if field in [NULL, '??'] else unicode(field).replace("'", '') for field in
                             layer.attributes()])
                        #                        print (replace_null_value)#str(layer.attributes()).replace(', None','')
                        #                        break
                        if geome_text:
                            insert_geom = 'geom'
                            attr_insert = replace_null_value + ("ST_GeomFromText('" + geome_text + "',2154)",)
                        if not geome_text:
                            insert_geom = 'sansgeom'
                            attr_insert = replace_null_value
                        list_insert_entite.append(attr_insert)
                    if insert_geom:
                        if insert_geom == 'geom':
                            req_insert_finale = req_insert_prepare + unicode(list_insert_entite).replace('[',
                                                                                                         '').replace(
                                ']', '').replace('"', '')
                        elif insert_geom == 'sansgeom':
                            req_insert_finale = req_insert_prepare_sans_geom + unicode(list_insert_entite).replace('[',
                                                                                                                   '').replace(
                                ']', '').replace('"', '')
                        try:
                            # print(req_insert_finale)
                            # break
                            self.General_Functions.function_execute_requete(req_insert_finale, '', connection)
                        except(Exception) as error:
                            QMessageBox.warning(self.General_Functions.w, "Message dexecution de requete",
                                                'Requete Insertion des donnees Non Executer' + layer_name)
            self.General_Functions.progress_processing(index_map, len_maplayer, bar_progress)
            if bar_progress.wasCanceled():
                iface.messageBar().pushMessage('Info', 'Action Cancelled', level=Qgis.Info)
                break


def function_execute_import_bdd(var_schema_name, create_shema, extension_table):
    global Import_Shape_CSV_BDD, connection
    var_Import_Shape_CSV_BDD = Import_Shape_CSV_BDD()
    var_Import_Shape_CSV_BDD.function_insert_data_qgis_BDD(var_schema_name, create_shema,
                                                           extension_table)  # 1 = nom_schema, 2 = SiCreateSchema, 3 = SiExtensionNomTable
    connection.commit()
    QMessageBox.information(General_Functions.w, "Message dexecution de requete", 'Execution Terminee')


# Class pour decoupe des lignes sans suppression de doublons de geometrie
class Class_Decoup_Line_Points():
    w = QWidget()
    General_Functions = General_Functions()

    # Couper les lignes par rapport aux Points
    def cut_line_at_points(self, line, points):

        # First coords of line
        coords = list(line.coords)

        # Keep list coords where to cut (cuts = 1)
        cuts = [0] * len(coords)
        cuts[0] = 1
        cuts[-1] = 1

        # Add the coords from the points
        coords += [list(p.coords)[0] for p in points]
        cuts += [1] * len(points)

        # Calculate the distance along the line for each point    
        dists = [line.project(Point(p)) for p in coords]
        # sort the coords/cuts based on the distances    
        # see http://stackoverflow.com/questions/6618515/sorting-list-based-on-values-from-another-list    
        coords = [p for (d, p) in sorted(zip(dists, coords))]
        cuts = [p for (d, p) in sorted(zip(dists, cuts))]

        # generate the Lines    
        # lines = [LineString([coords[i], coords[i+1]]) for i in range(len(coords)-1)]
        lines = []

        for i in range(len(coords) - 1):
            if cuts[i] == 1:
                # find next element in cuts == 1 starting from index i + 1 
                try:
                    j = cuts.index(1, i + 1)
                    lines.append(LineString(coords[i:j + 1]))
                except(Exception) as error:
                    QMessageBox.warning(self.w, "Message dexecution de requete", 'Erreur dexecution :' + str(error))
                    break
        return lines

    # Convertir les geometries multiparts to single part
    def multipart_to_singlepart(self, geom):

        multiGeom = QgsGeometry()
        geometries = []

        if geom != NULL or geom.isGeosValid():
            if geom.type() == QgsWkbTypes.LineGeometry:
                if geom.isMultipart():
                    multiGeom = geom.asMultiPolyline()
                    for i in multiGeom:
                        geometries.append(QgsGeometry().fromPolylineXY(i))
                else:
                    geometries.append(geom)

        return geometries

    # Execution de la function de conversion des geometries multiparts to single part
    def function_multipart_to_singlepart(self, layer_cable):

        if layer_cable.isValid():
            multiline_to_sigleline = QgsVectorLayer("LineString?crs=epsg:2154", "multiline_to_sigleline", "memory")
            multiline_to_sigleline_pr2 = multiline_to_sigleline.dataProvider()
            multiline_to_sigleline_attr2 = layer_cable.dataProvider().fields().toList()
            multiline_to_sigleline_pr2.addAttributes(multiline_to_sigleline_attr2)

            for feature_cab in layer_cable.getFeatures():
                geom_cable = feature_cab.geometry()

                if geom_cable != NULL or geom_cable.isGeosValid():
                    geometries = self.multipart_to_singlepart(geom_cable)

                    outFeat = QgsFeature()
                    attrs = feature_cab.attributes()
                    outFeat.setAttributes(attrs)

                    for g in geometries:
                        outFeat.setGeometry(g)
                        multiline_to_sigleline_pr2.addFeatures([outFeat])

            multiline_to_sigleline.updateFields()
            multiline_to_sigleline.commitChanges()

            return multiline_to_sigleline
        else:
            QMessageBox.warning(self.w, "function_multipart_to_singlepart", 'Layer invalide')

    # Detection des origines/extremites
    def function_detection_origine_extremite(self, layer_chem, layer_boite):  # function_B01_1

        if layer_chem.isValid() and layer_boite.isValid():

            bar_progress = self.General_Functions.progress_bar('Detection des Origines/Extremites')
            layer_features = layer_chem
            features_boite = layer_boite

            # Creation des shapefles des erreurs
            cable_decoupe = QgsVectorLayer("LineString?crs=EPSG:2154", "cable_decoupe", "memory")
            cable_decoupe_pr = cable_decoupe.dataProvider()
            cable_decoupe.startEditing()
            cable_decoupe_pr.addAttributes(
                [QgsField('NOM', QVariant.String), QgsField('LG_REELLE', QVariant.Double, 'double', 200, 2), \
                 QgsField('Originee', QVariant.String),
                 QgsField('Extremitee', QVariant.String)])  # ,QgsField('PROPRIETAI', QVariant.String)
            cable_decoupe.updateFields()
            cable_decoupe.commitChanges()

            # Creation Index des boites
            feature_dict_boite = {f.id(): f for f in features_boite.getFeatures()}
            index_boite = QgsSpatialIndex()
            for current, f in enumerate(feature_dict_boite.values()):
                geom_point = f.geometry()
                if geom_point != NULL or geom_point.isGeosValid():
                    index_boite.insertFeature(f)

            count_features = layer_features.featureCount()
            features = layer_features.getFeatures()  #
            count = 0
            for index, var_line in enumerate(features):
                geom_line = var_line.geometry()  # QgsGeometry.fromWkt(uniq)
                if geom_line != NULL or geom_line.isGeosValid():
                    boite_origine = '-1'
                    boite_extremite = '-1'
                    if geom_line.wkbType() == QgsWkbTypes.MultiLineString:
                        geom_line_type = geom_line.asMultiPolyline()
                        cable_origine = geom_line_type[0][0]
                        cable_extremite = geom_line_type[-1][-1]

                    if geom_line.wkbType() == QgsWkbTypes.LineString:
                        geom_line_type = geom_line.asPolyline()
                        cable_origine = geom_line_type[0]
                        cable_extremite = geom_line_type[-1]

                    candidates = index_boite.intersects(geom_line.boundingBox())
                    if candidates:
                        for candidate_id in candidates:
                            attr_feature_dict_boite = feature_dict_boite[candidate_id]
                            geomboite = attr_feature_dict_boite.geometry()  # geomSufIntersects = feature_suf_dict[candidate_id]
                            if geomboite.within(geom_line.buffer(0.1, 0.1)):
                                if (QgsGeometry.fromPointXY(QgsPointXY(cable_origine))).within(
                                        geomboite.buffer(0.1, 0.1)):
                                    boite_origine = attr_feature_dict_boite['pt_code']  # candidate_id
                                if (QgsGeometry.fromPointXY(QgsPointXY(cable_extremite))).within(
                                        geomboite.buffer(0.1, 0.1)):
                                    boite_extremite = attr_feature_dict_boite['pt_code']  # candidate_id
                    longueur = geom_line.length()
                    # if boite_origine != '-1' and boite_extremite != '-1' and longueur > 500:
                    count += 1
                    feat = QgsFeature()
                    feat.setGeometry(geom_line)
                    attrs = ['Ligne_' + unicode(count), longueur, boite_origine, boite_extremite]  # ,''
                    feat.setAttributes(attrs)
                    cable_decoupe_pr.addFeatures([feat])
                self.General_Functions.progress_processing(index, count_features, bar_progress)
                if bar_progress.wasCanceled():
                    iface.messageBar().pushMessage('Info', 'Action Cancelled', level=Qgis.Info)
                    break
            cable_decoupe.commitChanges()
            cable_decoupe.updateExtents()
            # QgsProject.instance().addMapLayer(cable_decoupe)
            return cable_decoupe
        else:
            QMessageBox.warning(self.w, "function_detection_origine_extremite", 'Layer invalide')
        # return list_boite_cable

    # Creation de la ligne de decoupe
    def function_create_ligne_decoupe(self, layer_cable, layer_ptech, var_cb_typelog, var_RAC):

        if layer_cable.isValid() and layer_ptech.isValid():

            layer_cable = self.function_multipart_to_singlepart(layer_cable)

            bar_progress = self.General_Functions.progress_bar(
                'Creation de la couche decoupe des lignes / Detection Origine/Extremite')

            # Creation des shapefles des erreurs
            Infra_Createe = QgsVectorLayer("LineString?crs=EPSG:2154", "Infra_Createe", "memory")
            Infra_Createe_pr = Infra_Createe.dataProvider()
            Infra_Createe.startEditing()
            Infra_Createe_pr.addAttributes([QgsField('NOM', QVariant.String),
                                            QgsField('LG_REELLE', QVariant.Double, 'double', 200,
                                                     2)])  # ,QgsField('PROPRIETAI', QVariant.String)
            Infra_Createe.updateFields()
            Infra_Createe.commitChanges()

            count = 0

            list_infra_creat_Avec_doublon = []
            list_lines_for_merge = []

            # Creation dictionnary pour recuperer les points a decouper pour chaque ligne
            linestring_dict_points = defaultdict(list)

            # Creation Index des Points Techniques
            feature_dict_pt = {f.id(): f for f in layer_ptech.getFeatures()}
            index_ptech = QgsSpatialIndex()
            for current, f in enumerate(feature_dict_pt.values()):
                geom_point = f.geometry()
                if geom_point != NULL or geom_point.isGeosValid():
                    index_ptech.insertFeature(f)

            # Len Features
            len_features_cable = len([feature for feature in layer_cable.getFeatures()])
            for index, feature_cab in enumerate(layer_cable.getFeatures()):
                # if feature_cab[var_cb_typelog] != var_RAC:#['cb_typelog'] != 'RA':
                geom_cable = feature_cab.geometry()
                if geom_cable != NULL or geom_cable.isGeosValid():
                    candidates = index_ptech.intersects(geom_cable.boundingBox())
                    if candidates:
                        for candidate_id in candidates:
                            attr_feature_dict_pt = feature_dict_pt[candidate_id]
                            geomptech = attr_feature_dict_pt.geometry()
                            # geomptech = geoms_ptech[candidate_id]
                            geom_ptech_wkt2 = Point(geomptech.asPoint())
                            if geomptech.within(geom_cable.buffer(0.1, 0.1)):
                                linestring_dict_points[geom_cable].append(geom_ptech_wkt2)
                self.General_Functions.progress_processing(index, len_features_cable, bar_progress)
                if bar_progress.wasCanceled():
                    iface.messageBar().pushMessage('Info', 'Action Cancelled', level=Qgis.Info)
                    break
            # Creation du shape de decoupe des lignes
            list_result_cut_linest = []
            for index, (key, value) in enumerate(linestring_dict_points.items()):
                geom_cable_wkt2 = LineString(key.asPolyline())
                result_cut_linest = self.cut_line_at_points(geom_cable_wkt2, value)
                list_result_cut_linest.append(result_cut_linest)
                for index, cut_line in enumerate(result_cut_linest):
                    geom_inf_decoupe = QgsGeometry.fromWkt(unicode(cut_line).replace('LINESTRING', 'LineString'))
                    count += 1
                    if geom_inf_decoupe != NULL or geom_inf_decoupe.isGeosValid():
                        feat = QgsFeature()
                        feat.setGeometry(geom_inf_decoupe)
                        longueur = geom_inf_decoupe.length()
                        if str(longueur) != '0.0':
                            attrs = ['Ligne_' + unicode(count), longueur]  # ,''
                            feat.setAttributes(attrs)
                            Infra_Createe_pr.addFeatures([feat])
                self.General_Functions.progress_processing(index, len(linestring_dict_points), bar_progress)
                if bar_progress.wasCanceled():
                    iface.messageBar().pushMessage('Info', 'Action Cancelled', level=Qgis.Info)
                    break

            Infra_Createe.commitChanges()
            Infra_Createe.updateExtents()

            features_cable = Infra_Createe
            decoupe_cables = self.function_detection_origine_extremite(features_cable, layer_ptech)
            # return decoupe_cables
            QgsProject.instance().addMapLayer(decoupe_cables)
        # return boite_plus_500m
        else:
            QMessageBox.warning(self.w, "function_create_ligne_decoupe", 'Layer invalide')


# Declaration des couches
# features_cable = General_Functions().GetLayerByGroup('Dev_Data', 'cable')
# # features_cable_decoupe_pt = General_Functions().GetLayerByGroup('Dev_Data', 'cable_decoupe')
# features_pt = General_Functions().GetLayerByGroup('Dev_Data', 'Point_Technique')
# features_boite = General_Functions().GetLayerByGroup('Input_Data', 'vs_elem_bp_pt_nd')
# features_chem = General_Functions().GetLayerByGroup('Dev_Data', 't_cheminement')

# # Variables pour Class_Decoup_Line_Points
# var_cb_typelog = 'cb_typelog'
# var_RAC = 'RA'
#
# # Variables pour Dimensionnement_Cables
# var_capaUtile = 'capaUtile'
# var_cb_etiquet = 'cb_etiquet'
# var_CFI = 'CFI'
# var_bp_typelog = 'bp_typelog'
# var_PBO = 'PBO'
# var_bp_etiquet = 'bp_etiquet'
# var_BFI = 'BFI'
#
# # Variables pour Insert resultats dans t_echange
# schema = var_schema
# var_MOE = 'MOE'
# var_PR = 'pr_2_2_exe_v_20191112'
# var_phase = 'DEO'

# Declaration Class Principale de Decoupe
# var_Class_Decoup_Line_Points = Class_Decoup_Line_Points()
# features_cable_decoupe_pt = var_Class_Decoup_Line_Points.function_create_ligne_decoupe(features_cable,features_pt,'','')#var_cb_typelog,var_RAC

# listing_error_control_ADN = []
# Class pour les controls des cables
class Dimensionnement_Cables():
    w = QWidget()
    General_Functions = General_Functions()

    # listing_error_control_ADN = []
    def __init__(self):
        self.listing_error_control_ADN = []

    # ajouter dans cm_fo_util de la table cheminement
    def function_C01_1(self, var_layer_chem, var_layer_cable_decoup, var_layer_cable, var_capaUtile):
        """Verifier que la capacite utile du cheminement est coherente.
        Decouper les cebles en fonction des points techniques et faire la somme des capafo des troncons entre deux points techniques
        et de lajouter dans cm_fo_util de la table cheminement"""
        if var_layer_chem.isValid() and var_layer_cable_decoup.isValid() and var_layer_cable.isValid():

            List_Fields = [field.name() for field in var_layer_chem.fields()]
            layer_provider_shape_ligne = var_layer_chem.dataProvider()
            if var_capaUtile not in List_Fields:
                layer_provider_shape_ligne.addAttributes([QgsField(var_capaUtile, QVariant.Int)])
            var_layer_chem.updateFields()
            indexe_cm_fo_util2 = var_layer_chem.fields().indexFromName(var_capaUtile)

            bar_progress = self.General_Functions.progress_bar('Calcul des capaUtile dans les cheminements')
            # Creation Index des ligne decoupe
            feature_dict_ligne_decoupe = {f.id(): f for f in var_layer_cable_decoup.getFeatures()}
            index_ligne_decoupe = QgsSpatialIndex()
            for current, f in enumerate(feature_dict_ligne_decoupe.values()):
                geom_point = f.geometry()
                if geom_point != NULL or geom_point.isGeosValid():
                    index_ligne_decoupe.insertFeature(f)

            # Creation Index des ligne decoupe
            feature_dict_var_layer_cable = {f.id(): f for f in var_layer_cable.getFeatures()}
            index_var_layer_cable = QgsSpatialIndex()
            for current, f in enumerate(feature_dict_var_layer_cable.values()):
                geom_cable = f.geometry()
                if geom_cable != NULL or geom_cable.isGeosValid():
                    index_var_layer_cable.insertFeature(f)

            count_features = var_layer_chem.featureCount()
            var_layer_chem.startEditing()
            for index_ligne, var_ligne in enumerate(var_layer_chem.getFeatures()):
                geomLigne = var_ligne.geometry()
                candidates = index_ligne_decoupe.intersects(geomLigne.boundingBox())
                List_Capa_Decoup = []
                if candidates:
                    for candidate_id in candidates:
                        attr_feature_dict_ligne_decoupe = feature_dict_ligne_decoupe[candidate_id]
                        geomLigneDecoupe = attr_feature_dict_ligne_decoupe.geometry()
                        if geomLigneDecoupe.within(geomLigne.buffer(0.1, 0.1)):
                            candidatesCable = index_var_layer_cable.intersects(geomLigneDecoupe.boundingBox())
                            if candidatesCable:
                                for candidatesCable_id in candidatesCable:
                                    attr_feature_dict_var_layer_cable = feature_dict_var_layer_cable[candidatesCable_id]
                                    geomCable = attr_feature_dict_var_layer_cable.geometry()
                                    if geomLigneDecoupe.within(geomCable.buffer(0.1, 0.1)):
                                        attr_append = attr_feature_dict_var_layer_cable[var_capaUtile]
                                        if attr_append not in List_Capa_Decoup:
                                            List_Capa_Decoup.append(attr_append)
                if List_Capa_Decoup:
                    # print (var_ligne[0],';',List_Capa_Decoup,';',sum(List_Capa_Decoup),';',var_ligne['cm_fo_util'])
                    var_layer_chem.changeAttributeValue(var_ligne.id(), indexe_cm_fo_util2, int(sum(List_Capa_Decoup)))
                self.General_Functions.progress_processing(index_ligne, count_features, bar_progress)
                if bar_progress.wasCanceled():
                    iface.messageBar().pushMessage('Info', 'Action Cancelled', level=Qgis.Info)
                    break
            var_layer_chem.commitChanges()

    # function_C01_1(features_chem, features_cable_decoupe_pt,features_cable,var_capaUtile)
    # Verifier que la capacite du cable est  coherente avec la capacite utile
    def function_C02_1(self, var_layer_ligne):
        """Verifier que la capacite du cable est coherente avec la capacite utile"""
        if var_layer_ligne.isValid():
            bar_progress = self.General_Functions.progress_bar('Verification de la coherence entre CapaUtile et CapaFo')
            count_features = var_layer_ligne.featureCount()
            message_C02_1 = 'C02_1'
            for index_ligne, var_ligne in enumerate(var_layer_ligne.getFeatures()):
                geomLigne = var_ligne.geometry()
                geomLigneWkt = geomLigne.buffer(0.5, 0.5).asWkt()
                if var_ligne['cb_typelog'] != 'RA':
                    if int(var_ligne['capaUtile']) > int(var_ligne['cb_capafo']):
                        # print (var_ligne[0],';',var_ligne['capaUtile'],';',var_ligne['cb_capafo'])
                        self.listing_error_control_ADN.append([var_ligne[0], geomLigneWkt, message_C02_1])
                    if int(var_ligne['capaUtile']) * 2 == int(var_ligne['cb_capafo']):
                        # print ('Double',';',var_ligne[0],';',int(var_ligne['capaUtile']) * 2,';',var_ligne['cb_capafo'])
                        self.listing_error_control_ADN.append([var_ligne[0], geomLigneWkt, message_C02_1])
                self.General_Functions.progress_processing(index_ligne, count_features, bar_progress)
                if bar_progress.wasCanceled():
                    iface.messageBar().pushMessage('Info', 'Action Cancelled', level=Qgis.Info)
                    break

    # function_C02_1(features_cable)
    # Verifier loptimisation des changements de cable
    def function_C03_1(self, var_layer_ligne, var_layer_ligne_decoup):
        """Verifier loptimisation des changements de cable (saut de de capacite, et en bout de branche notamment).
        Verifier le changement des capacites des cables sur une meme section ayant une longueur inferieur a 300 m."""
        pass

    # Verifier quil ny a pas de CFI raccordes a des PBO
    def function_C05_1(self, var_layer_ligne, var_layer_point, var_cb_etiquet, var_CFI, var_bp_typelog, var_PBO,
                       var_bp_etiquet, var_BFI):
        if var_layer_ligne.isValid() and var_layer_point.isValid():
            bar_progress = self.General_Functions.progress_bar('Verification des CFI raccordes a un PBO')
            # Creation Index des ligne decoupe
            feature_dict_point = {f.id(): f for f in var_layer_point.getFeatures()}
            index_point = QgsSpatialIndex()
            for current, f in enumerate(feature_dict_point.values()):
                # if f['bp_typelog'] == 'PBO' and f['bp_etiquet'][:3] != 'CFI':
                geom_point = f.geometry()
                if geom_point != NULL or geom_point.isGeosValid():
                    index_point.insertFeature(f)
            count_features = var_layer_ligne.featureCount()
            for index_ligne, var_ligne in enumerate(var_layer_ligne.getFeatures()):
                if var_ligne[var_cb_etiquet][
                   :3] == var_CFI:  # var_cb_etiquet, var_CFI, var_bp_typelog, var_PBO, var_bp_etiquet, var_BFI
                    attr_append = '-1'
                    geomLigne = var_ligne.geometry()
                    geomLigneWkt = geomLigne.buffer(0.5, 0.5).asWkt()
                    message_C05_1 = 'C05_1'

                    if geomLigne.wkbType() == QgsWkbTypes.MultiLineString:
                        geom_support_type = geomLigne.asMultiPolyline()
                        support_origine = geom_support_type[0][0]
                        support_extremite = geom_support_type[-1][-1]

                    if geomLigne.wkbType() == QgsWkbTypes.LineString:
                        geom_support_type = geomLigne.asPolyline()
                        support_origine = geom_support_type[0]
                        support_extremite = geom_support_type[-1]

                    candidates = index_point.intersects(geomLigne.boundingBox())
                    if candidates:
                        for candidate_id in candidates:
                            attr_feature_dict_point = feature_dict_point[candidate_id]
                            geomPoint = attr_feature_dict_point.geometry()  # geomSufIntersects = feature_suf_dict[candidate_id]
                            if geomPoint != NULL or geomPoint.isGeosValid():
                                if (QgsGeometry.fromPointXY(QgsPointXY(support_extremite))).within(
                                        geomPoint.buffer(0.1, 0.1)):
                                    if attr_feature_dict_point[var_bp_typelog] == var_PBO and attr_feature_dict_point[
                                                                                                  var_bp_etiquet][
                                                                                              :3] != var_BFI:
                                        attr_append = attr_feature_dict_point[var_bp_etiquet]  # +'_'+'Extremite'
                    if attr_append != '-1':
                        # print (var_ligne[0],';',attr_append,';',var_ligne['cb_etiquet'])
                        self.listing_error_control_ADN.append([var_ligne[0], geomLigneWkt, message_C05_1])
                self.General_Functions.progress_processing(index_ligne, count_features, bar_progress)
                if bar_progress.wasCanceled():
                    iface.messageBar().pushMessage('Info', 'Action Cancelled', level=Qgis.Info)
                    break

    # function_C05_1(features_cable, features_boite,var_cb_etiquet, var_CFI, var_bp_typelog, var_PBO, var_bp_etiquet, var_BFI)
    # Verifier quil ny a pas de cables de forte capacite inferieurs a 300m + zone radiale
    def function_C06_1_2(self, var_layer_ligne):
        """Verifier quil ny a pas de cables de forte capacite inferieurs a 300m + zone radiale (sauf justification due a la structure du reseau existant)"""
        if var_layer_ligne.isValid():
            bar_progress = self.General_Functions.progress_bar(
                'Verification des cables de forte capacite inferieurs a 300m')
            count_features = var_layer_ligne.featureCount()
            List_CB_Forte_Capa = ['864', '720', '576', '432', '288']
            for index_ligne, var_ligne in enumerate(var_layer_ligne.getFeatures()):
                geomLigne = var_ligne.geometry()
                geomLigneWkt = geomLigne.buffer(0.5, 0.5).asWkt()
                message_C06_1_2 = 'C06_1'
                if geomLigne != NULL or geomLigne.isGeosValid():
                    if str(var_ligne['cb_capafo']) in List_CB_Forte_Capa and geomLigne.length() <= 300:
                        # print (var_ligne[0],';',geomLigne.length(),';',var_ligne['cb_capafo'])
                        self.listing_error_control_ADN.append([var_ligne[0], geomLigneWkt, message_C06_1_2])
                self.General_Functions.progress_processing(index_ligne, count_features, bar_progress)
                if bar_progress.wasCanceled():
                    iface.messageBar().pushMessage('Info', 'Action Cancelled', level=Qgis.Info)
                    break

    # function_C06_1_2(features_cable)
    # Function pour inserer dans la table derreur control adn t_echange
    def function_create_tab_shape_erreur_control_design(self, schema, var_MOE, var_PR, var_phase):
        # shape_erreur_control_design,pr_shape_erreur_control_design,
        global connection
        var_connection = connection
        table_zsro = 't_zsro'
        attribut_zs_refpm = 'zs_refpm'
        var_aud = 'AUD'
        var_type = 'AUD'

        now = datetime.datetime.now()
        nowdate = str(now.year) + '-' + str(now.month).zfill(2) + '-' + str(now.day).zfill(2)

        # Creation de la table erreur_Control sil nexiste pas
        requete_create_tab = """SET search_path = """ + schema + """, public;
			CREATE TABLE if not exists t_echange
			(
				cle text, --VARCHAR(254),
				ident text, --VARCHAR(254),
				localisation text, --VARCHAR(20),
				num_sro text, --VARCHAR(20),
				phase text, --VARCHAR(20),
				type_rem text, --VARCHAR(20),
				support text, --VARCHAR(20),
				id text, --VARCHAR(254),
				com_init text, --VARCHAR(254),
				date_cr text, --TIMESTAMP,
				criticite text, --VARCHAR(20),
				actions text, --VARCHAR(20),
				destinataire text, --VARCHAR(254),
				prise_en_compte text, --VARCHAR(20),
				valid_derog text, --VARCHAR(20),
				com_rep text, --VARCHAR(254),
				date_rep text, --TIMESTAMP,
				lien_inter_rem text, --VARCHAR(254),
				geom geometry(Polygon,2154),
				CONSTRAINT t_echange_pk PRIMARY KEY (cle)
			);
			ALTER TABLE t_echange OWNER TO adn_ing;
			CREATE INDEX IF NOT EXISTS t_echange_geom_gist ON t_echange USING gist(geom);
			GRANT ALL ON TABLE t_echange TO adn_ing;
			GRANT ALL ON TABLE t_echange TO postgres;"""
        # Execution de la creation de la table erreur_control

        self.General_Functions.function_execute_requete(requete_create_tab, '', connection)
        # connection.commit()
        # print(requete_create_tab)

        table_erreur_control_adn = 't_echange'
        req_erreur_control_adn = """select count (*)::int from """ + schema + """.""" + table_erreur_control_adn
        get_count_erreur_control_adn = self.General_Functions.function_execute_requete(req_erreur_control_adn, 'bab',
                                                                                       connection)
        value_get_count_erreur_control_adn = get_count_erreur_control_adn[0][
            0]  # ','.join([str(i).replace(',','').replace('(','').replace(')','') for i in get_count_erreur_control_adn])

        name_pr_techange = str(var_PR).upper()[0:-15].replace('_', '-')

        bar_progress = self.General_Functions.progress_bar(
            'Insertion des erreurs dans la base sur schema correspondant')
        len_features_error = len(self.listing_error_control_ADN)

        req_tab_code_erreur = """select * from """ + schema + """.t_code_erreur"""
        table_code_erreur = self.General_Functions.function_execute_requete(req_tab_code_erreur, 'bab', connection)

        # export Shapefile erreur de control des designs
        layer_zsro = self.General_Functions.function_getLayer_bdd(schema, table_zsro, '', table_zsro, 'geom')  # zs_code
        # self.function_getLayer_bdd(self.schema,self.name_line,self.name_line_attribut,self.name_line,self.geom_attribut)

        # Creation Index des boites
        feature_dict_layer_zsro = {f.id(): f for f in layer_zsro.getFeatures()}
        index_zsro = QgsSpatialIndex()
        for current, f in enumerate(feature_dict_layer_zsro.values()):
            geom_point = f.geometry()
            if geom_point != NULL or geom_point.isGeosValid():
                index_zsro.insertFeature(f)

        count = int(value_get_count_erreur_control_adn)
        for feature_id, geom in enumerate(self.listing_error_control_ADN):
            geom_error = QgsGeometry.fromWkt(geom[1])  # geom[1]
            Name_PM = 'Pas de Zone SRO en Intersection ou bien lattribut zs_refpm du shapefile t_zsro est vide'
            id_comment = geom[2]
            id_categorie = geom[2]
            id_criticite = ''
            id_type = ''
            candidates = index_zsro.intersects(geom_error.boundingBox())
            id_cles = var_aud + '_' + var_MOE + '_' + unicode(count).zfill(6)
            id_code_entite = geom[0]
            if candidates:
                for candidate_id in candidates:
                    attr_feature_layer_zsro = feature_dict_layer_zsro[candidate_id]
                    geom_zsro = attr_feature_layer_zsro.geometry()
                    if geom_error.intersects(geom_zsro.buffer(0.1, 0.1)):
                        Name_PM = attr_feature_layer_zsro[attribut_zs_refpm]

            for current_code_erreur, var_code_erreur in enumerate(table_code_erreur):
                if var_code_erreur[0] == geom[2]:  # Code egale column 2
                    id_comment = var_code_erreur[3]  # Comment egale column 3
                    id_categorie = var_code_erreur[2]  # Categorie egale column 1
                    id_criticite = var_code_erreur[4]  # Criticite egale column 4
                    id_type = var_code_erreur[1]  # Criticite egale column 4

            feat = QgsFeature()
            feat.setGeometry(geom_error)  # geom[1]
            geome_text = geom_error.asWkt()  # geom[1]
            if geome_text != '':
                count += 1
                requete_insert_tab_echange = """INSERT INTO """ + schema + """.""" + """t_echange""" + """(
						cle, ident, localisation, num_sro, phase, type_rem, support,
						id, com_init, date_cr, criticite, actions,
						destinataire, prise_en_compte, valid_derog, com_rep, date_rep,
						lien_inter_rem, geom)
						VALUES ('""" + str(id_cles) + """','""" + str(var_MOE) + """','""" + str(
                    name_pr_techange) + """','""" + str(Name_PM) + """','""" + str(var_phase) + """','""" + str(
                    id_type) + """','""" + str(id_categorie) + """',
								'""" + str(id_code_entite) + """','""" + str(id_comment) + """','""" + str(
                    nowdate) + """','""" + str(id_criticite) + """', null,
								null,null,null,null,null,
								null,""" + """ST_GeomFromText(st_astext(ST_Geometryn(ST_GeomFromText('""" + str(
                    geome_text) + """',2154),1)),2154)""" + """);"""

                # Execution de linsertion de la table erreur_control
                self.General_Functions.function_execute_requete(requete_insert_tab_echange, '', connection)
            self.General_Functions.progress_processing(feature_id, len_features_error, bar_progress)
            if bar_progress.wasCanceled():
                iface.messageBar().pushMessage('Info', 'Action Cancelled', level=Qgis.Info)
                break

        connection.commit()

# var_Dimensionnement_Cabless = Dimensionnement_Cables()
# function_C01_1 = var_Dimensionnement_Cabless.function_C01_1(features_chem, features_cable_decoupe_pt,features_cable,var_capaUtile)
# function_C02_1 = var_Dimensionnement_Cabless.function_C02_1(features_cable)
# function_C05_1 = var_Dimensionnement_Cabless.function_C05_1(features_cable, features_boite,var_cb_etiquet, var_CFI, var_bp_typelog, var_PBO, var_bp_etiquet, var_BFI)
# function_C06_1_2 = var_Dimensionnement_Cabless.function_C06_1_2(features_cable)
# function_Insert_Res = var_Dimensionnement_Cabless.function_create_tab_shape_erreur_control_design(schema,var_MOE,var_PR,var_phase)

# connection.commit()
# connection.close()
