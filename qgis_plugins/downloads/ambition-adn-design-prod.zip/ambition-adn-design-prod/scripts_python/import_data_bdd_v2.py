# -*- coding: utf-8 -*-
import psycopg2
import xlwt
from qgis.PyQt.QtCore import *
from qgis.PyQt.QtGui import *
from qgis.PyQt.QtWidgets import *
from qgis.core import *
from qgis.utils import *


class FunctionsGeneral:
    w = QWidget()

    # Function pour la progression bar1
    def progress_bar(self, name_etape):
        prog = QProgressDialog(name_etape + ' : Veillez Patienter', 'Cancel', 0, 100)
        prog.setWindowModality(Qt.WindowModal)
        prog.setMinimumDuration(1)
        return prog

    # Function pour la progession bar2
    def progress_processing(self, index, count_entite, progress_dialog):
        f = int(index + 1)
        pcnt = int(f / count_entite * 100 / 1)
        progress_dialog.setValue(pcnt)

    # Function pour executer une requete sql dans la base
    def function_execute_requete(self, requete_execute, req_fetch, connection):
        curs = connection.cursor()
        try:
            curs.execute(requete_execute)
            if req_fetch:
                data_req = [row for row in curs.fetchall()]
                if data_req:
                    return data_req
        except(Exception, psycopg2.DatabaseError) as error:
            QMessageBox.warning(self.w, "Message dexecution de requete",
                                'Requete Non Executer : ' + str(error) + ' ; ' + str(requete_execute))
        curs.close()

    # Function Get file Sql
    def getFileContentSql(self, pathAndFileName, var_replace_schemaGra, schema_nameGra,
                          var_replace_schemaGra_IN_CHECK, schema_nameGra_In_CHECK):
        with open(pathAndFileName, 'r') as theFile:
            data = theFile.read().replace(var_replace_schemaGra, schema_nameGra).replace(var_replace_schemaGra_IN_CHECK,
                                                                                         schema_nameGra_In_CHECK)
            theFile.close()
            return data

    # Function pour recuperer lobjet deune couche a partir de son nom
    def function_getlayer_name(self, layer_name):
        layers = [tree_layer.layer() for tree_layer in QgsProject.instance().layerTreeRoot().findLayers()]
        for layer in layers:
            layerType = layer.type()
            if layerType == QgsMapLayer.VectorLayer:
                if layer.name() == layer_name:
                    return layer

    # Funciton de creations des noms des groups
    def function_create_groupe_name(self, name_groupe):
        root = QgsProject.instance().layerTreeRoot()
        group = root.findGroup(name_groupe)
        root.removeChildNode(group)
        shapeGroup = root.addGroup(name_groupe)
        return shapeGroup

    # Function pour ajouter les tables dans leur groupe respectif
    def function_add_layer_group(self, layer_to_add, groupe_name):
        QgsProject.instance().addMapLayer(layer_to_add, False)
        groupe_name.insertChildNode(0, QgsLayerTreeLayer(layer_to_add))

    # Function Suppression du group ajoute dans QGis
    def functiondelete_layer_qgis(self, name_groupe):
        root = QgsProject.instance().layerTreeRoot()
        group = root.findGroup(name_groupe)
        if group is not None:
            root.removeChildNode(group)


class CreateModeleGraceTHD:
    functions_General = FunctionsGeneral()

    def __init__(self, var_name_Gracethd_File_SQL, var_schema_Gracethd_MOD, var_name_GracethdCHECK_File_SQL,
                 var_schema_Gracethd_CHE, var_path_folder_gracethd, var_path_folder_gracethdcheck):

        self.schemaGraceTHDReplace = var_name_Gracethd_File_SQL  # 'gracethd' # NAme schema in the files sql
        self.schemaGraceTHD = var_schema_Gracethd_MOD  # 'gracethd_mod' # NAme schema To replace in the files sql

        self.schemaGraceTHDCHECKReplace = var_name_GracethdCHECK_File_SQL  # 'schemacheck' # NAme schema in the files sql
        self.schemaGraceTHDCHECK = var_schema_Gracethd_CHE  # 'gracethd_check' # NAme schema To replace in the files sql

        self.path_folder_gracethd = var_path_folder_gracethd  # QFileDialog.getExistingDirectory(None, 'Selection Repertoire ou se trouve les fichiers SQL pour GraceTHD')
        self.path_folder_gracethdcheck = var_path_folder_gracethdcheck  # QFileDialog.getExistingDirectory(None, 'Selection Repertoire ou se trouve les fichiers SQL pour GraceTHDCHECK')

    # Function Creation du Schema GraceTHD
    def Function_Create_SchemaGraceTHD(self):
        if self.path_folder_gracethd:
            bar_progress = self.functions_General.progress_bar('Creation du Schema GraceTHD')
            folder_iterate = os.listdir(self.path_folder_gracethd)
            for index_gracethd, file_gracethd_sql in enumerate(folder_iterate):
                chemin = self.path_folder_gracethd
                name, ext = os.path.splitext(file_gracethd_sql)
                chem_file_gracethd_sql = chemin + '/' + file_gracethd_sql
                if ext == ".sql":
                    text_sql_file = self.functions_General.getFileContentSql(chem_file_gracethd_sql,
                                                                             self.schemaGraceTHDReplace,
                                                                             self.schemaGraceTHD, '', '')
                    try:
                        if text_sql_file:
                            self.functions_General.function_execute_requete(text_sql_file, '', connection)
                    except(Exception) as error:
                        return QMessageBox.warning(self.functions_General.w, "Message dexecution de requete",
                                                   'Erreur dexecution :' + str(error))
                self.functions_General.progress_processing(index_gracethd, len(folder_iterate), bar_progress)
                if bar_progress.wasCanceled():
                    iface.messageBar().pushMessage('Info', 'Action Cancelled', level=Qgis.Info)
                    break

    #        QMessageBox.information(self.w, "Message-Creation-Schema-GraceTHD", 'Fin Creation du Schema GraceTHD')

    # Function Creation du Schema GraceTHDCHECK
    def Function_Create_SchemaGraceTHDCheck(self):
        if self.path_folder_gracethdcheck:
            bar_progress = self.functions_General.progress_bar('Creation du Schema GraceTHDCHECK')
            folder_iterateC = os.listdir(self.path_folder_gracethdcheck)
            list_sql_file_Gracethdcheck = ['gracethdcheck_10_lists', 'gracethdcheck_30_tables',
                                           'gracethdcheck_20_insert',
                                           'gracethdcheck_31_filltab_insert', 'gracethdcheck_32_fillatt_insert',
                                           'gracethdcheck_32_fillatt_update',
                                           'gracethdcheck_33_conf_insert', 'gracethdcheck_34_cat_insert',
                                           'gracethdcheck_35_code_pgs_insert',
                                           'gracethdcheck_37_exe_pgs_fillatt_to_exe', 'gracethdcheck_50_index',
                                           'gracethdcheck_60_views',
                                           'f_recreate_v_ct_units', 'f_recreate_v_ct_anom',
                                           'gracethdcheck_62_views_anom_statut']

            for index_file, file_sql in enumerate(list_sql_file_Gracethdcheck):
                for index_gracethdC, file_gracethdC_sql in enumerate(folder_iterateC):
                    chemin = self.path_folder_gracethdcheck
                    name, ext = os.path.splitext(file_gracethdC_sql)
                    chem_file_gracethdC_sql = chemin + '/' + file_gracethdC_sql
                    if file_sql == name:
                        if ext == ".sql":
                            text_sql_file = self.functions_General.getFileContentSql(chem_file_gracethdC_sql,
                                                                                     self.schemaGraceTHDReplace,
                                                                                     self.schemaGraceTHD,
                                                                                     self.schemaGraceTHDCHECKReplace,
                                                                                     self.schemaGraceTHDCHECK)
                            try:
                                if text_sql_file:
                                    self.functions_General.function_execute_requete(text_sql_file, '', connection)
                            except(Exception) as error:
                                QMessageBox.warning(self.functions_General.w, "Message dexecution de requete",
                                                    'Erreur dexecution :' + str(error))
                self.functions_General.progress_processing(index_file, len(list_sql_file_Gracethdcheck), bar_progress)
                if bar_progress.wasCanceled():
                    iface.messageBar().pushMessage('Info', 'Action Cancelled', level=Qgis.Info)
                    break

            # QMessageBox.information(self.w, "Message-Creation-Schema-GraceTHD", 'Fin Creation du Schema GraceTHD')


class Import_Data_BDD():
    functions_General = FunctionsGeneral()

    # Constructeur des variables qui change
    def __init__(self, var_name_Gracethd_File_SQL, var_schema_Gracethd_MOD, var_schema_gracethd_input,
                 var_path_folder_gracethd, var_path_folder_data, var_path_folder_gracethdcheck,
                 var_name_GracethdCHECK_File_SQL, var_schema_Gracethd_CHE, var_name_phase):

        self.schemaGraceTHDReplace = var_name_Gracethd_File_SQL  # 'gracethd' # NAme schema in the files sql
        self.schemaGraceTHD = var_schema_Gracethd_MOD  # 'gracethd_mod' # NAme schema To replace in the files sql
        self.schema_input_etude = var_schema_gracethd_input
        self.path_folder_gracethd = var_path_folder_gracethd  # QFileDialog.getExistingDirectory(None, 'Selection Repertoire ou se trouve les fichiers SQL pour GraceTHD')
        self.path_folder_data = var_path_folder_data  # QFileDialog.getExistingDirectory(None, 'Selection Repertoire ou se trouve les Shapes et les CSV de la Donnees GraceTHD')
        self.path_folder_gracethdcheck = var_path_folder_gracethdcheck
        self.schemaGraceTHDCHECKReplace = var_name_GracethdCHECK_File_SQL  # 'schemacheck' # NAme schema in the files sql
        self.schemaGraceTHDCHECK = var_schema_Gracethd_CHE
        self.name_phase = var_name_phase
        connection.commit()

    # Function Creation du Schema GraceTHD
    def Function_Create_vues(self):
        path_folder_gracethd = self.path_folder_gracethd
        if path_folder_gracethd:
            bar_progress = self.functions_General.progress_bar('Creation du Schema GraceTHD')
            folder_iterate = os.listdir(path_folder_gracethd)
            for index_gracethd, file_gracethd_sql in enumerate(folder_iterate):
                chemin = path_folder_gracethd
                name, ext = os.path.splitext(file_gracethd_sql)
                chem_file_gracethd_sql = chemin + '/' + file_gracethd_sql
                if ext == ".sql" and name in ('gracethd_61_vues_elem', 'gracethd_61_vues_elem_vmat'):
                    text_sql_file = self.functions_General.getFileContentSql(chem_file_gracethd_sql,
                                                                             self.schemaGraceTHDReplace,
                                                                             self.schema_input_etude, '', '')
                    try:
                        if text_sql_file:
                            self.functions_General.function_execute_requete(text_sql_file, '', connection)
                    except(Exception) as error:
                        QMessageBox.warning(self.functions_General.w, "Message dexecution de requete",
                                            'Erreur dexecution :' + str(error))
                self.functions_General.progress_processing(index_gracethd, len(folder_iterate), bar_progress)
                if bar_progress.wasCanceled():
                    iface.messageBar().pushMessage('Info', 'Action Cancelled', level=Qgis.Info)
                    break

    # Function Verfication de la structure de la donnee par rapport au format GraceTHD
    def Function_check_erreur_mcd(self):
        path_folder_gracethdcheck = self.path_folder_gracethdcheck
        schema_mcd_mod = 'schema_mcd_mod'
        schema_etude_input = 'schema_etude_input'
        if path_folder_gracethdcheck:
            bar_progress = self.functions_General.progress_bar(
                'Check des erreurs de la structure par rapport au format GraceTHD')
            folder_iterate = os.listdir(path_folder_gracethdcheck)
            for index_gracethd, file_gracethd_sql in enumerate(folder_iterate):
                chemin = path_folder_gracethdcheck
                name, ext = os.path.splitext(file_gracethd_sql)
                chem_file_gracethd_sql = chemin + '/' + file_gracethd_sql
                if ext == ".sql" and name in ('check_erreur_mcd'):
                    text_sql_file = self.functions_General.getFileContentSql(chem_file_gracethd_sql,
                                                                             schema_etude_input,
                                                                             self.schema_input_etude,
                                                                             schema_mcd_mod, self.schemaGraceTHD)
                    try:
                        if text_sql_file:
                            self.functions_General.function_execute_requete(text_sql_file, '', connection)
                    except(Exception) as error:
                        QMessageBox.warning(self.functions_General.w, "Message dexecution de requete",
                                            'Erreur dexecution :' + str(error))
                self.functions_General.progress_processing(index_gracethd, len(folder_iterate), bar_progress)
                if bar_progress.wasCanceled():
                    iface.messageBar().pushMessage('Info', 'Action Cancelled', level=Qgis.Info)
                    break

    # Function Check des erreurs de GraceTHDCHECK selon le status
    def Function_Erreur_Gracethdcheck_Statut(self):
        stringQueryREC = "select erreur_resCheck_statut('select requete as ct_code from synt_erreur_statut_check(''v_ct_anom_8_rec'')','erreur_gracethd_rec');"
        stringQueryPRO = "select erreur_resCheck_statut('select requete as ct_code from synt_erreur_statut_check(''v_ct_anom_4_pro'')','erreur_gracethd_pro');"
        stringQueryEXE = "select erreur_resCheck_statut('select requete as ct_code from synt_erreur_statut_check(''v_ct_anom_6_exe'')','erreur_gracethd_exe');"
        stringQueryAVP = "select erreur_resCheck_statut('select requete as ct_code from synt_erreur_statut_check(''v_ct_anom_3_avp'')','erreur_gracethd_avp');"
        list_function_statut = [stringQueryAVP, stringQueryPRO, stringQueryREC, stringQueryEXE]
        list_statut = ['REC', 'PRO', 'EXE', 'DEO']
        zipbObj = zip(list_statut, list_function_statut)
        dict_statut_check = dict(zipbObj)

        if self.path_folder_gracethdcheck:
            bar_progress = self.functions_General.progress_bar(
                'Creation des functions pour les checks des erreurs GraceTHDCHECK')
            folder_iterateC = os.listdir(self.path_folder_gracethdcheck)

            for index_gracethdC, file_gracethdC_sql in enumerate(folder_iterateC):
                chemin = self.path_folder_gracethdcheck
                name, ext = os.path.splitext(file_gracethdC_sql)
                chem_file_gracethdCS_sql = chemin + '/' + file_gracethdC_sql
                if ext == ".sql" and name == 'check_erreur_graceth_statut':
                    text_sql_file = self.functions_General.getFileContentSql(chem_file_gracethdCS_sql,
                                                                             self.schemaGraceTHDReplace,
                                                                             self.schemaGraceTHD, \
                                                                             self.schemaGraceTHDCHECKReplace,
                                                                             self.schemaGraceTHDCHECK)
                    try:
                        if text_sql_file:
                            self.functions_General.function_execute_requete(text_sql_file, '', connection)
                    except(Exception) as error:
                        QMessageBox.warning(self.functions_General.w, "Message dexecution de requete",
                                            'Erreur dexecution :' + str(error))
                self.functions_General.progress_processing(index_gracethdC, len(folder_iterateC), bar_progress)
                if bar_progress.wasCanceled():
                    iface.messageBar().pushMessage('Info', 'Action Cancelled', level=Qgis.Info)
                    break
        bar_progress = self.functions_General.progress_bar(
            'Generation des erreurs GraceTHDCHECK selon le statut choisi')
        for index_gracethdC, (key, value) in enumerate(dict_statut_check.items()):
            if str(key).lower() == str(self.name_phase).lower():
                self.functions_General.function_execute_requete(value, '', connection)
            self.functions_General.progress_processing(index_gracethdC, len(dict_statut_check.items()), bar_progress)
            if bar_progress.wasCanceled():
                iface.messageBar().pushMessage('Info', 'Action Cancelled', level=Qgis.Info)
                break

    # Function de chargement des layers dans Qgis
    def function_chargement_layer_qgis(self):
        folder_data = self.path_folder_data
        bar_progress_char_qgis = self.functions_General.progress_bar('Chargement des donnees dans Qgis')
        if folder_data:
            # Declaration des noms des groupes a travers la function de creatino des groups
            shape_group = self.functions_General.function_create_groupe_name('SHAPE_GraceTHD')
            csv_group = self.functions_General.function_create_groupe_name('CSV_GraceTHD')
            folder_iterate = os.listdir(folder_data)
            for index_char_qgis, file_etude in enumerate(folder_iterate):
                chemin = folder_data
                name, ext = os.path.splitext(file_etude)
                chem_etude = chemin + '/' + file_etude
                if ext == ".shp":
                    layer_shp_etude = QgsVectorLayer(chem_etude, name, 'ogr')
                    try:
                        self.functions_General.function_add_layer_group(layer_shp_etude, shape_group)
                    except(Exception) as error:
                        QMessageBox.warning(self.functions_General.w, "Message dexecution de requete",
                                            'Erreur dexecution du chargement du shape dans Qgis' + name)
                if ext == ".csv":
                    layer_csv_etude = QgsVectorLayer(chem_etude, name, 'ogr')
                    try:
                        self.functions_General.function_add_layer_group(layer_csv_etude, csv_group)
                    except(Exception) as error:
                        QMessageBox.warning(self.functions_General.w, "Message dexecution de requete",
                                            'Erreur dexecution du chargement du csv dans Qgis' + name)
                self.functions_General.progress_processing(index_char_qgis, len(folder_iterate), bar_progress_char_qgis)
                if bar_progress_char_qgis.wasCanceled():
                    iface.messageBar().pushMessage('Info', 'Action Cancelled', level=Qgis.Info)
                    break

    # Function pour la creation des tables
    def function_create_table(self, table_name, schema_name, var_geom, var_extension):
        features = self.functions_General.function_getlayer_name(table_name)
        list_fieldname = []
        for index_cm, field_name in enumerate(features.fields()):
            fielname = field_name.name().replace(' ', '_').replace("'", '') + ' text '
            list_fieldname.append(fielname)
        if var_geom:
            list_fieldname.append(var_geom + ' geometry')
        tuple_fieldname = ','.join(list_fieldname)
        req_create_table = 'CREATE TABLE IF NOT EXISTS ' + schema_name + '.' + '"' + var_extension + table_name + '"' + '(' + tuple_fieldname + ')'
        req_drop_table = 'DROP TABLE IF EXISTS ' + schema_name + '.' + '"' + var_extension + table_name + '"'
        return req_drop_table, req_create_table, tuple_fieldname

    # Function pour la creation des erreurs de checks Gracethd (Contraintes Null, Attribut en double, cles etrangeres)
    def function_erreur_check_gracethd(self):  # ,schema_input,schema_gracethd
        self.Function_Erreur_Gracethdcheck_Statut()

    # Function pour creer des tables annexes ainsi que des droits
    def function_table_annexe(self, file_sql_annexe):
        name_schema_in_file = 'schema_name'
        text_sql_file = self.functions_General.getFileContentSql(file_sql_annexe, name_schema_in_file,
                                                                 self.schema_input_etude, '', '')
        try:
            if text_sql_file:
                self.functions_General.function_execute_requete(text_sql_file, '', connection)
        except(Exception) as error:
            QMessageBox.warning(self.functions_General.w, "Message dexecution de requete",
                                'Erreur dexecution :' + str(error))

    # Function pour les insertions des donnees chargees dans Qgis dans la BDD
    def function_insert_data_qgis_BDD(self, var_schema_input, var_create_schema, var_rename_layer):
        # Execution de la bar
        bar_progress = self.functions_General.progress_bar(
            'Chargement des donnees dans Qgis, Creation du schema Input et Insertion')

        # Creation du Schema Ou seront importer les donnees
        if var_create_schema:
            create_schema_input = """DROP SCHEMA IF EXISTS """ + var_schema_input + """ CASCADE; CREATE SCHEMA """ + var_schema_input
            try:
                self.functions_General.function_execute_requete(create_schema_input, '', connection)
            except(Exception) as error:
                QMessageBox.warning(self.functions_General.w, "Message dexecution de requete",
                                    'Erreur dexecution :' + str(error))

        len_maplayer = len(QgsProject.instance().mapLayers().values())
        list_table_create = []
        for index_map, layers_name_mapLayers in enumerate(QgsProject.instance().mapLayers().values()):
            layer_name = layers_name_mapLayers.name()
            layer_features = layers_name_mapLayers.getFeatures()
            list_table_create.append(layer_name)
            layer_type = layers_name_mapLayers.geometryType()  # 1=Ligne, 2=polygon, 0=Point, 4=Sans Geom

            # On ne cree et supprime que les couches chargees dans qgis
            # Tables avec Geometries
            if str(layer_type) != '4':
                try:
                    req_create_table = \
                    self.function_create_table(layer_name, var_schema_input, 'geom', var_rename_layer)[
                        1]  # Requete pour la creation des tables
                    self.functions_General.function_execute_requete(req_create_table, '',
                                                                    connection)  # Execution de la requete pour la creation des tables
                except(Exception) as error:
                    QMessageBox.warning(self.functions_General.w, "Message dexecution de requete",
                                        'Create des tables Non Executer' + layer_name)

            # Tables sans Geometrie
            elif str(layer_type) == '4':
                try:
                    req_create_table = self.function_create_table(layer_name, var_schema_input, '', var_rename_layer)[
                        1]  # Requete pour la creation des tables
                    self.functions_General.function_execute_requete(req_create_table, '',
                                                                    connection)  # Execution de la requete pour la creation des tables
                except(Exception) as error:
                    QMessageBox.warning(self.functions_General.w, "Message dexecution de requete",
                                        'Create des tables Non Executer' + layer_name)

            # Debut de limportations
            if layers_name_mapLayers.type() == QgsMapLayer.VectorLayer:
                layer_not_empty = len(list(layer_features))
                if layer_not_empty > 0:  # Ignorer linsertion des couches vides
                    layer_re_name = '"' + var_rename_layer + layer_name + '"'
                    list_fielname_sans_geom = \
                    self.function_create_table(layer_name, var_schema_input, '', var_rename_layer)[2].replace(' text ',
                                                                                                              '')
                    list_fielname_geom = \
                    self.function_create_table(layer_name, var_schema_input, 'geom', var_rename_layer)[2].replace(
                        ' text ', '').replace('geometry', '')
                    req_insert_prepare = 'INSERT INTO ' + var_schema_input + '.' + layer_re_name + '(' + list_fielname_geom + ') values'
                    req_insert_prepare_sans_geom = 'INSERT INTO ' + var_schema_input + '.' + layer_re_name + '(' + list_fielname_sans_geom + ') values'
                    list_insert_entite = []
                    layer_features = layers_name_mapLayers.getFeatures()
                    insert_geom = ''
                    for index_layer, layer in enumerate(layer_features):
                        geome_text = layer.geometry().asWkt()
                        attr_insert = '-1'
                        replace_null_value = tuple(
                            [NULL if field in [NULL, '??'] else unicode(field).replace("'", '') for field in
                             layer.attributes()])
                        if geome_text:
                            insert_geom = 'geom'
                            attr_insert = replace_null_value + ("ST_GeomFromText('" + geome_text + "',2154)",)
                        if not geome_text:
                            insert_geom = 'sansgeom'
                            attr_insert = replace_null_value
                        list_insert_entite.append(attr_insert)
                    if insert_geom:
                        if insert_geom == 'geom':
                            req_insert_finale = req_insert_prepare + unicode(list_insert_entite).replace('[',
                                                                                                         '').replace(
                                ']', '').replace('"', '')
                        elif insert_geom == 'sansgeom':
                            req_insert_finale = req_insert_prepare_sans_geom + unicode(list_insert_entite).replace('[',
                                                                                                                   '').replace(
                                ']', '').replace('"', '')
                        try:
                            self.functions_General.function_execute_requete(req_insert_finale, '', connection)
                        except(Exception) as error:
                            QMessageBox.warning(self.functions_General.w, "Message dexecution de requete",
                                                'Requete Insertion des donnees Non Executer' + layer_name)
            self.functions_General.progress_processing(index_map, len_maplayer, bar_progress)
            if bar_progress.wasCanceled():
                iface.messageBar().pushMessage('Info', 'Action Cancelled', level=Qgis.Info)
                break

        # Execution des suppressions des couches charges dans qgis
        self.functions_General.functiondelete_layer_qgis('SHAPE_GraceTHD')
        self.functions_General.functiondelete_layer_qgis('CSV_GraceTHD')

        # Function des verifications du MCD
        self.Function_check_erreur_mcd()
        # Creation des vues
        self.Function_Create_vues()


class Export_resultats_check():
    functions_General = FunctionsGeneral()

    # Constructeur des variables qui change
    def __init__(self, var_schema_gracethd_input, var_path_folder_export):
        self.schema_input_etude = var_schema_gracethd_input
        self.path_folder_export = var_path_folder_export

    # Function pour ajouter des feuilles dans EXCEl
    def function_create_sheet(self, wb, sheet_name, list_user_export, Header):
        # Execution de la bar
        bar_progress = self.functions_General.progress_bar('Export des erreurs de Controls')
        ws_workbook = wb.add_sheet(sheet_name, cell_overwrite_ok=True)
        if list_user_export:
            for index_liste, k in enumerate(list_user_export[:65534]):
                for colx, value in enumerate(k):
                    ws_workbook.write(index_liste + 1, colx, str(value))
                    self.functions_General.progress_processing(index_liste, len(list_user_export), bar_progress)
                    if bar_progress.wasCanceled():
                        iface.messageBar().pushMessage('Info', 'Action Cancelled', level=Qgis.Info)
                        break
        colIdx = 0  # Start from Column 0
        font_style = xlwt.XFStyle()
        font_style.font.bold = True
        for indData in Header:
            col = ws_workbook.col(colIdx)
            col.width = 256 * 20
            ws_workbook.write(0, colIdx, indData, font_style)  # Insert in First Row ( Row 0)
            colIdx = colIdx + 1

    def function_export_resultat_check(self):
        name_file_export = 'CHECK_ERREUR_Gracethd_Export'
        path_folder_export = self.path_folder_export
        if path_folder_export:
            xlsfile_res = path_folder_export + "/" + name_file_export + ".xls"
            wb = xlwt.Workbook(encoding="UTF-8")
            requete_check = """set search_path to """ + self.schema_input_etude + """;
                select 
                    'select * from '||max(table_schema)||'.'||table_name::text as req,
                    table_name as table_name,
                    array_agg(distinct(column_name::text)) as column_name,
                    'GRANT ALL ON TABLE '||table_name||' TO adn_ing;'
                from information_schema.columns
                where table_schema = '""" + self.schema_input_etude + """' and table_name like 'check_%'
                group by table_name"""
            resultats_requete_dynamic = self.functions_General.function_execute_requete(requete_check, 'getres',
                                                                                        connection)
            for index, req_dynamic in enumerate(resultats_requete_dynamic):
                check_req = req_dynamic[0]
                name_sheet = req_dynamic[1]
                name_header = req_dynamic[2]
                grant_user = req_dynamic[3]
                res_check_req = self.functions_General.function_execute_requete(check_req, 'getres', connection)
                self.function_create_sheet(wb, name_sheet, res_check_req, name_header)
                self.functions_General.function_execute_requete(grant_user, '', connection)
            wb.save(xlsfile_res)
            QMessageBox.information(self.functions_General.w, "Message dexport du resultat",
                                    'Le Fichier de resultat est enregistre dans le repertoire :' + path_folder_export + ' Sous le Nom de : ' + name_file_export)


def function_execute_class(schemaInputEtude, name_bdd, name_user, name_password, name_host, name_port, name_phase,
                           path_folder_gracethd, path_folder_gracethdcheck, file_sql_annexe):
    global CreateModeleGraceTHD, connection, Import_Data_BDD, Export_resultats_check, FunctionsGeneral

    # Declaration des Parameters de connexion de la base
    DB = name_bdd  # 'gracethd_v2_0_1'
    user = name_user  # 'postgres'
    MP = name_password  # 'MYPASSWORD'
    host = name_host  # 'localhost'
    port = name_port  # '5439'

    # Connexion a la base
    message_connexion = False
    try:
        connection = psycopg2.connect(user=user, password=MP, host=host, port=port, database=DB)
        message_connexion = True
    except(Exception, psycopg2.DatabaseError) as error:  # psycop2
        message_connexion = False
        QMessageBox.warning(FunctionsGeneral().w, "Message de connexion de la base", 'Erreur de connexion de la base')

    if message_connexion != False:
        schemaGraceTHDReplace = 'gracethd'  # NAme schema in the files sql
        schemaGraceTHDCHECKReplace = 'schemacheck'  # NAme schema in the files sql
        schemaGraceTHDCHECK = 'gracethd_check'  # NAme schema To replace in the files sql
        schemaGraceTHD = 'gracethd_mod'  # NAme schema To replace in the files sql
        # schemaInputEtude = 'gracethd_input_etude_home'# Schema input name

        # Declaration des folders path_folder_gracethd,path_folder_gracethdcheck
        # path_folder_gracethd = QFileDialog.getExistingDirectory(None, 'Selection Repertoire ou se trouve les fichiers SQL pour GraceTHD')
        # path_folder_gracethdcheck = QFileDialog.getExistingDirectory(None, 'Selection Repertoire ou se trouve les fichiers SQL pour GraceTHDCHECK')
        path_folder_data = QFileDialog.getExistingDirectory(None,
                                                            'Selection Repertoire ou se trouve les Shapes et les CSV de la Donnees GraceTHD')
        path_folder_export_res = path_folder_data  # QFileDialog.getExistingDirectory(None,'Selection Repertoire ou exporter les resultats des checks')
        # Creation du Schema GraceTHD
        Class_SchemaGraceTHD = CreateModeleGraceTHD(schemaGraceTHDReplace, schemaGraceTHD, schemaGraceTHDCHECKReplace,
                                                    schemaGraceTHDCHECK, path_folder_gracethd,
                                                    path_folder_gracethdcheck)
        Create_Schema_GraceTHD = Class_SchemaGraceTHD.Function_Create_SchemaGraceTHD()

        # Create Schema Input Etude
        var_path_folder_gracethd = path_folder_gracethd
        var_path_folder_data = path_folder_data

        # Importation des donnees dans la BDD
        Class_Import_Data_BDD = Import_Data_BDD(schemaGraceTHDReplace, schemaGraceTHD, schemaInputEtude,
                                                var_path_folder_gracethd,
                                                var_path_folder_data, path_folder_gracethdcheck,
                                                schemaGraceTHDCHECKReplace, schemaGraceTHDCHECK, name_phase)
        Class_Import_Data_BDD.function_chargement_layer_qgis()
        Class_Import_Data_BDD.function_insert_data_qgis_BDD(schemaInputEtude, 'CreateSchema', '')
        # Class_Import_Data_BDD.function_insert_data_qgis_BDD(Class_Import_Data_BDD.schema_input_etude, 'CreateSchema','')

        # Reaffectation des variables pour un replacement
        schemaGraceTHD = Class_SchemaGraceTHD.schemaGraceTHD = schemaInputEtude
        schemaGraceTHDCHECK = Class_SchemaGraceTHD.schemaGraceTHDCHECK = schemaInputEtude + '_check'

        # Creation du Schema GraceTHDCHECK
        Create_Schema_GraceTHDCHECK = Class_SchemaGraceTHD.Function_Create_SchemaGraceTHDCheck()

        # Reaffectation des variables pour un replacement
        schemaGraceTHD = Class_Import_Data_BDD.schemaGraceTHD = schemaInputEtude
        schemaGraceTHDCHECK = Class_Import_Data_BDD.schemaGraceTHDCHECK = schemaInputEtude + '_check'
        connection.commit()
        # Creation des Erreurs GraceTHD et GraceTHDCHECK
        Class_Import_Data_BDD.function_erreur_check_gracethd()
        connection.commit()
        var_schema_mod = """DROP SCHEMA """ + """gracethd_mod""" + """ CASCADE"""
        var_schema_check = """DROP SCHEMA """ + schemaGraceTHDCHECK + """ CASCADE"""
        FunctionsGeneral().function_execute_requete(var_schema_mod, '', connection)
        FunctionsGeneral().function_execute_requete(var_schema_check, '', connection)
        Class_Import_Data_BDD.function_table_annexe(file_sql_annexe)
        # # Exportation des resultats
        # var_export_resultats_check = Export_resultats_check(schemaInputEtude, path_folder_export_res)
        # var_export_resultats_check.function_export_resultat_check()
        # Mise a jour et close de la connexion
        connection.commit()
        connection.close()
        QMessageBox.information(FunctionsGeneral().w, "Message Traitement", "Import des données réalisé avec succès ")
