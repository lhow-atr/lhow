# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'Dialog_IMPORT_BDD2.ui'
#
# Created by: PyQt5 UI code generator 5.11.3
#
# WARNING! All changes made in this file will be lost!

import datetime
import time
import sys
from pathlib import Path

from qgis.PyQt import QtCore, QtWidgets
from qgis.gui import QgsCheckableComboBox, QgsDateTimeEdit, QgsFileWidget
from qgis.PyQt.QtWidgets import QApplication, QFileDialog, QMessageBox, QWidget
from qgis.utils import iface

# {app = QApplication(sys.argv)}

folder_plugin = str(Path(__file__).parent.parent)

sys.path.append(folder_plugin)

from bdd.params_connexion import function_connexion
from scripts_python.import_data_class import ImportMultiplesFilesCsvShp
from scripts_python.create_model_gracethd_check import function_execute_class_model



class UiControleDesDesignDialogBase(object):
    def setupUi(self, UiControleDesDesignDialogBase):
        self.now = datetime.datetime.now()
        UiControleDesDesignDialogBase.setObjectName("UiControleDesDesignDialogBase")
        UiControleDesDesignDialogBase.setWindowModality(QtCore.Qt.ApplicationModal)
        UiControleDesDesignDialogBase.setEnabled(True)
        UiControleDesDesignDialogBase.resize(800, 800)
        UiControleDesDesignDialogBase.setMouseTracking(False)

        self.verticalLayoutWidget = QtWidgets.QWidget(UiControleDesDesignDialogBase)
        self.verticalLayoutWidget.setGeometry(QtCore.QRect(30, 30, 700, 700))
        self.verticalLayoutWidget.setObjectName("verticalLayoutWidget")

        self.verticalLayout = QtWidgets.QVBoxLayout(self.verticalLayoutWidget)
        self.verticalLayout.setContentsMargins(0, 0, 0, 0)
        self.verticalLayout.setObjectName("verticalLayout")

        self.gridLayout = QtWidgets.QGridLayout()
        self.gridLayout.setObjectName("gridLayout")
        
        self.label_folder_data = QtWidgets.QLabel(self.verticalLayoutWidget)
        self.label_folder_data.setObjectName("label_folder_data")
        self.gridLayout.addWidget(self.label_folder_data, 0, 0, 1, 1)

        self.label_12 = QtWidgets.QLabel(self.verticalLayoutWidget)
        self.label_12.setObjectName("label_12")
        self.gridLayout.addWidget(self.label_12, 0, 1, 1, 1)

        self.label_2 = QtWidgets.QLabel(self.verticalLayoutWidget)
        self.label_2.setObjectName("label_2")
        self.gridLayout.addWidget(self.label_2, 0, 2, 1, 1)

        self.label_18 = QtWidgets.QLabel(self.verticalLayoutWidget)
        self.label_18.setObjectName("label_18")
        self.gridLayout.addWidget(self.label_18, 0, 3, 1, 1)
        
        self.data_directory = QgsFileWidget(UiControleDesDesignDialogBase)
        self.data_directory.setObjectName("data_directory")
        self.gridLayout.addWidget(self.data_directory, 1, 0, 1, 1)

        self.name_pr = QtWidgets.QLineEdit(self.verticalLayoutWidget)
        self.name_pr.setMinimumSize(QtCore.QSize(111, 0))
        self.name_pr.setObjectName("name_pr")
        self.gridLayout.addWidget(self.name_pr, 1, 1, 1, 1)

        self.name_statut = QgsCheckableComboBox(self.verticalLayoutWidget)
        self.name_statut.setMinimumSize(QtCore.QSize(106, 0))
        self.name_statut.setObjectName("name_statut")
        self.name_statut.addItem("")
        self.name_statut.addItem("")
        self.name_statut.addItem("")
        self.name_statut.addItem("")
        self.name_statut.addItem("")
        self.name_statut.addItem("")
        self.name_statut.addItem("")
        self.name_statut.addItem("")
        self.name_statut.addItem("")
        self.gridLayout.addWidget(self.name_statut, 1, 2, 1, 1)

        self.name_date = QgsDateTimeEdit(self.verticalLayoutWidget)
        self.name_date.setEnabled(True)
        self.name_date.setMinimumSize(QtCore.QSize(110, 0))
        self.name_date.setMouseTracking(False)
        self.name_date.setTabletTracking(False)
        self.name_date.setAcceptDrops(False)
        self.name_date.setAutoFillBackground(False)
        self.name_date.setWrapping(False)
        self.name_date.setFrame(False)
        self.name_date.setReadOnly(False)
        self.name_date.setAccelerated(False)
        self.name_date.setKeyboardTracking(True)
        self.name_date.setProperty("showGroupSeparator", False)
        self.name_date.setDateTime(QtCore.QDateTime(QtCore.QDate(self.now.year, self.now.month, self.now.day),
                                                    QtCore.QTime(self.now.hour, self.now.minute, self.now.second)))
        self.name_date.setCalendarPopup(True)
        self.name_date.setAllowNull(False)
        self.name_date.setObjectName("name_date")
        self.gridLayout.addWidget(self.name_date, 1, 3, 1, 1)
        self.verticalLayout.addLayout(self.gridLayout)

        self.textBrowser = QtWidgets.QTextBrowser(self.verticalLayoutWidget)
        self.textBrowser.setObjectName("textBrowser")
        self.verticalLayout.addWidget(self.textBrowser)

        self.button_box = QtWidgets.QDialogButtonBox(self.verticalLayoutWidget)
        self.button_box.setOrientation(QtCore.Qt.Horizontal)
        self.button_box.setStandardButtons(QtWidgets.QDialogButtonBox.Cancel | QtWidgets.QDialogButtonBox.Ok)
        self.button_box.setObjectName("button_box")
        self.verticalLayout.addWidget(self.button_box)

        self.retranslateUi(UiControleDesDesignDialogBase)
        self.button_box.accepted.connect(UiControleDesDesignDialogBase.accept)
        self.button_box.rejected.connect(UiControleDesDesignDialogBase.reject)
        QtCore.QMetaObject.connectSlotsByName(UiControleDesDesignDialogBase)

    def retranslateUi(self, UiControleDesDesignDialogBase):
        _translate = QtCore.QCoreApplication.translate
        UiControleDesDesignDialogBase.setWindowTitle(
            _translate("UiControleDesDesignDialogBase", "DESIGN v0.01 - Importation des donnees dans la BDD"))
        self.label_folder_data.setText(_translate("UiControleDesDesignDialogBase", "Dossier Donnees"))
        self.label_12.setText(_translate("UiControleDesDesignDialogBase", "Nom du pr"))
        self.name_pr.setText(_translate("UiControleDesDesignDialogBase", "pr_baba"))
        self.label_2.setText(_translate("UiControleDesDesignDialogBase", "STATUT"))
        self.label_18.setText(_translate("UiControleDesDesignDialogBase", "Choisir la date"))
        self.name_statut.setItemText(0, _translate("UiControleDesDesignDialogBase", "AOR"))
        self.name_statut.setItemText(1, _translate("UiControleDesDesignDialogBase", "DEO"))
        self.name_statut.setItemText(2, _translate("UiControleDesDesignDialogBase", "DEP"))
        self.name_statut.setItemText(3, _translate("UiControleDesDesignDialogBase", "DIU"))
        self.name_statut.setItemText(4, _translate("UiControleDesDesignDialogBase", "DOE"))
        self.name_statut.setItemText(5, _translate("UiControleDesDesignDialogBase", "DET"))
        self.name_statut.setItemText(6, _translate("UiControleDesDesignDialogBase", "EXE"))
        self.name_statut.setItemText(7, _translate("UiControleDesDesignDialogBase", "MCO"))
        self.name_statut.setItemText(8, _translate("UiControleDesDesignDialogBase", "PRO"))
        self.name_date.setToolTip(
            _translate("UiControleDesDesignDialogBase", "<html><head/><body><p><br/></p></body></html>"))
        self.textBrowser.setHtml(_translate("UiControleDesDesignDialogBase",
                                            "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
                                            "<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
                                            "p, li { white-space: pre-wrap; }\n"
                                            "p { margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:8pt }\n"
                                            "</style></head><body style=\" font-family:\'MS Shell Dlg 2\'; font-size:8.25pt; font-weight:400; font-style:normal;\">\n"
                                            "<h2>Objectifs: </h2>\n"
                                            "<div >Ce module permet d'integrer un livrable en base de données. </div>\n"
                                            "<h2>Données en entrée: </h2>\n"
                                            "<div > L'ensemble des shapefiles et tables CSV qui composent le livrable à intégrer en base de données doit être dans un répertoire unique.</div>\n"
                                            "<div> L'utilisateur renseigne les paramètres correspondants au livrable à importer en base de données. S'il n'existe pas de schéma existant avec les paramètres renseignés, un nouveau schéma est alors créé, et les données importées.</div>\n"
                                            "<h2 >Résultat: </h2>\n"
                                            "<div> Le livrable est importé dans un schéma en base de données.</div>\n"
                                            "<h2 >Contraintes: </h2>\n"
                                            "<div >Le livrable à intégrer doit respecter le formalisme du MCD. </div>\n"
                                            "<h2 >Restrictions:</h2>\n"
                                            "<div >\n"
                                            "<p> Valeur d'attribut  ' NULL ' remplacée par ' 0 ' </p>\n"
                                            "<p> Attributs de type ' DATE ' non importés </p>\n"
                                            "</div>\n"
                                            "</body></html>"))


class class_general_dialog(QtWidgets.QDialog):
    def __init__(self, iface):
        QtWidgets.QDialog.__init__(self)
        self.iface = iface

    def get_version_plugin(self):
        folder_metada = open(folder_plugin + "\metadata.txt")
        for line in folder_metada:
            if str(line)[:7] == 'version':
                get_version = line.split('=')[1]
                folder_metada.close()
                return get_version


class class_import_dialog(class_general_dialog, UiControleDesDesignDialogBase):
    def __init__(self, iface):
        class_general_dialog.__init__(self, iface)
        self.setupUi(self)
        self.now = datetime.datetime.now()
        self.name_date.setDateTime(QtCore.QDateTime(QtCore.QDate(self.now.year, self.now.month, self.now.day),
                                                    QtCore.QTime(self.now.hour, self.now.minute, self.now.second)))
        self.data_directory.setStorageMode(QgsFileWidget.GetDirectory)
        self.button_box.button(QtWidgets.QDialogButtonBox.Ok).clicked.connect(self.run)
        self.setWindowTitle("DESIGN " + str(self.get_version_plugin()) + " - Importation des donnees dans la BDD")

    def run(self):
        w = QWidget()
        list_statut = self.name_statut
        text_statut = [x for x in list_statut.currentText().split(',') if x]

        if len(text_statut) != 1:
            QMessageBox.critical(w, "Message Du Choix", 'Veillez cocher un Seul STATUT')
        else:
            name_date = self.name_date.date().toString("yyyyMMdd")
            nom_pr = self.name_pr.text()
            nom_phase = "".join(text_statut)
            schema = str(nom_pr).lower() + '_' + str(nom_phase).lower() + '_' + 'v_' + str(name_date)

            # {QMessageBox.critical(QWidget(), "Animate Columns", schema + ' ; ' + name_date)
            # path_folder_gracethd = str(folder_plugin) + "/file_sql/create_schema_gracethd"
            # path_folder_gracethdcheck = str(folder_plugin) + "/file_sql/create_schema_ckeck"
            # var_file_sql_annexe = str(folder_plugin) + "/file_sql/autre_gracethd.sql"
            # function_execute_class(schema, DB, user, MP, host, port, nom_phase, path_folder_gracethd,
            #                        path_folder_gracethdcheck, var_file_sql_annexe)}

            # # function_execute_class(schema, nom_phase, path_folder_gracethd, path_folder_gracethdcheck, var_file_sql_annexe)
            path_folder_data = str(self.data_directory.filePath())
            ImportMultiplesFilesCsvShp(schema, path_folder_data, function_connexion())
            function_execute_class_model(schema, nom_phase)
            #{ start_time_import = time.time()
            # end_time_import = time.time()
            # print(f"EndTime ImportMultiplesFilesCsvShp: ';;;;;;;', {end_time_import-start_time_import}")
            # start_time_model = time.time()
            # end_time_model = time.time()
            # print(f"EndTime function_execute_class_model: ';;;;;;;', {end_time_model-start_time_model}")}
            
            QMessageBox.information(w, "Message Traitement", 'Fin du traitement')


# {baba_dialog = class_import_dialog(iface)
# baba_dialog.show()
# sys.exit(app.exec_())}