# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'Dialog_IMPORT_BDD2.ui'
#
# Created by: PyQt5 UI code generator 5.11.3
#
# WARNING! All changes made in this file will be lost!
import sys
from pathlib import Path

from qgis.PyQt import QtCore, QtWidgets
from qgis.gui import QgsCheckableComboBox

folder_plugin = str(Path(__file__).parent.parent)

sys.path.append(folder_plugin)

from scripts_python.dimensionnement_boitiers_optiques import *


class Ui_check_boite_dialog(object):
    def setupUi(self, check_boite_dialog):
        check_boite_dialog.setObjectName("check_boite_dialog")
        check_boite_dialog.setWindowModality(QtCore.Qt.ApplicationModal)
        check_boite_dialog.setEnabled(True)
        check_boite_dialog.resize(800, 800)  # 1305, 882
        check_boite_dialog.setMouseTracking(False)

        self.verticalLayoutWidget = QtWidgets.QWidget(check_boite_dialog)
        self.verticalLayoutWidget.setGeometry(QtCore.QRect(30, 30, 700, 700))  # 1161, 731
        self.verticalLayoutWidget.setObjectName("verticalLayoutWidget")

        self.verticalLayout = QtWidgets.QVBoxLayout(self.verticalLayoutWidget)
        self.verticalLayout.setContentsMargins(0, 0, 0, 0)
        self.verticalLayout.setObjectName("verticalLayout")

        self.gridLayout = QtWidgets.QGridLayout()
        self.gridLayout.setObjectName("gridLayout")

        self.label_12 = QtWidgets.QLabel(self.verticalLayoutWidget)
        self.label_12.setObjectName("label_12")
        self.gridLayout.addWidget(self.label_12, 0, 0, 1, 1)

        self.label_2 = QtWidgets.QLabel(self.verticalLayoutWidget)
        self.label_2.setObjectName("label_2")
        self.gridLayout.addWidget(self.label_2, 0, 1, 1, 1)

        self.name_pr = QgsCheckableComboBox(self.verticalLayoutWidget)
        self.name_pr.setMinimumSize(QtCore.QSize(106, 0))
        self.name_pr.setObjectName("name_pr")
        self.gridLayout.addWidget(self.name_pr, 1, 0, 1, 1)

        self.name_statut = QgsCheckableComboBox(self.verticalLayoutWidget)
        self.name_statut.setMinimumSize(QtCore.QSize(106, 0))
        self.name_statut.setObjectName("name_statut")
        self.name_statut.addItem("")
        self.name_statut.addItem("")
        self.name_statut.addItem("")
        self.name_statut.addItem("")
        self.name_statut.addItem("")
        self.name_statut.addItem("")
        self.name_statut.addItem("")
        self.name_statut.addItem("")
        self.name_statut.addItem("")
        self.gridLayout.addWidget(self.name_statut, 1, 1, 1, 1)

        self.verticalLayout.addLayout(self.gridLayout)

        self.textBrowser = QtWidgets.QTextBrowser(self.verticalLayoutWidget)
        self.textBrowser.setObjectName("textBrowser")
        self.verticalLayout.addWidget(self.textBrowser)

        self.button_box = QtWidgets.QDialogButtonBox(self.verticalLayoutWidget)
        self.button_box.setOrientation(QtCore.Qt.Horizontal)
        self.button_box.setStandardButtons(QtWidgets.QDialogButtonBox.Cancel | QtWidgets.QDialogButtonBox.Ok)
        self.button_box.setObjectName("button_box")
        self.verticalLayout.addWidget(self.button_box)

        self.retranslateUi(check_boite_dialog)
        self.button_box.accepted.connect(check_boite_dialog.accept)
        self.button_box.rejected.connect(check_boite_dialog.reject)
        QtCore.QMetaObject.connectSlotsByName(check_boite_dialog)

    def retranslateUi(self, check_boite_dialog):
        _translate = QtCore.QCoreApplication.translate
        check_boite_dialog.setWindowTitle(
            _translate("check_boite_dialog", "DESIGN v0.01 - Importation des donnees dans la BDD"))
        self.label_12.setText(_translate("check_boite_dialog", "Nom du pr"))
        self.label_2.setText(_translate("check_boite_dialog", "STATUT"))
        self.name_statut.setItemText(0, _translate("check_boite_dialog", "AOR"))
        self.name_statut.setItemText(1, _translate("check_boite_dialog", "DEO"))
        self.name_statut.setItemText(2, _translate("check_boite_dialog", "DEP"))
        self.name_statut.setItemText(3, _translate("check_boite_dialog", "DIU"))
        self.name_statut.setItemText(4, _translate("check_boite_dialog", "DOE"))
        self.name_statut.setItemText(5, _translate("check_boite_dialog", "DET"))
        self.name_statut.setItemText(6, _translate("check_boite_dialog", "EXE"))
        self.name_statut.setItemText(7, _translate("check_boite_dialog", "MCO"))
        self.name_statut.setItemText(8, _translate("check_boite_dialog", "PRO"))
        self.textBrowser.setHtml(_translate("check_boite_dialog",
                                            "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
                                            "<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
                                            "p, li { white-space: pre-wrap; }\n"
                                            "p { margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:8pt }\n"
                                            "</style></head><body style=\" font-family:\'MS Shell Dlg 2\'; font-size:8.25pt; font-weight:400; font-style:normal;\">\n"
                                            "<h2>Objectifs: </h2>\n"
                                            "<div > Ce module permet de contrôler l'implantation des équipements d'un livrable existant en base de données. </div>\n"
                                            "<h2>Données en entrée: </h2>\n"
                                            "<div > L’utilisateur sélectionne dans la liste déroulante le livrable qu'il souhaite contrôler sur les points suivants, </div>\n"
                                            "<div> B01 - Installation de boitiers optiques,</div>\n"
                                            "<div> B02 - Taille des boitiers optiques en fonction des points techniques,</div>\n"
                                            "<div> B03 - Taille des boitiers optiques en fonction des câbles,</div>\n"
                                            "<div> B04 - Boitiers optiques inférieurs à 6 dm³ sur aérien FT en aval PM,</div>\n"
                                            "<div> B05 - Boitiers optiques fictif raccordé par un CDI,</div>\n"
                                            "<div> B06 - Limiter les boitiers optiques sur les cables de forte capacité,</div>\n"
                                            "<div> B07 - Vérifier la présence de love dans toutes les chambres ADN et par cable</div>\n"
                                            "<h2 >Résultat: </h2>\n"
                                            "<div> La liste des erreurs est remontée, au format de la couche echange, dans la couche audit du schéma sélectionné. </div>\n"
                                            "<h2 >Contraintes: </h2>\n"
                                            "<div > La topologie du livrable doit être cohérente, les règles d'accrochage entre les objets doivent respectées </div>\n"
                                            "</body></html>"))


class class_general_dialog(QtWidgets.QDialog):

    def __init__(self, iface, var_connection):
        QtWidgets.QDialog.__init__(self)
        self.iface = iface
        self.connection = var_connection

    # Function pour executer une requete sql dans la base
    def function_execute_requete(self, requete_execute, req_fetch):
        curs = self.connection.cursor()
        try:
            curs.execute(requete_execute)
            if req_fetch:
                data_req = [row for row in curs.fetchall()]
                if data_req:
                    return data_req
        except(Exception, psycopg2.DatabaseError) as error:
            QMessageBox.critical(self.iface.mainWindow(), "Message dexecution de requete",
                                 'Requete Non Executer : ' + str(error) + ' ; ' + str(requete_execute))
        # print("Message dexecution de requete", 'Requete Non Executer : '+str(error)+' ; '+str(requete_execute))
        curs.close()

    def get_all_schema_name(self, list_widget):
        req_get_schema = """select 
			schema_name
		from information_schema.schemata
		where schema_name like 'pr%' order by schema_name;"""

        list_schema_name = self.function_execute_requete(req_get_schema, 'bab')

        for index, name_schema in enumerate(list_schema_name):
            if name_schema:
                list_widget.addItem("")
                list_widget.setItemText(index, name_schema[0])

    def get_version_plugin(self):
        # folder_plugin = os.path.dirname(os.path.abspath(__file__))
        folder_metada = open(
            folder_plugin + "\metadata.txt")  # open(folder_plugin.replace("forms\design", "\metadata.txt"))
        for line in folder_metada:
            if str(line)[:7] == 'version':
                get_version = line.split('=')[1]
                return get_version
        folder_metada.close()


class class_checkboite_dialog(class_general_dialog, Ui_check_boite_dialog):
    def __init__(self, iface):
        self.var_connection = function_connexion()
        class_general_dialog.__init__(self, iface, self.var_connection)
        self.setupUi(self)
        self.get_all_schema_name(self.name_pr)
        self.setWindowTitle("DESIGN " + str(self.get_version_plugin()) + " - Contrôle des équipements")
        self.var_connection.close()
        self.button_box.button(QtWidgets.QDialogButtonBox.Ok).clicked.connect(self.run)

    def run(self):

        list_statut = self.name_statut
        text_statut = [x for x in list_statut.currentText().split(',') if x]

        list_namePR = self.name_pr
        text_namePR = [x for x in list_namePR.currentText().split(',') if x]

        if len(text_statut) != 1 or len(text_namePR) != 1:  # len(text_titulaire) != 1 or  un seul MOE et
            QMessageBox.critical(self.iface.mainWindow(), "Message Du Choix",
                                 'Veillez cocher un seul STATUT et un seul PR')
        else:
            nom_moe = 'MOE'  # "".join(text_titulaire)
            nom_pr = "".join(text_namePR)
            nom_phase = str("".join(text_statut)).upper()
            schema = nom_pr
            function_Dimensionnement_boitiers_optiques(schema, nom_moe, nom_pr, nom_phase)
