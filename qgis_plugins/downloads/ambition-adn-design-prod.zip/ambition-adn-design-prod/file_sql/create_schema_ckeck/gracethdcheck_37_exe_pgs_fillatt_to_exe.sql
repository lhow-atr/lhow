SET search_path TO schemacheck, public;
INSERT INTO t_ct_exe_pgs
SELECT
t_ct_cat.ct_code,
t_ct_cat.ct_def,
t_ct_cat.ct_type,
t_ct_cat.ct_sensib,
t_ct_cat.ct_ordre AS ct_order,
t_ct_conf_fillatt.reseau AS ct_case,
t_ct_cat.ct_maintable AS ct_table,
t_ct_cat.ct_att,
t_ct_conf_fillatt.pre AS ct_exe_pre,
t_ct_conf_fillatt.dia AS ct_exe_dia,
t_ct_conf_fillatt.avp AS ct_exe_avp,
t_ct_conf_fillatt.pro_ou_act AS ct_exe_pro,
t_ct_conf_fillatt.pro_ou_act AS ct_exe_act,
t_ct_conf_fillatt.exe AS ct_exe_exe,
t_ct_conf_fillatt.tvx_ou_rec AS ct_exe_tvx,
t_ct_conf_fillatt.tvx_ou_rec AS ct_exe_rec,
t_ct_conf_fillatt.mco AS ct_exe_mco
FROM
t_ct_code_pgs,
t_ct_cat,
t_ct_conf_fillatt
WHERE
t_ct_cat.ct_code = t_ct_code_pgs.ct_pgs_cat_code AND
t_ct_conf_fillatt.attunique = t_ct_cat.ct_attunique AND
t_ct_code_pgs.ct_pgs_statut::integer > 2