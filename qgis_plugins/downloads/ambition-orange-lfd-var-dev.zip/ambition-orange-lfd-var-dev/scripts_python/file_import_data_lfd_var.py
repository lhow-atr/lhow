# -*- coding: utf-8 -*-
import os.path
import csv
import re
import sys
import psycopg2
from osgeo import ogr
import json

import xlrd
import xlwt
from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtWidgets import QWidget, QMessageBox, QProgressDialog
from qgis.core import QgsVectorLayer, QgsDataSourceUri, QgsProject, QgsMapLayer, Qgis
from qgis.utils import iface
from pathlib import Path

folder_plugin = str(Path(__file__).parent.parent)
sys.path.append(folder_plugin)
from bdd_lfd.params_connexion import function_connexion, DB, user, MP, host, port

# {folder_plugin = r'C:\Users\babacar.fassa\Documents\GitHub\orange-lfd-var'
# sys.path.append(folder_plugin)
# from bdd_lfd.params_connexion import *


# Class pour les fonctions generales
class GeneralFunctions:
    w = QWidget()
    MES_REQ_TITLE = "Message dexecution de requete"
    ACTION_CANCELLED = 'Action Cancelled'

    # Function pour la progession bar1
    @staticmethod
    def progress_bar(name_etape):
        prog = QProgressDialog(name_etape + ' : Veillez Patienter', 'Cancel', 0, 100)
        prog.setWindowModality(Qt.WindowModal)
        prog.setMinimumDuration(1)
        return prog

    # Function pour la progession bar2
    @staticmethod
    def progress_processing(index, count_entite, progress_dialog):
        f = int(index + 1)
        pcnt = int(f / count_entite * 100 / 1)
        progress_dialog.setValue(pcnt)

    # Function pour executer une requete sql dans la base
    def function_execute_requete(self, requete_execute, req_fetch, connection):
        curs = connection.cursor()
        try:
            curs.execute(requete_execute)
            if req_fetch:
                data_req = [row for row in curs.fetchall()]
                if data_req:
                    return data_req
            connection.commit()
        except(Exception, psycopg2.DatabaseError) as error:
            connection.close()
            QMessageBox.warning(self.w, self.MES_REQ_TITLE, 'Requete Non Executer : ' + str(error) + ' ; ' + str(requete_execute))
        curs.close()

    # Function pour  Get layer dans la BD
    def function_getlayer_bdd(self, schema, table_name, key, rename_table, column_geom):
        uri = QgsDataSourceUri()
        uri.setConnection(host, port, DB, user, MP)
        uri.setDataSource(schema, table_name, column_geom, '', key)
        layer = QgsVectorLayer(uri.uri(False), rename_table, "postgres")
        if layer.isValid():
            # QgsProject.instance().addMapLayer(layer)
            return layer
        else:
            QMessageBox.warning(self.w, "Message", 'Erreur de recuperation de la table : ' + str(table_name))

    # Function Get layer dans Qgis
    @staticmethod
    def function_getlayer_qgis(layer_name):
        layers = [tree_layer.layer() for tree_layer in QgsProject.instance().layerTreeRoot().findLayers()]  # Pyqgis3
        for layer in layers:
            layer_type = layer.type()
            if layer_type == QgsMapLayer.VectorLayer:
                if layer.name() == layer_name:
                    return layer

    # Function Get file Sql
    @staticmethod
    def get_file_content_sql(path_and_file_name):
        with open(path_and_file_name, 'r') as theFile:
            data = theFile.read()
            theFile.close()
            return data

    # Function pour ajouter des feuilles dans EXCEl
    def function_create_sheet(self, wb, sheet_name, list_user_export, header):
        # Execution de la bar
        bar_progress = self.progress_bar('Export des erreurs de Controls')
        ws_workbook = wb.add_sheet(sheet_name, cell_overwrite_ok=True)
        # print('Workbook', ';', ws_workbook)
        if list_user_export:
            for index_liste, k in enumerate(list_user_export):
                for colx, value in enumerate(k):
                    ws_workbook.write(index_liste + 1, colx, str(value))
                self.progress_processing(index_liste, len(list_user_export), bar_progress)
                if bar_progress.wasCanceled():
                    iface.messageBar().pushMessage('Info', self.ACTION_CANCELLED, level=Qgis.Info)
                    break
        colidx = 0  # Start from Column 0
        font_style = xlwt.XFStyle()
        font_style.font.bold = True
        for inddata in header:
            col = ws_workbook.col(colidx)
            col.width = 256 * 20
            ws_workbook.write(0, colidx, inddata, font_style)  # Insert in First Row ( Row 0)
            colidx = colidx + 1

    # Function pour exporter les fichiers de mauavis format
    def function_export_error_fichier(self, var_folder_export_error_fichier, var_name_file, connection, var_schema):
        cursor_db = connection.cursor()
        xlsfile_res = var_folder_export_error_fichier + "/" + var_name_file + ".xls"
        wb = xlwt.Workbook(encoding="UTF-8")
        requete = """select 
                    table_name,
                    'select * from "'||max(table_schema)||'".'||'"'||table_name||'"' as req, 
                    array_agg(column_name::text) entete
                from information_schema.columns
                where table_schema = '""" + str(var_schema).replace('"', '') + """' and 
                (table_name like 'IG%' or table_name like 'OC%' or table_name like 'SI%' or table_name like 'TE%' or 
                    table_name like 'TR%' or table_name like 'IA%' or table_name like 'SU%' or table_name like 'RO%'
                     or table_name like 'ZE%') and 
                table_name not in ('TRONCON_ROUTE_07-26', 'TRONCON_VOIE_FERREE_07-26')
                group by table_name
                order by table_name
                        """
        res_execute_requete = self.function_execute_requete(requete, 'baba', connection)
        try:
            if res_execute_requete:
                for index_export in range(len(res_execute_requete)):
                    value_feature = res_execute_requete[index_export]
                    value_name_table = value_feature[0]
                    value_req_execute = value_feature[1]
                    # {value_entet = value_feature[2]
                    # valeu_export = self.function_execute_requete(value_req_execute, 'baba', connection)
                    cursor_db.execute(value_req_execute)
                    valeu_export_fetchall = cursor_db.fetchall()
                    columns = [desc[0] for desc in cursor_db.description]  # list(cursor_db.description)
                    self.function_create_sheet(wb, str(value_name_table), valeu_export_fetchall, columns)
                wb.save(xlsfile_res)
                cursor_db.close()
        except(Exception, psycopg2.DatabaseError) as error:
            connection.close()
            return QMessageBox.warning(self.w, "Message de Traitement", 'Erreur Export des resultats: ' + str(error))


# Class pour importer des csv et shp dans BDD
class ImportMultiplesFilesCsvShp(GeneralFunctions):
    # Function initialisation
    def __init__(self, var_connection, var_schema, var_folder_data):
        self.connection = var_connection
        self.schema = var_schema
        self.folder_data = var_folder_data
        self.files_import = []
        self.list_error_traitement = []
        self.db_cursor = self.connection.cursor()
        self.function_import_mutiples_files()  # Execution des imports a linitialisation de la classe

    # Function Rename doublons name column
    @staticmethod
    def function_rename_column_name(var_list_column):
        dups = {}
        for i, val in enumerate(var_list_column):
            if val not in dups:
                # Store index of first occurrence and occurrence value
                dups[val] = [i, 1]
            else:
                # Special case for first occurrence
                if dups[val][1] == 1:
                    var_list_column[dups[val][0]] += str(dups[val][1])
                # Increment occurrence value, index value doesn't matter anymore
                dups[val][1] += 1
                # Use stored occurrence value
                var_list_column[i] += str(dups[val][1])
        return var_list_column

    # Function pour Importer des fichiers csv dans une BDD
    def function_insert_csv_bdd(self, var_file):
        try:
            # https://stackoverflow.com/questions/48085319/python-reading-and-writing-csv-files-with-utf-8-encoding
            with open(var_file, encoding="utf-8-sig", errors='ignore') as f:
                reader_file = csv.reader(f, delimiter=';')
                header = next(reader_file)
                file_name = '"' + os.path.basename(var_file).split('.')[0].replace(' ', '_').replace('-', '_').lower() \
                            + '"'
                # Creation de la table
                list_column = ["nan" if key == ''
                               else re.sub(r'\d', 'chiffre', ''.join(e for e in str(key) if e.isalnum()))
                               for key in header]
                # Partie Rename doublons name column
                list_column_rename = self.function_rename_column_name(list_column)

                list_column_text = [str(key) + ' text' for key in list_column_rename]
                req_create_table = f"DROP TABLE IF EXISTS {self.schema}.{file_name} cascade;" \
                                   f"CREATE TABLE {self.schema}.{file_name}({','.join(list_column_text)})"
                self.db_cursor.execute(req_create_table)
                # Insertion des elements dans la table creee
                list_all_feature_insert = []
                for index in reader_file:
                    list_tuple = tuple(index)
                    list_replace_carac = [str(key).replace("'", '').replace('"', '') for key in list_tuple]
                    values_features = str(tuple(list_replace_carac))
                    list_all_feature_insert.append(values_features)
                if list_all_feature_insert:
                    var_req_insert = f"INSERT INTO {self.schema}.{file_name}({','.join(list_column_rename)})" \
                                     f"values{','.join(list_all_feature_insert)}"
                    self.db_cursor.execute(var_req_insert)
                    self.connection.commit()
                # logging.info(f"Partie Import CSV: Le CSV {var_file} est bien importe dans le schema {self.schema}")
        except Exception as error:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            self.list_error_traitement.append(['function_insert_csv_bdd', var_file, f"{error} ... {exc_tb.tb_lineno}"])

    # Function pour Importer des fichiers shp dans une BDD
    def function_insert_shp_bdd(self, var_shp):
        try:
            file_open = ogr.Open(var_shp, 0)
            if file_open is None:
                QMessageBox.information(self.w, "Message-Execution-Plugin",
                                        f"Partie Import SHP: Probleme Import SHP...Le Shape {var_shp} "
                                        f"ne peut pas etre ouvert")
            else:
                shape_feature = file_open.GetLayer(0)
                var_file_name = '"' + os.path.basename(var_shp).split('.')[0]. \
                    replace(' ', '_').replace('-', '_').lower() + '"'
                dict_convert_type_field = {'String': 'character varying', 'Date': 'text',
                                           'Integer': 'Integer', 'Real': 'real', 'Integer64': 'Integer'}
                # Column_name et type
                list_column = []
                list_column_text = []
                for field in shape_feature.schema:
                    field_name = str(field.name).replace(' ', '_').replace('-', '_')
                    # {field_name = ''.join(e for e in re.sub('\d', '_', str(field.name).replace(' ', '_').
                    #                                        replace('-', '_')) if e.isalnum())
                    field_type_name = str(dict_convert_type_field[field.GetTypeName()])
                    field_width = str(field.GetWidth())
                    if field.GetTypeName() == 'String':
                        field_name_prepare = f"{field_name} {field_type_name}({str(field_width)})"
                    else:
                        field_name_prepare = f"{field_name} {field_type_name}"
                    list_column.append(field_name)
                    list_column_text.append(field_name_prepare)
                # Ajout de la colonne geometry
                list_column.append('geom')
                list_column_text.append('geom geometry')

                # Creation de la table
                req_create_table = f"DROP TABLE IF EXISTS {self.schema}.{var_file_name} cascade;" \
                                   f"CREATE TABLE {self.schema}.{var_file_name}({','.join(list_column_text)})"
                # Execution de la creation de la table
                self.db_cursor.execute(req_create_table)
                # Parcours du shape plus prepapration des donnees a inserer
                list_all_feature_insert = []
                for n in range(shape_feature.GetFeatureCount()):
                    feature_shp = shape_feature.GetFeature(n)
                    feature_json = json.loads(feature_shp.ExportToJson())
                    # {geaom_feature = f"ST_GeomFromText('{str(feature_shp.geometry())}')"
                    geaom_feature = f"ST_GeomFromText('{str(feature_shp.geometry())}',2154)"
                    list_values_attributs = list(feature_json['properties'].values())
                    list_appen_geom_feature = [None if field is None else str(field).replace("'", '')
                                               for field in list_values_attributs]
                    list_appen_geom_feature.append(geaom_feature)
                    tuple_appen_geom_feature = str(tuple(list_appen_geom_feature)).replace('"', '')
                    list_all_feature_insert.append(tuple_appen_geom_feature)
                # Insertion des elements dans la table
                if list_all_feature_insert:
                    name_index_geom = var_file_name.replace('"', '')
                    var_req_insert = f"INSERT INTO {self.schema}.{var_file_name}({','.join(list_column)}) " \
                                     f"values{','.join(list_all_feature_insert)}" \
                                     f";CREATE INDEX index_geom_{name_index_geom} ON {self.schema}.{var_file_name} " \
                                     f"USING gist (geom);".replace('None', 'NULL')
                    # f"CREATE INDEX rbal_phase2 ON {self.schema}.{var_file_name} USING gist (geom);"
                    self.db_cursor.execute(var_req_insert)
                    self.connection.commit()
                # logging.info(f"Partie Import SHP: Le Shape {var_shp} est bien importe dans le schema {self.schema}")
        except Exception as error:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            self.list_error_traitement.append(['function_insert_shp_bdd', var_shp, f"{error} ... {exc_tb.tb_lineno}"])

    # Function Execution en masse des Imports des fichiers CSV/SHP dans une BDD
    def function_import_mutiples_files(self):
        try:
            if self.folder_data:
                # Creation du schema import
                self.db_cursor.execute(f"CREATE SCHEMA IF NOT EXISTS {self.schema}")
                folder_iterate = os.listdir(self.folder_data)
                bar_progress = self.progress_bar('Partie Import en Masse des donnees')
                for index_char_qgis, file_etude in enumerate(folder_iterate):
                    chemin = self.folder_data
                    name, ext = os.path.splitext(file_etude)
                    chem_etude = f"{chemin}/{file_etude}"
                    if ext == ".shp":
                        self.function_insert_shp_bdd(chem_etude)
                        self.files_import.append(file_etude)
                    elif ext == ".csv":
                        self.function_insert_csv_bdd(chem_etude)
                        self.files_import.append(file_etude)
                    elif ext in (".dbf", ".cpg", ".prj", ".shx", ".log", ".sbn", ".sbx", ".qgz", ".qpj", ".qml"):
                        continue
                    else:
                        self.list_error_traitement.append(
                            ['function_import_mutiples_files', f"{name}_{ext}",
                             f"Partie Import chaque table: Le fichier {name}_{ext} ne sera "
                             f"pas importe puisse quil nest pas un csv ni un shape"])
                    self.progress_processing(index_char_qgis, len(folder_iterate), bar_progress)
                    if bar_progress.wasCanceled():
                        iface.messageBar().pushMessage('Info', 'Action Cancelled', level=Qgis.Info)
                        break
                # self.connection.commit()
                self.db_cursor.close()
                # self.connection.close()
                return self.files_import, self.list_error_traitement
            else:
                self.list_error_traitement.append(['function_import_mutiples_files', self.folder_data,
                                                   f"Partie Import en masse: Probleme choix repertoire des donnees..."
                                                   f"{self.folder_data}"])
        except Exception as error:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            self.list_error_traitement.append(['function_import_mutiples_files', 'function_import_mutiples_files', f"{error} ... {exc_tb.tb_lineno}"])


# Class pour Extraire des infos dans le fichier SVG
class ExtractInfoFromSVG(GeneralFunctions):
    # Function initialisation
    def __init__(self, var_connection, var_schema, var_folder_data):
        self.connection = var_connection
        self.schema = var_schema
        self.folder_data = var_folder_data
        self.files_import = []
        self.list_error_traitement = []
        self.db_cursor = self.connection.cursor()
        self.functionGetTextSvgMutiplesFiles()  # Execution des imports a linitialisation de la classe

    # Function pour recuperer les les cables dans le svg
    def functionGetTextSvg(self, filenamepath):
        try:
            try:
                from lxml import etree
            except(Exception,) as error:
                import subprocess
                subprocess.check_call(['pip', 'install', 'lxml'])
                from lxml import etree
            # {filenamepath = r'C:\Users\babacar.fassa\Documents\pythonProjectTestSvg\Vue-hierarchique.svg'
            tree = etree.parse(filenamepath)
            list_all_cables_text_svg = []
            for elem in tree.iter():
                var_text_tag = elem.text
                if var_text_tag and var_text_tag[:2] == 'TR':
                    list_all_cables_text_svg.append(var_text_tag)

            # Traitement les doublons
            list_all_cables_text_svg_unique = []
            for var_cable in list_all_cables_text_svg:
                if var_cable not in list_all_cables_text_svg_unique:
                    list_all_cables_text_svg_unique.append(var_cable)

            # Traitement pour list insert
            list_all_cables_text_svg_unique_insert = []
            for i in list_all_cables_text_svg_unique:
                var_text_prep = str(tuple([i])).replace(',', '')
                list_all_cables_text_svg_unique_insert.append(var_text_prep)

            # Prepare text requete insert
            requete_insert_cable_svg = f"""
                set search_path to {self.schema}, public;
                --- DROP TABLE IF EXISTS table_cable_svg;
                CREATE TABLE IF NOT EXISTS table_cable_svg(id_cable_svg text);
                INSERT INTO table_cable_svg(id_cable_svg) 
                VALUES {','.join(list_all_cables_text_svg_unique_insert)}"""
            return requete_insert_cable_svg
        except Exception as error:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            self.list_error_traitement.append(['functionGetTextSvg', 'functionGetTextSvg', f"{error} ... {exc_tb.tb_lineno}"])

    # Function Execution en masse des Imports des fichiers CSV/SHP dans une BDD
    def functionGetTextSvgMutiplesFiles(self):
        try:
            if self.folder_data:
                folder_iterate = os.listdir(self.folder_data)
                bar_progress = self.progress_bar('Partie Import en Masse des donnees')
                for index_char_qgis, file_etude in enumerate(folder_iterate):
                    chemin = self.folder_data
                    name, ext = os.path.splitext(file_etude)
                    chem_etude = f"{chemin}/{file_etude}"
                    if ext == ".svg":
                        requete_insert_cable_svg = self.functionGetTextSvg(chem_etude)
                        self.db_cursor.execute(requete_insert_cable_svg)
                        self.files_import.append(file_etude)
                    else:
                        self.list_error_traitement.append(
                            ['functionGetTextSvgMutiplesFiles', f"{name}_{ext}",
                             f"Partie Import chaque table: Le fichier {name}_{ext} ne sera "
                             f"pas importe puisse quil nest pas un csv ni un shape"])
                    self.progress_processing(index_char_qgis, len(folder_iterate), bar_progress)
                    if bar_progress.wasCanceled():
                        iface.messageBar().pushMessage('Info', 'Action Cancelled', level=Qgis.Info)
                        break
                self.connection.commit()
                self.db_cursor.close()
                # {self.connection.close()
                # return True
            else:
                self.list_error_traitement.append(['functionGetTextSvgMutiplesFiles', self.folder_data,
                                                   f"Partie Import en masse: Probleme choix repertoire des donnees..."
                                                   f"{self.folder_data}"])
                return self.list_error_traitement
        except Exception as error:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            self.list_error_traitement.append(['functionGetTextSvgMutiplesFiles', 'functionGetTextSvgMutiplesFiles', f"{error} ... {exc_tb.tb_lineno}"])
            return self.list_error_traitement


# Class pour lexecution des functions SQL
class ExecuteFileSQL(GeneralFunctions):
    # Constructeur des variables qui change
    def __init__(self, var_connection, var_schema):
        global folder_plugin
        self.list_error_traitement = []
        self.connection = var_connection
        self.db_cursor = self.connection.cursor()
        self.name_schema = var_schema
        self.pathAndFileName = f"{folder_plugin}/file_sql/requete_lfd.sql"  # var_file_sql_lfd
        self.name_schema_in_requete_lfd_sql = 'var_lfd'
        self.functionExecuteSql()

    # Function pour executer un file SQL
    def functionExecuteSql(self):
        try:
            if self.pathAndFileName:  # [0]
                text_sql_file = self.get_file_content_sql(self.pathAndFileName)  # [0]
                requete_execute_file_sql = str(text_sql_file).replace(self.name_schema_in_requete_lfd_sql,
                                                                      self.name_schema)
                self.db_cursor.execute(requete_execute_file_sql)
                self.connection.commit()
                self.db_cursor.close()
        except Exception as error:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            self.list_error_traitement.append(['function_execute_sql', 'function_execute_sql', f"{error} ... {exc_tb.tb_lineno}"])
            return self.list_error_traitement


# Class pour traitement des fichiers PT
class TraitementFichierIponPt(GeneralFunctions):
    def __init__(self, var_folder_data, var_schema):
        self.folder_data = var_folder_data
        self.name_schema = var_schema
        self.connection = function_connexion()
        self.db_cursor = self.connection.cursor()
        self.dict_all_vals_pt = {}
        self.list_error_traitement = []
        self.function_get_mutiples_files_ipon_pt()
        self.connection.commit()
        self.db_cursor.close()
        self.connection.close()

    # Function pour la lire les fichiers ipon des pt
    def function_get_file_ipon_pt(self, var_fichier):
        try:
            if var_fichier:
                file_name = str(os.path.splitext(os.path.basename(var_fichier))[0]).replace("'", '').replace('"', '')
                workbook = xlrd.open_workbook(var_fichier, on_demand=True)
                worksheet = workbook.sheet_by_index(0)
                first_row = []  # Header
                for col in range(worksheet.ncols):
                    name_column = str(worksheet.cell_value(0, col))
                    first_row.append(name_column)
                for row in range(1, worksheet.nrows):
                    for col in range(worksheet.ncols):
                        values_col = str(worksheet.cell_value(row, col)).replace("'", '"').replace('.0', '').split("\n")
                        if values_col != ['']:
                            val_key = f"{values_col[0]};{file_name}"
                            if val_key in self.dict_all_vals_pt:
                                self.dict_all_vals_pt[val_key].append(values_col)
                            else:
                                self.dict_all_vals_pt[val_key] = [values_col]
            else:
                # QMessageBox.warning(iface.mainWindow(), "Message-Execution-Plugin", f'Erreur lecture: {var_fichier}')
                self.list_error_traitement.append(['function_get_file_ipon_pt', var_fichier,
                                                   f'Erreur lecture: {var_fichier}'])
        except Exception as error:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            self.list_error_traitement.append(['function_get_file_ipon_pt', var_fichier, f"Erreur sur la function_get_file_ipon_pt: {var_fichier}...{error} ... {exc_tb.tb_lineno}"])

    # Function Execution en masse des traitements des fichiers Ipon PT
    def function_get_mutiples_files_ipon_pt(self):
        try:
            if self.folder_data:
                folder_iterate = os.listdir(self.folder_data)
                bar_progress = self.progress_bar('Partie Traitement en Masse des Fichiers Ipon PT')
                for index_char_qgis, file_etude in enumerate(folder_iterate):
                    chemin = self.folder_data
                    name, ext = os.path.splitext(file_etude)
                    chem_etude = f"{chemin}/{file_etude}"
                    if ext == ".xls":
                        self.function_get_file_ipon_pt(chem_etude)
                    else:
                        self.list_error_traitement.append(
                            ['function_get_mutiples_files_ipon_pt', f"{name}_{ext}",
                             f"Partie Traitement chaque fichier: Le fichier {name}_{ext} ne sera "
                             f"pas traite puisse quil nest pas un xls"])
                    self.progress_processing(index_char_qgis, len(folder_iterate), bar_progress)
                    if bar_progress.wasCanceled():
                        iface.messageBar().pushMessage('Info', 'Action Cancelled', level=Qgis.Info)
                        break
                list_insert_table = []
                for index_key, values in self.dict_all_vals_pt.items():
                    name_split = index_key.split(";")
                    val_insert = str(tuple([name_split[0], name_split[1], ','.join([str(val).replace("'", '')
                                                                                    for val in values]), len(values)]))
                    list_insert_table.append(val_insert)
                text_req_insert = f"""set search_path to {self.name_schema}, public; 
                    drop table if exists table_data_ipon_pt;
                    create table table_data_ipon_pt (nom_pt text, nom_fichier text, data_pt text, nombre_pt int);
                    INSERT INTO table_data_ipon_pt(nom_pt, nom_fichier, data_pt, nombre_pt) 
                    VALUES {','.join(list_insert_table)};"""
                self.db_cursor.execute(text_req_insert)
            else:
                self.list_error_traitement.append(['function_get_mutiples_files_ipon_pt', self.folder_data,
                                                   f"Partie Traitement en masse: Probleme choix repertoire des "
                                                   f"donnees...{self.folder_data}"])
        except Exception as error:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            self.list_error_traitement.append(['function_get_mutiples_files_ipon_pt', 'function_get_mutiples_files_ipon_pt', f"{error} ... {exc_tb.tb_lineno}"])


def function_execute_class_general_var(var_schema_name, var_folder_export,
                                          var_folder_data_shp, var_folder_data_csv, var_folder_data_svg, var_folder_data_ipon_pt):
    w = QWidget() # iface.mainWindow()
    connection = function_connexion()
    # Importation des donnees dans la BDD
    list_error = []
    try:
        # Partie Importation des donnees
        res_import_csv = ImportMultiplesFilesCsvShp(connection, var_schema_name, var_folder_data_csv)
        res_import_shp = ImportMultiplesFilesCsvShp(connection, var_schema_name, var_folder_data_shp)
        list_error = res_import_csv.list_error_traitement
        list_error = res_import_shp.list_error_traitement
        if not res_import_csv.list_error_traitement and not res_import_shp.list_error_traitement:
            # Partie Extraction FROM SVG
            res_extract_svg = ExtractInfoFromSVG(connection, var_schema_name, var_folder_data_svg)
            list_error = res_extract_svg.list_error_traitement
            res_traitement_pt_ipon = TraitementFichierIponPt(var_folder_data_ipon_pt, var_schema_name)
            if len(res_traitement_pt_ipon.list_error_traitement) == 0:
                if not res_extract_svg.list_error_traitement:
                    # Partie Execution fichier SQL
                    var_execute_file_sql = ExecuteFileSQL(connection, var_schema_name)
                    list_error = var_execute_file_sql.list_error_traitement
                    if not var_execute_file_sql.list_error_traitement:
                        var_execute_file_sql.function_export_error_fichier(var_folder_export, 'export_res',
                                                                        connection, var_schema_name)
                    else:
                        connection.close()
                        return QMessageBox.warning(w, "Message dexecution de requete",
                                                f"Erreur Execution File SQL: {str(','.join(var_execute_file_sql.list_error_traitement))}")
                    connection.close()
                    # Fin traitement
                    return QMessageBox.information(w, "Message dexecution de requete",
                                                'Création des résultats LFD Var réalisée avec succès')
                else:
                    connection.close()
                    return QMessageBox.warning(w, "Message dexecution de requete",
                                        f"Erreur sur les SVG: {str(','.join(res_extract_svg.list_error_traitement))}")
            else:
                connection.close()
                return QMessageBox.warning(w, "Message dexecution de requete",
                                            f"Erreur Erreur Creation table Ipon PT: \n"
                                            f"{','.join([str(val) for val in res_traitement_pt_ipon.list_error_traitement])}")
        else:
            connection.close()
            return QMessageBox.warning(w, "Message dexecution de requete",
                                f"Erreur sur les CSV: {str(','.join(res_import_csv.list_error_traitement))} \n"
                                f"Erreur sur les CSV: {str(','.join(res_import_shp.list_error_traitement))} ")

    except Exception as error:
        connection.close()
        exc_type, exc_obj, exc_tb = sys.exc_info()
        return QMessageBox.warning(w, "Message de Traitement", f"Erreur Execution Gloabl Script: {str(list_error)} ... {error} ... {exc_tb.tb_lineno}")


# {
# var_schema_name = '"schema_test_baba"'
# path_base = r'M:\CLIENT DIV\ORANGE RIP\ORANGE UI SE - controles LFD\Var THD\Affaires\20210818_FI-83119-000K'
# var_folder_export = path_base  # f"{path_base}/export"
# var_folder_data_shp = f"{path_base}/SHP"
# var_folder_data_csv = f"{path_base}/CSV"
# var_folder_data_svg = f"{path_base}/SVG"
# var_folder_data_rbal = f"{path_base}/rbal"
# var_folder_data_ipon_pt = f"{path_base}/Etiquette"
# function_execute_class_general_var(var_schema_name, var_folder_export, var_folder_data_shp, var_folder_data_csv, var_folder_data_svg, var_folder_data_ipon_pt)
# connection = function_connexion()
# res_import_csv = ImportMultiplesFilesCsvShp(connection, var_schema_name, var_folder_data_rbal)
# connection.close()
