# **Plugin de Contrôle des données sur le projet LFD VAR**
Ce Plugin est composé de deux parties, l'import des données dans la base de données et le Contrôle de ces données. Le Contrôle de données se fait par un lancement d'une serie de traitements qui seront décrits ci-dessous. Pour avoir plus de détails sur les Contrôles, reportez vous sur le [Fichier Spec des Contrôles](./assets/docs_spec/Details_Requetes_LFD_Var_THD.xlsx).
## ***Import des données***
- ### ***Objectif :***
Ce module permet de lancer les traitements LFD des données importées en base de données, et d’exporter les résultats sous forme d’un fichier Excel (un  onglet par requête). La base de données est celle configurée dans le projet : lfd_bdd.
- ### ***Données d’entrée :***
    [Exemple données d'entrée](./assets/docs_spec/donnees_sources.zip)
    - ##### CSV (liste des CSV attendus):
        - ###### Chambre FTTH.csv
        - ###### ipon.csv
        - ###### Export_site_IPON_commune.csv
        - ###### Optimum.csv
    - ##### Shapefiles (liste des Shapefiles attendus):
        - ###### contour_pm.shp
        - ###### ftth_cable.shp
        - ###### ftth_pf.shp
        - ###### ftth_site_appui_erdf.shp
        - ###### ftth_site_appui_ft.shp
        - ###### ftth_site_immeuble.shp
        - ###### ftth_zone_eligibilite.shp
        - ###### RBAL.shp
    - ##### Xls (liste des xls de fichier PT Ipon attendus):
        - ###### Etiquette_FI-83119-000K.xls
    - ##### Svg (liste des svg attendus):
        - ###### Vue-hierarchique.svg
- ### ***Variables demandés :***
    - ###### Code NRO: INSEE & 3 DIGIT
    - ###### Code NRO de rattachement: COMMUNE
    - ###### Choix de la date: via le calendrier
    - ###### Choix dossier des Shapefiles
    - ###### Choix dossier des CSV
    - ###### Choix dossier des SVG
    - ###### Choix dossier des PT Ipon
    - ###### Choix dossier de l’export des résultat
- ### ***Résultats :***
    Les données sont intégrées en base de données dans un schéma dédié (gestion des versions), les résultats du traitement sont enregistrés dans la base de données et exportées au format Excel (avec un onglet pour chaque résultat de requête)
- ### ***Contraintes :***
    Toutes les données d'entrée doivent etre conformes et toutes les variables doivent etre renseignées
- ### ***Mode opératoire :***
    ![Erreur Image](assets/import_data.png)
    ![Erreur Image](assets/import_message.png)

## ***Contrôle des données***
- ### ***Objectif :***
    Il est de réaliser trente contrôles qui sont :
    - ###### Contrôle IG01.1; Description: Vérifier la présence d’un seul PB par point technique par chambre selon les attributs
    - ###### Contrôle IG02.1; Description: Cohérence de l’ingénierie : 4 têtes max pour PM (2x28U) ou 6 têtes max pour PM (2x40U)
    - ###### Contrôle IA01.1; Description: anomalie du type_longu ou du statut_ftth
    - ###### Contrôle IA06.1; Description: anomalie du type_longu ou du statut_ftth
    - ###### Contrôle IA01.2; Description: anomalie du type_longu ou du statut_ftth
    - ###### Contrôle IA03.1; Description: recensement complet des appuis utilisés et plantés dans l’intégralité des SI d’oranges (GFI et IPON) geometrie
    - ###### Contrôle IA04.1; Description: verification que tout les appuis sont sur IPON
    - ###### Contrôle IA05.1; Description: Bilan des linéaires complets
    - ###### Contrôle SI01.1; Description: verifier que toute les ZE ont un PF
    - ###### Contrôle SI02.1; Description: retrouver tout les PF PB du PM
    - ###### Contrôle SI02.2; Description: retrouver tout les PF PB du PM
    - ###### Contrôle SI03.1; Description: verifier que les PB sont déployé sur GEOFIBRE (comparaison d'attributs)
    - ###### Contrôle SI03.2; Description: verifier que les PB sont déployé sur GEOFIBRE (comparaison d'attributs)
    - ###### Contrôle SI04.1; Description: verifier que les PB sont déployé sur IPON (comparaison d'attributs)
    - ###### Contrôle SI05.1; Description: verifier que tout les collectifs sont traités (comparaison d'attributs)
    - ###### Contrôle SI06.1; Description: verifications que tout les immeubles RBAL sont sur GFI (geometrie)
    - ###### Contrôle SI06.2; Description: verifications que tout les immeubles RBAL sont sur GFI (geometrie)
    - ###### Contrôle SI07.1; Description: verifications que tout les immeubles GFI sont sur OPTIMUM  (comparaison d'attributs)
    - ###### Contrôle SI08.1; Description: anomalie entre nom_site_pf_pb et position_d_equipement_pt_pb (comparaison d'attributs)
    - ###### Contrôle SI09.1; Description: Hauteur des équipements dans IPON (comparaison d'attributs)
    - ###### Contrôle SI10.1; Description: verifier si nature des travaux est coherent avec l'emplacement du PB (comparaison d'attributs)
    - ###### Contrôle SI11.1; Description: verifier les adduction vs les adductabilité (comparaison d'attributs)
    - ###### Contrôle SI12.1; Description: verification de l'operateur immeuble
    - ###### Contrôle SI13.1; Description:  Conventions façades présentes sous OPTIMUM (comparaison d'attributs)
    - ###### Contrôle IG06.1; Description: Cohérence de l’ingénierie : Réserve au PB 
    - ###### Contrôle IG06.2; Description: Cohérence de l’ingénierie : Réserve au PB 
    - ###### Contrôle ZE01.1; Description: sites immeubles a ajouter/retirer des ZE PF PB IPON part1
    - ###### Contrôle ZE01.2; Description: sites immeubles a ajouter/retirer des ZE PF PB IPON part2
    - ###### Contrôle SU01.1; Description: comparaison des sites supports GFI/IPON
    - ###### Contrôle SU02.2; Description: comparaison des sites supports GFI/IPON
- ### ***Résultats :***
    Les résultats du traitement sont enregistrés dans la base de données et exportées au format Excel (avec un onglet pour chaque résultat de requête)  
    ![Erreur Image](assets/ctrl_result.png)  
    [Exemple de resultat exportés](./assets/docs_spec/export_res.xls)
- ### ***Contraintes :***
    Toutes les données d'entrée doivent etre conformes et toutes les variables doivent etre renseignées