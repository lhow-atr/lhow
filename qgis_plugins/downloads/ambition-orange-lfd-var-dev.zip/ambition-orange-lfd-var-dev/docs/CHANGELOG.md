# Changelog Notes
## Tags
v_2023_01_03    Tags Version v_2023_01_03
v_2023_01_16    Tags Version v_2023_01_16
v_2023_01_17    Tags Version v_2023_01_17
## Commits
- Correction erreur mise a jour plugin (fd772c0) (Babacar FASSA) (2023-01-17)
- Correction erreur qmessageBox et ajout le changelog dans la documentation (f8c9516) (Babacar FASSA) (2023-01-16)
- Migration vers qgis3.22 version finale avec ajout de la methode du deploiement continu ainsi que la documentation avec mkdocs et la creation de tag a chaque modifications (303cf78) (Babacar FASSA) (2023-01-03)
- Migration vers qgis3.22 version finale avec ajout de la methode du deploiement continu ainsi que la documentation avec mkdocs (0803f41) (Babacar FASSA) (2022-12-30)
- Migration vers qgis3.22 version finale avec ajout de la methode du deploiement continu ainsi que la documentation avec mkdocs (3f18837) (Babacar FASSA) (2022-12-30)
- IMP: Correction de la supression de lexecution de la fonction test (ca8cce5) (Babacar FASSA) (2021-09-16)
- IMP: Modifications sur les requetes: ZE01.2, SI08.1, SI11.1, Ajout Version (d764911) (Babacar FASSA) (2021-09-15)
- IMP: Modifications sur les requetes: ZE01.2, SI08.1, SI11.1 (f15f9fb) (Babacar FASSA) (2021-09-15)
- IMP: Nouvelle requete IA06.1, IG06.2, ZE01.1, ZE01.2, SU01.1, SU02.2. Ajout nouvelle colonne rome_ok dans SI02.1. Ajout nouvelles colonnes dans SI02.2. Ajout nouvelle condition dans SI08.1, RO01.1, RO01.2, RO01.3. Ajout de la fonctionalité du traitement des fichier ipon pt (d3008d3) (Babacar FASSA) (2021-09-13)
- IMP: Ajout de nouvelles requetes SI02.2 et SI03.2 (a3ad22a) (Babacar) (2021-06-30)
- IMP: Correction Git ATHD VAR (44a044a) (babfas) (2021-06-24)
- "IMP: DEV: SI11.1, il faut que la requete ressorte aussi les lignes qui ont "adduction" ou "adductabilite" videSI12.1, il faut que la requete ressorte aussi les "oioperateurimmeuble" qui sont vide, meme si "codeimbzonedinfluencepfpbselonlesadresses" est vide." (9f24757) (Babacar) (2021-03-31)
- Initial commit (34451a6) (Babacar) (2021-03-22)
## Merges
## AUTHORS
- Babacar
- Babacar FASSA
- babfas
