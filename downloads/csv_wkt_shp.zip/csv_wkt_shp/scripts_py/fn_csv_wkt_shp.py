from qgis.PyQt.QtCore import *
from qgis.PyQt.QtGui import *
from qgis.core import * 
from qgis.utils import *
from qgis.PyQt.QtWidgets import *
from datetime import date
from glob import iglob
import os
import csv


qw = QWidget()
qfd = QFileDialog()

title = 'Select les csv'
#list layers importé
list_a = []

def run():
    
    def fn_filePath(title):
        qfd = QFileDialog()
        path = os.getcwd()
        filter = "(*.csv)"
        title = 'Select les csv'
        f, _filter= qfd.getOpenFileNames(qfd, title, path, filter)
        return f
    file_path = fn_filePath(title)
    
    
    def fn_test_n_load_wkt():
        
        root = QgsProject.instance().layerTreeRoot()
        node_group = QgsLayerTreeGroup("wkt_csv - "+str(date.today()))
        root.addChildNode(node_group)
        
        for file in file_path:
            fp = file_path
            data=[file.split(',',1)[0] for file in fp]
            file_1=(data[0])
            ht_1 = os.path.split(str(file_1))
            op_1 = ht_1 [0]
            os.chdir(op_1)
            
            unique_headers = set()
            for filename in iglob(file):
                with open(filename, 'r', encoding='cp1252') as fin:
                    csvin = csv.reader(fin, delimiter=";")
                    unique_headers.update(next(csvin, []))
            
            if 'wkt_geom' in unique_headers:
                try:
                    fn = os.path.basename((file))
                    uri =f'file:///{file}?type=csv&delimiter=;&encoding=System&skipEmptyFields=No&detectTypes=yes&wktField=wkt_geom&crs=EPSG:2154&spatialIndex=yes&subsetIndex=yes&watchFile=no'
                    wkt = QgsVectorLayer(uri, fn,'delimitedtext')
                    QgsProject().instance().addMapLayer(wkt, False)
                    node_layer = node_group.addLayer(wkt)
                    list_a.append(node_layer.name())
                    
                except:
                    iface.messageBar().pushMessage("Error de chargement", level=Qgis.Critical, duration=4)
            else:
                iface.messageBar().pushMessage("la colonne wkt_geom n'existe pas:", " %s" % file, level=Qgis.Critical, duration=4)
                
    fn_test_n_load_wkt()

   
    def fn_info_layers():
        if not list_a:
            iface.messageBar().pushMessage("Les couches ne sont pas chargé", level=Qgis.Critical, duration=4)
        else:
            i = list_a
            iface.messageBar().pushMessage("layers loaded ",  "%s"  % i, level=Qgis.Info, duration=2)
    fn_info_layers()
    
    
    def fn_save_as_shp():
   
        layers_b = []
        for layer in list_a:
            layer_n = QgsProject.instance().mapLayersByName(layer)[0]
            layers_b.append(layer_n)
        
        for layer in layers_b:
        # for layer in layers_tr:
            if layer.isValid():
                output = os.getcwd()

                name = layer.name()[:-4]+"_"+str(date.today())
                try:
                    writer = QgsVectorFileWriter.writeAsVectorFormat(layer, output+"/"+name, "system", QgsCoordinateReferenceSystem(2154),driverName='ESRI Shapefile')
                    iface.messageBar().pushMessage("Couches enregistré ici",  "%s"  % output, level=Qgis.Success, duration=2)
                    
                except:
                    iface.messageBar().pushMessage("L'enregistrement des shp a échoué",  "%s"  % output, level=Qgis.Critical, duration=4)
            else:
                iface.messageBar().pushMessage("Geom Not Valid",  "%s"  % output, level=Qgis.Critical, duration=4)
    fn_save_as_shp()




