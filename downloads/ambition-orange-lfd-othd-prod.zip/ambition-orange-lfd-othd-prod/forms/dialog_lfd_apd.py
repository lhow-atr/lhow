# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'C:\Users\babacar.fassa\Downloads\dialog_lfd_for_bf\dialog_lfd.ui'
#
# Created by: PyQt5 UI code generator 5.11.3
#
# WARNING! All changes made in this file will be lost!

import os
import sys
from pathlib import Path
from qgis.PyQt import QtWidgets, QtCore
from qgis.PyQt.QtWidgets import QMessageBox, QWidget
from qgis.gui import QgsFileWidget, QgsDateTimeEdit
from qgis.core import QgsApplication
from qgis.utils import iface

# # {
# # Initialize QGIS Application
# app = QgsApplication([], False)
# QgsApplication.setPrefixPath("C:\QGIS 3.22.13\apps\qgis-ltr", True)
# QgsApplication.initQgis()


folder_plugin = str(Path(__file__).parent.parent)
sys.path.append(folder_plugin)
from scripts_python.file_import_data_lfd_rip import function_execute_class_general_apd



class UiDialog(object):
    def functionCreateLabel(self, varDialog, varNameLabel, varNameTextLabel):
        varLabel = QtWidgets.QLabel(varDialog)
        varLabel.setObjectName(varNameLabel)
        varLabel.setText(varNameTextLabel)
        return varLabel
    
    def functionCreateObjetVariableQLineEdit(self, varDialog, varNameObjet):
        varObjetVariable = QtWidgets.QLineEdit(varDialog)
        varObjetVariable.setObjectName(varNameObjet)
        return varObjetVariable

    def functionCreateObjetVariableDateTime(self, varDialog, varNameObjet):
        varObjetVariableDate = QgsDateTimeEdit(varDialog)
        varObjetVariableDate.setObjectName(varNameObjet)
        return varObjetVariableDate

    def functionCreateObjetvariableQgsFileWidget(self, varDialog, varNameObjet):
        varObjetVariableFile = QgsFileWidget(varDialog)
        varObjetVariableFile.setObjectName(varNameObjet)
        return varObjetVariableFile
        
    def setupUi(self, Dialog):
        Dialog.setObjectName("Dialog")
        # Dialog.resize(662, 519)
        Dialog.setWindowTitle("Traitement LFD RIP")   
        Dialog.setWindowModality(QtCore.Qt.ApplicationModal)
        Dialog.setEnabled(True)
        Dialog.resize(800, 800)
        Dialog.setMouseTracking(False) 

        # Partie de la creation dun container de dessin de la boite de dialog
        self.verticalLayoutWidget = QtWidgets.QWidget(Dialog)
        self.verticalLayoutWidget.setGeometry(QtCore.QRect(30, 30, 700, 700))
        self.verticalLayoutWidget.setObjectName("verticalLayoutWidget")

        # Partie de la creation sous container
        self.verticalLayout = QtWidgets.QVBoxLayout(self.verticalLayoutWidget)
        self.verticalLayout.setContentsMargins(0, 0, 0, 0)
        self.verticalLayout.setObjectName("verticalLayout")

        # Partie de la creation d'une Grille pour organiser les labels et leur object
        self.gridLayout = QtWidgets.QGridLayout()
        self.gridLayout.setObjectName("gridLayout")

        # Partie Creation des Labels des objets des variables
        self.varLabelCodeNro = self.functionCreateLabel(self.verticalLayoutWidget, "varObjetCodeNro", "PA Reg :")
        self.varLabelCodeNroRattachement = self.functionCreateLabel(self.verticalLayoutWidget, "varObjetCodeNro", "NRO de rattachement :")
        self.varLabelDateTime = self.functionCreateLabel(self.verticalLayoutWidget, "varLabelDateTime", "Date de livraison :")
        # Partie Creation des objets de la premiere ligne (variable code nro, code nra et date)
        self.VarCodeNro = self.functionCreateObjetVariableQLineEdit(self.verticalLayoutWidget, "VarCodeNro")
        self.VarCodeRat = self.functionCreateObjetVariableQLineEdit(self.verticalLayoutWidget, "VarCodeRat")
        self.varObjetDateTime = self.functionCreateObjetVariableDateTime(self.verticalLayoutWidget, "varObjetDateTime")

        # Partie Creation des Labels des chemins des dossiers
        self.varLabelDossierShp = self.functionCreateLabel(self.verticalLayoutWidget, "varDossierShp", "Dossier Shapefiles :")
        self.varLabelDossierCsv = self.functionCreateLabel(self.verticalLayoutWidget, "varDossierCsv", "Dossier CSV :")
        self.varLabelDossierEtiquette = self.functionCreateLabel(self.verticalLayoutWidget, "varDossierEtiquette", "Dossier Etiquette :")
        self.varLabelDossierCible = self.functionCreateLabel(self.verticalLayoutWidget, "varDossierCible", "Dossier cible :")
        # Partie Creation des objets des chemins des dossiers
        self.varShpDirectory = self.functionCreateObjetvariableQgsFileWidget(self.verticalLayoutWidget, "varShpDirectory", )
        self.varCsvDirectory = self.functionCreateObjetvariableQgsFileWidget(self.verticalLayoutWidget, "varCsvDirectory")
        self.varEtiquetteDirectory = self.functionCreateObjetvariableQgsFileWidget(self.verticalLayoutWidget, "varEtiquetteDirectory")
        self.varCibleDirectory = self.functionCreateObjetvariableQgsFileWidget(self.verticalLayoutWidget, "varCibleDirectory")
        

        # Deuxieme argument == Numero la ligne et troisieme argument == Numero la colonne
        self.gridLayout.addWidget(self.varLabelCodeNro, 0, 0)
        self.gridLayout.addWidget(self.varLabelCodeNroRattachement, 0, 1)
        self.gridLayout.addWidget(self.varLabelDateTime, 0, 2)
        # Ligne Numero Deux sur la boite de dialogue
        self.gridLayout.addWidget(self.VarCodeNro, 1, 0)
        self.gridLayout.addWidget(self.VarCodeRat, 1, 1)
        self.gridLayout.addWidget(self.varObjetDateTime, 1, 2)
        # Ligne Numero Trois Une sur la boite de dialogue
        self.gridLayout.addWidget(self.varLabelDossierShp, 2, 0)
        self.gridLayout.addWidget(self.varLabelDossierCsv, 2, 1)
        self.gridLayout.addWidget(self.varLabelDossierEtiquette, 2, 2)
        self.gridLayout.addWidget(self.varLabelDossierCible, 2, 3)
        # Ligne Numero Quatre sur la boite de dialogue
        self.gridLayout.addWidget(self.varShpDirectory, 3, 0)
        self.gridLayout.addWidget(self.varCsvDirectory, 3, 1)
        self.gridLayout.addWidget(self.varEtiquetteDirectory, 3, 2)
        # Ligne Numero Cinq sur la boite de dialogue
        self.gridLayout.addWidget(self.varCibleDirectory, 3, 3)

        # Partie Description Text
        self.textBrowser = QtWidgets.QTextBrowser(self.verticalLayoutWidget)
        self.textBrowser.setGeometry(QtCore.QRect(20, 140, 621, 311))
        self.textBrowser.setObjectName("textBrowser")
        self.textBrowser.setHtml(
            # Ouverture Parametrage du HTML
            """
            <!DOCTYPE html>
            <html lang="en">
            <head>
                <meta charset="UTF-8">
                <title>Title</title>
                <style type="text/css">
                    div, li {text-indent: 25px; font-size:11pt}
                    body {text-align: justify; font: sans-serif;}
                </style>
            </head>
            <body>
            """
            # Corp du text
            """
            <h3> Objectifs: </h3>
                <div> Ce module permet de lancer le traitement LFD des données importées en base de données, et d’exporter les résultats sou forme d’un fichier Excel (un  onglet par requête).</div>
            <h3> Données en entrée: </h3>
                <div> Données transmises par le client, préparées au format CSV et SHP tout en respectant les noms ci-dessous: 
                    <ol>
                        <li> <h5> CSV </h5> </li>
                            <div> export_cable_ipon_commune.csv</div>\n
                            <div> ipon.csv</div>\n
                            <div> pointage_etude.csv</div>\n
                            <div> positionnement_etude.csv</div>\n
                        <li> <h5> Shapefiles </h5> </li>
                            <div> contour_pa.shp</div>\n
                            <div> ftth_cable.shp</div>\n
                            <div> ftth_pf.shp</div>\n
                            <div> ftth_site_immeuble.shp</div>\n
                            <div> ftth_zone_eligibilite.shp</div>\n
                        <li> <h5> Etiquette </h5> </li>
                            <div> Etiquette_FI-61460-0000.xls</div>\n
                    </ol>
                </div>
            <h3> Résultat: </h3>
                <div> Le livrable est importé dans un schéma en base de données. Des fichiers de sorties sont créés
                    <ol>
                        <li> export_res.xls </li>
                    </ol>
                </div>
            <h3> Contraintes: </h3>
                <div> Le livrable à intégrer doit respecter le formalisme du MCD.</div>
            <h3> Restrictions:</h3>
                <ol>
                  <li> Renseigner le « Code PA Reg », Renseigner le « NRO de rattachement » (COMMUNE) </li>
                  <li> Renseigner la « Date de livraison » (via le calendrier) </li>
                  <li> Renseigner le chemin des Shapefiles </li>
                  <li> Renseigner le chemin des CSV </li>
                  <li> Renseigner le chemin de l’export des résultats </li>
                  <li> Renseigner le chemin des etiquettes </li>
                </ol>
            """
            # Fin Parametrage du HTML
            """
            < / body >
            < / html > """
        )

         # Ajout de la grille dans le vertitcallayout
        self.verticalLayout.addLayout(self.gridLayout)
        # Ajout du textBrowser dans le vertitcallayout
        self.verticalLayout.addWidget(self.textBrowser)

        # Partie de la creation du Nom button_box
        self.buttonBox = QtWidgets.QDialogButtonBox(self.verticalLayoutWidget)
        self.buttonBox.setOrientation(QtCore.Qt.Horizontal)
        self.buttonBox.setStandardButtons(
            QtWidgets.QDialogButtonBox.Cancel | QtWidgets.QDialogButtonBox.Ok)
        self.buttonBox.setObjectName("button_box")
        
        # Ajout du button_box dans le vertitcallayout
        self.verticalLayout.addWidget(self.buttonBox)
        self.buttonBox.accepted.connect(Dialog.accept)
        self.buttonBox.rejected.connect(Dialog.reject)
        QtCore.QMetaObject.connectSlotsByName(Dialog)


class ClassGeneralDialog(QtWidgets.QDialog):
    def __init__(self, iface):
        QtWidgets.QDialog.__init__(self)
        self.iface = iface

    @staticmethod
    def get_version_plugin():
        folder_metada = open(f"{folder_plugin}\metadata.txt")
        for line in folder_metada:
            if str(line)[:7] == 'version':
                get_version = line.split('=')[1]
                folder_metada.close()
                return get_version


class ClassImportExecuteLfdApd(ClassGeneralDialog, UiDialog):
    def __init__(self, iface):
        ClassGeneralDialog.__init__(self, iface)
        self.setupUi(self)
        self.setWindowTitle("LFD RIP" + str(self.get_version_plugin()) + " - Traitement LFD APD ")
        self.varShpDirectory.setStorageMode(QgsFileWidget.GetDirectory)
        self.varCsvDirectory.setStorageMode(QgsFileWidget.GetDirectory)
        self.varEtiquetteDirectory.setStorageMode(QgsFileWidget.GetDirectory)
        self.varCibleDirectory.setStorageMode(QgsFileWidget.GetDirectory)
        self.buttonBox.button(QtWidgets.QDialogButtonBox.Ok).clicked.connect(self.run)
        
    
    def run(self):
        name_date = self.varObjetDateTime.date().toString("yyyyMMdd")
        nom_nro = self.VarCodeNro.text()
        nom_nro_rat = self.VarCodeRat.text()

        schema = '"' + str(nom_nro).lower() + '_' + str(nom_nro_rat).lower() + '_' + 'v_' + str(name_date) + '"'
        pathshp = str(self.varShpDirectory.filePath())
        pathcsv = str(self.varCsvDirectory.filePath())
        pathetiquette = str(self.varEtiquetteDirectory.filePath())
        pathexport = str(self.varCibleDirectory.filePath())

        # Check Directory
        isdirectoryshp = os.path.isdir(pathshp)
        isdirectorycsv = os.path.isdir(pathcsv)
        isdirectoryetiquette = os.path.isdir(pathetiquette)
        isdirectoryexport = os.path.isdir(pathexport)

        if isdirectoryshp and isdirectorycsv and isdirectoryetiquette and isdirectoryexport:
            function_execute_class_general_apd(schema, pathexport, pathshp, pathcsv, pathetiquette, "requete_lfd_apd")
        else:
            QMessageBox.critical(QWidget(), "Message Execution Plugin", 'Veillez tous les bons chemins')

#         var_schema_name = '"schema_test_baba_61"'
#         path_base = r'C:\Users\babacar.fassa.AMBITION\Desktop\LFD\BDD\folder_import_test'
#         var_folder_export = f"{path_base}/export"
#         var_folder_data_shp = f"{path_base}/shp"
#         var_folder_data_csv = f"{path_base}/csv"
#         var_folder_data_ipon_pt = f"{path_base}/Etiquette"
#         function_execute_class_general_apd(var_schema_name, var_folder_export, var_folder_data_shp, var_folder_data_csv, var_folder_data_ipon_pt, "requete_lfd_apd")



# # {
# baba_dialog = ClassImportExecuteLfdApd(iface)
# baba_dialog.show()
# sys.exit(app.exec_())