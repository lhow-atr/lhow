# -*- coding: utf-8 -*-
import win32com.client
import psycopg2
from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtWidgets import QWidget, QMessageBox, QProgressDialog
from qgis.core import QgsVectorLayer, QgsDataSourceUri, QgsProject, QgsMapLayer, Qgis
from qgis.utils import iface
import xlwt
import xlrd
import json
from osgeo import ogr
import re
import csv
from pathlib import Path
import os.path
import sys

# {folder_plugin = r'C:\Users\babacar.fassa.AMBITION\Documents\GitHub\orange-lfd-rip'
# sys.path.append(folder_plugin)
# from bdd_lfd.params_connexion import *

folder_plugin = str(Path(__file__).parent.parent)
sys.path.append(folder_plugin)
from bdd_lfd.params_connexion import function_connexion, DB, user, MP, host, port


# Class pour les fonctions generales
class GeneralFunctions:
    w = QWidget()

    # Function pour la progession bar1
    @staticmethod
    def progress_bar(name_etape):
        prog = QProgressDialog(
            name_etape + ' : Veillez Patienter', 'Cancel', 0, 100)
        prog.setWindowModality(Qt.WindowModal)
        prog.setMinimumDuration(1)
        return prog

    # Function pour la progession bar2
    @staticmethod
    def progress_processing(index, count_entite, progress_dialog):
        f = int(index + 1)
        pcnt = int(f / count_entite * 100 / 1)
        progress_dialog.setValue(pcnt)

    # Function pour executer une requete sql dans la base
    def function_execute_requete(self, requete_execute, req_fetch, connection):
        curs = connection.cursor()
        try:
            curs.execute(requete_execute)
            if req_fetch:
                data_req = [row for row in curs.fetchall()]
                if data_req:
                    return data_req
        except(Exception, psycopg2.DatabaseError) as error:
            connection.close()
            QMessageBox.warning(self.w, "Message dexecution de requete",
                                'Requete Non Executer : ' + str(error) + ' ; ' + str(requete_execute))
        curs.close()

    # Function pour  Get layer dans la BD
    def function_getlayer_bdd(self, schema, table_name, key, rename_table, column_geom):
        uri = QgsDataSourceUri()
        uri.setConnection(host, port, DB, user, MP)
        uri.setDataSource(schema, table_name, column_geom, '', key)
        layer = QgsVectorLayer(uri.uri(False), rename_table, "postgres")
        if layer.isValid():
            # QgsProject.instance().addMapLayer(layer)
            return layer
        else:
            QMessageBox.warning(
                self.w, "Message", 'Erreur de recuperation de la table : ' + str(table_name))

    # Function Get layer dans Qgis
    @staticmethod
    def function_getlayer_qgis(layer_name):
        layers = [tree_layer.layer() for tree_layer in QgsProject.instance(
        ).layerTreeRoot().findLayers()]  # Pyqgis3
        for layer in layers:
            layertype = layer.type()
            if layertype == QgsMapLayer.VectorLayer:
                if layer.name() == layer_name:
                    return layer

    # Function Get file Sql
    @staticmethod
    def getfilecontentsql(pathandfilename):
        with open(pathandfilename, 'r', encoding="utf-8") as theFile:
            data = theFile.read()
            theFile.close()
            return data

    # Function pour ajouter des feuilles dans EXCEl
    def function_create_sheet(self, wb, sheet_name, list_user_export, header):
        # Execution de la bar
        bar_progress = self.progress_bar('Export des erreurs de Controls')
        ws_workbook = wb.add_sheet(sheet_name, cell_overwrite_ok=True)
        # print('Workbook', ';', ws_workbook)
        if list_user_export:
            for index_liste, k in enumerate(list_user_export):
                for colx, value in enumerate(k):
                    ws_workbook.write(index_liste + 1, colx, str(value))
                self.progress_processing(index_liste, len(
                    list_user_export), bar_progress)
                if bar_progress.wasCanceled():
                    iface.messageBar().pushMessage('Info', 'Action Cancelled', level=Qgis.Info)
                    break
        colidx = 0  # Start from Column 0
        font_style = xlwt.XFStyle()
        font_style.font.bold = True
        for inddata in header:
            col = ws_workbook.col(colidx)
            col.width = 256 * 20
            # Insert in First Row ( Row 0)
            ws_workbook.write(0, colidx, inddata, font_style)
            colidx = colidx + 1

    # Function pour exporter les fichiers de mauavis format
    def function_export_error_fichier(self, var_folder_export_error_fichier, var_name_file, connection, var_schema):
        cursor_db = connection.cursor()
        xlsfile_res = var_folder_export_error_fichier + "/" + var_name_file + ".xls"
        wb = xlwt.Workbook(encoding="UTF-8")
        requete = """select 
                    table_name,
                    'select * from "'||max(table_schema)||'".'||'"'||table_name||'"' as req, 
                    array_agg(column_name::text) entete
                from information_schema.columns
                where table_schema = '""" + str(var_schema).replace('"', '') + """' and 
                (table_name like 'IG%' or table_name like 'OC%' or table_name like 'SI%' or table_name like 'TE%' or 
                    table_name like 'TR%' or table_name like 'IA%' or table_name like 'PD%' or table_name like 'IP%' 
                    or table_name like 'RE%' or table_name like 'GE%' or table_name like 'OP%') and 
                table_name not in ('TRONCON_ROUTE_07-26', 'TRONCON_VOIE_FERREE_07-26')
                group by table_name
                order by table_name
                        """
        res_execute_requete = self.function_execute_requete(
            requete, 'baba', connection)
        try:
            if res_execute_requete:
                for index_export in range(len(res_execute_requete)):
                    value_feature = res_execute_requete[index_export]
                    value_name_table = value_feature[0]
                    value_req_execute = value_feature[1]
                    # {value_entet = value_feature[2]
                    # valeu_export = self.function_execute_requete(value_req_execute, 'baba', connection)
                    cursor_db.execute(value_req_execute)
                    valeu_export_fetchall = cursor_db.fetchall()
                    # list(cursor_db.description)
                    columns = [desc[0] for desc in cursor_db.description]
                    self.function_create_sheet(
                        wb, str(value_name_table), valeu_export_fetchall, columns)
                wb.save(xlsfile_res)
                cursor_db.close()
        except(Exception, psycopg2.DatabaseError) as error:
            connection.close()
            return QMessageBox.warning(self.w, "Message de Traitement", 'Erreur Export des resultats: ' + str(error))


# Class pour importer des csv et shp dans BDD
class ImportMultiplesFilesCsvShp(GeneralFunctions):
    # Function initialisation
    def __init__(self, var_connection, var_schema, var_folder_data):
        self.connection = var_connection
        self.schema = var_schema
        self.folder_data = var_folder_data
        self.files_import = []
        self.list_error_traitement = []
        self.db_cursor = self.connection.cursor()
        # Execution des imports a linitialisation de la classe
        self.function_import_mutiples_files()

    # Function Rename doublons name column
    @staticmethod
    def function_rename_column_name(var_list_column):
        dups = {}
        for i, val in enumerate(var_list_column):
            if val not in dups:
                # Store index of first occurrence and occurrence value
                dups[val] = [i, 1]
            else:
                # Special case for first occurrence
                if dups[val][1] == 1:
                    var_list_column[dups[val][0]] += str(dups[val][1])
                # Increment occurrence value, index value doesn't matter anymore
                dups[val][1] += 1
                # Use stored occurrence value
                var_list_column[i] += str(dups[val][1])
        return var_list_column

    # Function pour Importer des fichiers csv dans une BDD
    def function_insert_csv_bdd(self, var_file):
        try:
            # https://stackoverflow.com/questions/48085319/python-reading-and-writing-csv-files-with-utf-8-encoding
            with open(var_file, encoding="utf-8-sig", errors='ignore') as f:
                reader_file = csv.reader(f, delimiter=';')
                header = next(reader_file)
                file_name = '"' + os.path.basename(var_file).split('.')[0].replace(' ', '_').replace('-', '_').lower() \
                            + '"'
                # Creation de la table
                list_column = ["nan" if key == ''
                               else re.sub(r'\d', 'chiffre', ''.join(e for e in str(key) if e.isalnum()))
                               for key in header]
                # Partie Rename doublons name column
                list_column_rename = self.function_rename_column_name(
                    list_column)

                list_column_text = [
                    str(key) + ' text' for key in list_column_rename]
                req_create_table = f"DROP TABLE IF EXISTS {self.schema}.{file_name} cascade;" \
                                   f"CREATE TABLE {self.schema}.{file_name}({','.join(list_column_text)})"
                self.db_cursor.execute(req_create_table)
                # Insertion des elements dans la table creee
                list_all_feature_insert = []
                for index in reader_file:
                    list_tuple = tuple(index)
                    list_replace_carac = [str(key).replace(
                        "'", '').replace('"', '') for key in list_tuple]
                    values_features = str(tuple(list_replace_carac))
                    list_all_feature_insert.append(values_features)
                if list_all_feature_insert:
                    var_req_insert = f"INSERT INTO {self.schema}.{file_name}({','.join(list_column_rename)})" \
                                     f"values{','.join(list_all_feature_insert)}"
                    self.db_cursor.execute(var_req_insert)
                    self.connection.commit()
                # logging.info(f"Partie Import CSV: Le CSV {var_file} est bien importe dans le schema {self.schema}")
        except Exception as error:
            # self.list_error_traitement.append(['function_insert_csv_bdd', var_file, error])
            exc_type, exc_obj, exc_tb = sys.exc_info()
            self.list_error_traitement.append(['function_insert_csv_bdd', exc_tb.tb_lineno, f"{var_file}___{error}"])

    # Function pour Importer des fichiers shp dans une BDD
    def function_insert_shp_bdd(self, var_shp):
        try:
            file = ogr.Open(var_shp, 0)
            if file is None:
                QMessageBox.information(self.w, "Message-Execution-Plugin",
                                        f"Partie Import SHP: Probleme Import SHP...Le Shape {var_shp} "
                                        f"ne peut pas etre ouvert")
            else:
                shape_feature = file.GetLayer(0)
                var_file_name = '"' + os.path.basename(var_shp).split('.')[0]. \
                    replace(' ', '_').replace('-', '_').lower() + '"'
                dict_convert_type_field = {'String': 'character varying', 'Date': 'text',
                                           'Integer': 'Integer', 'Real': 'real', 'Integer64': 'Integer'}
                # Column_name et type
                list_column = []
                list_column_text = []
                for field in shape_feature.schema:
                    field_name = str(field.name).replace(
                        ' ', '_').replace('-', '_')
                    # field_name = ''.join(e for e in re.sub('\d', '_', str(field.name).replace(' ', '_').
                    #                                        replace('-', '_')) if e.isalnum())
                    field_type_name = str(
                        dict_convert_type_field[field.GetTypeName()])
                    field_width = str(field.GetWidth())
                    if field.GetTypeName() == 'String':
                        field_name_prepare = f"{field_name} {field_type_name}({str(field_width)})"
                    else:
                        field_name_prepare = f"{field_name} {field_type_name}"
                    list_column.append(field_name)
                    list_column_text.append(field_name_prepare)
                # Ajout de la colonne geometry
                list_column.append('geom')
                list_column_text.append('geom geometry')

                # Creation de la table
                req_create_table = f"DROP TABLE IF EXISTS {self.schema}.{var_file_name} cascade;" \
                                   f"CREATE TABLE {self.schema}.{var_file_name}({','.join(list_column_text)})"
                # Execution de la creation de la table
                self.db_cursor.execute(req_create_table)
                # Parcours du shape plus prepapration des donnees a inserer
                list_all_feature_insert = []
                for n in range(shape_feature.GetFeatureCount()):
                    feature_shp = shape_feature.GetFeature(n)
                    feature_json = json.loads(feature_shp.ExportToJson())
                    # geaom_feature = f"ST_GeomFromText('{str(feature_shp.geometry())}')"
                    geaom_feature = f"ST_GeomFromText('{str(feature_shp.geometry())}',2154)"
                    list_values_attributs = list(
                        feature_json['properties'].values())
                    list_appen_geom_feature = [None if field is None else str(field).replace("'", '')
                                               for field in list_values_attributs]
                    list_appen_geom_feature.append(geaom_feature)
                    tuple_appen_geom_feature = str(
                        tuple(list_appen_geom_feature)).replace('"', '')
                    list_all_feature_insert.append(tuple_appen_geom_feature)
                # Insertion des elements dans la table
                if list_all_feature_insert:
                    name_index_geom = var_file_name.replace('"', '')
                    var_req_insert = f"INSERT INTO {self.schema}.{var_file_name}({','.join(list_column)}) " \
                                     f"values{','.join(list_all_feature_insert)}" \
                                     f";CREATE INDEX index_geom_{name_index_geom} ON {self.schema}.{var_file_name} " \
                                     f"USING gist (geom);".replace(
                                         'None', 'NULL')
                    # f"CREATE INDEX rbal_phase2 ON {self.schema}.{var_file_name} USING gist (geom);"
                    self.db_cursor.execute(var_req_insert)
                    self.connection.commit()
                # logging.info(f"Partie Import SHP: Le Shape {var_shp} est bien importe dans le schema {self.schema}")
        except Exception as error:
            # self.list_error_traitement.append(['function_insert_shp_bdd', var_shp, error])
            exc_type, exc_obj, exc_tb = sys.exc_info()
            self.list_error_traitement.append(['function_insert_shp_bdd', exc_tb.tb_lineno, f"{var_shp}___{error}"])

    # Function Execution en masse des Imports des fichiers CSV/SHP dans une BDD
    def function_import_mutiples_files(self):
        try:
            if self.folder_data:
                # Creation du schema import
                self.db_cursor.execute(
                    f"CREATE SCHEMA IF NOT EXISTS {self.schema}")
                folder_iterate = os.listdir(self.folder_data)
                bar_progress = self.progress_bar(
                    'Partie Import en Masse des donnees')
                for index_char_qgis, file_etude in enumerate(folder_iterate):
                    chemin = self.folder_data
                    name, ext = os.path.splitext(file_etude)
                    chem_etude = f"{chemin}/{file_etude}"
                    if ext == ".shp":
                        self.function_insert_shp_bdd(chem_etude)
                        self.files_import.append(file_etude)
                    elif ext == ".csv":
                        self.function_insert_csv_bdd(chem_etude)
                        self.files_import.append(file_etude)
                    elif ext in (".dbf", ".cpg", ".prj", ".shx", ".log", ".sbn", ".sbx", ".qgz", ".qpj", ".qml"):
                        continue
                    else:
                        self.list_error_traitement.append(
                            ['function_import_mutiples_files', f"{name}_{ext}",
                             f"Partie Import chaque table: Le fichier {name}_{ext} ne sera "
                             f"pas importe puisse quil nest pas un csv ni un shape"])
                    self.progress_processing(
                        index_char_qgis, len(folder_iterate), bar_progress)
                    if bar_progress.wasCanceled():
                        iface.messageBar().pushMessage('Info', 'Action Cancelled', level=Qgis.Info)
                        break
                # self.connection.commit()
                self.db_cursor.close()
                # self.connection.close()
                return self.files_import, self.list_error_traitement
            else:
                self.list_error_traitement.append(['function_import_mutiples_files', self.folder_data,
                                                   f"Partie Import en masse: Probleme choix repertoire des donnees..."
                                                   f"{self.folder_data}"])
        except Exception as error:
            # self.list_error_traitement.append(['function_import_mutiples_files', 'function_import_mutiples_files', error])
            exc_type, exc_obj, exc_tb = sys.exc_info()
            self.list_error_traitement.append(['function_import_mutiples_files', exc_tb.tb_lineno, f"function_import_mutiples_files___{error}"])


# Class pour importer des fichiers iponPT
class TraitementFichierIponPt(GeneralFunctions):
    def __init__(self, var_folder_data, var_schema):
        self.folder_data = var_folder_data
        self.name_schema = var_schema
        self.connection = function_connexion()
        self.db_cursor = self.connection.cursor()
        self.dict_all_vals_pt = {}
        self.list_error_traitement = []
        self.function_get_mutiples_files_ipon_pt()
        self.connection.commit()
        self.db_cursor.close()
        self.connection.close()

    # Function pour la lire les fichiers ipon des pt
    def function_get_file_ipon_pt(self, var_fichier):
        try:
            if var_fichier:
                file_name = str(os.path.splitext(os.path.basename(var_fichier))[
                                0]).replace("'", '').replace('"', '')
                workbook = xlrd.open_workbook(var_fichier, on_demand=True)
                worksheet = workbook.sheet_by_index(0)
                first_row = []  # Header
                for col in range(worksheet.ncols):
                    name_column = str(worksheet.cell_value(0, col))
                    first_row.append(name_column)
                for row in range(1, worksheet.nrows):
                    for col in range(worksheet.ncols):
                        values_col = str(worksheet.cell_value(row, col)).replace(
                            "'", '"').replace('.0', '').split("\n")
                        if values_col != ['']:
                            val_key = f"{values_col[0]};{file_name}"
                            if val_key in self.dict_all_vals_pt:
                                self.dict_all_vals_pt[val_key].append(
                                    values_col)
                            else:
                                self.dict_all_vals_pt[val_key] = [values_col]
            else:
                # QMessageBox.warning(iface.mainWindow(), "Message-Execution-Plugin", f'Erreur lecture: {var_fichier}')
                self.list_error_traitement.append(['function_get_file_ipon_pt', var_fichier,
                                                   f'Erreur lecture: {var_fichier}'])
        except Exception as error:
            # self.list_error_traitement.append(['function_get_file_ipon_pt', var_fichier,
            #                                    f"Erreur sur la function_get_file_ipon_pt: {var_fichier}...{error}"])
            exc_type, exc_obj, exc_tb = sys.exc_info()
            self.list_error_traitement.append(['function_get_file_ipon_pt', exc_tb.tb_lineno, f"Erreur sur la function_get_file_ipon_pt: {var_fichier}...{error}"])

    # Function Execution en masse des traitements des fichiers Ipon PT
    def function_get_mutiples_files_ipon_pt(self):
        try:
            if self.folder_data:
                folder_iterate = os.listdir(self.folder_data)
                bar_progress = self.progress_bar(
                    'Partie Traitement en Masse des Fichiers Ipon PT')
                for index_char_qgis, file_etude in enumerate(folder_iterate):
                    chemin = self.folder_data
                    name, ext = os.path.splitext(file_etude)
                    chem_etude = f"{chemin}/{file_etude}"
                    if ext == ".xls":
                        self.function_get_file_ipon_pt(chem_etude)
                    else:
                        self.list_error_traitement.append(
                            ['function_get_mutiples_files_ipon_pt', f"{name}_{ext}",
                             f"Partie Traitement chaque fichier: Le fichier {name}_{ext} ne sera "
                             f"pas traite puisse quil nest pas un xls"])
                    self.progress_processing(
                        index_char_qgis, len(folder_iterate), bar_progress)
                    if bar_progress.wasCanceled():
                        iface.messageBar().pushMessage('Info', 'Action Cancelled', level=Qgis.Info)
                        break
                list_insert_table = []
                for index_key, values in self.dict_all_vals_pt.items():
                    name_split = index_key.split(";")
                    val_insert = str(tuple([name_split[0], name_split[1], ','.join([str(val).replace("'", '')
                                                                                    for val in values]), len(values)]))
                    list_insert_table.append(val_insert)
                text_req_insert = f"""set search_path to {self.name_schema}, public; 
                    drop table if exists table_data_ipon_pt;
                    create table table_data_ipon_pt (nom_pt text, nom_fichier text, data_pt text, nombre_pt int);
                    INSERT INTO table_data_ipon_pt(nom_pt, nom_fichier, data_pt, nombre_pt) 
                    VALUES {','.join(list_insert_table)};"""
                self.db_cursor.execute(text_req_insert)
            else:
                self.list_error_traitement.append(['function_get_mutiples_files_ipon_pt', self.folder_data,
                                                   f"Partie Traitement en masse: Probleme choix repertoire des "
                                                   f"donnees...{self.folder_data}"])
        except Exception as error:
            # self.list_error_traitement.append(['function_get_mutiples_files_ipon_pt',
            #                                    'function_get_mutiples_files_ipon_pt', error])
            exc_type, exc_obj, exc_tb = sys.exc_info()
            self.list_error_traitement.append(['function_get_mutiples_files_ipon_pt', exc_tb.tb_lineno, f"{error}"])


# Class pour lexecution des functions SQL
class ExecuteFileSQL(GeneralFunctions):
    # Constructeur des variables qui change
    def __init__(self, var_connection, var_schema, varFileSql):
        global folder_plugin
        self.list_error_traitement = []
        self.connection = var_connection
        self.db_cursor = self.connection.cursor()
        self.name_schema = var_schema
        # var_file_sql_lfd
        self.pathAndFileName = f"{folder_plugin}/file_sql/{varFileSql}.sql"
        self.name_schema_in_requete_lfd_sql = 'var_lfd'
        self.functionExecuteSql()

    # Function pour executer un file SQL
    def functionExecuteSql(self):
        try:
            if self.pathAndFileName:  # [0]
                text_sql_file = self.getfilecontentsql(
                    self.pathAndFileName)  # [0]
                requete_execute_file_sql = str(text_sql_file).replace(self.name_schema_in_requete_lfd_sql, self.name_schema)
                self.db_cursor.execute(requete_execute_file_sql)
                self.connection.commit()
                self.db_cursor.close()
        except Exception as error:
            # self.list_error_traitement.append(['function_execute_sql', 'function_execute_sql', error])
            exc_type, exc_obj, exc_tb = sys.exc_info()
            self.list_error_traitement.append(['functionExecuteSql', exc_tb.tb_lineno, error])
            return self.list_error_traitement


# Class General des functions
class GeneralFunctions:
    # Constructeur des variables qui change

    # Declaration de la variable pour les messages derreur
    w = QWidget()

    # Function pour la progession bar1
    def functionProgressBar(self, name_etape):
        prog = QProgressDialog(
            name_etape + ' : Veillez Patienter', 'Cancel', 0, 100)
        prog.setWindowModality(Qt.WindowModal)
        prog.setMinimumDuration(1)
        return prog

    # Function pour la progession bar2
    def functionProgressProcessing(self, index, count_entite, progress_dialog):
        f = int(index + 1)
        pcnt = int(f / count_entite * 100 / 1)
        progress_dialog.setValue(pcnt)


class ExportResExcelFeuille(GeneralFunctions):
    def __init__(self, varPathCsvSave):
        self.worbook = xlwt.Workbook(encoding="UTF-8")
        self.varNameFileExport = varPathCsvSave + "/" + \
            'file_resultat_fibre_longueur' + ".xls"

    # Function pour ajouter des feuilles dans EXCEl

    def functionCreateSheet(self, sheet_name, list_user_export, Header):
        # Execution de la bar
        bar_progress = self.functionProgressBar('Export des resultats')
        ws_workbook = self.worbook.add_sheet(
            sheet_name, cell_overwrite_ok=True)
        if list_user_export:
            if len(list_user_export) > 65535:
                QMessageBox.information(QWidget(), "Message dexport du resultat", 'Le sheet ' + sheet_name +
                                        ' a des valeurs superieurs a ' + '65535, donc on importe une impartie des resultats dans la base')
            for index_liste, k in enumerate(list_user_export[:65535]):
                for colx, value in enumerate(k):
                    ws_workbook.write(index_liste + 1, colx, str(value))
                    self.functionProgressProcessing(
                        index_liste, len(list_user_export), bar_progress)
                    if bar_progress.wasCanceled():
                        iface.messageBar().pushMessage('Info', 'Action Cancelled', level=Qgis.Info)
                        break

        colIdx = 0  # Start from Column 0
        font_style = xlwt.XFStyle()
        font_style.font.bold = True
        for indData in Header:
            col = ws_workbook.col(colIdx)
            col.width = 256 * 20
            # Insert in First Row ( Row 0)
            ws_workbook.write(0, colIdx, str(indData), font_style)
            colIdx = colIdx + 1

    def functionExportRes(self, varSheetName, varHeader, varListValueSave):
        self.functionCreateSheet(varSheetName, varListValueSave, varHeader)
        self.worbook.save(self.varNameFileExport)


# Class pour extraire les informations des fibres
class ExtractFibreFile(ExportResExcelFeuille):
    def __init__(self, var_folder_data, var_folder_export):
        super().__init__(var_folder_export)

        self.var_list_all_erreur_traitement = []
        self.varListGlobalResultat = []
        self.varListNombreFichierSorResultat = []

        self.w = QWidget()
        self.error_open = 'Error_Open_'
        self.extension_file_sor = '.sor'
        self.extension_file_xls = '.xls'
        self.folder_data = var_folder_data
        self.function_get_all_info_file()
        self.entete_num_fib = ['Namefile', 'NameEntete'] + \
            [f"FibreNumero_{x+1}" for x in range(144)]
        self.entete_fichier_sor = ['NomDuFichier', 'NombreFichierSor']
        self.functionExportRes(
            'nombre_fichier_sor', self.entete_fichier_sor, self.varListNombreFichierSorResultat)
        self.functionExportRes(
            'nombre_fibre', self.entete_num_fib, self.varListGlobalResultat)
        # QMessageBox.information(
        #     self.w, "Message Execution Plugin", f"{self.var_list_all_erreur_traitement}")

    # function creation des dictionnaires
    @staticmethod
    def function_create_dict(var_dict, var_val_key, var_val_value):
        if var_val_key not in var_dict:
            var_dict[var_val_key] = [var_val_value]
        else:
            var_dict[var_val_key].append(var_val_value)

    # function creation des dictionnaires pour les colonnes en fonction des noms
    @staticmethod
    def functionGetValuesCol(varWorkSheet, varNumberRow, varNumberCol, varNameColumn, varDict, varKeyDict, varValuesDict):
        if varWorkSheet.Cells(varNumberRow, varNumberCol).Value == varNameColumn:
            if str(varKeyDict) not in varDict:
                varDict[str(varKeyDict)] = [varValuesDict]
            else:
                varDict[str(varKeyDict)].append(varValuesDict)

    # Function pour lire et recuperer les informations des fichiers excel proteges
    def functionReadFileExcelProtected(self, varFile, varListGlobal, varObjetExcel):
        try:
            # create excel object
            # excel = win32com.client.Dispatch('Excel.Application')
            # excel can be visible or not
            # self.objetExcel.Visible = False  # False

            # {varObjetExcel = win32com.client.Dispatch('Excel.Application')  # create excel object
            # varObjetExcel.Visible = False  # False

            file_name = os.path.basename(varFile)
            workbook = varObjetExcel.Workbooks.Open(varFile)
            # get worksheet names
            sheet_names = [sheet.Name for sheet in workbook.Sheets]
            # workbook.Worksheets("Données")
            worksheet = workbook.Worksheets(sheet_names[0])
            var_min_row = 32

            var_tete = worksheet.Range("C" + str(8)).Value
            var_tete_value = worksheet.Range("D" + str(8)).Value
            var_ref_pb = worksheet.Range("C" + str(7)).Value
            var_ref_pb_value = worksheet.Range("D" + str(7)).Value

            # {lastCol = worksheet.UsedRange.Columns.Count
            # used = worksheet.UsedRange
            # nrows = used.Row + used.Rows.Count - 1
            # ncols = used.Column + used.Columns.Count - 1
            # lastrow = worksheet.Cells(worksheet.Rows.Count, "C").End(var_max_row).Row + 1
            lastrow = worksheet.UsedRange.Rows.Count

            var_dict_val_col_longueur = {}
            var_dict_val_col_numero_fibre = {}
            var_dict_val_col_concat_long_fib = {}
            used = worksheet.UsedRange
            col_count = used.Column + used.Columns.Count - 1

            # Partie pour les indexes de colonnes qui changent afin de recuperer les nbre de fibre et leur longueur
            for c in range(1, col_count):
                var_value_long = False
                for i in range(var_min_row, lastrow):
                    var_value_cell = worksheet.Cells(i, c).Value
                    self.functionGetValuesCol(
                        worksheet, 32, c, 'Long.(m)', var_dict_val_col_longueur, 'longueur', [i, var_value_cell])
                    self.functionGetValuesCol(
                        worksheet, 31, c, 'Numéro fibre', var_dict_val_col_numero_fibre, 'numero_fibre', [i, var_value_cell])
            for index, values in var_dict_val_col_longueur.items():
                for indexfib, values_fib in var_dict_val_col_numero_fibre.items():
                    for val_long in values:
                        for val_fib in values_fib:
                            if val_long[0] == val_fib[0]:
                                if str(val_fib[1]).replace('.0', '') not in var_dict_val_col_concat_long_fib:
                                    var_dict_val_col_concat_long_fib[str(val_fib[1]).replace('.0', '')] = [
                                        val_long[1]]
                                else:
                                    var_dict_val_col_concat_long_fib[str(
                                        val_fib[1]).replace('.0', '')].append(val_long[1])

            # Partie pour la creation de la liste en fonction du nombre de fibre compris ente 1 a 144
            varListColumn = [x+1 for x in range(144)]
            for indexConcate, valuesConcate in var_dict_val_col_concat_long_fib.items():
                varRes = False
                for indexColumn in range(len(varListColumn)):
                    valIndexHeader = varListColumn[indexColumn]
                    if str(valIndexHeader) == str(indexConcate):
                        varRes = True
                        varListColumn[
                            indexColumn] = f"{var_tete}:{var_tete_value};{valIndexHeader};{var_ref_pb_value};{max(valuesConcate)}"

            # {varListGlobal.append([varFile, f"{var_tete}:{var_tete_value}", varListColumn])
            # varListGlobal.append(varListColumn)
            varListColumn.insert(0, f"{var_tete}:{var_tete_value}")
            varListColumn.insert(0, varFile)
            varListGlobal.append(varListColumn)

            workbook.Close(True)
            # objetExcel.Quit()
        except Exception as error:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            self.var_list_all_erreur_traitement.append(
                ['functionReadFileExcelProtected', exc_tb.tb_lineno, f"{error};{varFile}"])

    def function_get_all_info_file(self):
        try:
            bar_progress = self.functionProgressBar(
                'Extraction des elements dans les fichiers Excel')
            iterate_folder = os.listdir(self.folder_data)
            # {var_dict_count_nbre_file_sor_folder = {}
            vr_list_all_chemin_file_xls = []
            for index_folder, file_etude in enumerate(iterate_folder):
                chemin_folder = f"{self.folder_data}/{file_etude}"
                # Parcours des sous dossiers
                isDirectory = os.path.isdir(chemin_folder)
                if isDirectory:
                    iterate_sub_folder = os.listdir(chemin_folder)
                    count_file_sor = 0
                    for index_subfolder, file_subfolder in enumerate(iterate_sub_folder):
                        name, ext = os.path.splitext(file_subfolder)
                        if str(ext).lower() == str(self.extension_file_sor).lower():
                            count_file_sor += 1
                        if str(ext).lower() == str(self.extension_file_xls).lower():
                            chemin_file_xls = f"{chemin_folder}/{file_subfolder}"
                            vr_list_all_chemin_file_xls.append(chemin_file_xls)
                    self.varListNombreFichierSorResultat.append(
                        [file_etude, count_file_sor])
                self.functionProgressProcessing(
                    index_folder, len(iterate_folder), bar_progress)
                if bar_progress.wasCanceled():
                    iface.messageBar().pushMessage('Info', 'Action Cancelled', level=Qgis.Info)
                    break

            varObjetExcel = win32com.client.Dispatch('Excel.Application')  # create excel object
            varObjetExcel.Visible = False  # False
            for index_chem_file_xls in range(len(vr_list_all_chemin_file_xls)):
                var_chem_file_xls = vr_list_all_chemin_file_xls[index_chem_file_xls]
                file_name = os.path.basename(var_chem_file_xls)
                self.functionReadFileExcelProtected(
                    var_chem_file_xls, self.varListGlobalResultat, varObjetExcel)
                self.functionProgressProcessing(index_chem_file_xls, len(
                    vr_list_all_chemin_file_xls), bar_progress)
                if bar_progress.wasCanceled():
                    iface.messageBar().pushMessage('Info', 'Action Cancelled', level=Qgis.Info)
                    break
            varObjetExcel.Quit()

        except Exception as error:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            self.var_list_all_erreur_traitement.append(
                ['function_get_all_info_file', exc_tb.tb_lineno, error])
            # print(self.var_list_all_erreur_traitement)


def function_execute_class_general_deo(var_schema_name, var_folder_export,
                                       var_folder_data_shp, var_folder_data_csv, var_folder_data_ipon_pt, 
                                       var_folder_data_msr, varFileSql):
    w = QWidget()
    connection = function_connexion()
    # Importation des donnees dans la BDD
    list_error = []
    try:
        # Partie Importation des donnees
        res_import_csv = ImportMultiplesFilesCsvShp(
            connection, var_schema_name, var_folder_data_csv)
        res_import_shp = ImportMultiplesFilesCsvShp(
            connection, var_schema_name, var_folder_data_shp)
        list_error = res_import_csv.list_error_traitement
        list_error = res_import_shp.list_error_traitement
        if not res_import_csv.list_error_traitement and not res_import_shp.list_error_traitement:
            res_traitement_pt_ipon = TraitementFichierIponPt(var_folder_data_ipon_pt, var_schema_name)
            if len(res_traitement_pt_ipon.list_error_traitement) == 0:
                # Partie Execution fichier SQL
                var_execute_file_sql = ExecuteFileSQL(connection, var_schema_name, varFileSql)
                list_error = var_execute_file_sql.list_error_traitement
                if not var_execute_file_sql.list_error_traitement:
                    res_traitement_msr = ExtractFibreFile(var_folder_data_msr, var_folder_export)
                    if not res_traitement_msr.var_list_all_erreur_traitement:
                        var_execute_file_sql.function_export_error_fichier(var_folder_export, 'export_res', connection, var_schema_name)
                    else:
                        connection.close()
                        # Error module 'win32com.gen_py.00020813-0000-0000-C000-000000000046x0x1x8' has no attribute 'CLSIDToPackageMap'
                        # Correction A solution is to locate the gen_py folder (C:\Users\\AppData\Local\Temp\gen_py) and delete its content. It works for me when using the COM with another program.
                        return QMessageBox.warning(w, "Message dexecution de requete",
                                                    f"Erreur Execution Dossier MSR: {str(res_traitement_msr.var_list_all_erreur_traitement)}")
                else:
                    connection.close()
                    return QMessageBox.warning(w, "Message dexecution de requete",
                                                f"Erreur Execution File SQL: {str(var_execute_file_sql.list_error_traitement)}")
            else:
                connection.close()
                return QMessageBox.warning(w, "Message de Traitement",
                                            f"Erreur Erreur Creation table Ipon PT: \n"
                                            f"{str(res_traitement_pt_ipon.list_error_traitement)}")
            connection.close()
            # Fin traitement
            return QMessageBox.information(w, "Message dexecution de requete",
                                           'Création des résultats LFD RIP réalisée avec succès')
        else:
            connection.close()
            return QMessageBox.warning(w, "Message dexecution de requete",
                                       f"Erreur sur les CSV: {str(res_import_csv.list_error_traitement)} \n"
                                       f"Erreur sur les CSV: {str(res_import_shp.list_error_traitement)} ")
    except Exception as error:
        connection.close()
        exc_type, exc_obj, exc_tb = sys.exc_info()
        return QMessageBox.critical(w, "Message de Traitement", 'function_execute_class_general_deo' + '\n' + str(exc_tb.tb_lineno) +
                                   '\n' + str(error))

def function_execute_class_general_aps(var_schema_name, var_folder_export, var_folder_data_shp, var_folder_data_csv, varFileSql):
    w = QWidget()
    connection = function_connexion()
    # Importation des donnees dans la BDD
    list_error = []
    try:
        # Partie Importation des donnees
        res_import_csv = ImportMultiplesFilesCsvShp(
            connection, var_schema_name, var_folder_data_csv)
        res_import_shp = ImportMultiplesFilesCsvShp(
            connection, var_schema_name, var_folder_data_shp)
        list_error = res_import_csv.list_error_traitement
        list_error = res_import_shp.list_error_traitement
        if not res_import_csv.list_error_traitement and not res_import_shp.list_error_traitement:
            # Partie Execution fichier SQL
            var_execute_file_sql = ExecuteFileSQL(connection, var_schema_name, varFileSql)
            list_error = var_execute_file_sql.list_error_traitement
            if not var_execute_file_sql.list_error_traitement:
                var_execute_file_sql.function_export_error_fichier(var_folder_export, 'export_res', connection, var_schema_name)
            else:
                connection.close()
                return QMessageBox.warning(w, "Message dexecution de requete",
                                            f"Erreur Execution File SQL: {str(var_execute_file_sql.list_error_traitement)}")
            connection.close()
            # Fin traitement
            return QMessageBox.information(w, "Message dexecution de requete",
                                           'Création des résultats LFD RIP réalisée avec succès')
        else:
            connection.close()
            return QMessageBox.warning(w, "Message dexecution de requete",
                                       f"Erreur sur les CSV: {str(res_import_csv.list_error_traitement)} \n"
                                       f"Erreur sur les CSV: {str(res_import_shp.list_error_traitement)} ")
    except Exception as error:
        connection.close()
        exc_type, exc_obj, exc_tb = sys.exc_info()
        return QMessageBox.critical(w, "Message de Traitement", 'function_execute_class_general_var' + '\n' + str(exc_tb.tb_lineno) +
                                   '\n' + str(error))

def function_execute_class_general_apd(var_schema_name, var_folder_export,
                                       var_folder_data_shp, var_folder_data_csv, var_folder_data_ipon_pt, varFileSql):
    w = QWidget()
    connection = function_connexion()
    # Importation des donnees dans la BDD
    list_error = []
    try:
        # Partie Importation des donnees
        res_import_csv = ImportMultiplesFilesCsvShp(
            connection, var_schema_name, var_folder_data_csv)
        res_import_shp = ImportMultiplesFilesCsvShp(
            connection, var_schema_name, var_folder_data_shp)
        list_error = res_import_csv.list_error_traitement
        list_error = res_import_shp.list_error_traitement
        if not res_import_csv.list_error_traitement and not res_import_shp.list_error_traitement:
            res_traitement_pt_ipon = TraitementFichierIponPt(var_folder_data_ipon_pt, var_schema_name)
            if len(res_traitement_pt_ipon.list_error_traitement) == 0:
                # Partie Execution fichier SQL
                var_execute_file_sql = ExecuteFileSQL(connection, var_schema_name, varFileSql)
                list_error = var_execute_file_sql.list_error_traitement
                if not var_execute_file_sql.list_error_traitement:
                    var_execute_file_sql.function_export_error_fichier(var_folder_export, 'export_res', connection, var_schema_name)
                else:
                    connection.close()
                    return QMessageBox.warning(w, "Message dexecution de requete",
                                                f"Erreur Execution File SQL: {str(var_execute_file_sql.list_error_traitement)}")
            else:
                connection.close()
                return QMessageBox.warning(w, "Message de Traitement",
                                            f"Erreur Erreur Creation table Ipon PT: \n"
                                            f"{str(res_traitement_pt_ipon.list_error_traitement)}")
            connection.close()
            # Fin traitement
            return QMessageBox.information(w, "Message dexecution de requete",
                                           'Création des résultats LFD RIP réalisée avec succès')
        else:
            connection.close()
            return QMessageBox.warning(w, "Message dexecution de requete",
                                       f"Erreur sur les CSV: {str(res_import_csv.list_error_traitement)} \n"
                                       f"Erreur sur les CSV: {str(res_import_shp.list_error_traitement)} ")
    except Exception as error:
        connection.close()
        exc_type, exc_obj, exc_tb = sys.exc_info()
        return QMessageBox.critical(w, "Message de Traitement", 'function_execute_class_general_var' + '\n' + str(exc_tb.tb_lineno) +
                                   '\n' + str(error))

# {var_schema_name = '"schema_test_baba"'
# path_base = r'C:\Users\babacar.fassa.AMBITION\Desktop\LFD\BDD\folder_import_test'
# var_folder_export = f"{path_base}/export"
# var_folder_data_shp = f"{path_base}/shp"
# var_folder_data_csv = f"{path_base}/csv"
# var_folder_data_svg = f"{path_base}/SVG"
# var_folder_data_rbal = f"{path_base}/rbal"
# var_folder_data_ipon_pt = f"{path_base}/Etiquette"
# var_folder_data_msr = f"{path_base}/MSR"

# function_execute_class_general_var(var_schema_name, var_folder_export, var_folder_data_shp, var_folder_data_csv,
#                                    var_folder_data_ipon_pt)


# ExtractFibreFile(var_folder_data_msr)
