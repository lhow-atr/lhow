from qgis.PyQt.QtWidgets import QMessageBox, QWidget
from .class_file_global_menu import var_class_init_custom_menu_bar, ambition_menu
from .vidange_cache_qgis import function_delete_cache_qgis
from .forms.dialog_lfd_aps import ClassImportExecuteLfdAps
from .forms.dialog_lfd_apd import ClassImportExecuteLfdApd
from .forms.dialog_lfd_deo import ClassImportExecuteLfdDeo


class ClassGeneraleMenu:
    def __init__(self, iface):
        self.iface = iface
        self.name_menu_projet = var_class_init_custom_menu_bar.funct_add_submenu_projet_to_global(ambition_menu, 'LFD')
        self.name_group_athd = "C.3. RIP_Orne"

    def initGui(self):
        # ATHD Submenu
        res_vidange = function_delete_cache_qgis()
        if res_vidange[1] is False:
            QMessageBox.warning(QWidget(), "Message dexecution de requete", 'Le cache nest pas vide ... ' + str(res_vidange))
        self.atfd_sub_menu = var_class_init_custom_menu_bar.func_add_submenu_group_to_projet(self.name_menu_projet, self.name_group_athd)
        var_class_init_custom_menu_bar.func_add_action_menu(self.atfd_sub_menu, "C.3.1. Traitement LFD APS", self.exe_class_import_execute_lfd_aps)
        var_class_init_custom_menu_bar.func_add_action_menu(self.atfd_sub_menu, "C.3.2. Traitement LFD APD", self.exe_class_import_execute_lfd_apd)
        var_class_init_custom_menu_bar.func_add_action_menu(self.atfd_sub_menu, "C.3.3. Traitement LFD DEO", self.exe_class_import_execute_lfd_deo)

    def unload(self):
        self.iface.removePluginMenu(self.name_group_athd, self.atfd_sub_menu.menuAction())

    # Couche LFD Integration APS
    def exe_class_import_execute_lfd_aps(self):
        self.exeaps = ClassImportExecuteLfdAps(self.iface)
        self.exeaps.exec_()
    
    # Couche LFD Integration APD
    def exe_class_import_execute_lfd_apd(self):
        self.exeapd = ClassImportExecuteLfdApd(self.iface)
        self.exeapd.exec_()
    
    # Couche LFD Integration DEO
    def exe_class_import_execute_lfd_deo(self):
        self.exedeo = ClassImportExecuteLfdDeo(self.iface)
        self.exedeo.exec_()
