# **Plugin de Contrôle des données sur le projet LFD OTHD**
Ce Plugin est composé de trois parties, Traitement LFD APD, Traitement LFD APS, Traitement LFD DEO. Le Contrôle de données se fait par un lancement d'une serie de traitements qui seront décrits ci-dessous. Pour avoir plus de détails sur les Contrôles, reportez vous sur le [Fichier Spec des Contrôles](./assets/docs_spec/Details_Requetes_LFD_OTHD_APS_APD_DOE.xlsx).
## ***Traitement LFD APD***
- ### ***Import des données :***
    - #### ***Objectif :***
    Ce module permet de lancer les traitements LFD des données importées en base de données, et d’exporter les résultats sous forme d’un fichier Excel (un  onglet par requête). La base de données est celle configurée dans le projet : lfd_bdd.
    - #### ***Données d’entrée :***
        [Exemple données d'entrée](./assets/docs_spec/donnees_sources.zip)
        - ##### CSV (liste des CSV attendus):
            - ###### export_cable_ipon_commune.csv 
            - ###### ipon.csv 
            - ###### pointage_etude.csv 
            - ###### positionnement_etude.csv 
        - ##### Shapefiles (liste des Shapefiles attendus):
            - ###### contour_pa.shp 
            - ###### ftth_cable.shp 
            - ###### ftth_pf.shp 
            - ###### ftth_site_immeuble.shp 
            - ###### ftth_zone_eligibilite.shp 
        - ##### Xls (liste des xls de fichier PT Ipon attendus):
            - ###### Etiquette_FI-83119-000K.xls
    - #### ***Variables demandés :***
        - ###### Code Code PA Reg
        - ###### Code NRO de rattachement: COMMUNE
        - ###### Choix de la date: via le calendrier
        - ###### Choix dossier des Shapefiles
        - ###### Choix dossier des CSV
        - ###### Choix dossier des etiquettes
        - ###### Choix dossier de l’export des résultat
    - #### ***Résultats :***
        Les données sont intégrées en base de données dans un schéma dédié (gestion des versions), les résultats du traitement sont enregistrés dans la base de données et exportées au format Excel (avec un onglet pour chaque résultat de requête)
    - #### ***Contraintes :***
        Toutes les données d'entrée doivent etre conformes et toutes les variables doivent etre renseignées
    - #### ***Mode opératoire :***
        ![Erreur Image](assets/app_apd_import.png)
- ### ***Contrôle des données***
    - #### ***Objectif :***
        Il est de réaliser vingt-trois contrôles qui sont :
        - ###### Contrôle SIG01.1; Description: recuperation des données du PF PA
        - ###### Contrôle SIG01.2; Description: verifier que toute les ZE ont un PF
        - ###### Contrôle SIG01.3; Description: faire la liste des IMB par ZE
        - ###### Contrôle SIG01.4; Description: retrouver tout les PF PB du PA
        - ###### Contrôle SIG01.5; Description: Un seul PB par chambre et par appui ORANGE 
        - ###### Contrôle SII01.1; Description: recuperation de la liste des PT
        - ###### Contrôle SII02.1; Description: comptage du nombre de fibre dispo par PB
        - ###### Contrôle PDG03.1; Description: verification des sites immeubles GFI et des sites relevés lors de l'étude
        - ###### Contrôle PDG03.2; Description: verifications de la couverture des IMB
        - ###### Contrôle PDG03.3; Description: verifications de la couverture des IMB
        - ###### Contrôle PDG03.4; Description: verification des sites support des PB
        - ###### Contrôle PDG03.5; Description: verifier la correspondance des infos entre les onglets
        - ###### Contrôle GEO102.1; Description: Vérifier le statut des PF type PB ( a minima statut En Cours)
        - ###### Contrôle GEO105.1; Description: verif des cables present
        - ###### Contrôle GEO105.2; Description: verif des cables present
        - ###### Contrôle GEO106.1; Description: verifier les racco long
        - ###### Contrôle IPO202.1; Description: verification de la descriptions des PT PB
        - ###### Contrôle IPO202.4; Description: verification entre le sites support GFI et le site support IPON
        - ###### Contrôle IPO208.1; Description: verification des informations immeubles
        - ###### Contrôle IPO208.2; Description: verification des informations immeubles
        - ###### Contrôle IPO206.1; Description: sites immeubles a ajouter/retirer des ZE PF PB IPON part1
        - ###### Contrôle IPO206.2; Description: sites immeubles a ajouter/retirer des ZE PF PB IPON part2
        - ###### Contrôle REF301.1; Description: liste des codes IMB
    - #### ***Résultats :***
        Les résultats du traitement sont enregistrés dans la base de données et exportées au format Excel (avec un onglet pour chaque résultat de requête)  
        ![Erreur Image](assets/ctrl_result.png)  
        [Exemple de resultat exportés](./assets/docs_spec/export_res.xls)
    - #### ***Contraintes :***
        Toutes les données d'entrée doivent etre conformes et toutes les variables doivent etre renseignées
## ***Traitement LFD APS***
- ### ***Import des données :***
    - #### ***Objectif :***
    Ce module permet de lancer les traitements LFD des données importées en base de données, et d’exporter les résultats sous forme d’un fichier Excel (un  onglet par requête). La base de données est celle configurée dans le projet : lfd_bdd.
    - #### ***Données d’entrée :***
        [Exemple données d'entrée](./assets/docs_spec/donnees_sources.zip)
        - ##### CSV (liste des CSV attendus):
            - ###### pointage_etude.csv
            - ###### positionnement_etude.csv
        - ##### Shapefiles (liste des Shapefiles attendus):
            - ###### ftth_cable.shp
            - ###### ftth_pf.shp
            - ###### ftth_site_immeuble.shp
            - ###### ftth_zone_eligibilite.shp
    - #### ***Variables demandés :***
        - ###### Code Code PA Reg
        - ###### Code NRO de rattachement: COMMUNE
        - ###### Choix de la date: via le calendrier
        - ###### Choix dossier des Shapefiles
        - ###### Choix dossier des CSV
        - ###### Choix dossier de l’export des résultat
    - #### ***Résultats :***
        Les données sont intégrées en base de données dans un schéma dédié (gestion des versions), les résultats du traitement sont enregistrés dans la base de données et exportées au format Excel (avec un onglet pour chaque résultat de requête)
    - #### ***Contraintes :***
        Toutes les données d'entrée doivent etre conformes et toutes les variables doivent etre renseignées
    - #### ***Mode opératoire :***
        ![Erreur Image](assets/app_aps_import.png)
- ### ***Contrôle des données***
    - #### ***Objectif :***
        Il est de réaliser douze contrôles qui sont :
        - ###### Contrôle SIG01.1; Description: recuperation des données du PF PA
        - ###### Contrôle SIG01.2; Description: verifier que toute les ZE ont un PF
        - ###### Contrôle SIG01.3; Description: faire la liste des IMB par ZE
        - ###### Contrôle SIG01.4; Description: retrouver tout les PF PB du PA
        - ###### Contrôle PDG03.1; Description: verification des sites immeubles GFI et des sites relevés lors de l'étude
        - ###### Contrôle PDG03.2; Description: verifications de la couverture des IMB
        - ###### Contrôle PDG03.3; Description: verifications de la couverture des IMB
        - ###### Contrôle PDG03.4; Description: verification des sites support des PB
        - ###### Contrôle PDG03.5; Description: verifier la correspondance des infos entre les onglets
        - ###### Contrôle GEO102.1; Description: Vérifier le statut des PF type PB ( a minima statut En Cours)
        - ###### Contrôle GEO105.1; Description: verif des cables present
        - ###### Contrôle GEO106.1; Description: verifier les racco long
    - #### ***Résultats :***
        Les résultats du traitement sont enregistrés dans la base de données et exportées au format Excel (avec un onglet pour chaque résultat de requête)  
        ![Erreur Image](assets/ctrl_result.png)  
        [Exemple de resultat exportés](./assets/docs_spec/export_res.xls)
    - #### ***Contraintes :***
        Toutes les données d'entrée doivent etre conformes et toutes les variables doivent etre renseignées
## ***Traitement LFD DEO***
- ### ***Import des données :***
    - #### ***Objectif :***
    Ce module permet de lancer les traitements LFD des données importées en base de données, et d’exporter les résultats sous forme d’un fichier Excel (un  onglet par requête). La base de données est celle configurée dans le projet : lfd_bdd.
    - #### ***Données d’entrée :***
        [Exemple données d'entrée](./assets/docs_spec/donnees_sources.zip)
        - ##### CSV (liste des CSV attendus):
            - ###### export_cable_ipon_commune.csv
            - ###### ipon.csv
            - ###### Optimum.csv
            - ###### pointage_etude.csv
            - ###### positionnement_etude.csv
        - ##### Shapefiles (liste des Shapefiles attendus):
            - ###### ftth_cable.shp
            - ###### ftth_pf.shp
            - ###### ftth_site_immeuble.shp
            - ###### ftth_zone_eligibilite.shp
        - ##### Xls (liste des xls de fichier PT Ipon attendus):
            - ###### Etiquette_FI-83119-000K.xls
        - ##### Mesures (liste des svg attendus):
            - ###### fichier .sor
            - ###### fichier .xls 
    - #### ***Variables demandés :***
        - ###### Code Code PA Reg
        - ###### Code NRO de rattachement: COMMUNE
        - ###### Choix de la date: via le calendrier
        - ###### Choix dossier des Shapefiles
        - ###### Choix dossier des CSV
        - ###### Choix dossier des etiquettes
        - ###### Choix dossier des mesures
        - ###### Choix dossier de l’export des résultat
    - #### ***Résultats :***
        Les données sont intégrées en base de données dans un schéma dédié (gestion des versions), les résultats du traitement sont enregistrés dans la base de données et exportées au format Excel (avec un onglet pour chaque résultat de requête)
    - #### ***Contraintes :***
        Toutes les données d'entrée doivent etre conformes et toutes les variables doivent etre renseignées
    - #### ***Mode opératoire :***
        ![Erreur Image](assets/app_deo_import.png)
- ### ***Contrôle des données***
    - #### ***Objectif :***
        Il est de réaliser vingt-cinq contrôles qui sont :
        - ###### Contrôle SIG01.1; Description: recuperation des données du PF PA
        - ###### Contrôle SIG01.2; Description: verifier que toute les ZE ont un PF
        - ###### Contrôle SIG01.3; Description: faire la liste des IMB par ZE
        - ###### Contrôle SIG01.4; Description: retrouver tout les PF PB du PA
        - ###### Contrôle SIG01.5; Description: Un seul PB par chambre et par appui ORANGE 
        - ###### Contrôle SII01.1; Description: recuperation de la liste des PT
        - ###### Contrôle SII02.1; Description: comptage du nombre de fibre dispo par PB
        - ###### Contrôle PDG03.1; Description: verification des sites immeubles GFI et des sites relevés lors de l'étude
        - ###### Contrôle PDG03.2; Description: verifications de la couverture des IMB
        - ###### Contrôle PDG03.3; Description: verifications de la couverture des IMB
        - ###### Contrôle PDG03.4; Description: verification des sites support des PB
        - ###### Contrôle PDG03.5; Description: verifier la correspondance des infos entre les onglets
        - ###### Contrôle GEO102.1; Description: Vérifier le statut des PF type PB ( a minima statut En Cours)
        - ###### Contrôle GEO105.1; Description: verif des cables present
        - ###### Contrôle GEO105.2; Description: verif des cables present
        - ###### Contrôle GEO106.1; Description: verifier les racco long
        - ###### Contrôle IPO202.1; Description: verification de la descriptions des PT PB
        - ###### Contrôle IPO202.4; Description: verification entre le sites support GFI et le site support IPON
        - ###### Contrôle IPO208.1; Description: verification des informations immeubles
        - ###### Contrôle IPO208.2; Description: verification des informations immeubles
        - ###### Contrôle IPO206.1; Description: sites immeubles a ajouter/retirer des ZE PF PB IPON part1
        - ###### Contrôle IPO206.2; Description: sites immeubles a ajouter/retirer des ZE PF PB IPON part2
        - ###### Contrôle IPO211.1; Description: verification de la descriptions des PT PB
        - ###### Contrôle REF301.1; Description: liste des codes IMB
        - ###### Contrôle OPT301.1; Description: tirer la liste simplifié des IMB
    - #### ***Résultats :***
        Les résultats du traitement sont enregistrés dans la base de données et exportées au format Excel (avec un onglet pour chaque résultat de requête). Deux fichiers de sortie: export_res.xls et file_resultat_fibre_longueur.xls  
        ![Erreur Image](assets/ctrl_result.png)  
        [Exemple de resultat exportés](./assets/docs_spec/export_res.xls)
        [Exemple de resultat exportés](./assets/docs_spec/file_resultat_fibre_longueur.xls)
    - #### ***Contraintes :***
        Toutes les données d'entrée doivent etre conformes et toutes les variables doivent etre renseignées