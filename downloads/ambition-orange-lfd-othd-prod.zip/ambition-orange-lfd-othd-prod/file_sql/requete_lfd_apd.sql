SET search_path TO var_lfd, public;
GRANT ALL ON SCHEMA var_lfd TO lfd_ing;
GRANT SELECT, INSERT, Update ON ALL TABLES IN SCHEMA var_lfd TO lfd_ing;
ALTER DEFAULT PRIVILEGES IN SCHEMA var_lfd GRANT SELECT, INSERT, UPDATE  ON TABLES TO lfd_ing;

CREATE or replace FUNCTION array_sum_int(int[]) returns int AS 
$$
  SELECT sum(unnest)::int FROM (select unnest($1)) as foo;
$$
LANGUAGE sql;


-- SIG01.1
DROP TABLE IF EXISTS "SIG01.1";
CREATE TABLE "SIG01.1" as
select 
	distinct 
	id_metier_, 
	type_site, 
	id_metie_1, 
	id_regleme
from ftth_pf where lower(id_regleme) = lower('PA-61508-000P');

-- SIG01.2
DROP TABLE IF EXISTS "SIG01.2";
CREATE TABLE "SIG01.2" as
select 
	distinct 
	fz.id_metier_ as id_metier_zone,
	fp.id_metier_,
	fp.id_metie_1,
	fp.type_site,
	fp.statut_ftt,
	fp.type_pf,
	fp.code_com
from ftth_zone_eligibilite as fz 
	left join ftth_pf fp on fz.id_metier_ = fp.id_metier_ where fp.id_metier_ is null;

-- SIG01.3
DROP TABLE IF EXISTS "SIG01.3";
CREATE TABLE "SIG01.3" as
select 
	distinct 
	fs.id_metier_,
	fs.nom_com,
	fs.nb_logemen,
	fs.num_voie,
	fs.type_voie,
	fs.nom_voie,
	fs.batiment,
	fz.id_metier_ as id_metier_zone
from ftth_site_immeuble as fs
	left join ftth_zone_eligibilite as fz on st_contains(fz.geom,fs.geom);

-- SIG01.4
DROP TABLE IF EXISTS "SIG01.4";
CREATE TABLE "SIG01.4" as
select 
	distinct 
	fz.id_metier_ as id_metier_zone,
	fp.id_metier_,
	fp.type_site,
	fp.id_metie_1,
	fp.statut_ftt,
	fp.type_pf,
	fp.code_com
from ftth_pf as fp
	join ftth_zone_eligibilite as fz on fz.id_metier_ = fp.id_metier_;


-- SIG01.5
DROP TABLE IF EXISTS "SIG01.5";
CREATE TABLE "SIG01.5" as
with requete_ipon_pt as (
select 
	array_to_string(array_agg(distinct nomcommunepm),',') nomcommunepm,
	array_to_string(array_agg(distinct nomdupmreg),',') nomdupmreg,
	array_to_string(array_agg(distinct nomdupareg),',') nomdupareg, 
	nomsitepfpb,
	array_to_string(array_agg(distinct nomduptpb),',') nomduptpb,
	array_to_string(array_agg(distinct nomdupfpb),',') nomdupfpb,
	array_to_string(array_agg(distinct adresseousousadressesitepfpb),',') adresseousousadressesitepfpb,
	array_length(array_agg(distinct nomduptpb), 1) nombre_pt_pb
from ipon
group by nomsitepfpb)
select 
	distinct * 
from requete_ipon_pt 
where nombre_pt_pb::int > 1;

-- SII01.1
DROP TABLE IF EXISTS "SII01.1";
CREATE TABLE "SII01.1" as
select 
	distinct CODECOMMUNEPM,
	NOMNRO,
	NOMDUPMREG,
	IDTIGREPMREG,
	NOMDUPAREG,
	IDTIGREPAREG,
	NOMDUPFPB,
	ETATPRODUCTIONPFPB,
	DESCRIPTIONPFPB,
	ETATPHYSIQUEPTPB,
	NOMDUPTPB,
	DESCRIPTIONPTPB,
	NOMSITEPFPB,
	POSITIONDEQUIPEMENTPTPB,
	HAUTEURPARRAPPORTAUSOLPTPB,
	ADRESSEOUSOUSADRESSESITEPFPB,
	nbelducodeimmeuble
from ipon;

-- SII02.1 a Faire, la table requete est remplacer par SII01.1
DROP TABLE IF EXISTS "SII02.1";
CREATE TABLE "SII02.1" as
with intermediare_igo6 as (
select

	distinct array_agg(distinct ip.codecommunepm) codecommunepm,
	array_agg(distinct ip.NOMNRO) NOMNRO,
	array_agg(distinct ip.NOMDUPMREG) NOMDUPMREG,
	array_agg(distinct ip.IDTIGREPMREG) IDTIGREPMREG,
	array_agg(distinct ip.NOMDUPAREG) NOMDUPAREG,
	array_agg(distinct ip.IDTIGREPAREG) IDTIGREPAREG,
	array_agg(distinct ip.NOMDUPFPB) NOMDUPFPB,
	array_agg(distinct ip.ETATPRODUCTIONPFPB) ETATPRODUCTIONPFPB,
	array_agg(distinct ip.DESCRIPTIONPFPB) DESCRIPTIONPFPB,
	array_agg(distinct ip.ETATPHYSIQUEPTPB) ETATPHYSIQUEPTPB,
	ip.NOMDUPTPB,
	array_agg(distinct ip.DESCRIPTIONPTPB) DESCRIPTIONPTPB,
	array_agg(distinct ip.NOMSITEPFPB) NOMSITEPFPB,
	array_agg(distinct ip.POSITIONDEQUIPEMENTPTPB) POSITIONDEQUIPEMENTPTPB,
	array_agg(distinct ip.HAUTEURPARRAPPORTAUSOLPTPB) HAUTEURPARRAPPORTAUSOLPTPB,
	array_agg(distinct ip.ADRESSEOUSOUSADRESSESITEPFPB) ADRESSEOUSOUSADRESSESITEPFPB,
	array_agg(CASE
			WHEN ip.nbelducodeimmeuble IS NULL or ip.nbelducodeimmeuble = '' THEN
				0
			ELSE
				ip.nbelducodeimmeuble::int
		END) as nb_el_du_code_immeuble_replace,
	--count(ip.nb_el_du_code_immeuble) + ((count(ip.nb_el_du_code_immeuble) * 20)::float/100) as vingtpourcen,
	array_to_string(array_agg(distinct case when ip_pt.nombre_pt is null then 0 else ip_pt.nombre_pt::int end),';') as nombre_pt_ipon_file
from "SII01.1" ip
	left join table_data_ipon_pt ip_pt on ip_pt.nom_pt = ip.nomduptpb
where ip.nomduptpb is not null and ip.nomduptpb != ''
group by ip.nomduptpb)
select 
	
	*,
	array_sum_int(nb_el_du_code_immeuble_replace) as nb_el_du_code_immeuble_sum, 
	array_sum_int(nb_el_du_code_immeuble_replace) + ((array_sum_int(nb_el_du_code_immeuble_replace) * 20)::float/100) as vingtpourcen
from intermediare_igo6;


-- PDG03.1
DROP TABLE IF EXISTS "PDG03.1";
CREATE TABLE "PDG03.1" as
select 
	distinct 
	pe.codeimb,
	pe.batiment,
	pe.total,
	fs.id_metier_,
	fs.nb_logemen,
	fs.batiment as batiment_site_imb,
	case
		when ((case when pe.total::text = '' or pe.total is null then '0' else pe.total end)::text = 
			(case when fs.nb_logemen::text = '' or fs.nb_logemen is null then '0' else fs.nb_logemen end)::text) = true then 'OK' 
	else 'KO' end as compare_tot_log ,
	case
		when ((case when pe.batiment::text = '' or pe.batiment is null then '0' else pe.batiment end)::text = 
			(case when fs.batiment::text = '' or fs.batiment is null then '0' else fs.batiment end)::text) = true then 'OK' 
	else 'KO' end as compare_bat_bat 
from pointage_etude as pe
	full outer join ftth_site_immeuble as fs on fs.id_metier_ = pe.codeimb;

-- PDG03.2
DROP TABLE IF EXISTS "PDG03.2";
CREATE TABLE "PDG03.2" as
select 
	distinct 
	pe.codeimb,
	pe.batiment,
	pe.nbrelog,
	fs.id_metier_,
	fs.nb_logemen,
	fs.batiment as batiment_site_imb,
	case
		when ((case when pe.nbrelog::text = '' or pe.nbrelog is null then '0' else pe.nbrelog end)::text = 
			(case when fs.nb_logemen::text = '' or fs.nb_logemen is null then '0' else fs.nb_logemen end)::text) = true then 'OK' 
	else 'KO' end as compare_nbrelog_nblog 
from positionnement_etude as pe
	full outer join ftth_site_immeuble as fs on fs.id_metier_ = pe.codeimb;

-- PDG03.3
DROP TABLE IF EXISTS "PDG03.3";
CREATE TABLE "PDG03.3" as
select 
	distinct 
	pe.codeimb,
	pe.batiment,
	pe.nbrelog,
	pe.idpbgeofibre,

	si.id_metier_,
	si.nb_logemen,
	si.num_voie,
	si.type_voie,
	si.nom_voie,
	si.batiment as batiment_sig,
	si.id_metier_zone,
	case
		when ((case when pe.idpbgeofibre::text = '' or pe.idpbgeofibre is null then '0' else pe.idpbgeofibre end)::text = 
			(case when si.id_metier_zone::text = '' or si.id_metier_zone is null then '0' else si.id_metier_zone end)::text) = true then 'OK' 
	else 'KO' end as compare_geofib_id_metier_zone
from positionnement_etude as pe
	full outer join "SIG01.3" as si on si.id_metier_ = pe.codeimb
where id_metier_zone like '%PB%';

-- PDG03.4
DROP TABLE IF EXISTS "PDG03.4";
CREATE TABLE "PDG03.4" as
select 
	distinct 
	pe.idpbgeofibre,
	pe.emplacementdespb,
	pe.calculernbmodulesingnierie,
	pe.modulesissusdeltudedelazonearriredepa,
	pe.trononpaverspb,
	pe.numrositesupport,

	si.id_metier_,
	si.type_site,
	si.id_metie_1,
	si.statut_ftt,
	si.type_pf,
	si.code_com,

	pe.statutpb
from positionnement_etude as pe
	full outer join "SIG01.4" as si on si.id_metier_ = pe.idpbgeofibre
where pe.statutpb is not null and pe.statutpb != '';

-- PDG03.5
DROP TABLE IF EXISTS "PDG03.5";
CREATE TABLE "PDG03.5" as
select 
	distinct 
	pe.codeimb,
	pe.pmz,
	pe.pa,
	pe.localit,
	pe.codepostal,
	pe.rue,
	pe.num,
	pe.batiment,
	pe.total,
	pe.idpbgfi,

	si.codeimb as code_imb_pos,
	si.rue as rue_pos,
	si.num as num_pos,
	si.comp,
	si.batiment as batiment_pos,
	si.nbrelog,
	si.idpbgeofibre, 
	case
		when ((case when pe.total::text = '' or pe.total is null then '0' else pe.total end)::text = 
			(case when si.nbrelog::text = '' or si.nbrelog is null then '0' else si.nbrelog end)::text) = true then 'OK' 
	else 'KO' end as compare_tot_nbrelog,
	case
		when ((case when pe.idpbgfi::text = '' or pe.idpbgfi is null then '0' else pe.idpbgfi end)::text = 
			(case when si.idpbgeofibre::text = '' or si.idpbgeofibre is null then '0' else si.idpbgeofibre end)::text) = true then 'OK' 
	else 'KO' end as compare_pbgfi_nbrelog
from pointage_etude as pe
	full outer join positionnement_etude as si on si.codeimb = pe.codeimb;

-- GEO102.1
DROP TABLE IF EXISTS "GEO102.1";
CREATE TABLE "GEO102.1" as
select 
	distinct 
	pe.id_metier_,
	pe.id_metie_1,
	pe.type_site,
	pe.statut_ftt,
	pe.type_pf,
	pe.code_com
from "SIG01.4" as pe
where upper(pe.statut_ftt)::text != 'E';

-- GEO105.1
DROP TABLE IF EXISTS "GEO105.1";
CREATE TABLE "GEO105.1" as
select 
	distinct 
	pe.ref_cable,
	pe.statut_ftt,
	pe.type_longu,
	pe.longueur,
	pe.diametre,
	pe.nb_fibre,
	pe.type_cable,
	pe.id_metier_,
	pe.type_site_,
	pe.id_metier1,
	pe.type_site1,
	pe.commentair
from ftth_cable as pe;

-- GEO105.2
DROP TABLE IF EXISTS "GEO105.2";
CREATE TABLE "GEO105.2" as
select 
	distinct 
	ge.ref_cable,
	pe.nom,
	pe.longueurmètre,
	pe.statutphysique,
	pe.nombredefibres,
	pe.diamètre,
	pe.idcâble,
	pe.nra,
	pe.description
from "GEO105.1" ge
	left join export_cable_ipon_commune as pe on split_part(ge.ref_cable, '/', 3) = pe.nom;

-- GEO106.1
DROP TABLE IF EXISTS "GEO106.1";
CREATE TABLE "GEO106.1" as
select
	distinct 

	ad.id_metier_,
	ad.nb_logemen,
	
	pf.id_metier_ as id_metier_pf,

	case 
		when st_distance(pf.geom,ad.geom) is null then 0
	else st_distance(pf.geom,ad.geom)* 1.15 end as distance,
	case 
		when pf.geom is null or zn.geom is null then 'PointFonctionel  ou SiteImb non Incluse dans ZoneEligibilite'::text
	else 'OK'::text end as mes_zone_pf,
	zn.id_metier_ as id_metier_zone,
	ip.adduction,
	ip.adductabilite	
from ftth_site_immeuble ad
left join ftth_zone_eligibilite zn on st_contains(zn.geom,ad.geom)
left join ftth_pf pf on st_contains(zn.geom, pf.geom)
left join ipon ip on ip.codeimbzonedinfluencepfpbselonlesadresses = ad.id_metier_
where st_distance(pf.geom,ad.geom)* 1.15 > 100 or ( pf.geom is null or zn.geom is null);

-- IPO202.1
DROP TABLE IF EXISTS "IPO202.1";
CREATE TABLE "IPO202.1" as
with tab_requete_ipon as (
select 	distinct 
	nomdupfpb,
	descriptionpfpb,
	nomduptpb,
	descriptionptpb,
	nomsitepfpb,
	positiondequipementptpb,
	hauteurparrapportausolptpb,
	adresseousousadressesitepfpb
from "SII01.1"),
-- CH:en chambre
check_chambre as (
select 
	length(nomsitepfpb) length,
	array_to_string(REGEXP_MATCHES(nomsitepfpb::text, '[\w]{2}'), ',')::text = 'CH' check_nature,
	array_to_string(REGEXP_MATCHES(nomsitepfpb::text, '[A-Za-z0-9/]{5}$'), ',')::text ~* '[A-Za-z]' nbre_digit,
	* 
from tab_requete_ipon
where positiondequipementptpb = 'CHAMBRE' ),

-- AERIEN POTEAU ORANGE
check_aerien_orange as (
select 
	length(nomsitepfpb) length,
	array_to_string(REGEXP_MATCHES(nomsitepfpb::text, '[\w]{2}'), ',')::text = 'AP' check_nature,
	array_to_string(REGEXP_MATCHES(nomsitepfpb::text, '[A-Za-z0-9/]{7}$'), ',')::text ~* '[A-Za-z]' nbre_digit,
	* 
from tab_requete_ipon
where positiondequipementptpb = 'AERIEN POTEAU ORANGE' ),

-- AERIEN POTEAU ENEDIS
check_aerien_enedis as (
select 
	length(nomsitepfpb) length,
	array_to_string(REGEXP_MATCHES(nomsitepfpb::text, '[\w]{2}'), ',')::text = 'AP' check_nature,
	array_to_string(REGEXP_MATCHES(nomsitepfpb::text, '[A-Za-z0-9/E]{6}$'), ',')::text ~* '[A-Za-z]' nbre_digit,
	* 
from tab_requete_ipon
where positiondequipementptpb = 'AERIEN POTEAU ENEDIS' ),

-- FACADE COTE COUR ou FACADE COTE RUE ou like IMMEUBLE
check_aerien_facade_imb as (
select 
	length(nomsitepfpb) length,
	array_to_string(REGEXP_MATCHES(nomsitepfpb::text, '[\w]{3}'), ',')::text = 'IMB' check_nature,
	array_to_string(REGEXP_MATCHES(nomsitepfpb::text, '[A-Za-z0-9/]{7}$'), ',')::text ~* '[A-Za-z]' nbre_digit,
	* 
from tab_requete_ipon
where positiondequipementptpb like '%FACADE%' or positiondequipementptpb like '%IMB%'),

-- AERIEN
check_aerien as (
select 
	length(nomsitepfpb) length,
	array_to_string(REGEXP_MATCHES(nomsitepfpb::text, '[\w]{2}'), ',')::text = 'AP' check_nature,
	array_to_string(REGEXP_MATCHES(nomsitepfpb::text, '[A-Za-z0-9/]{7}$'), ',')::text ~* '[A-Za-z]' nbre_digit,
	* 
from tab_requete_ipon
where positiondequipementptpb = 'AERIEN' ), 

ipo202_1 as (
	select 
		*
	from tab_requete_ipon
	where positiondequipementptpb = 'CHAMBRE' and descriptionptpb != 'PB Nexans Black Box' or 
		positiondequipementptpb != 'CHAMBRE' and descriptionptpb not like '%3M%'),
ipo202_3 as (
	select 
		*
	from tab_requete_ipon
	where (positiondequipementptpb like '%FACADE%' and hauteurparrapportausolptpb != 'GH : h sup 2,5 m') or 
		(positiondequipementptpb like '%AERIEN%' and hauteurparrapportausolptpb not in ('GH : h sup 2,5 m', 'PH : h 1,8m - 2,5 m')) or 
		(positiondequipementptpb like '%CHAMBRE%' and hauteurparrapportausolptpb != 'HH : h inf  1,8 m')
	),
ipo205_1 as (
	select 
		nomdupfpb,
		descriptionpfpb,
		array_to_string(REGEXP_MATCHES(descriptionpfpb::text, '[\w]{2}'), ',')::text = 'PB' as check_nature,
		array_to_string(REGEXP_MATCHES(descriptionpfpb::text, '[A-Za-z0-9/]{5}$'), ',')::text ~* '[A-Za-z]' as nbre_digit
	from tab_requete_ipon
	union all select 
		nomdupfpb,
		descriptionpfpb,
		false,
		true
	from tab_requete_ipon
	where descriptionpfpb is null or descriptionpfpb = ''
	)

select 
	distinct tb.*,
	case when ipo202_1.nomdupfpb is null then 'OK' else 'KO' end as verif_description,
	case when chec_desc.nomdupfpb is null then 'OK' else 'KO' end as verif_pos,
	case when ipo202_3.nomdupfpb is null then 'OK' else 'KO' end as verif_haut,
	case when ipo205_1.nomdupfpb is null then 'OK' else 'la description du PF PB est mal renseigné' end as verif_pf

from tab_requete_ipon tb
	left join (
		select * from check_chambre where (check_nature is false or nbre_digit is true or length != 8) union all
		select * from check_aerien_orange where (check_nature is false or nbre_digit is true or length != 10) union all
		select * from check_aerien_enedis where (check_nature is false or nbre_digit is true or length != 10) union all
		select * from check_aerien_facade_imb where (check_nature is false or length != 16) union all
		select * from check_aerien where (check_nature is false or length != 10)
		) as chec_desc on chec_desc.nomdupfpb = tb.nomdupfpb
	left join ipo202_1 on ipo202_1.nomdupfpb = tb.nomdupfpb
	left join ipo202_3 on ipo202_3.nomdupfpb = tb.nomdupfpb
	left join (select * from ipo205_1 where (check_nature is false or nbre_digit is true)) as ipo205_1 
	on ipo205_1.nomdupfpb = tb.nomdupfpb;

-- IPO202.4
DROP TABLE IF EXISTS "IPO202.4";
CREATE TABLE "IPO202.4" as
select 
	distinct si4.id_metier_,
	si4.type_site,
	si4.id_metie_1,
	si4.code_com,

	si1.nomdupfpb,
	si1.descriptionpfpb,
	si1.nomduptpb,
	si1.nomsitepfpb,
	si1.positiondequipementptpb,
	si1.adresseousousadressesitepfpb


from "SIG01.4" as si4
	full outer join "SII01.1" si1 on right(si4.id_metier_, 5) = si1.descriptionpfpb;

---IPO206.1
DROP TABLE IF EXISTS "IPO206.1";
CREATE TABLE "IPO206.1" as
with intersect_siteimmeuble_zonel as 
(select
	sit_imb.id_metier_, sit_imb.nb_logemen, sit_imb.batiment,
	zft.id_metier_ as id_metier_zone
from ftth_site_immeuble sit_imb
	 left join ftth_zone_eligibilite zft on st_intersects(sit_imb.geom,zft.geom)
where zft.geom is not null)
select 
	inter.*,
	reqip.adresseousousadressesitepfpb,
	reqip.nomsitepfpb,
	reqip.descriptionpfpb,
	reqip.nomduptpb,
	reqip.nomdupfpb,
	reqip.codeimbzonedinfluencepfpbselonlesadresses,
	reqip.nbelducodeimmeuble,
	reqip.descriptiondusitecommentaires
from intersect_siteimmeuble_zonel as inter
	left join ipon as reqip on inter.id_metier_ = reqip.codeimbzonedinfluencepfpbselonlesadresses
where reqip.codeimbzonedinfluencepfpbselonlesadresses is null or 
	right(inter.id_metier_zone, 5) != replace(left(reqip.descriptionpfpb, 8), left(reqip.descriptionpfpb, 3),'');

--- IPO206.2
DROP TABLE IF EXISTS "IPO206.2";
with intersect_siteimmeuble_zonel as 
(select
	sit_imb.id_metier_, sit_imb.nb_logemen, sit_imb.batiment,
	zft.id_metier_ as id_metier_zone
from ftth_site_immeuble sit_imb
	 left join ftth_zone_eligibilite zft on st_intersects(sit_imb.geom,zft.geom)
where zft.geom is not null),
group_id_metier_zone as (
select 
	reqip.codeimbzonedinfluencepfpbselonlesadresses,
	array_to_string(array_agg(distinct reqip.descriptionpfpb), ',') descriptionpfpb,
	array_to_string(array_agg(distinct inter.id_metier_), ',') id_metier_,
	array_to_string(array_agg(distinct inter.id_metier_zone), ',') id_metier_zone,
	array_to_string(array_agg(inter.nb_logemen), ',') nb_logemen
from intersect_siteimmeuble_zonel as inter
	left join ipon as reqip on inter.id_metier_ = reqip.codeimbzonedinfluencepfpbselonlesadresses

--where reqip.descriptionpfpb is not null and reqip.descriptionpfpb != ''
group by reqip.codeimbzonedinfluencepfpbselonlesadresses
order by reqip.codeimbzonedinfluencepfpbselonlesadresses)

select distinct * into "IPO206.2" 
from group_id_metier_zone
where descriptionpfpb ~ right(id_metier_zone, 5) is false;

-- IPO208.1
DROP TABLE IF EXISTS "IPO208.1";
CREATE TABLE "IPO208.1" as
select 
	distinct 
	codeimbzonedinfluencepfpbselonlesadresses,
	nbelducodeimmeuble,
	oioperateurimmeuble,
	nomsitesissi,
	typedingenierie,
	adduction,
	adductabilite
from ipon
where oioperateurimmeuble != 'ORNE DEPARTEMENT TRES HAUT DEB' or typedingenierie != 'mono-fibre' or nomsitesissi = '' or nomsitesissi is null;

-- IPO208.2
DROP TABLE IF EXISTS "IPO208.2";
CREATE TABLE "IPO208.2" as
select 
	distinct 
	codeimbzonedinfluencepfpbselonlesadresses,
	adduction,
	adductabilite
from ipon
where (adduction not like 'AS%' and adductabilite like '1 :%') or 
	(adduction like 'AS%' and adductabilite like '2 :%') or adduction is null or adduction = '' or adductabilite is null or adductabilite = '';


-- REF301.1
DROP TABLE IF EXISTS "REF301.1";
CREATE TABLE "REF301.1" as
select 
	distinct
	codeimbzonedinfluencepfpbselonlesadresses,
	nbelducodeimmeuble,
	oioperateurimmeuble,
	descriptiondusitecommentaires,
	nomsitesissi,
	typedingenierie,
	adduction,
	naturetravaux,
	adductabilite

from ipon;
