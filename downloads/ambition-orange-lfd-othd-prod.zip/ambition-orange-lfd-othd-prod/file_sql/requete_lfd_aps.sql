SET search_path TO var_lfd, public;
GRANT ALL ON SCHEMA var_lfd TO lfd_ing;
GRANT SELECT, INSERT, Update ON ALL TABLES IN SCHEMA var_lfd TO lfd_ing;
ALTER DEFAULT PRIVILEGES IN SCHEMA var_lfd GRANT SELECT, INSERT, UPDATE  ON TABLES TO lfd_ing;


-- SIG01.1
DROP TABLE IF EXISTS "SIG01.1";
CREATE TABLE "SIG01.1" as
select 
	distinct 
	id_metier_, 
	type_site, 
	id_metie_1, 
	id_regleme
from ftth_pf where lower(id_regleme) = lower('PA-61508-000P');

-- SIG01.2
DROP TABLE IF EXISTS "SIG01.2";
CREATE TABLE "SIG01.2" as
select 
	distinct 
	fz.id_metier_ as id_metier_zone,
	fp.id_metier_,
	fp.id_metie_1,
	fp.type_site,
	fp.statut_ftt,
	fp.type_pf,
	fp.code_com
from ftth_zone_eligibilite as fz 
	left join ftth_pf fp on fz.id_metier_ = fp.id_metier_ where fp.id_metier_ is null;

-- SIG01.3
DROP TABLE IF EXISTS "SIG01.3";
CREATE TABLE "SIG01.3" as
select 
	distinct 
	fs.id_metier_,
	fs.nom_com,
	fs.nb_logemen,
	fs.num_voie,
	fs.type_voie,
	fs.nom_voie,
	fs.batiment,
	fz.id_metier_ as id_metier_zone
from ftth_site_immeuble as fs
	left join ftth_zone_eligibilite as fz on st_contains(fz.geom,fs.geom);

-- SIG01.4
DROP TABLE IF EXISTS "SIG01.4";
CREATE TABLE "SIG01.4" as
select 
	distinct 
	fz.id_metier_ as id_metier_zone,
	fp.id_metier_,
	fp.type_site,
	fp.id_metie_1,
	fp.statut_ftt,
	fp.type_pf,
	fp.code_com
from ftth_pf as fp
	join ftth_zone_eligibilite as fz on fz.id_metier_ = fp.id_metier_;

-- PDG03.1
DROP TABLE IF EXISTS "PDG03.1";
CREATE TABLE "PDG03.1" as
select 
	distinct 
	pe.codeimb,
	pe.batiment,
	pe.total,
	fs.id_metier_,
	fs.nb_logemen,
	fs.batiment as batiment_site_imb,
	case
		when ((case when pe.total::text = '' or pe.total is null then '0' else pe.total end)::text = 
			(case when fs.nb_logemen::text = '' or fs.nb_logemen is null then '0' else fs.nb_logemen end)::text) = true then 'OK' 
	else 'KO' end as compare_tot_log ,
	case
		when ((case when pe.batiment::text = '' or pe.batiment is null then '0' else pe.batiment end)::text = 
			(case when fs.batiment::text = '' or fs.batiment is null then '0' else fs.batiment end)::text) = true then 'OK' 
	else 'KO' end as compare_bat_bat 
from pointage_etude as pe
	full outer join ftth_site_immeuble as fs on fs.id_metier_ = pe.codeimb;

-- PDG03.2
DROP TABLE IF EXISTS "PDG03.2";
CREATE TABLE "PDG03.2" as
select 
	distinct 
	pe.codeimb,
	pe.batiment,
	pe.nbrelog,
	fs.id_metier_,
	fs.nb_logemen,
	fs.batiment as batiment_site_imb,
	case
		when ((case when pe.nbrelog::text = '' or pe.nbrelog is null then '0' else pe.nbrelog end)::text = 
			(case when fs.nb_logemen::text = '' or fs.nb_logemen is null then '0' else fs.nb_logemen end)::text) = true then 'OK' 
	else 'KO' end as compare_nbrelog_nblog 
from positionnement_etude as pe
	full outer join ftth_site_immeuble as fs on fs.id_metier_ = pe.codeimb;

-- PDG03.3
DROP TABLE IF EXISTS "PDG03.3";
CREATE TABLE "PDG03.3" as
select 
	distinct 
	pe.codeimb,
	pe.batiment,
	pe.nbrelog,
	pe.idpbgeofibre,

	si.id_metier_,
	si.nb_logemen,
	si.num_voie,
	si.type_voie,
	si.nom_voie,
	si.batiment as batiment_sig,
	si.id_metier_zone,
	case
		when ((case when pe.idpbgeofibre::text = '' or pe.idpbgeofibre is null then '0' else pe.idpbgeofibre end)::text = 
			(case when si.id_metier_zone::text = '' or si.id_metier_zone is null then '0' else si.id_metier_zone end)::text) = true then 'OK' 
	else 'KO' end as compare_geofib_id_metier_zone
from positionnement_etude as pe
	full outer join "SIG01.3" as si on si.id_metier_ = pe.codeimb;

-- PDG03.4
DROP TABLE IF EXISTS "PDG03.4";
CREATE TABLE "PDG03.4" as
select 
	distinct 
	pe.idpbgeofibre,
	pe.emplacementdespb,
	pe.calculernbmodulesingnierie,
	pe.modulesissusdeltudedelazonearriredepa,
	pe.trononpaverspb,
	pe.numrositesupport,

	si.id_metier_,
	si.type_site,
	si.id_metie_1,
	si.statut_ftt,
	si.type_pf,
	si.code_com,

	pe.statutpb
from positionnement_etude as pe
	full outer join "SIG01.4" as si on si.id_metier_ = pe.idpbgeofibre
where pe.statutpb is not null and pe.statutpb != '';

-- PDG03.5
DROP TABLE IF EXISTS "PDG03.5";
CREATE TABLE "PDG03.5" as
select 
	distinct 
	pe.codeimb,
	pe.pmz,
	pe.pa,
	pe.localit,
	pe.codepostal,
	pe.rue,
	pe.num,
	pe.batiment,
	pe.total,
	pe.idpbgfi,

	si.codeimb as code_imb_pos,
	si.rue as rue_pos,
	si.num as num_pos,
	si.comp,
	si.batiment as batiment_pos,
	si.nbrelog,
	si.idpbgeofibre, 
	case
		when ((case when pe.total::text = '' or pe.total is null then '0' else pe.total end)::text = 
			(case when si.nbrelog::text = '' or si.nbrelog is null then '0' else si.nbrelog end)::text) = true then 'OK' 
	else 'KO' end as compare_tot_nbrelog,
	case
		when ((case when pe.idpbgfi::text = '' or pe.idpbgfi is null then '0' else pe.idpbgfi end)::text = 
			(case when si.idpbgeofibre::text = '' or si.idpbgeofibre is null then '0' else si.idpbgeofibre end)::text) = true then 'OK' 
	else 'KO' end as compare_pbgfi_nbrelog
from pointage_etude as pe
	full outer join positionnement_etude as si on si.codeimb = pe.codeimb;

-- GEO102.1
DROP TABLE IF EXISTS "GEO102.1";
CREATE TABLE "GEO102.1" as
select 
	distinct 
	pe.id_metier_,
	pe.id_metie_1,
	pe.type_site,
	pe.statut_ftt,
	pe.type_pf,
	pe.code_com
from "SIG01.4" as pe
where upper(pe.statut_ftt)::text != 'E';

-- GEO105.1
DROP TABLE IF EXISTS "GEO105.1";
CREATE TABLE "GEO105.1" as
select 
	distinct 
	pe.ref_cable,
	pe.statut_ftt,
	pe.type_longu,
	pe.longueur,
	pe.diametre,
	pe.nb_fibre,
	pe.type_cable,
	pe.id_metier_,
	pe.type_site_,
	pe.id_metier1,
	pe.type_site1,
	pe.commentair
from ftth_cable as pe;

-- GEO106.1
DROP TABLE IF EXISTS "GEO106.1";
CREATE TABLE "GEO106.1" as
select
	distinct 

	ad.id_metier_,
	ad.nb_logemen,
	
	pf.id_metier_ as id_metier_pf,

	case 
		when st_distance(pf.geom,ad.geom) is null then 0
	else st_distance(pf.geom,ad.geom)* 1.15 end as distance,
	case 
		when pf.geom is null or zn.geom is null then 'PointFonctionel  ou SiteImb non Incluse dans ZoneEligibilite'::text
	else 'OK'::text end as mes_zone_pf
from ftth_site_immeuble ad
left join ftth_zone_eligibilite zn on st_contains(zn.geom,ad.geom)
left join ftth_pf pf on st_contains(zn.geom, pf.geom)
where st_distance(pf.geom,ad.geom)* 1.15 > 100 or ( pf.geom is null or zn.geom is null)