import psycopg2
from qgis.PyQt.QtWidgets import QMessageBox
from qgis.utils import iface

server = {
    'dev': {'DB': 'bthd', 'user': 'admambigroup', 'MP': 'secure', 'host': '192.168.30.195', 'port': '5432'},
    'prod': {'DB': 'bthd', 'user': 'admambigroup', 'MP': 'secure', 'host': '192.168.30.194', 'port': '5432'}
}

DB = server['prod']['DB']
user = server['prod']['user']
MP = server['prod']['MP']
host = server['prod']['host']
port = server['prod']['port']


def function_connexion():
    # Parameter connexion base
    global DB, user, MP, host, port
    # Connexion a la base
    try:
        connection = psycopg2.connect(user=user, password=MP, host=host, port=port, database=DB)
        return connection
    except(Exception, psycopg2.DatabaseError) as error:
        QMessageBox.critical(iface, "Message de connexion de la base", 'Erreur de connexion de la base' + str(error))
