set search_path to var_schema_etude, public;
-- Creation du schema de modelisation
DROP SCHEMA IF EXISTS trans_model cascade;
CREATE SCHEMA trans_model;

GRANT ALL ON SCHEMA trans_model TO admambigroup;
GRANT ALL ON SCHEMA trans_model TO bthd_ing;

ALTER DEFAULT PRIVILEGES IN SCHEMA trans_model
    GRANT INSERT, SELECT, UPDATE ON TABLES
    TO bthd_ing;

---Suppression des tables
Drop table if exists trans_model.t_adresse;	
Drop table if exists trans_model.t_baie;	
Drop table if exists trans_model.t_cab_cond;	
Drop table if exists trans_model.t_cable;	
Drop table if exists trans_model.t_cableline;	
Drop table if exists trans_model.t_cassette;	
Drop table if exists trans_model.t_cheminement;	
Drop table if exists trans_model.t_cond_chem;	
Drop table if exists trans_model.t_conduite;	
Drop table if exists trans_model.t_ebp;	
Drop table if exists trans_model.t_equipement;	
Drop table if exists trans_model.t_fibre;	
Drop table if exists trans_model.t_love;	
Drop table if exists trans_model.t_ltech;	
Drop table if exists trans_model.t_masque;	
Drop table if exists trans_model.t_noeud;	
Drop table if exists trans_model.t_organisme;	
Drop table if exists trans_model.t_position;	
Drop table if exists trans_model.t_ptech;	
Drop table if exists trans_model.t_reference;	
Drop table if exists trans_model.t_ropt;	
Drop table if exists trans_model.t_siteemission;	
Drop table if exists trans_model.t_sitetech;	
Drop table if exists trans_model.t_suf;	
Drop table if exists trans_model.t_tiroir;	
Drop table if exists trans_model.t_znro;	
Drop table if exists trans_model.t_zpbo;	
Drop table if exists trans_model.t_zsro;

-- Creation de la table t_adresse
select 
	cb.* into  trans_model.t_adresse 
from t_adresse cb;

-- Creation de la table t_organisme
select 
	* into trans_model.t_organisme 
from t_organisme;

-- Creation de la table t_reference
select 
	* into trans_model.t_reference 
from t_reference;

-- Creation de la table t_document
select 
	cd.* into trans_model.t_document 
from t_document cd;

-- Creation de la table t_empreinte
select 
	em.* into trans_model.t_empreinte 
from t_empreinte em
	join trans_model.t_document doc on doc.do_code = em.em_do_code;



-- Creation des cables de transports
select 
	* into  trans_model.t_cable 
from t_cable where cb_typelog = 'TR';

-- Creation de la table t_cheminement
select
	cb.* into  trans_model.t_cheminement
from t_cheminement cb where cm_typelog in ('TR', 'TD');

-- Creation des noeuds transport par rapport au cables, cheminement, zdep
select
	cb_nd1 as val_noeud into  trans_model.t_noeud_cable
from trans_model.t_cable union
select
	cb_nd2 from
trans_model.t_cable union
select
	cm_ndcode1 from
trans_model.t_cheminement union
select
	cm_ndcode2 from
trans_model.t_cheminement union
select
	cd.zd_nd_code
from t_zdep cd;


-- Creation de la table t_noeud
select 
	nd.* into  trans_model.t_noeud 
from t_noeud nd 
	join trans_model.t_noeud_cable nd_cb on nd.nd_code = nd_cb.val_noeud;

-- Creation de la table t_sitetech
select 
	st.* into  trans_model.t_sitetech 
from t_sitetech st 
	join trans_model.t_noeud nd on nd.nd_code=st.st_nd_code;

-- Creation de la table t_ltech
select 
	st.* into  trans_model.t_ltech 
from t_ltech st 
	join trans_model.t_sitetech nd on nd.st_code=st.lt_st_code;

-- Creation de la table t_baie
select 
	st.* into  trans_model.t_baie
from t_baie st join trans_model.t_ltech nd on nd.lt_code=st.ba_lt_code;

-- Creation de la table t_tiroir
select 
	st.* into  trans_model.t_tiroir 
from t_tiroir st 
	join trans_model.t_baie nd on nd.ba_code=st.ti_ba_code;

-- Creation de la table t_equipement
select 
	st.* into  trans_model.t_equipement 
from t_equipement st 
	join trans_model.t_baie nd on nd.ba_code=st.eq_ba_code;

-- Creation de la table t_ptech
select 
	st.* into  trans_model.t_ptech 
from t_ptech st 
	join trans_model.t_noeud nd on nd.nd_code=st.pt_nd_code;

-- Creation de la table t_ebp
select 
	st.* into  trans_model.t_ebp 
from t_ebp st 
	join trans_model.t_ptech nd on nd.pt_code=st.bp_pt_code;

-- Creation de la table t_cassette
select 
	st.* into  trans_model.t_cassette 
from t_cassette st 
	join trans_model.t_ebp nd on nd.bp_code=st.cs_bp_code;

---- Creation de la table t_cheminement
--select
--	cb.* into  trans_model.t_cheminement
--from t_cheminement cb where cm_typelog in ('TR', 'TD');

-- Creation de la table t_conduite
select 
	cd.* into  trans_model.t_conduite 
from t_conduite cd 
	join t_cond_chem dm on cd.cd_code=dm.dm_cd_code
	join trans_model.t_cheminement cm on cm.cm_code=dm.dm_cm_code;
	
-- Creation de la table t_cond_chem
select 
	cd.* into  trans_model.t_cond_chem 
from t_cond_chem cd 
	join trans_model.t_cheminement dm on dm.cm_code=cd.dm_cm_code;

-- Creation de la table t_masque
select 
	cd.* into  trans_model.t_masque 
from t_masque cd 
	join trans_model.t_noeud nd on nd.nd_code=cd.mq_nd_code;

-- Creation de la table t_cableline
select 
	cl.* into  trans_model.t_cableline 
from t_cableline cl 
	join trans_model.t_cable cb on cb.cb_code = cl.cl_cb_code;

-- Creation de la table t_cab_cond
select 
	cd.* into trans_model.t_cab_cond 
from t_cab_cond cd 
	join trans_model.t_cable cb on cb.cb_code=cd.cc_cb_code;

-- Creation de la table t_love
select 
	cd.* into trans_model.t_love 
from t_love cd 
	join trans_model.t_noeud cb on cb.nd_code=cd.lv_nd_code;

-- Creation de la table t_fibre
select 
	cd.* into trans_model.t_fibre 
from t_fibre cd 
	join trans_model.t_cable cb on cb.cb_code=cd.fo_cb_code;

-- Creation de la table t_position
select 
	cd.* into trans_model.t_position 
from t_position cd 
	left join trans_model.t_fibre cb on cb.fo_code=cd.ps_2 
	left join trans_model.t_fibre cb2 on cb2.fo_code=cd.ps_2
	join trans_model.t_cassette cs on cs.cs_code=cd.ps_cs_code
	where cb.fo_code is not null or cb2.fo_code is not null;

-- Creation de la table t_ropt
select 
	cd.* into trans_model.t_ropt 
from t_ropt cd 
	join trans_model.t_fibre cb on cb.fo_code=cd.rt_fo_code;

-- Creation de la table t_siteemission
select 
	cd.* into trans_model.t_siteemission 
from t_siteemission cd 
	join trans_model.t_noeud cb on cb.nd_code=cd.se_nd_code;

-- Creation de la table t_znro
select 
	cd.* into trans_model.t_znro 
from t_znro cd 
	join trans_model.t_noeud cb on cb.nd_code=cd.zn_nd_code;

-- Creation de la table t_zsro
select 
	cd.* into trans_model.t_zsro 
from t_zsro cd 
	join trans_model.t_noeud cb on cb.nd_code=cd.zs_nd_code;

-- Creation de la table t_zdep
select 
	cd.* into trans_model.t_zdep 
from t_zdep cd 
	join trans_model.t_zsro cb on cb.zs_code=cd.zd_zs_code;

-- Creation de la table t_zpbo
select 
	cd.* into trans_model.t_zpbo 
from t_zpbo cd 
	join trans_model.t_noeud cb on cb.nd_code=cd.zp_nd_code;

-- Creation de la table t_suf
select 
	cd.* into trans_model.t_suf 
from t_suf cd 
	join trans_model.t_noeud cb on cb.nd_code=cd.sf_nd_code;

-- Application des vues
set search_path to trans_model, public;
SET client_encoding TO 'WIN1252';
CREATE TABLE t_docobj
(
  od_id bigint NOT NULL,
  od_do_code character varying(254) NOT NULL,
  od_tbltype character varying(2) NOT NULL,
  od_codeobj character varying(254) NOT NULL,
  od_creadat timestamp without time zone,
  od_majdate timestamp without time zone,
  od_majsrc character varying(254),
  od_abddate date,
  od_abdsrc character varying(254));

CREATE TABLE t_zcoax
(
  zc_code character varying(254) NOT NULL,
  zc_codeext character varying(254),
  zc_nd_code character varying(254),
  zc_r1_code character varying(100),
  zc_r2_code character varying(100),
  zc_r3_code character varying(100),
  zc_r4_code character varying(100),
  zc_prop character varying(20),
  zc_gest character varying(20),
  zc_statut character varying(3) NOT NULL,
  zc_comment character varying(254),
  zc_geolsrc character varying(254),
  zc_creadat timestamp without time zone,
  zc_majdate timestamp without time zone,
  zc_majsrc character varying(254),
  zc_abddate date,
  zc_abdsrc character varying(254),
  geom geometry(MultiPolygon,2154));

/*vs_elem_sf_nd*/
DROP VIEW IF EXISTS "vs_elem_sf_nd";
CREATE VIEW "vs_elem_sf_nd" AS
SELECT 
  * 
FROM 
  t_suf, 
  t_noeud
WHERE 
  t_suf.sf_nd_code = t_noeud.nd_code;

  
/*vs_elem_bp_sf_nd*/
DROP VIEW IF EXISTS "vs_elem_bp_sf_nd";
CREATE VIEW "vs_elem_bp_sf_nd" AS
SELECT 
  * 
FROM 
  t_ebp,
  t_suf, 
  t_noeud
WHERE 
  t_ebp.bp_sf_code = t_suf.sf_code AND
  t_suf.sf_nd_code = t_noeud.nd_code;

  
/*vs_elem_st_nd*/
DROP VIEW IF EXISTS "vs_elem_st_nd";
CREATE VIEW "vs_elem_st_nd" AS
SELECT 
  * 
FROM 
  t_sitetech, 
  t_noeud
WHERE 
  t_sitetech.st_nd_code = t_noeud.nd_code;

  
/*vs_elem_lt_st_nd*/
DROP VIEW IF EXISTS "vs_elem_lt_st_nd";
CREATE VIEW "vs_elem_lt_st_nd" AS
SELECT 
  * 
FROM 
  t_ltech,
  t_sitetech, 
  t_noeud 
WHERE 
  t_sitetech.st_nd_code = t_noeud.nd_code AND
  t_ltech.lt_st_code = t_sitetech.st_code;
  

/*vs_elem_bp_lt_st_nd*/ 
DROP VIEW IF EXISTS "vs_elem_bp_lt_st_nd";
CREATE VIEW "vs_elem_bp_lt_st_nd" AS
SELECT 
  * 
FROM 
  t_ebp,
  t_ltech,
  t_sitetech, 
  t_noeud 
WHERE 
  t_sitetech.st_nd_code = t_noeud.nd_code AND
  t_ltech.lt_st_code = t_sitetech.st_code AND
  t_ebp.bp_lt_code = t_ltech.lt_code;  

/*vs_elem_cs_bp_lt_st_nd*/ 
DROP VIEW IF EXISTS "vs_elem_cs_bp_lt_st_nd";
CREATE VIEW "vs_elem_cs_bp_lt_st_nd" AS
SELECT 
  * 
FROM 
  t_cassette,
  t_ebp,
  t_ltech,
  t_sitetech, 
  t_noeud 
WHERE 
  t_sitetech.st_nd_code = t_noeud.nd_code AND
  t_ltech.lt_st_code = t_sitetech.st_code AND
  t_ebp.bp_lt_code = t_ltech.lt_code AND
  t_cassette.cs_bp_code = t_ebp.bp_code
  ;  
  
/*vs_elem_ba_lt_st_nd*/
DROP VIEW IF EXISTS "vs_elem_ba_lt_st_nd";
CREATE VIEW "vs_elem_ba_lt_st_nd" AS
SELECT 
  * 
FROM 
  t_baie,
  t_ltech, 
  t_sitetech, 
  t_noeud
WHERE 
  t_sitetech.st_nd_code = t_noeud.nd_code AND
  t_ltech.lt_st_code = t_sitetech.st_code AND
  t_baie.ba_lt_code = t_ltech.lt_code;

/*vs_elem_ti_ba_lt_st_nd*/
DROP VIEW IF EXISTS "vs_elem_ti_ba_lt_st_nd";
CREATE VIEW "vs_elem_ti_ba_lt_st_nd" AS
SELECT 
  * 
FROM 
  t_tiroir,
  t_baie, 
  t_ltech, 
  t_sitetech, 
  t_noeud   
WHERE 
  t_sitetech.st_nd_code = t_noeud.nd_code AND
  t_ltech.lt_st_code = t_sitetech.st_code AND
  t_baie.ba_lt_code = t_ltech.lt_code AND
  t_tiroir.ti_ba_code = t_baie.ba_code;

  
/*vs_elem_eq_ba_lt_st_nd*/
DROP VIEW IF EXISTS "vs_elem_eq_ba_lt_st_nd";
CREATE VIEW "vs_elem_eq_ba_lt_st_nd" AS
SELECT 
  * 
FROM 
  t_equipement,
  t_baie, 
  t_ltech, 
  t_sitetech, 
  t_noeud 
WHERE 
  t_sitetech.st_nd_code = t_noeud.nd_code AND
  t_ltech.lt_st_code = t_sitetech.st_code AND
  t_baie.ba_lt_code = t_ltech.lt_code AND
  t_equipement.eq_ba_code = t_baie.ba_code;

   
/*vs_elem_pt_nd*/
DROP VIEW IF EXISTS "vs_elem_pt_nd";
CREATE VIEW "vs_elem_pt_nd" AS
SELECT 
  * 
FROM 
  t_ptech, 
  t_noeud
WHERE 
  t_ptech.pt_nd_code = t_noeud.nd_code;

/*vs_elem_mq_nd*/
DROP VIEW IF EXISTS "vs_elem_mq_nd";
CREATE VIEW "vs_elem_mq_nd" AS
SELECT 
  * 
FROM 
  t_masque, 
  t_noeud
WHERE 
  t_masque.mq_nd_code = t_noeud.nd_code;

  
/*vs_elem_cl_cb*/ 
DROP VIEW IF EXISTS "vs_elem_cl_cb";
CREATE VIEW "vs_elem_cl_cb" AS
SELECT 
  * 
FROM 
  t_cable, 
  t_cableline
WHERE 
  t_cableline.cl_cb_code = t_cable.cb_code;


/*vs_elem_cl_cb_lv*/ 
DROP VIEW IF EXISTS "vs_elem_cl_cb_lv";
CREATE VIEW "vs_elem_cl_cb_lv" AS
SELECT 
    *
FROM "t_cableline" AS "cl"
JOIN "t_cable" AS "cb" ON ("cl"."cl_cb_code" = "cb"."cb_code")
LEFT JOIN "t_love" AS "lv" ON ("cb"."cb_code" = "lv"."lv_cb_code")
--ORDER BY "cb"."cb_code"
;

  
/*vs_elem_fo_cb_cl*/ 
DROP VIEW IF EXISTS "vs_elem_fo_cb_cl";
CREATE VIEW "vs_elem_fo_cb_cl" AS
SELECT 
  * 
FROM 
  t_fibre,
  t_cable,
  t_cableline
WHERE 
  t_fibre.fo_cb_code = t_cable.cb_code AND
  t_cableline.cl_cb_code = t_cable.cb_code;

  
/*vs_elem_rt_fo_cb_cl*/
DROP VIEW IF EXISTS "vs_elem_rt_fo_cb_cl";
CREATE VIEW "vs_elem_rt_fo_cb_cl" AS  
SELECT 
  * 
FROM 
  t_ropt,
  t_fibre, 
  t_cable,
  t_cableline 
WHERE 
  t_cable.cb_code = t_fibre.fo_cb_code AND
  t_cableline.cl_cb_code = t_cable.cb_code AND
  t_fibre.fo_code = t_ropt.rt_fo_code;

  
/*vs_elem_lv_nd*/
DROP VIEW IF EXISTS "vs_elem_lv_nd";
CREATE VIEW "vs_elem_lv_nd" AS
  SELECT 
  * 
FROM 
  t_love,
  t_noeud 
WHERE 
  t_love.lv_nd_code = t_noeud.nd_code;

  
/*vs_elem_bp_pt_nd*/ 
DROP VIEW IF EXISTS "vs_elem_bp_pt_nd";
CREATE VIEW "vs_elem_bp_pt_nd" AS
SELECT 
  * 
FROM 
  t_ebp,
  t_ptech, 
  t_noeud 
WHERE 
  t_ptech.pt_nd_code = t_noeud.nd_code AND
  t_ebp.bp_pt_code = t_ptech.pt_code;

  
/*vs_elem_cs_bp_pt_nd*/  
DROP VIEW IF EXISTS "vs_elem_cs_bp_pt_nd";
CREATE VIEW "vs_elem_cs_bp_pt_nd" AS
SELECT 
  * 
FROM 
  t_cassette,
  t_ebp, 
  t_ptech, 
  t_noeud 
WHERE 
  t_ptech.pt_nd_code = t_noeud.nd_code AND
  t_ebp.bp_pt_code = t_ptech.pt_code AND
  t_cassette.cs_bp_code = t_ebp.bp_code;

  
/*vs_elem_se_nd*/  
DROP VIEW IF EXISTS "vs_elem_se_nd";
CREATE VIEW "vs_elem_se_nd" AS
SELECT 
  * 
FROM 
  t_siteemission, 
  t_noeud
WHERE 
  t_siteemission.se_nd_code = t_noeud.nd_code;
  

/*vs_elem_do_em*/  
DROP VIEW IF EXISTS "vs_elem_do_em";
CREATE VIEW "vs_elem_do_em" AS
SELECT 
  * 
FROM 
  t_document, 
  t_empreinte
WHERE 
  t_empreinte.em_do_code = t_document.do_code;
  
  
/*vs_elem_cd_dm_cm*/ 
DROP VIEW IF EXISTS "vs_elem_cd_dm_cm";
CREATE VIEW "vs_elem_cd_dm_cm" AS
SELECT 
  t_cond_chem.dm_cd_code || t_cond_chem.dm_cm_code AS dm_id,
  * 
FROM 
  t_conduite,
  t_cond_chem, 
  t_cheminement 
WHERE 
  t_cheminement.cm_code = t_cond_chem.dm_cm_code AND
  t_cond_chem.dm_cd_code = t_conduite.cd_code;

  
/*vs_elem_cb_nd*/
DROP VIEW IF EXISTS vs_elem_cb_nd;
CREATE VIEW vs_elem_cb_nd AS
SELECT DISTINCT
  'ND1-' || cb.cb_code || '_' || cb.cb_nd1 AS cb_nd,
  * 
FROM 
  t_cable AS cb, 
  t_noeud AS nd
WHERE 
  cb.cb_nd1 = nd.nd_code
UNION
SELECT DISTINCT
  'ND2-' || cb.cb_code || '_' || cb.cb_nd1 AS cb_nd,
  * 
FROM 
  t_cable AS cb, 
  t_noeud AS nd
WHERE 
  cb.cb_nd2 = nd.nd_code;

-- Parti Creation des erreurs de cles etrangere rapport au Modele MCD
DROP FUNCTION If EXISTS function_check_attribut_cles_entrangeres(text,text);
CREATE OR REPLACE FUNCTION function_check_attribut_cles_entrangeres(schem_input text,schem_mode_mcd text) RETURNS void AS
$$
DECLARE
var_req_execute record;
BEGIN
	EXECUTE 'DROP TABLE IF EXISTS  check_attribut_cles_etrangeres';
	EXECUTE 'CREATE TABLE check_attribut_cles_etrangeres(  def text,  attribut text)';
	FOR var_req_execute in
		SELECT distinct
		    'INSERT INTO '||schem_input||'.check_attribut_cles_etrangeres ' ||
		    'select ''Attribut manquant dans '||ccu.column_name||'_'||ccu.table_name||
		    ' Mais present dans '||kcu.column_name||'_'||tc.table_name||''' as attribut_manquant,'||kcu.column_name||'::text as attribut'||
		    ' from '||schem_input||'.'||tc.table_name||' where '||kcu.column_name||' not in (select '||ccu.column_name||' from '||
		    schem_input||'.'||ccu.table_name||' union select '''') '||'and '||kcu.column_name|| ' is not null;' as erreur_tt_tl
		FROM information_schema.table_constraints tc
		JOIN information_schema.key_column_usage kcu ON tc.constraint_name = kcu.constraint_name
		JOIN information_schema.constraint_column_usage ccu ON ccu.constraint_name = tc.constraint_name
		WHERE constraint_type = 'FOREIGN KEY'
		AND tc.table_schema = ''||schem_mode_mcd||'' and ccu.table_name like 't_%'
	LOOP
		-- RAISE NOTICE '%', var_req_execute.column_name;
		IF var_req_execute.erreur_tt_tl is not null then
			EXECUTE var_req_execute.erreur_tt_tl;
		END IF;
	END LOOP;
END;
$$ LANGUAGE plpgsql;

select * from function_check_attribut_cles_entrangeres('trans_model','gracethd');
