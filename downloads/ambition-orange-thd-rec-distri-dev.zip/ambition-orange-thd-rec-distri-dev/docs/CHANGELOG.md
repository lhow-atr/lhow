# Changelog Notes
## Tags
- v_2023_01_03
- v_2023_01_16
- v_2023_01_17
- v_2023_02_16
- v_2023_03_20
- vp_2021_03_25
## Commits
- Modification de la requete RCAB.015 afin les erreurs remontent (5a12287) (Babacar FASSA) (2023-03-20)
- Correction sur lexecution du build (cdd644b) (Babacar FASSA) (2023-02-16)
- passer la criticité des erreurs de « Bloquant (KO) » à « Avertissement (NOK) » sur les contrôles suivants : RPTE.007 (Distri et Transport), REBP.012 (Distri et Transport), REBP.015 (Distri) (b523107) (Babacar FASSA) (2023-02-16)
- Correction erreur mise a jour plugin (e40fa4b) (Babacar FASSA) (2023-01-17)
- Correction erreur qmessageBox et ajout le changelog dans la documentation (618d308) (Babacar FASSA) (2023-01-16)
- Correction erreur qmessageBox et ajout le changelog dans la documentation (d39a1bd) (Babacar FASSA) (2023-01-16)
- Correction erreur qmessageBox et ajout le changelog dans la documentation (d14d18f) (Babacar FASSA) (2023-01-16)
- Migration vers qgis3.22 version finale avec ajout de la methode du deploiement continu ainsi que la documentation avec mkdocs et la creation de tag a chaque modifications (1b160df) (Babacar FASSA) (2023-01-03)
- Migration vers qgis3.22 version finale avec ajout de la methode du deploiement continu ainsi que la documentation avec mkdocs et la creation de tag a chaque modifications (5783e5f) (Babacar FASSA) (2023-01-03)
- Migration vers qgis3.22 version finale avec ajout de la methode du deploiement continu ainsi que la documentation avec mkdocs (1e4ca2d) (Babacar FASSA) (2022-12-29)
- Migration vers qgis3.22 version finale avec ajout de la methode du deploiement continu ainsi que la documentation avec mkdocs (0b5470e) (Babacar FASSA) (2022-12-29)
- IMP: close#1; Modifier le controle RCAB.011 (4fefbe2) (Babacar FASSA) (2022-10-10)
- IMP: DEV: 'Ajout des controls de RCAB.017;CABLE;Bloquant (KO);CABLE - INCOHERENCE LONGUEUR REEL; REBP.015;BOITIER;Bloquant (KO);BPE – ZONE DE CONTOUR PBO CHEVAUCHE ZONE DE CONTOUR PA ' (f183e33) (Babacar) (2021-04-01)
- IMP: 'Mise en Prod de la version test' (a13e210) (Babacar) (2021-03-25)
- IMP: 'I.	Modifications 1.	RSRO.010 (SRO - INCOHERENCE DATE D'INSTALLATION) a mettre « Avertissement - (NOK) » plutôt que « Bloquant – (KO==> OK 2.	Suppression de la colonne geometrie de la table t_controle ==> OK 3.	Debogage de l'erreur sur les points techniques: a.	le probléme vient sur la récupération des rb_volume (avec une jointure entre t_ptech, t_ebp et t_ref_ebp). Si derniers etaient nuls ce qui bloquaient le traitement. Pour pallier a cette erreur, j'ai intégré la possibilité d'avoir des valeurs nulles qui seront tagué à '0' sans autant bloqué le traitement, évidement ces valeurs nulles sont juste ignorées (a50ce0c) (Babacar) (2021-02-22)
## Merges
## AUTHORS
- Babacar
- Babacar FASSA
