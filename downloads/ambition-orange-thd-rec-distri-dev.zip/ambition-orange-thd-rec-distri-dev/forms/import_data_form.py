from qgis.PyQt import QtCore, QtWidgets
from qgis.gui import QgsDateTimeEdit, QgsFileWidget
from qgis.core import QgsApplication
from qgis.utils import iface
from qgis.PyQt.QtWidgets import QWidget, QMessageBox
import psycopg2
import datetime
import sys
from pathlib import Path

# # {
# # Initialize QGIS Application
# app = QgsApplication([], False)
# QgsApplication.setPrefixPath("C:\QGIS 3.22.13\apps\qgis-ltr", True)
# QgsApplication.initQgis()

folder_plugin = str(Path(__file__).parent.parent)
sys.path.append(folder_plugin)

from bdd_bthd.params_connexion import function_connexion
from scripts_python.file_import_csv_shp import function_execute_import_export, function_execute_class_check_data


class ClassUiImportBthdDialog(object):
    def setupUi(self, var_dialog):
        self.now = datetime.datetime.now()

        # Partie de la declaration de la fenetre de boite de dialog
        var_dialog.setObjectName("CheckBthdDialog")
        var_dialog.setWindowModality(QtCore.Qt.ApplicationModal)
        var_dialog.setEnabled(True)
        var_dialog.resize(800, 800)
        var_dialog.setMouseTracking(False)
        var_dialog.setWindowTitle("DESIGN v0.01 - Importation des donnees dans la BDD")

        # Partie de la creation dun container de dessin de la boite de dialog
        self.verticalLayoutWidget = QtWidgets.QWidget(var_dialog)
        self.verticalLayoutWidget.setGeometry(QtCore.QRect(30, 30, 700, 700))
        self.verticalLayoutWidget.setObjectName("verticalLayoutWidget")

        # Partie de la creation sous container
        self.verticalLayout = QtWidgets.QVBoxLayout(self.verticalLayoutWidget)
        self.verticalLayout.setContentsMargins(0, 0, 0, 0)
        self.verticalLayout.setObjectName("verticalLayout")

        # Partie de la creation d'une Grille pour organiser les labels et leur object
        self.gridLayout = QtWidgets.QGridLayout()
        self.gridLayout.setObjectName("gridLayout")

        # Ligne 0
        # Partie de la creation du Choisir la date
        self.label_code_deploi_dep = QtWidgets.QLabel(self.verticalLayoutWidget)
        self.label_code_deploi_dep.setObjectName("label_code_deploi_dep")
        self.label_code_deploi_dep.setText("Code déploiement + département")
        self.gridLayout.addWidget(self.label_code_deploi_dep, 0, 0)  # Ajout du label dans la grille

        # Partie de la creation du label_code_affaire
        self.label_code_affaire = QtWidgets.QLabel(self.verticalLayoutWidget)
        self.label_code_affaire.setObjectName("label_code_affaire")
        self.label_code_affaire.setText("Code affaire")
        self.gridLayout.addWidget(self.label_code_affaire, 0, 1)  # Ajout du label dans la grille

        # Partie de la creation du label Choisir la date
        self.label_date = QtWidgets.QLabel(self.verticalLayoutWidget)
        self.label_date.setObjectName("label_date")
        self.label_date.setText("Choisir la date")
        self.gridLayout.addWidget(self.label_date, 0, 2)

        # Ligne Un
        # Partie de la creation du label_trigramme_nro
        self.label_trigramme_nro = QtWidgets.QLabel(self.verticalLayoutWidget)
        self.label_trigramme_nro.setObjectName("label_trigramme_nro")
        self.label_trigramme_nro.setText("Trigramme NRO")
        self.gridLayout.addWidget(self.label_trigramme_nro, 2, 0)  # Ajout du label dans la grille

        # Partie de la creation du label_code_affaire
        self.label_insee_nro = QtWidgets.QLabel(self.verticalLayoutWidget)
        self.label_insee_nro.setObjectName("label_insee_nro")
        self.label_insee_nro.setText("Insee NRO")
        self.gridLayout.addWidget(self.label_insee_nro, 2, 1)  # Ajout du label dans la grille

        # Partie de la creation du label_code_affaire
        self.label_code_armoire = QtWidgets.QLabel(self.verticalLayoutWidget)
        self.label_code_armoire.setObjectName("label_code_armoire")
        self.label_code_armoire.setText("Code Armoire")
        self.gridLayout.addWidget(self.label_code_armoire, 2, 2)  # Ajout du label dans la grille

        # Ligne Deux
        # Partie de la creation du Nom name_depart_nro
        self.name_deploi_dep = QtWidgets.QLineEdit(self.verticalLayoutWidget)
        self.name_deploi_dep.setMinimumSize(QtCore.QSize(111, 0))
        self.name_deploi_dep.setObjectName("name_deploi_dep")
        self.name_deploi_dep.setText("T2-29")
        self.gridLayout.addWidget(self.name_deploi_dep, 1, 0)  # Ajout du label dans la grille

        # Partie de la creation du Nom name_code_affaire
        self.name_code_affaire = QtWidgets.QLineEdit(self.verticalLayoutWidget)
        self.name_code_affaire.setMinimumSize(QtCore.QSize(111, 0))
        self.name_code_affaire.setObjectName("name_code_affaire")
        self.name_code_affaire.setText("01109")
        self.gridLayout.addWidget(self.name_code_affaire, 1, 1)

        # Partie de la creation du Nom name_date
        self.name_date = QgsDateTimeEdit(self.verticalLayoutWidget)
        self.name_date.setDateTime(QtCore.QDateTime(QtCore.QDate(self.now.year, self.now.month, self.now.day),
                                                    QtCore.QTime(self.now.hour, self.now.minute, self.now.second)))
        # self.name_date.setEnabled(True)
        # self.name_date.setMinimumSize(QtCore.QSize(110, 0))
        # self.name_date.setDateTime(QtCore.QDateTime(QtCore.QDate(self.now.year, self.now.month, self.now.day)))
        # self.name_date.setCalendarPopup(True)
        # self.name_date.setAllowNull(False)
        self.name_date.setObjectName("name_date")
        self.gridLayout.addWidget(self.name_date, 1, 2)

        # Ligne Trois
        # Partie de la creation du Nom name_trigrame_nro
        self.name_trigrame_nro = QtWidgets.QLineEdit(self.verticalLayoutWidget)
        self.name_trigrame_nro.setMinimumSize(QtCore.QSize(111, 0))
        self.name_trigrame_nro.setObjectName("name_trigrame_nro")
        self.name_trigrame_nro.setText("CRO")
        self.gridLayout.addWidget(self.name_trigrame_nro, 3, 0)

        # Partie de la creation du Nom name_insee_nro
        self.name_insee_nro = QtWidgets.QLineEdit(self.verticalLayoutWidget)
        self.name_insee_nro.setMinimumSize(QtCore.QSize(111, 0))
        self.name_insee_nro.setObjectName("name_insee_nro")
        self.name_insee_nro.setText("29042")
        self.gridLayout.addWidget(self.name_insee_nro, 3, 1)

        # Partie de la creation du Nom name_insee_nro
        self.name_code_armoire = QtWidgets.QLineEdit(self.verticalLayoutWidget)
        self.name_code_armoire.setMinimumSize(QtCore.QSize(111, 0))
        self.name_code_armoire.setObjectName("name_code_armoire")
        self.name_code_armoire.setText("S029")
        self.gridLayout.addWidget(self.name_code_armoire, 3, 2)
        self.verticalLayout.addLayout(self.gridLayout)  # Ajout de la grille dans le vertitcallayout

        # Partie de la creation du label label_folder
        self.label_folder = QtWidgets.QLabel(self.verticalLayoutWidget)
        self.label_folder.setObjectName("label_folder")
        self.label_folder.setText("Dossier GraceTHD")
        # self.gridLayout.addWidget(self.label_folder, 4, 0)
        self.verticalLayout.addWidget(self.label_folder)
        self.name_directory = QgsFileWidget(self.verticalLayoutWidget)
        self.name_directory.setObjectName("name_directory")
        self.name_directory.setStorageMode(QgsFileWidget.GetDirectory)
        self.verticalLayout.addWidget(self.name_directory)
        # self.gridLayout.addWidget(self.name_directory, 5, 0)

        # Partie de la creation du Nom textBrowser
        self.textBrowser = QtWidgets.QTextBrowser(self.verticalLayoutWidget)
        self.textBrowser.setObjectName("textBrowser")
        self.textBrowser.setHtml(
            # Ouverture Parametrage du HTML
            """
            <!DOCTYPE html>
            <html lang="en">
            <head>
                <meta charset="UTF-8">
                <title>Title</title>
                <style type="text/css">
                    div, li {text-indent: 25px; font-size:11pt}
                    body {text-align: justify; font: sans-serif;}
                </style>
            </head>
            <body>
            """

            # Corp du text
            """
            <h3> Objectifs: </h3>
                <div> Ce module permet d'importer des données dans la bdd dans le schema déclaré dans l'interface. </div>
            <h3> Données en entrée: </h3>
                <div> 
                    Les données correspondent à des fichiers csv et shp uniqument se trouvant dans un dossier déclaré dans l'interface
                </div>
            <h3> Résultat: </h3>
                <div> Dans le schema declaré dans l'interface, il se trouve les données importées </div>
            <h3> Restrictions:</h3>
                <ol>
                  <li> Code déploiement+departement sous la forme suivante : 'T2-29'</li>
                  <li> Code affaire sous la forme : '01109'</li>
                  <li> Trigramme NRO sous la forme : 'CRO'</li>
                  <li> INSEE NRO sous la forme : '29042'</li>
                  <li> Code armoire MEGALIS sous la forme : 'S029'</li>
                </ol>
            """

            # Fin Parametrage du HTML
            """
            < / body >
            < / html > """
        )
        self.verticalLayout.addWidget(self.textBrowser)  # Ajout du textBrowser dans le vertitcallayout

        # Partie de la creation du Nom button_box
        self.button_box = QtWidgets.QDialogButtonBox(self.verticalLayoutWidget)
        self.button_box.setOrientation(QtCore.Qt.Horizontal)
        self.button_box.setStandardButtons(QtWidgets.QDialogButtonBox.Cancel | QtWidgets.QDialogButtonBox.Ok)
        self.button_box.setObjectName("button_box")
        self.verticalLayout.addWidget(self.button_box)  # Ajout du button_box dans le vertitcallayout

        # self.retranslateUi(Controle_Des_DesignDialogBase)
        self.button_box.accepted.connect(var_dialog.accept)
        self.button_box.rejected.connect(var_dialog.reject)
        QtCore.QMetaObject.connectSlotsByName(var_dialog)


class ClassGeneralDialog(QtWidgets.QDialog):
    def __init__(self, iface, var_connection):
        QtWidgets.QDialog.__init__(self)
        self.iface = iface
        self.connection = var_connection

    # Function pour executer une requete sql dans la base
    def function_execute_requete(self, requete_execute, req_fetch):
        curs = self.connection.cursor()
        try:
            curs.execute(requete_execute)
            if req_fetch:
                data_req = [row for row in curs.fetchall()]
                if data_req:
                    curs.close()
                    return data_req
        except(Exception, psycopg2.DatabaseError) as error:
            QMessageBox.critical(self.iface.mainWindow(), "Message dexecution de requete",
                                 'Requete Non Executer : ' + str(error) + ' ; ' + str(requete_execute))

    # Function pour recuperer les chemas
    def get_all_schema_name(self, list_widget):
        req_get_schema = """select schema_name from information_schema.schemata order by schema_name;"""
        list_schema_name = self.function_execute_requete(req_get_schema, 'bab')
        if list_schema_name:
            for index, name_schema in enumerate(list_schema_name):
                if name_schema:
                    list_widget.addItem("")
                    list_widget.setItemText(index, name_schema[0])
        else:
            QMessageBox.critical(self.iface.mainWindow(), "Message Du Choix", 'Error List Schema')

    # Function pour recuperer la version
    def get_version_plugin(self):
        folder_metada = open(folder_plugin + "\metadata.txt")
        for line in folder_metada:
            if str(line)[:7] == 'version':
                get_version = line.split('=')[1]
                return get_version
        folder_metada.close()


class ClassCheckImportExecuteDialog(ClassGeneralDialog, ClassUiImportBthdDialog):

    def __init__(self, iface):
        self.var_connection = function_connexion()
        ClassGeneralDialog.__init__(self, iface, self.var_connection)
        self.setupUi(self)
        self.setWindowTitle("BTHD-ORANGE " + str(self.get_version_plugin()) + " - Import des données")
        self.var_connection.close()
        self.button_box.button(QtWidgets.QDialogButtonBox.Ok).clicked.connect(self.run)

    def run(self):
        w = QWidget()
        date = self.name_date.date().toString("yyyyMMdd")
        time = QtCore.QTime(self.now.hour, self.now.minute, self.now.second).toString("HHmm")
        name_schema = f"RECD_Z{self.name_code_affaire.text()}_v{date}{time}".lower()
        name_folder = str(self.name_directory.filePath())
        # QMessageBox.critical(self.iface.mainWindow(), "Message Du Choix", f'{name_schema}\n{name_folder}')
        res_import = function_execute_import_export(name_schema, name_folder, 'import')
        res_check = function_execute_class_check_data(name_schema, 'REC')
        QMessageBox.information(w, "Message-Execution-Plugin", f"Tables importees: {len(res_import[1])}\n"
                                                    f"Error Import: {' '.join(map(str, res_import[2]))}\n"
                                                    f"Error Create GraceTHD: {' '.join(map(str, res_check[0]))}\n"
                                                    f"Error Create GraceTHDChck: {' '.join(map(str, res_check[1]))}")
        # QMessageBox.information(w, "Message-Execution-Plugin", f"Fin")


# # {
# baba_dialog = ClassCheckImportExecuteDialog(iface)
# baba_dialog.show()
# sys.exit(app.exec_())
