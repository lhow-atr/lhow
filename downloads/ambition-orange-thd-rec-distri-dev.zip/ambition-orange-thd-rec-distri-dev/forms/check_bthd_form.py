from qgis.PyQt import QtCore, QtWidgets
from qgis.gui import QgsCheckableComboBox
from qgis.core import QgsApplication
from qgis.PyQt.QtWidgets import QWidget, QMessageBox
from qgis.utils import iface
import psycopg2
import sys
from pathlib import Path

# # {
# # Initialize QGIS Application
# app = QgsApplication([], False)
# QgsApplication.setPrefixPath("C:\QGIS 3.22.13\apps\qgis-ltr", True)
# QgsApplication.initQgis()

folder_plugin = str(Path(__file__).parent.parent)
sys.path.append(folder_plugin)
from bdd_bthd.params_connexion import function_connexion
from scripts_python.design_bthd_bretagne import function_execute_dicopointcontrolesthdbdistribution


class ClassUiCheckBthdDialog(object):
    def setupUi(self, var_dialog):

        # Partie de la declaration de la fenetre de boite de dialog
        var_dialog.setObjectName("CheckBthdDialog")
        var_dialog.setWindowModality(QtCore.Qt.ApplicationModal)
        var_dialog.setEnabled(True)
        var_dialog.resize(800, 800)
        var_dialog.setMouseTracking(False)
        var_dialog.setWindowTitle("DESIGN v0.01 - Importation des donnees dans la BDD")

        # Partie de la creation dun container de dessin de la boite de dialog
        self.verticalLayoutWidget = QtWidgets.QWidget(var_dialog)
        self.verticalLayoutWidget.setGeometry(QtCore.QRect(30, 30, 700, 700))
        self.verticalLayoutWidget.setObjectName("verticalLayoutWidget")

        # Partie de la creation sous container
        self.verticalLayout = QtWidgets.QVBoxLayout(self.verticalLayoutWidget)
        self.verticalLayout.setContentsMargins(0, 0, 0, 0)
        self.verticalLayout.setObjectName("verticalLayout")

        # Partie de la creation d'une Grille pour organiser les labels et leur object
        self.gridLayout = QtWidgets.QGridLayout()
        self.gridLayout.setObjectName("gridLayout")

        # Ligne 0
        # Partie de la creation du label Nom_PR
        self.label_schema_etude = QtWidgets.QLabel(self.verticalLayoutWidget)
        self.label_schema_etude.setObjectName("label_schema_etude")
        self.label_schema_etude.setText("Schema Etude")
        self.gridLayout.addWidget(self.label_schema_etude, 0, 0)  # Ajout du label dans la grille

        # # Partie de la creation du label Statut
        # self.label_schema_ogre = QtWidgets.QLabel(self.verticalLayoutWidget)
        # self.label_schema_ogre.setObjectName("label_schema_ogre")
        # self.label_schema_ogre.setText("Schema Ogre")
        # self.gridLayout.addWidget(self.label_schema_ogre, 0, 1)  # Ajout du label dans la grille

        # Partie de la creation du Choisir la date
        self.label_code_deploi_dep = QtWidgets.QLabel(self.verticalLayoutWidget)
        self.label_code_deploi_dep.setObjectName("label_code_deploi_dep")
        self.label_code_deploi_dep.setText("Code déploiement + département")
        self.gridLayout.addWidget(self.label_code_deploi_dep, 0, 1)  # Ajout du label dans la grille

        # Partie de la creation du Choisir la date
        self.label_schema_depart_nro = QtWidgets.QLabel(self.verticalLayoutWidget)
        self.label_schema_depart_nro.setObjectName("label_schema_depart_nro")
        self.label_schema_depart_nro.setText("Code départ pour le parcours")
        self.gridLayout.addWidget(self.label_schema_depart_nro, 4, 1)  # Ajout du label dans la grille

        # Ligne Un
        # Partie de la creation du label_code_affaire
        self.label_code_affaire = QtWidgets.QLabel(self.verticalLayoutWidget)
        self.label_code_affaire.setObjectName("label_code_affaire")
        self.label_code_affaire.setText("Code affaire")
        self.gridLayout.addWidget(self.label_code_affaire, 2, 0)  # Ajout du label dans la grille

        # Partie de la creation du label_trigramme_nro
        self.label_trigramme_nro = QtWidgets.QLabel(self.verticalLayoutWidget)
        self.label_trigramme_nro.setObjectName("label_trigramme_nro")
        self.label_trigramme_nro.setText("Trigramme NRO")
        self.gridLayout.addWidget(self.label_trigramme_nro, 2, 1)  # Ajout du label dans la grille

        # Partie de la creation du label_code_affaire
        self.label_insee_nro = QtWidgets.QLabel(self.verticalLayoutWidget)
        self.label_insee_nro.setObjectName("label_insee_nro")
        self.label_insee_nro.setText("Insee NRO")
        self.gridLayout.addWidget(self.label_insee_nro, 2, 2)  # Ajout du label dans la grille

        # Partie de la creation du label_code_affaire
        self.label_code_armoire = QtWidgets.QLabel(self.verticalLayoutWidget)
        self.label_code_armoire.setObjectName("label_code_armoire")
        self.label_code_armoire.setText("Code Armoire")
        self.gridLayout.addWidget(self.label_code_armoire, 4, 0)  # Ajout du label dans la grille

        # Ligne Deux
        # Partie de la creation du Nom pr_baba
        self.name_schema_etude = QgsCheckableComboBox(self.verticalLayoutWidget)
        self.name_schema_etude.setMinimumSize(QtCore.QSize(111, 0))
        self.name_schema_etude.setObjectName("name_schema_etude")
        self.gridLayout.addWidget(self.name_schema_etude, 1, 0)  # Ajout du label dans la grille

        # # Partie de la creation du Nom name_schema_ogre
        # self.name_schema_ogre = QgsCheckableComboBox(self.verticalLayoutWidget)
        # self.name_schema_ogre.setMinimumSize(QtCore.QSize(111, 0))
        # self.name_schema_ogre.setObjectName("name_schema_ogre")
        # self.gridLayout.addWidget(self.name_schema_ogre, 1, 1)  # Ajout du label dans la grille

        # Partie de la creation du Nom name_depart_nro
        self.name_deploi_dep = QtWidgets.QLineEdit(self.verticalLayoutWidget)
        self.name_deploi_dep.setMinimumSize(QtCore.QSize(111, 0))
        self.name_deploi_dep.setObjectName("name_deploi_dep")
        self.name_deploi_dep.setText("T2-29")
        self.gridLayout.addWidget(self.name_deploi_dep, 1, 1)  # Ajout du label dans la grille

        # Partie de la creation du Nom name_depart_nro
        self.name_depart_nro = QtWidgets.QLineEdit(self.verticalLayoutWidget)
        self.name_depart_nro.setMinimumSize(QtCore.QSize(111, 0))
        self.name_depart_nro.setObjectName("name_depart_nro")
        self.name_depart_nro.setText("NDMB2104300001")
        self.gridLayout.addWidget(self.name_depart_nro, 5, 1)  # Ajout du label dans la grille

        # Ligne Trois
        # Partie de la creation du Nom name_code_affaire
        self.name_code_affaire = QtWidgets.QLineEdit(self.verticalLayoutWidget)
        self.name_code_affaire.setMinimumSize(QtCore.QSize(111, 0))
        self.name_code_affaire.setObjectName("name_code_affaire")
        self.name_code_affaire.setText("01109")
        self.gridLayout.addWidget(self.name_code_affaire, 3, 0)

        # Partie de la creation du Nom name_trigrame_nro
        self.name_trigrame_nro = QtWidgets.QLineEdit(self.verticalLayoutWidget)
        self.name_trigrame_nro.setMinimumSize(QtCore.QSize(111, 0))
        self.name_trigrame_nro.setObjectName("name_trigrame_nro")
        self.name_trigrame_nro.setText("CRO")
        self.gridLayout.addWidget(self.name_trigrame_nro, 3, 1)

        # Partie de la creation du Nom name_insee_nro
        self.name_insee_nro = QtWidgets.QLineEdit(self.verticalLayoutWidget)
        self.name_insee_nro.setMinimumSize(QtCore.QSize(111, 0))
        self.name_insee_nro.setObjectName("name_insee_nro")
        self.name_insee_nro.setText("29042")
        self.gridLayout.addWidget(self.name_insee_nro, 3, 2)

        # Partie de la creation du Nom name_insee_nro
        self.name_code_armoire = QtWidgets.QLineEdit(self.verticalLayoutWidget)
        self.name_code_armoire.setMinimumSize(QtCore.QSize(111, 0))
        self.name_code_armoire.setObjectName("name_code_armoire")
        self.name_code_armoire.setText("S029")
        self.gridLayout.addWidget(self.name_code_armoire, 5, 0)

        self.verticalLayout.addLayout(self.gridLayout)  # Ajout de la grille dans le vertitcallayout

        # Partie de la creation du Nom textBrowser
        self.textBrowser = QtWidgets.QTextBrowser(self.verticalLayoutWidget)
        self.textBrowser.setObjectName("textBrowser")
        self.textBrowser.setHtml(
            # Ouverture Parametrage du HTML
            """
            <!DOCTYPE html>
            <html lang="en">
            <head>
                <meta charset="UTF-8">
                <title>Title</title>
                <style type="text/css">
                    div, li {text-indent: 25px; font-size:11pt}
                    body {text-align: justify; font: sans-serif;}
                </style>
            </head>
            <body>
            """

            # Corp du text
            """
            <h3> Objectifs: </h3>
                <div> Ce module permet de lancer les traitements THDB sur les données importées en base de données. </div>
            <h3> Données en entrée: </h3>
                <div> 
                    Les données correspondent de deux schemas: un schema étude et un schema OGRE ainsi que les attributs
                    declarés dans cet interface
                </div>
            <h3> Résultat: </h3>
                <div> Les résultats sont dans la table: t_controle dans le schema étude declaré dans l'interface</div>
            <h3> Contraintes: </h3>
                <div> Tous les variables de l'interface doivent etre renseignés et correspodants aux données.</div>
            """

            # Fin Parametrage du HTML
            """
            < / body >
            < / html > """
        )
        self.verticalLayout.addWidget(self.textBrowser)  # Ajout du textBrowser dans le vertitcallayout

        # Partie de la creation du Nom button_box
        self.button_box = QtWidgets.QDialogButtonBox(self.verticalLayoutWidget)
        self.button_box.setOrientation(QtCore.Qt.Horizontal)
        self.button_box.setStandardButtons(QtWidgets.QDialogButtonBox.Cancel | QtWidgets.QDialogButtonBox.Ok)
        self.button_box.setObjectName("button_box")
        self.verticalLayout.addWidget(self.button_box)  # Ajout du button_box dans le vertitcallayout

        # self.retranslateUi(Controle_Des_DesignDialogBase)
        self.button_box.accepted.connect(var_dialog.accept)
        self.button_box.rejected.connect(var_dialog.reject)
        QtCore.QMetaObject.connectSlotsByName(var_dialog)


class ClassGeneralDialog(QtWidgets.QDialog):
    def __init__(self, iface, var_connection):
        QtWidgets.QDialog.__init__(self)
        self.iface = iface
        self.connection = var_connection

    # Function pour executer une requete sql dans la base
    def function_execute_requete(self, requete_execute, req_fetch):
        curs = self.connection.cursor()
        try:
            curs.execute(requete_execute)
            if req_fetch:
                data_req = [row for row in curs.fetchall()]
                if data_req:
                    curs.close()
                    return data_req
        except(Exception, psycopg2.DatabaseError) as error:
            QMessageBox.critical(self.iface.mainWindow(), "Message dexecution de requete",
                                 'Requete Non Executer : ' + str(error) + ' ; ' + str(requete_execute))

    # Function pour recuperer les chemas
    def get_all_schema_name(self, list_widget):
        req_get_schema = """select schema_name from information_schema.schemata order by schema_name;"""
        list_schema_name = self.function_execute_requete(req_get_schema, 'bab')
        if list_schema_name:
            for index, name_schema in enumerate(list_schema_name):
                if name_schema:
                    list_widget.addItem("")
                    list_widget.setItemText(index, name_schema[0])
        else:
            QMessageBox.critical(self.iface.mainWindow(), "Message Du Choix", 'Error List Schema')

    # Function pour recuperer la version
    def get_version_plugin(self):
        folder_metada = open(folder_plugin + "\metadata.txt")
        for line in folder_metada:
            if str(line)[:7] == 'version':
                get_version = line.split('=')[1]
                folder_metada.close()
                return get_version


class ClassCheckBthdDistriExecuteDialog(ClassGeneralDialog, ClassUiCheckBthdDialog):

    def __init__(self, iface):
        self.var_connection = function_connexion()
        ClassGeneralDialog.__init__(self, iface, self.var_connection)
        self.setupUi(self)
        self.get_all_schema_name(self.name_schema_etude)
        # {self.get_all_schema_name(self.name_schema_ogre)
        self.setWindowTitle("BTHD-ORANGE " + str(self.get_version_plugin()) + " - Controle REC-DISTRI")
        self.var_connection.close()
        self.button_box.button(QtWidgets.QDialogButtonBox.Ok).clicked.connect(self.run)

    def run(self):
        text_schema_etude = [x for x in self.name_schema_etude.currentText().split(',') if x]
        # {text_schema_ogre = [x for x in self.name_schema_ogre.currentText().split(',') if x]

        if len(text_schema_etude) != 1:
            QMessageBox.critical(QWidget(), "Message Du Choix", 'Veillez cocher un Seul schema')
        else:

            schema_etude = "".join(text_schema_etude)
            # {schema_ogre = "".join(text_schema_ogre)
            code_deploi_dep = self.name_deploi_dep.text()
            depart_nro = self.name_depart_nro.text()
            code_affaire = self.name_code_affaire.text()
            trigrame_nro = self.name_trigrame_nro.text()
            insee_nro = self.name_insee_nro.text()
            code_armoire = self.name_code_armoire.text()
            function_execute_dicopointcontrolesthdbdistribution(schema_etude, schema_etude,
                                                                depart_nro, 'DI', code_deploi_dep, code_affaire,
                                                                trigrame_nro, insee_nro, code_armoire)


# # {
# baba_dialog = ClassCheckBthdDistriExecuteDialog(iface)
# baba_dialog.show()
# sys.exit(app.exec_())

