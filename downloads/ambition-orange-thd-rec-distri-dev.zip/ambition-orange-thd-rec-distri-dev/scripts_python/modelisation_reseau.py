# Classse Generale
import itertools
from qgis.PyQt.QtCore import Qt, QVariant
from qgis.core import QgsVectorLayer, QgsProject, QgsMapLayer, QgsGeometry, QgsWkbTypes, QgsPointXY, QgsFeatureRequest, QgsDataSourceUri, QgsField, QgsFeature, NULL, Qgis, QgsMultiLineString
from qgis.utils import iface
from qgis.PyQt.QtWidgets import QWidget, QProgressDialog, QMessageBox
import psycopg2

import re
import sys
from pathlib import Path

# {from qgis.PyQt.QtWidgets import QApplication
# app = QApplication(sys.argv)

folder_plugin = str(Path(__file__).parent.parent)
sys.path.append(folder_plugin)
from bdd_bthd.params_connexion import function_connexion, DB, user, MP, host, port

# {folder_plugin = r'C:\Users\babacar.fassa.AMBITION\Documents\GitHub\orange-thdb-rec-distri'#'C:\Users\babacar.fassa\Documents\GitHub\orange-thdb-rec-distri'
# sys.path.append(folder_plugin)
# from bdd_bthd.params_connexion import function_connexion, DB, user, MP, host, port


# Class pour les fonctions generales
class GeneralFunctions:
    w = QWidget()

    # Function pour la progession bar1
    @staticmethod
    def progress_bar(name_etape):
        prog = QProgressDialog(name_etape + ' : Veillez Patienter', 'Cancel', 0, 100)
        prog.setWindowModality(Qt.WindowModal)
        prog.setMinimumDuration(1)
        return prog

    # Function pour la progession bar2
    @staticmethod
    def progress_processing(index, count_entite, progress_dialog):
        f = int(index + 1)
        pcnt = int(f / count_entite * 100 / 1)
        progress_dialog.setValue(pcnt)

    # Return Not Null Value attribut
    @staticmethod
    def function_return_not_null(field):
        if field == NULL:
            return 'Identifiant NULL pour cette entite'
        else:
            return field

    # Function pour identifier les doublons didentifiant
    @staticmethod
    def get_doublon(count_doublon_list):
        counts = {}
        result_double_list = []
        for i in count_doublon_list:
            counts[i[1]] = counts.get(i[1], 0) + 1
        for key, value in counts.items():
            if value > 1:
                for i in count_doublon_list:
                    if i[1] == key:
                        result_double_list.append([i[0], key])
        return result_double_list

    # Function pour  Get layer dans la BD
    def function_getlayer_bdd(self, schema, table_name, key, rename_table, column_geom):
        global DB, user, MP, host, port
        uri = QgsDataSourceUri()
        uri.setConnection(host, port, DB, user, MP)
        uri.setDataSource(schema, table_name, column_geom, '', key)
        layer = QgsVectorLayer(uri.uri(False), rename_table, "postgres")
        if layer.isValid():
            return layer
        else:
            return QMessageBox.warning(self.w, "Message", 'Erreur de recuperation de la table : ' + str(table_name))


# Class pour la modelisation des reseaux
class ModelisationReseau(GeneralFunctions):
    w = QWidget()

    def __init__(self, var_connection, var_schema, var_type_sitetech_depart, var_t_noeud='t_noeud',
                 var_vs_elem_cl_cb='vs_elem_cl_cb', var_nd_code='nd_code', var_cb_code='cb_code',
                 var_distance_buffer='0.1'):

        self.connection = var_connection
        self.db_cursor = self.connection.cursor()
        self.liste_erreur_modelisation = []
        self.list_shape_ligne = []
        self.list_shape_point = []
        self.liste_message_execution_function = []

        self.schema = var_schema
        self.point_val_depart = var_type_sitetech_depart  # 'NRO+SROL'
        self.name_point_tab = var_t_noeud  # 't_noeud'
        self.name_line = var_vs_elem_cl_cb  # 'vs_elem_cl_cb'
        self.name_point_attribut = var_nd_code  # 'nd_code'
        self.name_line_attribut = var_cb_code  # 'cb_code'
        self.distance_buffer = var_distance_buffer  # '0.1'

        self.geom_attribut = 'geom'
        self.message_erreur_accroche = 'erreur_accroche'
        self.message_erreur_doublon_geom = 'erreur_doublon_geometrie'
        self.message_erreur_detection = 'erreur_detection_origine_extremite'
        self.message_erreur_sens_dessin = 'erreur_sens_dessin'
        self.name_attribut_origine_cal = 'origine_cal'
        self.name_attribut_extremite_cal = 'extremite_cal'
        self.name_table_erreur_modelisation = "check_erreur_modelisation"
        self.name_attribut_distance_point_depart = "distance_dep_arrive"
        self.name_attribut_distance_dep_pm = 'distance_dep_pm'
        self.name_attribut_distance_pm_pbo = 'distance_pm_pbo'
        self.name_line_traitement = f"""{self.name_line}_traitement"""
        self.name_point = f"""{self.name_point_tab}_traitement"""
        self.name_table_erreur_modelisation_columns = ['name_table', 'id_identifiant', 'message_erreur',
                                                       self.geom_attribut]
        # Execution prepartion des tables a utiliser
        self.function_prepare_data_use()

        # Exectuion des fonctions de traitement
        self.function_accrochage_lines_to_point()
        self.function_prepare_data_and_check_sens()
        self.function_check_origine_extremite_id()
        self.function_create_table_erreur()
        self.function_update_distances_dep_pm_pbo()

        # Dernier commit pour enregistrer les modifications pour securite et femeture connexion et cursor
        self.connection.commit()
        self.db_cursor.close()
        self.connection.close()

        # Exection message finale
        self.function_message_finale()

    # Function message finale
    def function_message_finale(self):
        if len(self.liste_message_execution_function) > 0:
            return QMessageBox.information(self.w, "Message-Execution-Plugin",
                                           f"Resultats Error Modelisation, "
                                           f"Cliquer sur Ok pour continuer le traitement : "
                                           f"{len(self.liste_message_execution_function)}\n"
                                           f"{','.join([str(i) for i in self.liste_message_execution_function])}")

    # Function pour preparer les donnees a utiliser
    def function_prepare_data_use(self):
        try:
            # Preparation des table miroires de Lines et de point pour lutilisation
            self.db_cursor.execute(
                f"""set search_path to {self.schema}, public;
                drop table if exists {self.name_line_traitement}; 
                SELECT * into {self.name_line_traitement}  FROM {self.name_line}; drop table if exists {self.name_point}; 
                SELECT * into {self.name_point}  FROM {self.name_point_tab}; update {self.name_line_traitement} set {self.geom_attribut} = st_lineMerge({self.geom_attribut});
                ALTER TABLE IF EXISTS {self.name_line_traitement} ADD COLUMN IF NOT EXISTS {self.name_attribut_origine_cal} text;
                ALTER TABLE IF EXISTS {self.name_line_traitement} ADD COLUMN IF NOT EXISTS {self.name_attribut_extremite_cal} text;
                ALTER TABLE IF EXISTS {self.name_point} ADD COLUMN IF NOT EXISTS {self.name_attribut_distance_point_depart} text;
                ALTER TABLE IF EXISTS {self.name_point} ADD COLUMN IF NOT EXISTS {self.name_attribut_distance_dep_pm} text;
                ALTER TABLE IF EXISTS {self.name_point} ADD COLUMN IF NOT EXISTS {self.name_attribut_distance_pm_pbo} text;
                DROP TABLE IF EXISTS {self.name_table_erreur_modelisation};
                create table if not exists {self.name_table_erreur_modelisation} (ID  SERIAL PRIMARY KEY, name_table text, id_identifiant text, message_erreur text, {self.geom_attribut} geometry)""")
            self.connection.commit()
        except Exception as error:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            prepare_list_error = ['function_prepare_data_use', f"{error} ... {exc_tb.tb_lineno}"]
            self.liste_message_execution_function.append(prepare_list_error)

    # function prepare requete insert
    def function_prepare_requete_insert(self, var_name_table, var_entite, var_message_error, var_geometry_text):
        geom_insert = str(tuple([var_name_table, var_entite, var_message_error,
                                 f"ST_GeomFromText('{str(var_geometry_text)}',2154)"])).replace('"', '')
        self.liste_erreur_modelisation.append(geom_insert)

    # Function de la creation de la table erreur de modelisation
    def function_create_table_erreur(self):
        try:
            # Insertion des elements erreurs dans la table erreur de modelisation
            if self.liste_erreur_modelisation:
                var_req_insert = f"INSERT INTO {self.schema}.{self.name_table_erreur_modelisation}" \
                                 f"({','.join(self.name_table_erreur_modelisation_columns)}) " \
                                 f"values{','.join(self.liste_erreur_modelisation)}"
                self.db_cursor.execute(var_req_insert)
                self.connection.commit()
        except Exception as error:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            prepare_list_error = ['function_create_table_erreur', f"{error} ... {exc_tb.tb_lineno}"]
            self.liste_message_execution_function.append(prepare_list_error)

    # Function pour corriger les erreurs daccrochage ligne et point
    def function_accrochage_lines_to_point(self):
        try:
            bar_progress = self.progress_bar('Correction Accrochage Line et Point')
            layershape_lines = self.function_getlayer_bdd(self.schema, self.name_line_traitement,
                                                          self.name_line_attribut,
                                                          self.name_line_traitement, self.geom_attribut)
            layershape_point = self.function_getlayer_bdd(self.schema, self.name_point, '', self.name_point,
                                                          self.geom_attribut)
            layershape_lines_features = [feature for feature in layershape_lines.getFeatures()]
            layershape_point_features = [feature for feature in layershape_point.getFeatures()]
            liste_correction_accrochage = []
            liste_id_erreur_accrochage = []

            layershape_support_count = layershape_lines.featureCount()
            for index_shape_support, shape_support in enumerate(layershape_lines_features):
                res_originee = 'KO'
                res_extremitee = 'KO'
                geom_support = shape_support.geometry()
                if geom_support != NULL or geom_support.isGeosValid():
                    if geom_support.wkbType() == QgsWkbTypes.MultiLineString:
                        geom_support_type = geom_support.asMultiPolyline()
                        support_origine = geom_support_type[0][0]
                        support_extremite = geom_support_type[-1][-1]
                    if geom_support.wkbType() == QgsWkbTypes.LineString:
                        geom_support_type = geom_support.asPolyline()
                        support_origine = geom_support_type[0]
                        support_extremite = geom_support_type[-1]

                    for var_pnt in layershape_point_features:
                        geompoint = var_pnt.geometry()
                        if geompoint != NULL or geompoint.isGeosValid():
                            if (QgsGeometry.fromPointXY(QgsPointXY(support_origine))).equals(geompoint):
                                res_originee = 'OK'
                            if (QgsGeometry.fromPointXY(QgsPointXY(support_extremite))).equals(geompoint):
                                res_extremitee = 'OK'
                    if res_originee == 'KO' or res_extremitee == 'KO':
                        liste_id_erreur_accrochage.append(shape_support[self.name_line_attribut])  # Ajout pour filtre
                        # geom_insert = str(tuple([self.name_line_traitement, shape_support[self.name_line_attribut],
                        #                                            self.message_erreur_accroche,
                        #                          f"ST_GeomFromText('{str(geom_support.asWkt())}',2154)"])
                        #                          ).replace('"', '')
                        # self.liste_erreur_modelisation.append(geom_insert)  # Erreur daccrochage pour une insertion
                        self.function_prepare_requete_insert(self.name_line_traitement,
                                                             shape_support[self.name_line_attribut],
                                                             self.message_erreur_accroche, geom_support.asWkt())
                        for candidate_id2 in layershape_point_features:
                            geompoint2 = candidate_id2.geometry()
                            if geompoint2 != NULL or geompoint2.isGeosValid():
                                geom_pt_type = geompoint2.asPoint()
                                if (QgsGeometry.fromPointXY(QgsPointXY(support_origine))).within(
                                        geompoint2.buffer((float(self.distance_buffer)),
                                                                    (float(self.distance_buffer)))):
                                    for i, geom_vertex_lines in enumerate(geom_support_type):
                                        if geom_vertex_lines == support_origine:
                                            geom_support_type[i] = geom_pt_type

                                if (QgsGeometry.fromPointXY(QgsPointXY(support_extremite))).within(
                                        geompoint2.buffer((float(self.distance_buffer)),
                                                                    (float(self.distance_buffer)))):
                                    for i, geom_vertex_lines in enumerate(geom_support_type):
                                        if geom_vertex_lines == support_extremite:
                                            geom_support_type[i] = geom_pt_type

                    # Ajout que des lines avec erreur accrochage
                    if geom_support.wkbType() in [QgsWkbTypes.MultiLineString, QgsWkbTypes.LineString] and \
                            shape_support[self.name_line_attribut] in liste_id_erreur_accrochage:
                        polyline = QgsGeometry.fromPolylineXY(geom_support_type).asWkt()
                        correction_accrochage_prepare = str(tuple([shape_support[self.name_line_attribut],
                                                                   f"ST_GeomFromText('{str(polyline)}',2154)"])
                                                            ).replace('"', '')
                        liste_correction_accrochage.append(correction_accrochage_prepare)

                self.progress_processing(index_shape_support, layershape_support_count, bar_progress)
                if bar_progress.wasCanceled():
                    iface.messageBar().pushMessage('Info', 'Action Cancelled', level=Qgis.Info)
                    break

            # Update correction accrochage uniquement ce qui ont des problemes daccrochage
            if liste_correction_accrochage:
                req_update_accrochage = f""" update {self.schema}.{self.name_line_traitement} as t 
                    set {self.geom_attribut} = c.geom_aa
                    from (values
                        {','.join(liste_correction_accrochage)}
                    ) as c(id_bb, geom_aa)
                    where c.id_bb = t.{self.name_line_attribut};"""
                self.db_cursor.execute(req_update_accrochage)
                self.connection.commit()
        except Exception as error:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            prepare_list_error = ['function_accrochage_lines_to_point', f"{error} ... {exc_tb.tb_lineno}"]
            self.liste_message_execution_function.append(prepare_list_error)

    # Function Delete Duplicate geometry
    def function_check_duplicate_geom(self):
        try:
            layershape_lines = self.function_getlayer_bdd(self.schema, self.name_line_traitement, self.name_line_attribut,
                                                          self.name_line_traitement, self.geom_attribut)
            features_lines = [feature for feature in layershape_lines.getFeatures()]
            for feature1, feature2 in itertools.combinations(features_lines, 2):
                if feature1.geometry().isGeosEqual(feature2.geometry()):
                    self.function_prepare_requete_insert(self.name_line_traitement,
                                                         f"{feature1[self.name_line_attribut]}___"
                                                         f"{feature2[self.name_line_attribut]}",
                                                         self.message_erreur_doublon_geom, feature1.geometry().asWkt())
        except Exception as error:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            prepare_list_error = ['function_check_duplicate_geom', f"{error} ... {exc_tb.tb_lineno}"]
            self.liste_message_execution_function.append(prepare_list_error)

    # Function Parcours sens du cable
    def function_cable_parcours_sens(self, depart_origine_support, pt_amont, ordre, niveau, distance):
        pt_aval = ""
        if niveau < 100000:  # list_shape_ligne list_shape_point
            for index_shape_cable, shape_cable in enumerate(self.list_shape_ligne):
                # On ne prend que les supports non parcourus dont
                # lorigine est le point dorigine est depart_origine_support
                if (shape_cable[1] == depart_origine_support) and (shape_cable[3] == 0):
                    # le support est dans le bon sens
                    shape_cable[3] = 1
                    for shape_noeud in self.list_shape_point:
                        if shape_cable[2] == shape_noeud[1]:
                            self.function_cable_parcours_sens(shape_cable[2], shape_noeud[0], ordre, niveau + 1,
                                                              shape_cable[7] + distance)
                            pt_aval = self.function_return_not_null(shape_noeud[0])
                            shape_noeud[5] = distance

                    shape_cable[4] = self.function_return_not_null(pt_amont)
                    shape_cable[5] = self.function_return_not_null(pt_aval)

                # On ne prend que les supports non parcourus dont l'extremite est le point dorigine
                # est depart_origine_support
                elif (shape_cable[2] == depart_origine_support) and (shape_cable[3] == 0):
                    # le support nest pas dans le bon sens
                    shape_cable[3] = -1
                    for shape_noeud in self.list_shape_point:
                        if shape_cable[1] == shape_noeud[1]:
                            self.function_cable_parcours_sens(shape_cable[1], shape_noeud[0], 1, niveau + 1,
                                                              shape_cable[7] + distance)
                            pt_aval = self.function_return_not_null(shape_noeud[0])
                            shape_noeud[5] = distance

                    shape_cable[4] = self.function_return_not_null(pt_amont)
                    shape_cable[5] = self.function_return_not_null(pt_aval)

            if pt_aval == "" or pt_aval == NULL:
                pt_aval = 'Erreur pas de noeud Extremite'
                for shape_noeud in self.list_shape_point:
                    if depart_origine_support == shape_noeud[1]:
                        pt_aval = shape_noeud[0]
            return pt_aval

    # Function pour recuperer les resultats du parcours et update
    def function_prepare_data_and_check_sens(self):
        try:
            shape_point = self.function_getlayer_bdd(self.schema, self.name_point, self.name_point_attribut,
                                                     self.name_point, self.geom_attribut)
            shape_ligne = self.function_getlayer_bdd(self.schema, self.name_line_traitement, self.name_line_attribut,
                                                     self.name_line_traitement, self.geom_attribut)
            bar_progress = self.progress_bar('Partie Traitement Prepation des donnees, check sens et correction')

            layershape_noeud = [i for i in shape_point.getFeatures()]
            layershape_cable = [i for i in shape_ligne.getFeatures()]

            # Partie Noeuds et Point depart
            listshape_depart = []
            list_point_unique = []
            for index_feat, feature in enumerate(layershape_noeud):
                geom_noeud = feature.geometry()
                noeud_id = feature[self.name_point_attribut]
                shape_noeud = [noeud_id, geom_noeud.asWkt(2), -1, -1, -1, -1]
                if geom_noeud.asWkt(2) not in list_point_unique:
                    list_point_unique.append(geom_noeud.asWkt(2))
                    self.list_shape_point.append(shape_noeud)  # Liste point pour parcours
                if noeud_id not in listshape_depart:
                    if str(noeud_id) == str(self.point_val_depart):  # Noeud de depart pour le parcours
                        point_depart = geom_noeud.asWkt(2)
                        listshape_depart.append(point_depart)  # Liste point depart pour parcours
                self.progress_processing(index_feat, shape_point.featureCount(), bar_progress)
                if bar_progress.wasCanceled():
                    iface.messageBar().pushMessage('Info', 'Action Cancelled', level=Qgis.Info)
                    break

            # Check Doublons de noeuds
            for feature1, feature2 in itertools.combinations(layershape_noeud, 2):
                if feature1.geometry().isGeosEqual(feature2.geometry()):
                    self.function_prepare_requete_insert(self.name_line_traitement,
                                                         f"{feature1[self.name_point_attribut]}___"
                                                         f"{feature2[self.name_point_attribut]}",
                                                         self.message_erreur_doublon_geom, feature1.geometry().asWkt())

            # Check Doublons de lines
            for feature_line1, feature_line2 in itertools.combinations(layershape_cable, 2):
                if feature_line1.geometry().isGeosEqual(feature_line2.geometry()):
                    self.function_prepare_requete_insert(self.name_line_traitement,
                                                         f"{feature_line1[self.name_line_attribut]}___"
                                                         f"{feature_line2[self.name_line_attribut]}",
                                                         self.message_erreur_doublon_geom,
                                                         feature_line1.geometry().asWkt())

            # Partie Lines
            list_lines_unique_geom = []
            for index_lines, shape_cable in enumerate(layershape_cable):
                geom_cable_lines = shape_cable.geometry()
                cable_id = shape_cable[self.name_line_attribut]
                geom_cable_wkt = geom_cable_lines.asWkt()
                geom_cable_lines_lenth = geom_cable_lines.length()
                geom_cable = geom_cable_lines
                if geom_cable.wkbType() == QgsWkbTypes.MultiLineString:
                    geom_cable_type = geom_cable.asMultiPolyline()
                    cable_origine = geom_cable_type[0][0]
                    cable_extremite = geom_cable_type[-1][-1]
                if geom_cable.wkbType() == QgsWkbTypes.LineString:
                    geom_cable_type = geom_cable.asPolyline()
                    cable_origine = geom_cable_type[0]
                    cable_extremite = geom_cable_type[-1]
                shape_cables_origine = (QgsGeometry.fromPointXY(QgsPointXY(cable_origine))).asWkt(2)
                shape_cables_extremite = (QgsGeometry.fromPointXY(QgsPointXY(cable_extremite))).asWkt(2)
                prepare_list_line = [cable_id, shape_cables_origine, shape_cables_extremite, 0, -1, -1,
                                     geom_cable_wkt, geom_cable_lines_lenth]
                if geom_cable_wkt not in list_lines_unique_geom:
                    list_lines_unique_geom.append(geom_cable_wkt)
                    self.list_shape_ligne.append(prepare_list_line)  # Liste lines pour parcours

                self.progress_processing(index_lines, shape_ligne.featureCount(), bar_progress)
                if bar_progress.wasCanceled():
                    iface.messageBar().pushMessage('Info', 'Action Cancelled', level=Qgis.Info)
                    break

            # Verif si point depart est un et executer le parcours de verif du sens du dessin
            if len(listshape_depart) == 1:
                point_val_depart = ','.join(listshape_depart)
                self.function_cable_parcours_sens(point_val_depart, str(self.point_val_depart), 1, 1, 0)

                # Update le calcul des distances dans point
                liste_update_calcule_distance = []
                for index_point in range(len(self.list_shape_point)):
                    feature_point = self.list_shape_point[index_point]
                    id_code_point = feature_point[0]
                    id_distance_cal_point = feature_point[5]
                    prepare_update_req_dis_pnt = str(tuple([id_code_point, id_distance_cal_point]))
                    liste_update_calcule_distance.append(prepare_update_req_dis_pnt)
                    self.progress_processing(index_point, shape_point.featureCount(), bar_progress)
                    if bar_progress.wasCanceled():
                        iface.messageBar().pushMessage('Info', 'Action Cancelled', level=Qgis.Info)
                        break

                liste_correction_sens_dessin = []
                liste_update_calcule_origine_extremite = []
                for index_line in range(len(self.list_shape_ligne)):
                    feature_lines = self.list_shape_ligne[index_line]
                    id_code_lines = feature_lines[0]
                    # id_origine_lines = feature_lines[1]
                    # id_extremite_lines = feature_lines[2]
                    id_sens_lines = feature_lines[3]
                    id_ori_cal_lines = feature_lines[4]
                    id_ext_cal_lines = feature_lines[5]
                    id_geom_lines = feature_lines[6]
                    # id_distance_cal_lines = feature_lines[7]
                    geom_lines_from_wkt = QgsGeometry.fromWkt(id_geom_lines)

                    # ajout des origines/extremites calcules dans la table
                    prepare_update_req_oe = str(tuple([id_code_lines, id_ori_cal_lines, id_ext_cal_lines]))
                    liste_update_calcule_origine_extremite.append(prepare_update_req_oe)

                    # Erreur Detection origines extremites sens Lines
                    if id_sens_lines != 1:
                        # Erreur Detection origines extremites Lines
                        if id_sens_lines == 0:
                            self.function_prepare_requete_insert(self.name_line_traitement,
                                                                 f"{id_code_lines}",
                                                                 self.message_erreur_detection,
                                                                 id_geom_lines)
                        # Inverser le sens
                        if id_sens_lines == -1:
                            self.function_prepare_requete_insert(self.name_line_traitement,
                                                                 f"{id_code_lines}",
                                                                 self.message_erreur_sens_dessin,
                                                                 id_geom_lines)
                            geom_line_rec = None
                            if geom_lines_from_wkt.isGeosValid():
                                if geom_lines_from_wkt.wkbType() == QgsWkbTypes.MultiLineString:
                                    mls = QgsMultiLineString()
                                    for line in geom_lines_from_wkt.asGeometryCollection():
                                        mls.addGeometry(line.constGet().reversed())
                                    geom_line_rec = QgsGeometry(mls)

                                elif geom_lines_from_wkt.wkbType() == QgsWkbTypes.LineString:
                                    geom_line_rec = QgsGeometry(geom_lines_from_wkt.constGet().reversed())
                            if geom_line_rec is not None:
                                rect_sens_dessin = geom_line_rec.asWkt()
                                correction_accrochage_prepare = str(tuple([id_code_lines,
                                                                           f"ST_GeomFromText('{str(rect_sens_dessin)}',"
                                                                           f"2154)"])).replace('"', '')
                                liste_correction_sens_dessin.append(correction_accrochage_prepare)
                        else:
                            pas_dans_condition = ['function_prepare_data_and_check_sens', id_sens_lines]
                            self.liste_message_execution_function.append(pas_dans_condition)

                    self.progress_processing(index_line, shape_ligne.featureCount(), bar_progress)
                    if bar_progress.wasCanceled():
                        iface.messageBar().pushMessage('Info', 'Action Cancelled', level=Qgis.Info)
                        break
                # Update correction sens du dessin uniquement ce qui ont des problemes de sens
                if liste_correction_sens_dessin:
                    req_update_accrochage = f""" update {self.schema}.{self.name_line_traitement} as t 
                                                set {self.geom_attribut} = c.geom_aa
                                                from (values
                                                    {','.join(liste_correction_sens_dessin)}
                                                ) as c(id_bb, geom_aa)
                                                where c.id_bb = t.{self.name_line_attribut};"""
                    self.db_cursor.execute(req_update_accrochage)
                    self.connection.commit()

                # Update correction calcul distance
                if liste_update_calcule_distance:
                    req_update_distance = f""" update {self.schema}.{self.name_point} as t 
                                                        set {self.name_attribut_distance_point_depart} = c.distance_cal
                                                        from (values
                                                            {','.join(liste_update_calcule_distance)}
                                                        ) as c(id_bb, distance_cal)
                                                        where c.id_bb = t.{self.name_point_attribut};"""
                    self.db_cursor.execute(req_update_distance)
                    self.connection.commit()

                # Update des origines extremites calcules
                if liste_update_calcule_origine_extremite:
                    req_update_or_ex_cal = f""" update {self.schema}.{self.name_line_traitement} as t 
                                                                set {self.name_attribut_origine_cal} = c.ori_cal, 
                                                                    {self.name_attribut_extremite_cal} = c.ext_cal
                                                                from (values
                                                                    {','.join(liste_update_calcule_origine_extremite)}
                                                                ) as c(id_bb, ori_cal, ext_cal)
                                                                where c.id_bb = t.{self.name_line_attribut};"""
                    self.db_cursor.execute(req_update_or_ex_cal)
                    self.connection.commit()
            else:
                return QMessageBox.information(self.w, "Message-Execution-Plugin",
                                               f"Veillez choisir le point de depart pour faire le parcours")
        except Exception as error:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            prepare_list_error = ['function_prepare_data_and_check_sens', f"{error} ... {exc_tb.tb_lineno}"]
            self.liste_message_execution_function.append(prepare_list_error)

    # Function pour Verifier les origines extremites doublon id des lignes et points
    def function_check_origine_extremite_id(self):
        try:
            shape_point = self.function_getlayer_bdd(self.schema, self.name_point, self.name_point_attribut,
                                                     self.name_point, self.geom_attribut)
            shape_ligne = self.function_getlayer_bdd(self.schema, self.name_line_traitement, self.name_line_attribut,
                                                     self.name_line_traitement, self.geom_attribut)

            layershape_noeud = [i for i in shape_point.getFeatures()]
            layershape_lines = [i for i in shape_ligne.getFeatures()]

            # Creation des listes pour checker les doublons
            list_check_ligne_id = []
            list_check_ligne_exetremite = []
            list_check_ligne_origine_egale_extremite = []
            list_check_point_id = []

            # Partie shape Ligne et preparation des listes utilitaires
            bar_progress = self.progress_bar('Partie Traitement Check detection origine extremite')
            for index_cable, cable in enumerate(layershape_lines):
                geometry_lignes = cable.geometry()
                if geometry_lignes != NULL or geometry_lignes.isGeosValid():
                    geom_wkt_ligne = geometry_lignes.asWkt(2)

                    # Append List ID Ligne
                    attribute_ligne_id = [geom_wkt_ligne, cable[self.name_line_attribut]]
                    list_check_ligne_id.append(attribute_ligne_id)

                    # Append List Extremite Ligne
                    attribute_ligne_extremite = [geom_wkt_ligne, cable[self.name_attribut_extremite_cal]]
                    list_check_ligne_exetremite.append(attribute_ligne_extremite)

                    # Erreur Origine egale Extremite Ligne
                    if cable[self.name_attribut_origine_cal] == cable[self.name_attribut_extremite_cal]:
                        attribute_ligne_origine_extremite = [geom_wkt_ligne, cable[self.name_line_attribut]]
                        list_check_ligne_origine_egale_extremite.append(attribute_ligne_origine_extremite)
                self.progress_processing(index_cable, shape_ligne.featureCount(), bar_progress)
                if bar_progress.wasCanceled():
                    iface.messageBar().pushMessage('Info', 'Action Cancelled', level=Qgis.Info)
                    break

            # Partie shape Point et preparation des listes utilitaires
            for index_point, point in enumerate(layershape_noeud):
                geom_wkt_point = point.geometry().asWkt(2)
                # Append List ID Point
                attribute_point_id = [geom_wkt_point, point[self.name_point_attribut]]
                list_check_point_id.append(attribute_point_id)
                self.progress_processing(index_point, shape_point.featureCount(), bar_progress)
                if bar_progress.wasCanceled():
                    iface.messageBar().pushMessage('Info', 'Action Cancelled', level=Qgis.Info)
                    break

            # Erreur Shape identification des doublons didentifiant de Ligne
            erreur_doublon_id_ligne = 'Erreur : Cette Entite est presente plus dune fois dans ID_CODE du shape Ligne'
            for ligne_double in self.get_doublon(list_check_ligne_id):
                self.function_prepare_requete_insert(self.name_line_traitement,
                                                     f"{ligne_double[1]}",
                                                     erreur_doublon_id_ligne,
                                                     ligne_double[0])

            # Erreur Shape identification des doublons extremites de Ligne
            erreur_doublon_extremite_ligne = 'Erreur : Cette Entite est presente plus dune ' \
                                             'fois dans Extremite du shape Ligne'
            for ligne_double_extremite in self.get_doublon(list_check_ligne_exetremite):
                self.function_prepare_requete_insert(self.name_line_traitement,
                                                     f"{ligne_double_extremite[1]}",
                                                     erreur_doublon_extremite_ligne,
                                                     ligne_double_extremite[0])

            # Erreur Shape identification des origines egal extremite de Ligne
            erreur_origine_extremite_ligne = 'ERREUR: Cette Entite a un ID_CODE qui est a la fois origine et extemite'
            for ligne_origine_extremite in list_check_ligne_origine_egale_extremite:
                self.function_prepare_requete_insert(self.name_line_traitement,
                                                     f"{ligne_origine_extremite[1]}",
                                                     erreur_origine_extremite_ligne,
                                                     ligne_origine_extremite[0])

            # Erreur Shape identification des doublons didentifiant de Point
            erreur_doublon_id_point = 'Erreur : Cette Entite est presente plus dune fois dans le shape Point'
            for point_double in self.get_doublon(list_check_point_id):
                self.function_prepare_requete_insert(self.name_line_traitement,
                                                     f"{point_double[1]}",
                                                     erreur_doublon_id_point,
                                                     point_double[0])
        except Exception as error:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            prepare_list_error = ['function_check_origine_extremite_id', f"{error} ... {exc_tb.tb_lineno}"]
            self.liste_message_execution_function.append(prepare_list_error)

    # Function mise a jour des distances dep_pm, pm_pbo
    def function_update_distances_dep_pm_pbo(self):
        try:
            req_update = f"""set search_path to {self.schema}, public;
                -- Boite PT LTECH
                with data_all_boite as (select 
                    bp.*, st.st_nd_code as nd_code_cal
                from t_ebp bp 
                    left join t_ptech pt on pt.pt_code = bp.bp_pt_code
                    left join t_ltech lt on lt.lt_code = bp.bp_lt_code
                    left join t_sitetech st on st.st_code = lt.lt_st_code
                where lt.lt_code is not null
                
                union 
                
                select 
                    bp.*, pt.pt_nd_code
                from t_ebp bp 
                    left join t_ptech pt on pt.pt_code = bp.bp_pt_code
                where pt.pt_code is not null)
                -- select 
                -- 	dtb.*, 
                -- 	ndt.distance_dep_arrive as distance_nro_boite,
                -- 	ndt2.distance_dep_arrive as distance_nro_pm,
                -- 	ndt.distance_dep_arrive::float - ndt2.distance_dep_arrive::float as distance_pm_boite,
                -- 	st.st_nd_code noeud_sro
                -- from data_all_boite as dtb
                update {self.name_point} ndt3 
                    set {self.name_attribut_distance_pm_pbo} = ndt.distance_dep_arrive::float - ndt2.distance_dep_arrive::float, 
                    {self.name_attribut_distance_dep_pm} = ndt2.distance_dep_arrive
                from data_all_boite as dtb
                    left join {self.name_point} ndt on ndt.{self.name_point_attribut} = nd_code_cal
                    left join t_zsro zs on st_within(ndt.geom, zs.geom)
                    left join (select * from t_sitetech where st_typelog in ('SRO')) as st on st.st_nd_code = zs.zs_nd_code
                    left join {self.name_point} ndt2 on ndt2.{self.name_point_attribut} = st.st_nd_code
                where dtb.bp_typelog = 'PBO' and dtb.nd_code_cal = ndt3.{self.name_point_attribut};
                
                -- Update des noeuds de SRO pour les distances NRO-PM
                update {self.name_point} ndt set {self.name_attribut_distance_dep_pm} = ndt2.distance_dep_arrive
                from {self.name_point} ndt2
                    join t_sitetech st on (ndt2.nd_code = st.st_nd_code and st.st_typelog in ('SRO'))
                    join t_zsro zs on st_within(ndt2.geom, zs.geom)
                where ndt.{self.name_point_attribut} = ndt2.{self.name_point_attribut};"""
            self.db_cursor.execute(req_update)
            self.connection.commit()
        except Exception as error:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            prepare_list_error = ['function_update_distances_dep_pm_pbo', f"{error} ... {exc_tb.tb_lineno}"]
            self.liste_message_execution_function.append(prepare_list_error)


# schema = 'recd_z31305_v202206100900'  # Schema etude
# depart_nro = 'NDMB1130500211'  # id noeud Depart
# # Connexion a la base
# connection = function_connexion()
# ModelisationReseau(connection, schema, depart_nro)  # , var_vs_elem_cl_cb='vs_elem_cl_cb_traitement'
