SET search_path TO schemacheck, gracethd, public;

CREATE OR REPLACE FUNCTION recreate_v_ct_anom() 
RETURNS void 
AS
$$
DECLARE
    qry varchar := '';
    row record;
BEGIN
    FOR row IN 
        SELECT ct_code FROM v_ct_exe where ct_code not in ('cm_geom_1_g80013', 'cm_geom_1_m80011','cl_geom_1_g80010', 
		'cl_geom_1_g80012','cl_geom_1_m80010','cl_geom_1_r00551','cm_geom_1_r00450')
		
    LOOP
	    IF length(qry) > 0 THEN
		  qry := qry || ' UNION ';
		END IF;
	    qry := qry || 'SELECT COUNT(*) AS ct_nbobj, (SELECT valeur FROM t_ct_conf WHERE nom=''ct_1_liv'') AS ct_liv, LOCALTIMESTAMP(0) AS ct_date, ct_code '
		       'FROM v_ct_unit_' || row.ct_code || ' GROUP BY ct_code';
    END LOOP;

	qry :=  'SELECT A.ct_nbobj, A.ct_liv, A.ct_date, A.ct_code, E.ct_def, E.ct_type, E.ct_sensib, E.ct_order, '
			'E.ct_case, E.ct_table, E.ct_att, E.ct_exe_pre, E.ct_exe_dia, E.ct_exe_avp, E.ct_exe_pro, E.ct_exe_act, '
			'E.ct_exe_exe, E.ct_exe_tvx, E.ct_exe_rec, E.ct_exe_mco '
			'FROM (' || qry || ') AS A, v_ct_exe AS E '
			'WHERE A.ct_code = E.ct_code ;';
			
	EXECUTE 'CREATE OR REPLACE VIEW v_ct_anom AS ' || qry || ';';
END;
$$
LANGUAGE plpgsql;
SELECT * from recreate_v_ct_anom();