import re
from qgis.PyQt.QtWidgets import *
from qgis.PyQt.QtGui import *
from qgis.PyQt.QtCore import *
from qgis.utils import *
from qgis.core import *



try:
    import openpyxl
    from openpyxl import Workbook
    from openpyxl import load_workbook
except(Exception,) as error:
    # https://stackoverflow.com/questions/42974450/iterate-over-worksheets-rows-columns
    # https://www.soudegesu.com/en/post/python/cell-excel-with-openpyxl/
    import subprocess
    subprocess.check_call(['pip', 'install', 'openpyxl'])  # 'python', '-m',
    import openpyxl


# app = QApplication(sys.argv)

class SyntheseAuditDpi:
    # Constructeur des variables qui change
    def __init__(self, var_fichier_appuis, var_path_export_res):
        # Declaration de la variable pour les messages derreur
        self.fichier_appuis = var_fichier_appuis
        self.folder_export_res = var_path_export_res # os.path.dirname(self.fichier_appuis)

        self.w = QWidget()
        self.error_open = 'Error_Open_'
        self.var_sheet_name = 'name_sheet'
        self.var_incoherence_nom_entete = 'Incoherence Nom Entete'
        self.var_incoherence_longueur_entete = 'Incoherence LOngueur Entete'

        self.var_list_erreur_model = []
        self.var_list_all_erreur_traitement = []
        # self.list_synthese_aer_orange = []
        self.all_dict_synthese_aer_orange = []
        # self.list_synthese_aer_enedis = []
        self.all_dict_synthese_aer_enedis = []
        self.list_synthese_global_pr = []

        # self.list_capacite = ['-6F-', '-12F-', '-24F-', '-36F-', '-48F-', '-72F-', '-96F-', '-144F-', '-288F-',
        #                       '-576F-', '-720F-', '-864F-']
        self.list_capacite = ['_6F', '_12F', '_24F', '_36F', '_48F', '_72F', '_96F', '_144F', '_288F',
                              '_576F', '_720F', '_864F']
        # self.list_capacite = ['6F', '12F', '24F', '36F', '48F', '72F', '96F', '144F', '288F', '576F', '720F', '864F']
        self.var_all_list_majeur = ['incoherence mcd', 'incohérence travaux', 'non respect des règles Orange',
                                    'Incoherence branchements modelises', 'Defaut parallelisme',
                                    'Croissement de reseau']
        self.var_list_cable_filtre = ['CDI', 'CTR', 'CAB']
        self.var_coherence_mcd_conforme = 'OUI'
        self.var_res_conforme = 'CONFORME'
        self.var_res_majeur = 'MAJEUR'
        self.var_res_mineur = 'MINEUR'
        self.var_res_valide_etat = "VALIDE EN L'ETAT"
        self.var_res_a_reprendre = "A REPRENDRE"
        self.var_orange_appui = 'ORANGE'
        self.var_enedis_appui = 'ENEDIS'
        self.var_sheet_aer_orange = 'AER_ORANGE'
        self.var_sheet_aer_enedis = 'AER_ENEDIS'
        self.var_res_enedis = self.function_create_fusion_sheet_dpi_enedis()
        self.var_res_orange = self.function_create_fusion_sheet_dpi_orange()
        self.function_create_all_syntheses()
        if self.var_list_all_erreur_traitement:
            QMessageBox.critical(self.w, "Message-Plugin", f"Il y a des erreurs sur le traitement\n"
                                                           f"{str(self.var_list_all_erreur_traitement)}")
        else:
            QMessageBox.information(self.w, "Message-Plugin", f"Traitement Reussi avec Succes\n"
                                                              f"{self.var_list_all_erreur_traitement}")

    # Function pour la progession bar1
    @staticmethod
    def progress_bar(name_etape):
        prog = QProgressDialog(name_etape + ' : Veillez Patienter', 'Cancel', 0, 100)
        prog.setWindowModality(Qt.WindowModal)
        prog.setMinimumDuration(1)
        return prog

    # Function pour la progession bar2
    @staticmethod
    def progress_processing(index, count_entite, progress_dialog):
        f = int(index + 1)
        pcnt = int(f / count_entite * 100 / 1)
        progress_dialog.setValue(pcnt)
    
    # Function pour la creation des syntheses globales
    def function_create_all_syntheses(self):
        try:
            res_data_orange = self.var_res_orange
            res_data_enedis = self.var_res_enedis
            dict_merging = dict(res_data_orange[0], **res_data_enedis[0])  # Fusion des resultats ORANGE et ENEDIS
            # self.res_orange ==> format ==
            #     {'ZSRO_07346_MD01;EFT_001_07346_Quartier Couijanet':
            #         ['ORANGE', 'ZSRO_07346_MD01;EFT_001_07346_Quartier Couijanet', 'A REPRENDRE', 3, 0, 1,
            #             'A-N8227A;2470', 'MAJEUR', 'MAJEUR', 'MAJEUR', 'CONFORME', 33],
            #     'ZSRO_07346_MD01;EFT_002_07346_Quartier Couijanet_2':
            #         ['ORANGE', 'ZSRO_07346_MD01;EFT_002_07346_Quartier Couijanet_2', 'A REPRENDRE', 14, 2, 3,
            #             'P-TF303G;9680', 'CONFORME', 'MAJEUR', 'MAJEUR', 'MAJEUR', 21]}

            # self.res_enedis == > format ==
            # {'ZSRO_07346_MD01;EBT_001_07346_PAURIERE 2_1':
            #      ['ENEDIS', 'ZSRO_07346_MD01;EBT_001_07346_PAURIERE 2_1', 'A REPRENDRE', 13, 1,
            #       'A-N8227A;2470', 'MAJEUR', 'MAJEUR', 'MAJEUR', 'MAJEUR', 'MAJEUR', 8],
            #  'ZSRO_07346_MD01;EBT_002_07346_PAURIERE 3_1':
            #      ['ENEDIS', 'ZSRO_07346_MD01;EBT_002_07346_PAURIERE 3_1', "VALIDE EN L'ETAT", 3, 0,
            #       'P-TF303G- 72F-80-A-N8227;A2470', 'CONFORME', 'CONFORME', 'CONFORME', 'CONFORME', 'CONFORME', 0]}

            # Partie des entetes pour les sheets
            entete_global_sheet_orange = ['TYPE ETUDE', 'ZSRO', 'NB_ETUDE', 'A REPRENDRE', 'NB_APPUI', 'NB_APPUI_KO', '% KO', "Cohérence SIG", "Cohérence version CAPFT",	"Cohérence Description de l'appui",	"Cohérence Contrôle Visuel", "Cohérence Photos",	"Cohérence Equipements Existants",	"Remplissage de la Fiche d'Appui", "Cohérence Nature du cable",	"Cohérence Nombre de cable", "Cohérence Orientation de la ligne", "Cohérence Orientation de l'appui",	"Cohérence écart des lignes",	"Cohérence Pose de réhausse",	"Cohérence travaux à réaliser"]
            entete_global_sheet_enedis = ['TYPE ETUDE', 'ZSRO', 'NB_ETUDE', 'A REPRENDRE', 'NB_APPUI', 'NB_APPUI_KO', '% KO', "Cohérence SIG","Cohérence version COMAC",	"Cohérence Hypothèse Climatique", "Cohérence modélisation Canton", "Cohérence Description de l'appui",	"Cohérence Equipements Existants",	"Cohérence Photos",	"Cohérence Contrôle Visuel", "Cohérence Nature du cable",	"Cohérence Nombre de cable", "Cohérence Orientation de la ligne", "Cohérence Orientation de l'appui", "Cohérence écart des lignes",	"Cohérence Flèche Usuelle",	"Cohérence Hauteur de ligne", "Cohérence Parallélisme de la ligne",	"Cohérence des branchements non modélisés"]
            entete_orange = ['TYPE ETUDE', 'ETUDE', 'STATUT', 'NB_APPUI', 'NB_APPUI_ME', 'NB_APPUI_KO', 'CABLE_MAX',
                             'Cohérence MCD', 'Cohérence Appui', 'Cohérence Ligne', 'Cohérence travaux à réaliser',
                             '% KO']
            entete_enedis = ['TYPE ETUDE', 'ETUDE', 'STATUT', 'NB_APPUI', 'NB_APPUI_KO', 'CABLE_MAX', 'Cohérence MCD',
                             'Cohérence Appui', 'Cohérence Ligne', 'Cohérence Parametres de la ligne', 'Branchements',
                             '% KO']

            # Partie Creation des listes globales utilisables
            list_pr_global = []

            # Parti Creation du sheet Global et renommage
            var_workbook = Workbook()
            global_sheet = var_workbook[var_workbook.sheetnames[0]]
            global_sheet.title = 'Global_PR'
            bar_progress = self.progress_bar('Partie Création Toutes les Syntheses')

            # Partie Creation dictionnaire pour les syntheses par ZSRO
            dict_synthese_zsro = {}
            for index_dic, value_dict in dict_merging.items():
                # str(value_dict[1]).split(';')[1] == nom Etude
                # str(index_dic).split(';')[0][-4:] == CODE_ZSRO
                value_dict[1] = str(value_dict[1]).split(';')[1]
                self.function_create_dict(dict_synthese_zsro, str(index_dic).split(';')[0], value_dict)

            len_list_cable_not_cdi_ctr_cab_orange = 0
            len_list_cable_not_cdi_ctr_cab_enedis = 0
            for index_count, (index_dic, value_dict) in enumerate(dict_synthese_zsro.items()):
                var_dynamic_sheet = var_workbook.create_sheet(str(index_dic))  # Creation des sheets par ZSRO
                # Cretion des sommes par sheet
                var_list_sum_orange = self.function_calcule_sum_row_column(value_dict, self.var_orange_appui)
                var_list_sum_enedis = self.function_calcule_sum_row_column(value_dict, self.var_enedis_appui)

                # Cretion des pourcentages
                res_pourcent = self.function_round(var_list_sum_orange[5], var_list_sum_orange[3])
                res_pourcent_enedis = self.function_round(var_list_sum_enedis[4], var_list_sum_enedis[3])

                # Creation des listes pour la synthese globale
                value_list_pr_global = [self.var_orange_appui, index_dic, var_list_sum_orange[1],
                                        var_list_sum_orange[2],
                                        var_list_sum_orange[3], var_list_sum_orange[5],
                                        res_pourcent]
                value_list_pr_global_enedis = [self.var_enedis_appui, index_dic, var_list_sum_enedis[1],
                                               var_list_sum_enedis[2],
                                               var_list_sum_enedis[3], var_list_sum_enedis[4], res_pourcent_enedis]
                # Partie Synthese Orange
                var_res_orange = False
                for index_insert in range(len(value_dict)):
                    if value_dict[index_insert][0] == self.var_orange_appui:
                        var_dynamic_sheet.append(entete_orange)
                        break
                for index_insert in range(len(value_dict)):
                    insert_vals = value_dict[index_insert]
                    current_type = value_dict[index_insert][0]
                    old_current_type = value_dict[index_insert - 1][0]
                    if current_type != old_current_type:
                        if current_type == self.var_orange_appui:
                            pass
                        else:
                            # Synthese after column KO pour ORANGE
                            for index_key, values_data in res_data_orange[1].items():
                                if index_key == index_dic:
                                    value_list_pr_global = value_list_pr_global + values_data[2:]
                                    var_res_orange = True
                                    len_list_cable_not_cdi_ctr_cab_orange = len(values_data[2:])
                            list_pr_global.append(value_list_pr_global)  # Ajout dans la liste PR_GLOBAL
                            var_dynamic_sheet.append(var_list_sum_orange)  # Sum Row_Column
                            var_dynamic_sheet.append([])
                            var_dynamic_sheet.append(entete_enedis)
                    var_dynamic_sheet.append(insert_vals)
                # Exclure les cables non CDI CTR CAB dans le Calcul
                if var_res_orange is False:  # Orange sans cables CDI, CTR, CAB
                    value_list_pr_global_orange = value_list_pr_global + \
                                                  [0 for x in range(len_list_cable_not_cdi_ctr_cab_orange)]
                    list_pr_global.append(value_list_pr_global_orange)  # Ajout dans la liste PR_GLOBAL
                    var_dynamic_sheet.append(var_list_sum_orange)  # Sum Row_Column

                # Partie Synthese ENEDIS
                # Synthese after column KO pour ENEDIS
                var_res_enedis = False
                for index_key, values_data in res_data_enedis[1].items():
                    if index_key == index_dic:
                        value_list_pr_global_enedis = value_list_pr_global_enedis + values_data[2:]
                        var_res_enedis = True
                        len_list_cable_not_cdi_ctr_cab_enedis = len(values_data[2:])
                # Exclure les cables non CDI CTR CAB dans le Calcul
                if var_res_enedis is False:  # ENEDIS sans cables CDI, CTR, CAB
                    value_list_pr_global_enedis = value_list_pr_global_enedis + \
                                                  [0 for x in range(len_list_cable_not_cdi_ctr_cab_enedis)]
                list_pr_global.append(value_list_pr_global_enedis)  # Ajout dans la liste PR_GLOBAL
                if len(list(set(var_list_sum_enedis))) != 1:  # Pas de somme sur ENEDIS vides
                    var_dynamic_sheet.append(var_list_sum_enedis)  # Sum Row_Column
                self.progress_processing(index_count, len(dict_synthese_zsro), bar_progress)
                if bar_progress.wasCanceled():
                    iface.messageBar().pushMessage('Info', 'Action Cancelled', level=Qgis.Info)
                    break
            # Partie Sheet pour la synthese Global
            list_pr_global.sort(key=lambda x: x[0], reverse=True)
            for index_global_sheet in range(len(list_pr_global)):
                insert_vals_global = list_pr_global[index_global_sheet]
                current_type_global = list_pr_global[index_global_sheet][0]
                old_current_type_global = list_pr_global[index_global_sheet - 1][0]
                if current_type_global != old_current_type_global:
                    if current_type_global == self.var_orange_appui:
                        global_sheet.append(entete_global_sheet_orange)
                    else:
                        var_list_sum_global_orange = self.function_calcule_sum_row_column(list_pr_global,
                                                                                          self.var_orange_appui)
                        global_sheet.append(var_list_sum_global_orange)  # Sum Row_Column
                        global_sheet.append([])
                        global_sheet.append(entete_global_sheet_enedis)
                global_sheet.append(insert_vals_global)
                self.progress_processing(index_global_sheet, len(list_pr_global), bar_progress)
                if bar_progress.wasCanceled():
                    iface.messageBar().pushMessage('Info', 'Action Cancelled', level=Qgis.Info)
                    break

            var_list_sum_global_enedis = self.function_calcule_sum_row_column(list_pr_global, self.var_enedis_appui)
            global_sheet.append(var_list_sum_global_enedis)  # Sum Row_Column
            var_workbook.save(f"{self.folder_export_res}/resultat_brut_synthese.xlsx")
        except Exception as error:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            self.var_list_all_erreur_traitement.append(['function_create_all_syntheses', exc_type, exc_obj,
                                                        exc_tb.tb_lineno, error])

    # Function pour calculer les sommes dans le PR global apres la colonne %
    def function_sum_column_after_ko(self, var_list_sheet_data, var_list_sum_column_orange_entet):
        try:
            dict_get_all_data_for_zsro = {}
            dict_all_data_after_column_ko = {}
            for index_global in var_list_sheet_data:
                value_sro = index_global[self.var_sheet_name]  # SRO name_sheet
                for enete_ref_column in var_list_sum_column_orange_entet:
                    self.function_create_dict(dict_get_all_data_for_zsro, f'{value_sro};{enete_ref_column}',
                                              index_global[enete_ref_column])

            for index_key, values_data in dict_get_all_data_for_zsro.items():
                count = 0
                for majeur in values_data:
                    # Count que si different de OUI et vide
                    if str(majeur).upper() not in [self.var_coherence_mcd_conforme, '']:
                        count += 1
                self.function_create_dict(dict_all_data_after_column_ko,
                                          f'{str(index_key).split(";")[0][-4:]}', count)
            return dict_all_data_after_column_ko
        except Exception as error:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            self.var_list_all_erreur_traitement.append(['function_sum_column_after_ko', exc_type, exc_obj,
                                                        exc_tb.tb_lineno, error])

    # Function pour creer la liste des sommes row colomn
    def function_calcule_sum_row_column(self, var_list, var_type_appuis):
        try:
            sum_list = []
            if var_list:
                ncols = len(var_list[0])
                for index_len in var_list:
                    if index_len[0] == var_type_appuis:
                        ncols = len(index_len)
                        break
                for col in range(ncols):
                    list_intermediare = []
                    for row in var_list:
                        if row[0] == var_type_appuis:  # Si ORANGE ou ENEDIS
                            list_intermediare.append(row[col])
                    cal_value_sum_len = ''.join([str(ii) for ii in list_intermediare])
                    if cal_value_sum_len.isnumeric():  # Si cest que du numeric on fait la sum
                        sum_list.append(sum(list_intermediare))
                    else:  # Si autres que numeric on fait la longueur
                        count = 0
                        for majeur in list_intermediare:
                            # Count que les majeurs ou a reprendre
                            if majeur in [self.var_res_majeur, self.var_res_a_reprendre]:
                                count += 1
                        if count != 0:
                            sum_list.append(count)
                        else:
                            sum_list.append(len(list_intermediare))
            return sum_list
        except Exception as error:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            self.var_list_all_erreur_traitement.append(['function_calcule_sum_row_column', exc_type, exc_obj,
                                                        exc_tb.tb_lineno, error])

    # Function pour calculer le %
    def function_round(self, x, y):
        try:
            if y != 0:
                return round((x / y) * 100)
            else:
                return 0
        except Exception as error:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            self.var_list_all_erreur_traitement.append(['function_round', exc_type, exc_obj, exc_tb.tb_lineno, error])
            return 0

    # function creation des dictionnaires
    @staticmethod
    def function_create_dict(var_dict, var_val_key, var_val_value):
        if var_val_key not in var_dict:
            var_dict[var_val_key] = [var_val_value]
        else:
            var_dict[var_val_key].append(var_val_value)

    # Function Count Occurrence
    @staticmethod
    def function_occur_dict(a):
        d = {}
        for i in a:
            if i in d:
                d[i] = d[i] + 1
            else:
                d[i] = 1
        return d

    # Function Count nombre
    def function_number_occurrence_etat_appuis(self, var_dict, var_etat_appuis, var_all_dict_synthese):
        try:
            dict_number_occurrence_etat_appuis = {}
            for key_index_nb_appui_me, value_index_nb_appui_me in var_dict.items():
                nbre_me_appui = 0
                for index_vals, vals in self.function_occur_dict(value_index_nb_appui_me).items():
                    if index_vals == var_etat_appuis:
                        nbre_me_appui = vals
                # self.list_synthese_aer_orange.append([key_index_nb_appui_me, nbre_me_appui, value_index_nb_appui_me])
                self.function_create_dict(dict_number_occurrence_etat_appuis, key_index_nb_appui_me, nbre_me_appui)
            var_all_dict_synthese.append(dict_number_occurrence_etat_appuis)
        except Exception as error:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            self.var_list_all_erreur_traitement.append(['function_number_occurrence_etat_appuis', exc_type, exc_obj,
                                                        exc_tb.tb_lineno, error])

    # Function count Nombre
    def function_count_nombre_appuis(self, var_dict, var_all_dict_synthese):
        try:
            dict_count_nombre_appuis = {}
            for key_index_nb_appui, value_index_nb_appui in var_dict.items():
                # self.list_synthese_aer_orange.append([key_index_nb_appui, len(value_index_nb_appui), value_index_nb_appui])
                self.function_create_dict(dict_count_nombre_appuis, key_index_nb_appui, len(value_index_nb_appui))
            var_all_dict_synthese.append(dict_count_nombre_appuis)
        except Exception as error:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            self.var_list_all_erreur_traitement.append(['function_count_nombre_appuis', exc_type, exc_obj,
                                                        exc_tb.tb_lineno, error])

    # Function Capa Max des cables de lappuis
    def function_capa_max_appui(self, var_dict_value_cable_max, var_all_dict_synthese):
        dict_capa_max_appuis = {}
        try:
            for index_capa, value_capa in var_dict_value_cable_max.items():
                dict_capa_max_etude_test = {}
                for check_i in value_capa:
                    for val_capa_ref in self.list_capacite:
                        matching = [s[:s.find('vers')] for s in str(check_i).split('/') if
                                    val_capa_ref in s.replace(' ', '')]
                        if matching:
                            # print('matching', ';;;', index_capa, ';;;', matching)
                            self.function_create_dict(dict_capa_max_etude_test, index_capa, ''.join(list(set(matching))))

                # self.function_create_dict(dict_capa_max_appuis, index_capa, var_values_list_capa_max)
                if dict_capa_max_etude_test:
                    var_values_list_capa_max = list(set(list(dict_capa_max_etude_test.values())[0]))
                    self.function_create_dict(dict_capa_max_appuis, index_capa, var_values_list_capa_max)
                else:
                    self.function_create_dict(dict_capa_max_appuis, index_capa, ['EstVide'])

            dict_capa_max_appuis_final = {}
            for index_max_capa, value_max_capa in dict_capa_max_appuis.items():
                capa = list(set([x for x in value_max_capa[0]]))  # Supprimer les doublons
                restest = [(index_capa[:index_capa.replace(' ', '').find(val_capa_ref)],
                            re.sub(r"[\s+F-]", "", str(index_capa[index_capa.replace(' ', '').find(val_capa_ref):]))
                            )
                           for val_capa_ref in self.list_capacite for index_capa in capa
                           if index_capa.replace(' ', '').find(val_capa_ref) != -1]
                if restest:
                    result_max_capa = ';'.join(max(restest, key=lambda item: item[1]))
                    # self.list_synthese_aer_orange.append([index_max_capa, result_max_capa, capa])
                    self.function_create_dict(dict_capa_max_appuis_final, index_max_capa, result_max_capa)
                else:  # Si La cellule est vide on replace par CONFORME
                    self.function_create_dict(dict_capa_max_appuis_final, index_max_capa, self.var_res_conforme)
            var_all_dict_synthese.append(dict_capa_max_appuis_final)

        except Exception as error:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            self.var_list_all_erreur_traitement.append(['function_capa_max_appui', exc_type, exc_obj,
                                                        exc_tb.tb_lineno, error])

    # Function Coherence Majeur et Conforme
    def function_coherence_appuis_majeur_conforme(self, var_dict_value_coherence, var_all_dict_synthese):
        try:
            dict_coherence_appuis_final = {}
            for index_cohernce, values_coherence in var_dict_value_coherence.items():
                var_check_mcd = list(set(str(xx).lower() for xx in values_coherence if xx))
                result_coherence_mcd = self.var_res_conforme
                var_check_majeur_conform = [self.var_res_majeur for yy in self.var_all_list_majeur if str(yy).lower() in var_check_mcd]
                if len(var_check_majeur_conform) != 0:
                    result_coherence_mcd = self.var_res_majeur
                # self.list_synthese_aer_orange.append([index_cohernce, result_coherence_mcd, values_coherence])
                self.function_create_dict(dict_coherence_appuis_final, index_cohernce, result_coherence_mcd)
            var_all_dict_synthese.append(dict_coherence_appuis_final)
        except Exception as error:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            self.var_list_all_erreur_traitement.append(['function_coherence_appuis_majeur_conforme', exc_type, exc_obj,
                                                        exc_tb.tb_lineno, error])

    # Function Coherence Majeur, Conforme et OUI
    def function_coherence_appuis_majeur_mineur_conforme(self, var_dict_value_coherence, var_all_dict_synthese):
        try:
            dict_coherence_appuis_final = {}
            for index_cohernce, values_coherence in var_dict_value_coherence.items():
                var_check_appuis_miniscule = list(set(str(xx).lower() if xx else str(self.var_coherence_mcd_conforme).lower() for xx in values_coherence))
                result_coherence_appuis = False
                if str(self.var_res_majeur).lower() in var_check_appuis_miniscule:
                    result_coherence_appuis = self.var_res_majeur
                if str(self.var_res_mineur).lower() in var_check_appuis_miniscule and \
                        not str(self.var_res_majeur).lower() in var_check_appuis_miniscule:
                    result_coherence_appuis = self.var_res_mineur
                if str(self.var_coherence_mcd_conforme).lower() in var_check_appuis_miniscule and \
                        not str(self.var_res_majeur).lower() in var_check_appuis_miniscule and \
                        not str(self.var_res_mineur).lower() in var_check_appuis_miniscule:
                    result_coherence_appuis = self.var_res_conforme
                # self.list_synthese_aer_orange.append([index_cohernce, result_coherence_appuis, values_coherence])
                self.function_create_dict(dict_coherence_appuis_final, index_cohernce, result_coherence_appuis)
            var_all_dict_synthese.append(dict_coherence_appuis_final)
        except Exception as error:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            self.var_list_all_erreur_traitement.append(['function_coherence_appuis_majeur_mineur_conforme', exc_type, exc_obj, exc_tb.tb_lineno, error])

    # Function pour lecture fichier pour Orange
    def function_create_fusion_sheet_dpi_orange(self):
        if self.fichier_appuis:
            try:
                bar_progress = self.progress_bar('Partie Création Sheet DPI pour ORANGE')
                # data_only ignores loading formulas and instead loads only the resulting values.
                wb = load_workbook(filename=self.fichier_appuis, data_only=True)
                sheets_all = wb.sheetnames
                list_values_data = []
                list_key_data = []
                list_sheet_data = []
                var_list_erreur_model = []
                var_entet_ref = ['SRO', 'Nom Etude', 'Réf. FCI', 'Commune', 'INSEE', 'Nom appui', 'Type Appui', 'Description', 'Type de déploiement (Raccordement/Distribution)', 'Etat du support', 'Résultat du Calcul de Charge', 'Solution', "Nouveau type d'appui", 'Date de livraison Etude', 'Validation Orange', 'Date prévisionnelle déploiement fibre optique', 'Date prévisionnelle de travaux de remplacement', 'Comentaires', 'Etiquette du câble\n(cb_etiquet)', '\nType de fibre\n(cb_capa_fo)', '\nCohérence\nSIG\n(Oui/Majeur)', 'Cohérence version CAPFT', "\nCohérence\nDescription de l'appui\n(Oui/Majeur)", '\nCohérence\nContrôle Visuel\n(Oui/Mineur)', '\nCohérence\nPhotos\n(Oui/Majeur)', '\nCohérence\nEquipements Existants\n(Oui/Mineur/Majeur)', "\nRemplissage de la\nFiche d'Appui\n(Oui/Mineur/Majeur)", "\nCohérence\nFiche d'Appui\n(Oui/Mineur/Majeur)", '\nCohérence\nNature du cable\n(Oui/Majeur)', '\nCohérence\nNombre de cable\n(Oui/Majeur)', '\nCohérence\nOrientation de la ligne\n(Oui/Majeur)', "\nCohérence\nOrientation de l'appui\n(Oui/Majeur)", '\nCohérence\nDescription de la ligne \n(Oui/Mineur/Majeur)', 'Cohérence\nécart des lignes\n(Oui/Mineur/Majeur)', '\nCohérence\nPose de réhausse\n(Oui/Mineur)', 'Cohérence\ntravaux à réaliser', 'Contre Relevé terrain', 'Appui\nMobilisable', 'Synthèse\nEtude DEO', 'Commentaire DEO', 'Réponse DEO', 'Type : Chambre Orange = C,    Appui Orange = A,    Potelet Orange = P,    Immeuble = IMB,    Façade = F,    Chambre Tiers = CT,    Appui tiers = AT,    Potelet Tiers = PT', 'Numéro chambre ou de poteau ou de Potelet (code INSEE/N° chambre ou code INSEE/ N° de poteau ou code INSEE/ N° de Potelet)', 'Type : Chambre Orange = C,    Appui Orange = A,    Potelet Orange = P,    Immeuble = IMB,    Façade = F,    Chambre Tiers = CT,    Appui tiers = AT,    Potelet Tiers = PT', 'Numéro chambre ou de poteau ou de Potelet (code INSEE/N° chambre ou code INSEE/N° de poteau ou code INSEE/ N° de Potelet)', 'Longueur du tronçon ou de la portée en domaine public (m)', "Diamètre de l'alvéole prévue d'être utilisée par l'opérateur (mm)", ' Tubage rigide pour convenance', 'Diamètre du tube à installer (mm)', 'Diamètre du câble à poser (mm)', 'Commentaires opérateur', "Percement de la chambre A ou remplacement ou renforcement de l'appui aérien A", "Percement de la chambre B ou remplacement ou renforcement de l'appui aérien B", 'Installation de manchons ou PEO ou PMSB ou PB : chambre ou appui aérien (A ou B)', 'Synthèse\nEtude EXE', 'Commentaire EXE', 'Réponse EXE']
                var_list_sum_column_orange = ['SRO', 'Nom Etude', '\nCohérence\nSIG\n(Oui/Majeur)', 'Cohérence version CAPFT', "\nCohérence\nDescription de l'appui\n(Oui/Majeur)", '\nCohérence\nContrôle Visuel\n(Oui/Mineur)', '\nCohérence\nPhotos\n(Oui/Majeur)', '\nCohérence\nEquipements Existants\n(Oui/Mineur/Majeur)', "\nRemplissage de la\nFiche d'Appui\n(Oui/Mineur/Majeur)", '\nCohérence\nNature du cable\n(Oui/Majeur)', '\nCohérence\nNombre de cable\n(Oui/Majeur)', '\nCohérence\nOrientation de la ligne\n(Oui/Majeur)', "\nCohérence\nOrientation de l'appui\n(Oui/Majeur)", 'Cohérence\nécart des lignes\n(Oui/Mineur/Majeur)', '\nCohérence\nPose de réhausse\n(Oui/Mineur)', 'Cohérence\ntravaux à réaliser']

                # Partie Parcours des sheets et les fusionner
                for index_loop in range(len(sheets_all)):
                    index_sheet = sheets_all[index_loop]
                    # Prendre que les les sheets dont les dix derniers digits = AER_ORANGE
                    if index_sheet[-10:] == self.var_sheet_aer_orange:  # if index_sheet == 'MD01_AER_ORANGE':
                        sheet = wb[index_sheet]
                        col_count = sheet.max_column + 1
                        column_names = {}
                        for c in range(1, col_count):
                            heading = sheet.cell(row=7, column=c).value
                            column_names[c] = heading

                        # Verfication des colonnes absentes par rapport au modele
                        list_val_dict = list(column_names.values())
                        for index_file in range(0, len(list_val_dict)):
                            var_entite_file = list_val_dict[index_file]
                            if var_entite_file not in var_entet_ref:
                                var_insert = [index_sheet, var_entite_file, var_entite_file, self.var_incoherence_nom_entete]
                                if var_insert not in var_list_erreur_model:
                                    var_list_erreur_model.append(var_insert)

                        # Ne prendre que les entites presentes dans le modele
                        var_compare_entete_by_ref = len(var_entet_ref) == len(list_val_dict)
                        if var_compare_entete_by_ref:
                            sheet_values = sheet.iter_rows(min_row=8, values_only=True)
                            for r, row_cells in enumerate(sheet_values, 8):
                                row = {}
                                for c in range(1, col_count):
                                    cell_content = sheet.cell(row=r, column=c)
                                    celle_value = str(cell_content.value).replace('None', '')
                                    row[self.var_sheet_name] = str(index_sheet[:4])
                                    row[column_names[c]] = celle_value
                                # Filtre des cables pour ne prendre que ceux des CDI, CTR ET CAB
                                var_value_capa = row['Etiquette du câble\n(cb_etiquet)']
                                if var_value_capa:
                                    var_mist_filtre_cab = [indexCab[:3] for indexCab in var_value_capa.split(',')
                                                           if indexCab[:3] in self.var_list_cable_filtre]
                                    if var_mist_filtre_cab:
                                        list_values_data.append(tuple(row.values()))
                                        list_key_data.append(tuple(row.keys()))
                                        list_sheet_data.append(row)
                        else:
                            var_res_insert = [index_sheet, len(var_entet_ref), len(list_val_dict),
                                              self.var_incoherence_longueur_entete]
                            if var_res_insert not in var_list_erreur_model:
                                var_list_erreur_model.append(var_res_insert)
                    self.progress_processing(index_loop, len(sheets_all), bar_progress)
                    if bar_progress.wasCanceled():
                        iface.messageBar().pushMessage('Info', 'Action Cancelled', level=Qgis.Info)
                        break
                # Partie recuperation des informations par colonnne
                if not var_list_erreur_model:
                    dict_value_finale = {}
                    dict_value_nb_appui = {}
                    dict_value_nb_appui_me = {}
                    dict_value_nb_appui_ko = {}
                    dict_value_cable_max = {}
                    dict_coherence_mcd = {}
                    dict_coherence_appui = {}
                    dict_coherence_ligne = {}
                    dict_coherence_travaux_realiser = {}

                    # Partie Recuperation des sommes de syntheses pour le sheet Global
                    res_sum_column_after_ko = self.function_sum_column_after_ko(list_sheet_data,
                                                                                var_list_sum_column_orange)

                    # Partie recuperation des informations pour chaque sheet
                    for index_data_recup in range(len(list_sheet_data)):
                        value_sheet = list_sheet_data[index_data_recup]
                        value_sro = value_sheet['name_sheet']
                        value_etude = value_sheet['Nom Etude']
                        value_nb_appui = value_sheet['Nom appui']  # somme du nombre de poteau de la colonne F
                        value_nb_appui_me = value_sheet['Etat du support']  # somme du nombre de poteau ME de la colonne J

                        # somme du nombre de poteau KO de la colonne L et M pour ENEDIS
                        value_nb_appui_ko = value_sheet['Solution']

                        # capacité la plus forte issue de la colonne S pour ORANGE et X pour ENEDIS
                        value_cable_max = value_sheet['Etiquette du câble\n(cb_etiquet)']

                        # MAJEUR si l’information « incoherence MCD », CONFORME si « OUI » est indiquée
                        # dans la colonne U pour ORANGE et AA pour ENEDIS
                        value_coherence_mcd = value_sheet['\nCohérence\nSIG\n(Oui/Majeur)']

                        # MAJEUR si l’information « MAJEUR», MINEUR si l’information « MINEUR»,
                        # CONFORME si « OUI » est indiquée dans la colonne AB pour ORANGE et AI pour ENEDIS
                        value_coherence_appui = value_sheet['\nCohérence\nFiche d\'Appui\n(Oui/Mineur/Majeur)']

                        # MAJEUR si l’information « MAJEUR», MINEUR si l’information « MINEUR»,
                        # CONFORME si « OUI » est indiquée dans la colonne AG pour ORANGE et AN pour ENEDIS
                        value_coherence_ligne = value_sheet['\nCohérence\nDescription de la ligne \n(Oui/Mineur/Majeur)']

                        # MAJEUR si l’information « incohérence travaux» ou « non respect des règles Orange »,
                        # CONFORME si « OUI » est indiquée dans la colonne AJ pour ORANGE
                        value_coherence_travaux_realiser = value_sheet['Cohérence\ntravaux à réaliser']
                        if value_etude:
                            self.function_create_dict(dict_value_finale, f'{value_sro};{value_etude}', [value_nb_appui,
                                                                                       value_nb_appui_me,
                                                                                       value_nb_appui_ko,
                                                                                       value_cable_max,
                                                                                       value_coherence_mcd,
                                                                                       value_coherence_appui,
                                                                                       value_coherence_ligne,
                                                                                       value_coherence_travaux_realiser])

                    for key_index_test, value_index_test in dict_value_finale.items():
                        for index_val in range(len(value_index_test)):
                            self.function_create_dict(dict_value_nb_appui, key_index_test, value_index_test[index_val][0])
                            self.function_create_dict(dict_value_nb_appui_me, key_index_test,
                                                      value_index_test[index_val][1])
                            self.function_create_dict(dict_value_nb_appui_ko, key_index_test,
                                                      value_index_test[index_val][2])
                            self.function_create_dict(dict_value_cable_max, key_index_test,
                                                      value_index_test[index_val][3])
                            self.function_create_dict(dict_coherence_mcd, key_index_test,
                                                      value_index_test[index_val][4])
                            self.function_create_dict(dict_coherence_appui, key_index_test,
                                                      value_index_test[index_val][5])
                            self.function_create_dict(dict_coherence_ligne, key_index_test,
                                                      value_index_test[index_val][6])
                            self.function_create_dict(dict_coherence_travaux_realiser, key_index_test,
                                                      value_index_test[index_val][7])
                    # Partie Synthese NBAppui----------------------------somme du nombre de poteau de la colonne F
                    self.function_count_nombre_appuis(dict_value_nb_appui, self.all_dict_synthese_aer_orange)
                    # Partie Synthese ME_Appui----------------------------somme du nombre de poteau ME de la colonne J
                    self.function_number_occurrence_etat_appuis(dict_value_nb_appui_me, 'ME', self.all_dict_synthese_aer_orange)
                    # Partie Synthese KO_Appui----------------------------# somme du nombre de poteau KO de la colonne L
                    self.function_number_occurrence_etat_appuis(dict_value_nb_appui_ko, 'KO', self.all_dict_synthese_aer_orange)
                    # Partie Synthese CapaMax_Appui----------------------------
                    self.function_capa_max_appui(dict_value_cable_max, self.all_dict_synthese_aer_orange)
                    # Partie Synthese CoherenceMCD_Appui----------------------------
                    self.function_coherence_appuis_majeur_conforme(dict_coherence_mcd, self.all_dict_synthese_aer_orange)
                    # Partie Synthese CoherenceAppui_Appui----------------------------
                    self.function_coherence_appuis_majeur_mineur_conforme(dict_coherence_appui, self.all_dict_synthese_aer_orange)
                    # Partie Synthese CoherenceLigne_Appui----------------------------
                    self.function_coherence_appuis_majeur_mineur_conforme(dict_coherence_ligne, self.all_dict_synthese_aer_orange)
                    # Partie Synthese CoherenceLigne_Appui----------------------------
                    self.function_coherence_appuis_majeur_conforme(dict_coherence_travaux_realiser, self.all_dict_synthese_aer_orange)

                    dict_all_info_synthese = {}
                    for k in self.all_dict_synthese_aer_orange[0].keys():
                        dict_all_info_synthese[k] = sum([dict_all_info_synthese[k] for dict_all_info_synthese in
                                                         self.all_dict_synthese_aer_orange if k in dict_all_info_synthese], [])
                    for index_val, (index_xx, vauex_xx) in enumerate(dict_all_info_synthese.items()):
                        # Calul du %
                        dict_all_info_synthese[index_xx].append(self.function_round(vauex_xx[2], vauex_xx[0]))

                        # indiquer VALIDE EN L'ETAT si sur les colonnes G à J tout est CONFORME / MINEUR ou
                        # A REPRENDRE si sur les colonnes G à J un ou plusieurs MAJEUR est indiqué
                        if self.var_res_majeur in vauex_xx[-5:]:
                            dict_all_info_synthese[index_xx].insert(0, self.var_res_a_reprendre)
                        else:
                            dict_all_info_synthese[index_xx].insert(0, self.var_res_valide_etat)
                        dict_all_info_synthese[index_xx].insert(0, index_xx)  # Insert Nom etude dans la liste
                        # Insert Tag Name ORANGE dans la liste
                        dict_all_info_synthese[index_xx].insert(0, self.var_orange_appui)
                        self.progress_processing(index_val, len(dict_all_info_synthese), bar_progress)
                        if bar_progress.wasCanceled():
                            iface.messageBar().pushMessage('Info', 'Action Cancelled', level=Qgis.Info)
                            break
                    return dict_all_info_synthese, res_sum_column_after_ko
                else:
                    self.var_list_all_erreur_traitement.append(
                    ['function_create_fusion_sheet_dpi_orange', 'ERRRR Model', var_list_erreur_model, 'ERRRR Model', 'ERRRR Model'])

            except Exception as error:
                exc_type, exc_obj, exc_tb = sys.exc_info()
                self.var_list_all_erreur_traitement.append(
                    ['function_create_fusion_sheet_dpi_orange', exc_type, exc_obj, exc_tb.tb_lineno, error])
        else:
            self.var_list_all_erreur_traitement.append(
                ['function_create_fusion_sheet_dpi_orange', '', '', '',
                 'Erreur douverture du fichier donc pas de tratitement sur ce fichier'])

    # Function pour lecture fichier pour Enedis
    def function_create_fusion_sheet_dpi_enedis(self):
        if self.fichier_appuis:
            try:
                bar_progress = self.progress_bar('Partie Création Sheet DPI pour ENEDIS')
                # data_only ignores loading formulas and instead loads only the resulting values.
                wb = load_workbook(filename=self.fichier_appuis, data_only=True)
                sheets_all = wb.sheetnames
                list_values_data = []
                list_key_data = []
                list_sheet_data = []
                list_sheet_data_test_abaa = []
                var_list_erreur_model = []
                var_entet_ref = ['SRO', 'Nom Etude', 'Référence ENEDIS', 'Commune', 'INSEE', 'Nom appui', 'Type Appui', 'Année', 'Taux Global', 'Description', 'Type de déploiement (Raccordement/Distribution)', 'Etat du support', 'Résultat du Calcul de Charge', 'Date de livraison Etude', 'Validation ENEDIS', 'Bandeau Vert\nAprès retour ENEDIS', "Utilisable\nNon utilisable\nManque d'informations\nAprès retour ENEDIS", 'Solution', 'Linéaire facturé', "Nouveau type d'appui", 'Date prévisionnelle déploiement fibre optique', 'Date prévisionnelle de travaux de remplacement', 'Comentaires', 'Etiquette du câble\n(cb_etiquet)', '\nType de fibre\n(cb_capa_fo)', "Contrôle Visuel\n(cf, fiche d'appui)", 'Cohérence\nSIG\n(Oui/Majeur)', 'Cohérence version COMAC', 'Cohérence Hypothèse Climatique', 'Cohérence modélisation Canton', "Cohérence\nDescription de l'appui\n(Oui/Majeur)", 'Cohérence\nEquipements Existants\n(Oui/Mineur)', 'Cohérence\nPhotos\n(Oui/Majeur)', 'Cohérence\nContrôle Visuel\n(Oui/Mineur)', "Cohérence\nde l'Appui\n(Oui/Mineur/Majeur)", 'Cohérence\nNature du cable\n(Oui/Majeur)', 'Cohérence\nNombre de cable\n(Oui/Majeur)', 'Cohérence\nOrientation de la ligne\n(Oui/Majeur)', "Cohérence\nOrientation de l'appui\n(Oui/Majeur)", 'Cohérence\nDescription de la ligne \n(Oui/Mineur/Majeur)', 'Cohérence\nécart des lignes\n(Oui/Mineur/Majeur)', 'Cohérence\nFlèche Usuelle\n(Oui/Majeur)', 'Cohérence\nHauteur de ligne\n(Oui//Majeur)', 'Cohérence\nParallélisme de la ligne\n(Oui/Majeur)', 'Cohérence\nParametres de la ligne \n(Oui/Mineur/Majeur)', 'Cohérence des branchements\nnon modélisés \n(Oui/Majeur)', 'Contre Relevé terrain', 'Appui\nMobilisable', 'Synthèse\nEtude DEO', 'Commentaire DEO', 'Réponse DEO', 'Synthèse\nEtude EXE', 'Commentaire EXE', 'Réponse EXE']
                var_list_sum_column_enedis = ['SRO', 'Nom Etude', 'Cohérence\nSIG\n(Oui/Majeur)', 'Cohérence version COMAC', 'Cohérence Hypothèse Climatique', 'Cohérence modélisation Canton', "Cohérence\nDescription de l'appui\n(Oui/Majeur)", 'Cohérence\nEquipements Existants\n(Oui/Mineur)', 'Cohérence\nPhotos\n(Oui/Majeur)', 'Cohérence\nContrôle Visuel\n(Oui/Mineur)', 'Cohérence\nNature du cable\n(Oui/Majeur)', 'Cohérence\nNombre de cable\n(Oui/Majeur)', 'Cohérence\nOrientation de la ligne\n(Oui/Majeur)', "Cohérence\nOrientation de l'appui\n(Oui/Majeur)", 'Cohérence\nécart des lignes\n(Oui/Mineur/Majeur)', 'Cohérence\nFlèche Usuelle\n(Oui/Majeur)', 'Cohérence\nHauteur de ligne\n(Oui//Majeur)', 'Cohérence\nParallélisme de la ligne\n(Oui/Majeur)', 'Cohérence des branchements\nnon modélisés \n(Oui/Majeur)']

                # Partie Parcours des sheets et les fusionner
                for index_loop in range(len(sheets_all)):
                    index_sheet = sheets_all[index_loop]
                    # Prendre que les les sheets dont les dix derniers digits = AER_ORANGE
                    if index_sheet[-10:] == 'AER_ENEDIS':  # if index_sheet == 'MD01_AER_ORANGE':
                        sheet = wb[index_sheet]
                        col_count = sheet.max_column + 1
                        column_names = {}
                        for c in range(1, col_count):
                            heading = sheet.cell(row=7, column=c).value
                            column_names[c] = heading

                        # Verfication des colonnes absentes par rapport au modele
                        list_val_dict = list(column_names.values())
                        for index_file in range(0, len(list_val_dict)):
                            var_entite_file = list_val_dict[index_file]
                            if var_entite_file not in var_entet_ref:
                                var_insert = [index_sheet, var_entite_file, var_entite_file,
                                              self.var_incoherence_nom_entete]
                                if var_insert not in var_list_erreur_model:
                                    var_list_erreur_model.append(var_insert)

                        # Ne prendre que les entites presentes dans le modele
                        var_compare_entete_by_ref = len(var_entet_ref) == len(list_val_dict)
                        if var_compare_entete_by_ref:
                            sheet_values = sheet.iter_rows(min_row=8, values_only=True)
                            for r, row_cells in enumerate(sheet_values, 8):
                                row = {}
                                for c in range(1, col_count):
                                    cell_content = sheet.cell(row=r, column=c)
                                    celle_value = str(cell_content.value).replace('None', '')
                                    row[self.var_sheet_name] = str(index_sheet[:4])
                                    row[column_names[c]] = celle_value
                                # Filtre des cables pour ne prendre que ceux des CDI, CTR ET CAB
                                var_value_capa = row['Etiquette du câble\n(cb_etiquet)']
                                if var_value_capa:
                                    var_mist_filtre_cab = [indexCab[:3] for indexCab in var_value_capa.split(',')
                                                           if indexCab[:3] in self.var_list_cable_filtre]
                                    if var_mist_filtre_cab:
                                        # print(var_value_capa, ';;;;;;', var_mist_filtre_cab)
                                        list_sheet_data_test_abaa.append(row)
                                        list_values_data.append(tuple(row.values()))
                                        list_key_data.append(tuple(row.keys()))
                                        list_sheet_data.append(row)
                        else:
                            var_res_insert = [index_sheet, len(var_entet_ref), len(list_val_dict),
                                              self.var_incoherence_longueur_entete]
                            if var_res_insert not in var_list_erreur_model:
                                var_list_erreur_model.append(var_res_insert)
                    self.progress_processing(index_loop, len(sheets_all), bar_progress)
                    if bar_progress.wasCanceled():
                        iface.messageBar().pushMessage('Info', 'Action Cancelled', level=Qgis.Info)
                        break
                if not var_list_erreur_model:
                    # Partie recuperation des informations par colonnne
                    dict_value_finale = {}
                    dict_value_nb_appui = {}
                    dict_value_nb_appui_ko = {}
                    dict_value_cable_max = {}
                    dict_coherence_mcd = {}
                    dict_coherence_appui = {}
                    dict_coherence_ligne = {}
                    dict_parallelisme_ligne = {}
                    dict_coherence_branchements = {}

                    # Partie Recuperation des sommes de syntheses pour le sheet Global
                    res_sum_column_after_ko_enedis = self.function_sum_column_after_ko(list_sheet_data,
                                                                                       var_list_sum_column_enedis)

                    for index_data_recup in range(len(list_sheet_data)):
                        value_sheet = list_sheet_data[index_data_recup]
                        value_sro = value_sheet[self.var_sheet_name]
                        value_etude = value_sheet['Nom Etude']
                        value_nb_appui = value_sheet['Nom appui']  # somme du nombre de poteau de la colonne F

                        # somme du nombre de poteau KO de la colonne L et M pour ENEDIS
                        value_nb_appui_ko = value_sheet['Résultat du Calcul de Charge']

                        # capacité la plus forte issue de la colonne S pour ORANGE et X pour ENEDIS
                        value_cable_max = value_sheet['Etiquette du câble\n(cb_etiquet)']

                        # MAJEUR si l’information « incoherence MCD », CONFORME si « OUI » est indiquée
                        # dans la colonne U pour ORANGE et AA pour ENEDIS
                        value_coherence_mcd = value_sheet['Cohérence\nSIG\n(Oui/Majeur)']

                        # MAJEUR si l’information « MAJEUR», MINEUR si l’information « MINEUR»,
                        # CONFORME si « OUI » est indiquée dans la colonne AB pour ORANGE et AI pour ENEDIS
                        value_coherence_appui = value_sheet['Cohérence\nde l\'Appui\n(Oui/Mineur/Majeur)']

                        # MAJEUR si l’information « MAJEUR», MINEUR si l’information « MINEUR»,
                        # CONFORME si « OUI » est indiquée dans la colonne AG pour ORANGE et AN pour ENEDIS
                        value_coherence_ligne = value_sheet[
                            'Cohérence\nDescription de la ligne \n(Oui/Mineur/Majeur)']

                        # MAJEUR si l’information « MAJEUR», MINEUR si l’information « MINEUR»,
                        # CONFORME si « OUI » est indiquée dans la colonne AR pour ENEDIS
                        value_parallelisme_ligne = value_sheet['Cohérence\nParallélisme de la ligne\n(Oui/Majeur)']

                        # MAJEUR si l’information « incohérence travaux» ou « non respect des règles Orange »,
                        # CONFORME si « OUI » est indiquée dans la colonne AJ pour ORANGE
                        value_coherence_branchements = value_sheet['Cohérence des branchements\nnon modélisés \n(Oui/Majeur)']
                        if value_etude:
                            self.function_create_dict(dict_value_finale, f'{value_sro};{value_etude}',
                                                      [value_nb_appui,
                                                       value_nb_appui_ko,
                                                       value_cable_max,
                                                       value_coherence_mcd,
                                                       value_coherence_appui,
                                                       value_coherence_ligne,
                                                       value_parallelisme_ligne,
                                                       value_coherence_branchements])
                    for key_index_test, value_index_test in dict_value_finale.items():
                        for index_val in range(len(value_index_test)):
                            self.function_create_dict(dict_value_nb_appui, key_index_test,
                                                      value_index_test[index_val][0])
                            self.function_create_dict(dict_value_nb_appui_ko, key_index_test,
                                                      value_index_test[index_val][1])
                            self.function_create_dict(dict_value_cable_max, key_index_test,
                                                      value_index_test[index_val][2])
                            self.function_create_dict(dict_coherence_mcd, key_index_test,
                                                      value_index_test[index_val][3])
                            self.function_create_dict(dict_coherence_appui, key_index_test,
                                                      value_index_test[index_val][4])
                            self.function_create_dict(dict_coherence_ligne, key_index_test,
                                                      value_index_test[index_val][5])
                            self.function_create_dict(dict_parallelisme_ligne, key_index_test,
                                                      value_index_test[index_val][6])
                            self.function_create_dict(dict_coherence_branchements, key_index_test,
                                                      value_index_test[index_val][7])

                    # Partie Synthese NBAppui----------------------------somme du nombre de poteau de la colonne F
                    self.function_count_nombre_appuis(dict_value_nb_appui, self.all_dict_synthese_aer_enedis)
                    # Partie Synthese KO_Appui----------------------------# somme du nombre de poteau KO de la colonne L
                    self.function_number_occurrence_etat_appuis(dict_value_nb_appui_ko, 'KO', self.all_dict_synthese_aer_enedis)
                    # Partie Synthese CapaMax_Appui----------------------------
                    self.function_capa_max_appui(dict_value_cable_max, self.all_dict_synthese_aer_enedis)
                    # Partie Synthese CoherenceMCD_Appui----------------------------
                    self.function_coherence_appuis_majeur_conforme(dict_coherence_mcd, self.all_dict_synthese_aer_enedis)
                    # Partie Synthese CoherenceAppui_Appui----------------------------
                    self.function_coherence_appuis_majeur_mineur_conforme(dict_coherence_appui, self.all_dict_synthese_aer_enedis)
                    # Partie Synthese CoherenceLigne_Appui----------------------------
                    self.function_coherence_appuis_majeur_mineur_conforme(dict_coherence_ligne, self.all_dict_synthese_aer_enedis)
                    # Partie Synthese CoherenceParallelisme_ligne----------------------------
                    self.function_coherence_appuis_majeur_conforme(dict_parallelisme_ligne, self.all_dict_synthese_aer_enedis)
                    # Partie Synthese CoherenceBranchements----------------------------
                    self.function_coherence_appuis_majeur_conforme(dict_coherence_branchements, self.all_dict_synthese_aer_enedis)

                    dict_all_info_synthese = {}
                    for k in self.all_dict_synthese_aer_enedis[0].keys():
                        dict_all_info_synthese[str(k)] = sum([dict_all_info_synthese[k] for dict_all_info_synthese in self.all_dict_synthese_aer_enedis if k in dict_all_info_synthese], [])
                    for index_val, (index_xx, vauex_xx) in enumerate(dict_all_info_synthese.items()):
                        dict_all_info_synthese[index_xx].append(self.function_round(vauex_xx[1], vauex_xx[0]))
                        # indiquer VALIDE EN L'ETAT si sur les colonnes G à J tout est CONFORME / MINEUR ou
                        # A REPRENDRE si sur les colonnes G à J un ou plusieurs MAJEUR est indiqué
                        if self.var_res_majeur in vauex_xx[-6:]:
                            dict_all_info_synthese[index_xx].insert(0, self.var_res_a_reprendre)
                        else:
                            dict_all_info_synthese[index_xx].insert(0, self.var_res_valide_etat)

                        dict_all_info_synthese[index_xx].insert(0, index_xx)  # Insert NOM dans la liste
                        dict_all_info_synthese[index_xx].insert(0, self.var_enedis_appui)  # Insert Tag Name ORANGE dans la liste
                        self.progress_processing(index_val, len(dict_all_info_synthese), bar_progress)
                        if bar_progress.wasCanceled():
                            iface.messageBar().pushMessage('Info', 'Action Cancelled', level=Qgis.Info)
                            break
                    return dict_all_info_synthese, res_sum_column_after_ko_enedis
                else:
                    self.var_list_all_erreur_traitement.append(
                    ['function_create_fusion_sheet_dpi_enedis', 'ERRRR Model', var_list_erreur_model, 'ERRRR Model', 'ERRRR Model'])
            except Exception as error:
                exc_type, exc_obj, exc_tb = sys.exc_info()
                self.var_list_all_erreur_traitement.append(
                    ['function_create_fusion_sheet_dpi_enedis', exc_type, exc_obj, exc_tb.tb_lineno, error])
        else:
            self.var_list_all_erreur_traitement.append(
                ['function_create_fusion_sheet_dpi_enedis', '', '', '',
                 'Erreur douverture du fichier donc pas de tratitement sur ce fichier'])


# # SyntheseAuditDpi(r"C:\Users\babacar.fassa\Desktop\test_import_dpi\AUD_VVRS_2-9_DEO_INF_R002_vf.xlsx")  # DEV
# var_file = r"C:\Users\babacar.fassa.AMBITION\Desktop\test_import_dpi\Nouveau dossier\AUD_VLTE_4-15_DEO_INF_R001_vf.xlsx"
# var_path_export_res = r"C:\Users\babacar.fassa.AMBITION\Desktop\test_import_dpi"
# SyntheseAuditDpi(var_file,var_path_export_res)  # Ne marche Pas
