from win32com.client import Dispatch
import win32com.client as win32
import xlwt
import os
import glob
#from tkinter.filedialog import askdirectory
from qgis.PyQt.QtWidgets import *
from qgis.PyQt.QtCore import *
from qgis.PyQt.QtGui import *
from qgis.core import * 
from qgis.utils import *
from qgis.gui import *
import time
import datetime

#folder = QFileDialog.getExistingDirectory(None, 'Selection Repertoire ou se trouve les fiches Appuis de FT')#askdirectory()
def function_conv_xlsx_to_xls():
    
	folder = QFileDialog.getExistingDirectory(None, 'Selection Repertoire ou se trouve les fiches Appuis de FT')#askdirectory()

	#Function pour la progession bar1
	def progress_bar(name_etape):
		prog = QProgressDialog(name_etape + ' : Veillez Patienter', 'Cancel', 0, 100)
		prog.setWindowModality(Qt.WindowModal)
		prog.setMinimumDuration(1)
		return prog
		
	#Function pour la progession bar2
	def progress_processing(index,count_entite,progress_dialog):
		f = int(index + 1)
		pcnt = int(f/count_entite * 100/1)
		progress_dialog.setValue(pcnt)

	bar_progress=progress_bar('Execution de la Conversion des XLSX vers XLS')
	
	
	if folder:
		#dir_path = folder
		cmp = 0
		list_test=glob.glob(folder + "/*")#os.listdir(folder)
		#print (list_test)
		## Paramètrage Excel
		excel = win32.gencache.EnsureDispatch('Excel.Application')
		excel.DisplayAlerts = False
		for index_x, x in enumerate(list_test):
			cmp += 1
			name, ext = os.path.splitext(x)
			if ext == ".xlsx":
				path1 = name + ext
				path2 = name + '.xls'

				## Creation Excel (.xls)
				xls_to_create = xlwt.Workbook()
				sheet = xls_to_create.add_sheet('wedontcareaboutname')
				xls_to_create.save(path2)

				

				## Ouverture Excel (.xlsx)
				excel_xlsx = excel.Workbooks.Open(path1, False)
				excel_xlsx_sheet = excel_xlsx.Worksheets(1)

				## Ouverture Excel (.xls)
				excel_xls = excel.Workbooks.Open(path2)
				excel_xls_sheet = excel_xls.Worksheets.Add()
				excel_xls_sheet.Name = excel_xlsx.Worksheets(1).Name
				excel_xls_sheet = excel_xls.Worksheets(1)
				excel_xls_sheet_to_delete = excel_xls.Worksheets('wedontcareaboutname')
				excel_xls_sheet_to_delete.Delete()

				excel_xlsx_sheet.Range("A1:AF100").Copy(excel_xls_sheet.Range("A%s:AF%s" % (1, 100)))
				excel_xls.Save()
				excel_xls.Close()
				excel_xlsx.Close()
				
				
			
			progress_processing(index_x,len(list_test),bar_progress)
			if bar_progress.wasCanceled():
				iface.messageBar().pushMessage('Info', 'Action Cancelled', level=Qgis.Info)
				break
		excel.Quit()
	#print("Conversion terminée")
	#function_conv_xlsx_to_xls()



