from .class_file_global_menu import *
from .vidange_cache_qgis import *
from .forms.import_data_form import *


class ClassGeneraleMenu:
    def __init__(self, iface):
        self.iface = iface
        self.name_menu_projet = var_class_init_custom_menu_bar.funct_add_submenu_projet_to_global(ambition_menu,
                                                                                                  'AXIONE')
        self.name_groupe_echange = "B.1. Couche échange"

    def initGui(self):
        # AXIONE ECHANGE Submenu
        res_vidange = function_delete_cache_qgis()
        if res_vidange[1] is False:
            QMessageBox.warning(QWidget(), "Message dexecution de requete", 'Le cache nest pas vide ... ' +
                                str(res_vidange))
        self.couche_echange_menu = var_class_init_custom_menu_bar.func_add_submenu_group_to_projet(
            self.name_menu_projet, self.name_groupe_echange)
        var_class_init_custom_menu_bar.func_add_action_menu(self.couche_echange_menu,
                                                            "B.1.1 Intégration APS",
                                                            self.exe_class_import_data_axione_dialog)

    def unload(self):
        self.iface.removePluginMenu(self.name_groupe_echange, self.couche_echange_menu.menuAction())

    # Couche echange Axione
    def exe_class_import_data_axione_dialog(self):
        self.execable = class_import_data_axione_dialog(self.iface)
        self.execable.exec_()
