SET search_path TO var_lfd, public;
GRANT ALL ON SCHEMA var_lfd TO lfd_ing;
GRANT SELECT, INSERT, Update ON ALL TABLES IN SCHEMA var_lfd TO lfd_ing;
ALTER DEFAULT PRIVILEGES IN SCHEMA var_lfd GRANT SELECT, INSERT, UPDATE  ON TABLES TO lfd_ing;

--Module Pour les croises dynamiques
-- See the README.md file distributed with this project for documentation.
create or replace function colpivot(
    out_table varchar, in_query varchar,
    key_cols varchar[], class_cols varchar[],
    value_e varchar, col_order varchar
) returns void as $$
    declare
        in_table varchar;
        col varchar;
        ali varchar;
        on_e varchar;
        i integer;
        rec record;
        query varchar;
        -- This is actually an array of arrays but postgres does not support an array of arrays type so we flatten it.
        -- We could theoretically use the matrix feature but it's extremly cancerogenous and we would have to involve
        -- custom aggrigates. For most intents and purposes postgres does not have a multi-dimensional array type.
        clsc_cols text[] := array[]::text[];
        n_clsc_cols integer;
        n_class_cols integer;
    begin
        in_table := quote_ident('__' || out_table || '_in');
        execute ('create temp table ' || in_table || ' on commit drop as ' || in_query);
        -- get ordered unique columns (column combinations)
        query := 'select array[';
        i := 0;
        foreach col in array class_cols loop
            if i > 0 then
                query := query || ', ';
            end if;
            query := query || 'quote_literal(' || quote_ident(col) || ')';
            i := i + 1;

        end loop;
        query := query || '] x from ' || in_table;
        for j in 1..2 loop
            if j = 1 then
                query := query || ' group by ';
            else
                query := query || ' order by ';
                if col_order is not null then
                    query := query || col_order || ' ';
                    exit;
                end if;
            end if;
            i := 0;
            foreach col in array class_cols loop
                if i > 0 then
                    query := query || ', ';
                end if;
                query := query || quote_ident(col);
                i := i + 1;
            end loop;
        end loop;
        --raise notice '%', 'bababa';
        for rec in
		execute query
        loop
            clsc_cols := array_cat(clsc_cols, rec.x);
        end loop;
        n_class_cols := array_length(class_cols, 1);
        n_clsc_cols := array_length(clsc_cols, 1) / n_class_cols;
        -- build target query
        query := 'select ';
        i := 0;
        foreach col in array key_cols loop
            if i > 0 then
                query := query || ', ';
            end if;
            query := query || '_key.' || quote_ident(col) || ' ';
            i := i + 1;

        end loop;
        for j in 1..n_clsc_cols loop
            query := query || ', ';
            col := '';
            for k in 1..n_class_cols loop
                if k > 1 then
                    col := col || ', ';
                end if;
                col := col || clsc_cols[(j - 1) * n_class_cols + k];

            end loop;
            ali := '_clsc_' || j::text;
            query := query || '(' || replace(value_e, '#', ali) || ')' || ' as ' || quote_ident(col) || ' ';
            --raise notice '%', replace(value_e, '#', ali);
        end loop;

        query := query || ' from (select distinct ';
        i := 0;
        foreach col in array key_cols loop
            if i > 0 then
                query := query || ', ';
            end if;
            query := query || quote_ident(col) || ' ';
            i := i + 1;
        end loop;
        query := query || ' from ' || in_table || ') _key ';
        for j in 1..n_clsc_cols loop
            ali := '_clsc_' || j::text;
            on_e := '';
            i := 0;
            foreach col in array key_cols loop
                if i > 0 then
                    on_e := on_e || ' and ';
                end if;
                on_e := on_e || ali || '.' || quote_ident(col) || ' = _key.' || quote_ident(col) || ' ';
                i := i + 1;
            end loop;
            for k in 1..n_class_cols loop
                on_e := on_e || ' and ';
                on_e := on_e || ali || '.' || quote_ident(class_cols[k]) || ' = ' || clsc_cols[(j - 1) * n_class_cols + k];
            end loop;
            query := query || 'left join ' || in_table || ' as ' || ali || ' on ' || on_e || ' ';
        end loop;
        --raise notice '%', query;
        -- raise notice '%', out_table;
        execute ('create temp table ' || quote_ident(out_table) || ' on commit drop as ' || query);
        -- cleanup temporary in_table before we return
        execute ('drop table ' || in_table)
        return;
    end;
$$ language plpgsql volatile;

---Construction des tables avec geometry
--Requete IPON
DROP TABLE IF EXISTS requete_ipon;
CREATE TABLE requete_ipon as
select
	---ip.*,
	distinct 
	ip.NOM_COMMUNE_PM,
	ip.DESCRIPTION_PF_PB,
	ip.NOM_DU_PT_PB,
	ip.POSITION_D_EQUIPEMENT_PT_PB,
	ip.CODE_IMB_ZONE_D_INFLUENCE_PF_PB_SELON_LES_ADRESSES,
	ip.NB_EL_DU_CODE_IMMEUBLE,
	ip.nom_site_pf_pb,
	ip.nature_travaux,
	ip.description_du_site_pa,
	ip.position_d_equipement_pt_pa,
	ip.nom_du_pm_reg,
	ip.nom_du_pa_reg,
	ip.nom_du_pf_pb,
	ip.hauteur_par_rapport_au_sol_pt_pb,
	ip.code_commune_pm,
	ip.nom_du_pf_pa,
	ip.nom_du_pt_pa,
	ip.nom_site_pf_pa,
	ip.etat_production_pf_pb,
	ip.etat_physique_pt_pb,
	ip.description_du_site_pb,
	ip.adresse_ou_sous_adresse_site_pf_pb,
	ip.adductabilite,
	ip.adduction,
	ip.nom_sissi_local_technique_pt_pb,
	ip.description_du_site_commentaires,
	o.raccordable_sur_demande,


	-- ST_Transform(ST_SetSRID(ST_MakePoint(ao.coord_x::double precision,ao.coord_y::double precision),27572),2154) as geom_ipon,
	o.id_processus_particulier as id_processus_particulier
from ipon ip
-- left join "Adresses_Optimum" as ao on ao.num_dossier_site = ip.nom_site_pf_pb
-- left join "Couverture_FTTH_Phase2" as ct on
-- 	st_intersects(
-- 	ct.geom,
-- 	ST_Transform(ST_SetSRID(ST_MakePoint(ao.coord_x::double precision,ao.coord_y::double precision),27572),2154)
-- 	)
-- left join "Optimum" as o on o.num_dossier_site = ao.num_dossier_site;
left join "Optimum" as o on o.num_dossier_site = ip.code_imb_zone_d_influence_pf_pb_selon_les_adresses;

--Requete Optimum
DROP TABLE IF EXISTS requete_optimum;
CREATE TABLE requete_optimum as
select
	o.*
from "Optimum" as o;
	-- left join "Adresses_Optimum" as ao on ao.num_dossier_site = o.num_dossier_site;
--Requete GEOFIBRE
--ftth_site_immeuble.shp t_adresse_gfi
DROP TABLE IF EXISTS t_adresse_gfi;
CREATE TABLE t_adresse_gfi as
select im.* from ftth_site_immeuble im
join ftth_zone_eligibilite as zn on st_contains(zn.geom,im.geom);

--ftth_pf.shp t_ebp_gfi
DROP TABLE IF EXISTS t_ebp_gfi;
CREATE TABLE t_ebp_gfi as
select pf.* from ftth_pf pf
join ftth_zone_eligibilite as zn on st_contains(zn.geom,pf.geom);

-- Creation des index pour adresse gfi et ""RBAL_Phase2""
DROP INDEX IF EXISTS adresse_gfi;
CREATE INDEX adresse_gfi ON "t_adresse_gfi" USING GIST (geom);
DROP INDEX IF EXISTS RBAL_Phase2;
CREATE INDEX RBAL_Phase2 ON "RBAL_Phase2" USING GIST (geom);

---TR01.1
/*
select colpivot('_test_pivoted', 'select
	''test''::text as uniq,localite_site,
	sum(nombre_de_logements::int) as sum
from requete_optimum
group by localite_site;',
    array['uniq'], array['localite_site'], '#.sum', null);
select * from _test_pivoted;*/

create or replace function "TR01.1"(
) returns void as $$
    declare
        requete text;
        col_uniq text;
        col_transpose text;
        col_value_transpose text;
        var_req_execute record;
    begin

	EXECUTE 'DROP TABLE IF EXISTS "inter_TR01.1"';
	EXECUTE 'CREATE TABLE "inter_TR01.1" as
	select
		''test''::text as uniq,localite_site,
		sum(nombre_de_logements::int) as sum
	from requete_optimum
	group by localite_site';

	requete := quote_literal(e'select * from "inter_TR01.1"');
	col_uniq := quote_literal(e'uniq');
	col_transpose := quote_literal(e'localite_site');
	col_value_transpose := quote_literal(e'#.sum');

	/*EXECUTE 'DROP TABLE IF EXISTS "TR01.1"';
	EXECUTE 'select colpivot(''_test_pivoted'', '||
		requete||',array['||col_uniq||'], array['||col_transpose||'], '||col_value_transpose||', null)';
	EXECUTE 'CREATE TABLE "TR01.1" as ' || 'select * from _test_pivoted';*/

	FOR var_req_execute in select count(*)::int as len from "inter_TR01.1" limit 1
		LOOP
			if var_req_execute.len > 0 then

				EXECUTE 'DROP TABLE IF EXISTS "TR01.1"';
				EXECUTE 'select colpivot(''_test_pivoted'', '||
					requete||',array['||col_uniq||'], array['||col_transpose||'], '||col_value_transpose||', null)';
				EXECUTE 'CREATE TABLE "TR01.1" as ' || 'select * from _test_pivoted';
			else
				EXECUTE 'DROP TABLE IF EXISTS "TR01.1"';
				EXECUTE 'CREATE TABLE "TR01.1" (vide text)';
			end if;
		END LOOP;

    end;
$$ language plpgsql volatile;

select * from "TR01.1"();


---TR02.1
create or replace function "TR02.1"(
) returns void as $$
    declare
        requete text;
        col_uniq text;
        col_transpose text;
        col_value_transpose text;
        var_req_execute record;
    begin
	EXECUTE 'DROP TABLE IF EXISTS _test_pivoted';
	EXECUTE 'DROP TABLE IF EXISTS "inter_TR02.1"';
	EXECUTE 'CREATE TABLE "inter_TR02.1" as
	select
		--''test''::text as uniq,
		localite_site,
		sum(nombre_de_logements::int) as sum,
		array_agg(distinct date_pose_pb) as date_pose_pb
	from requete_optimum
	where ((date_pose_pb != NULL or date_pose_pb != '''')) or 
	(nombre_de_logements::int > 3 and libelle_site_etat_negociation_syndic in (''DENONCE'', ''REFUSE'')) 
	group by localite_site';

	requete := quote_literal(e'select * from "inter_TR02.1"');
	col_uniq := quote_literal(e'uniq');
	col_transpose := quote_literal(e'localite_site');
	col_value_transpose := quote_literal(e'#.sum');
	FOR var_req_execute in select count(*)::int as len from "inter_TR02.1" limit 1
		LOOP
			if var_req_execute.len > 0 then
				EXECUTE 'DROP TABLE IF EXISTS "TR02.1"';
				/*EXECUTE 'select colpivot(''_test_pivoted'', '||
					requete||',array['||col_uniq||'], array['||col_transpose||'], '||col_value_transpose||', null)';
				EXECUTE 'CREATE TABLE "TR02.1" as ' || 'select * from _test_pivoted';*/
				EXECUTE 'CREATE TABLE "TR02.1" as ' || 'select distinct * from "inter_TR02.1"';
			else
					EXECUTE 'DROP TABLE IF EXISTS "TR02.1"';
					EXECUTE 'CREATE TABLE "TR02.1" (vide text)';

			end if;
		END LOOP;
    end;
$$ language plpgsql volatile;

select * from "TR02.1"();

---TR03.1
create or replace function "TR03.1"(
) returns void as $$
    declare
        requete text;
        col_uniq text;
        col_transpose text;
        col_value_transpose text;
        var_req_execute record;
    begin
	EXECUTE 'DROP TABLE IF EXISTS _test_pivoted';
	EXECUTE 'DROP TABLE IF EXISTS "inter_TR03.1"';
	EXECUTE 'CREATE TABLE "inter_TR03.1" as
	select
		--''tr01''::text as uniq,
		ro.localite_site,
		count(*) as count,
		--max(tr2.sum) as tr01,
		/*max(tr2.sum) as tr02,*/
		round((100/sum(tr2.sum))*sum(tr.sum),0) as percent
	from requete_optimum as ro
	join "inter_TR01.1" as tr2 on tr2.localite_site = ro.localite_site
	join "inter_TR02.1" as tr on tr.localite_site = ro.localite_site
	group by ro.localite_site
	union all
	select
		--''tr01''::text as uniq,
		ro.localite_site,
		count(*) as count,
		--max(tr.sum) as tr02,
		/*max(tr2.sum) as tr01,*/
		round((100/sum(tr2.sum))*sum(tr.sum),0) as percent
	from requete_optimum as ro
	join "inter_TR02.1" as tr on tr.localite_site = ro.localite_site
	join "inter_TR01.1" as tr2 on tr2.localite_site = ro.localite_site
	group by ro.localite_site';

	requete := quote_literal(e'select distinct * from "inter_TR03.1"');
	col_uniq := quote_literal(e'localite_site');
	col_transpose := quote_literal(e'localite_site');
	col_value_transpose := quote_literal(e'#.percent');
	FOR var_req_execute in select count(*)::int as len from "inter_TR03.1" limit 1
		LOOP
			if var_req_execute.len > 0 then
				EXECUTE 'DROP TABLE IF EXISTS "TR03.1"';
				/*EXECUTE 'select colpivot(''_test_pivoted'', '||
					requete||',array['||col_uniq||'], array['||col_transpose||'], '||col_value_transpose||', null)';
				EXECUTE 'CREATE TABLE "TR03.1" as ' || 'select * from _test_pivoted';*/
				EXECUTE 'CREATE TABLE "TR03.1" as ' || 'select distinct * from "inter_TR03.1"';
			else
					EXECUTE 'DROP TABLE IF EXISTS "TR03.1"';
					EXECUTE 'CREATE TABLE "TR03.1" (vide text)';
			end if;
		END LOOP;
    end;
$$ language plpgsql volatile;

-- select * from "TR03.1"();

--TR04.1
create or replace function "TR04.1"(
) returns void as $$
    declare
        requete text;
        col_uniq text;
        col_transpose text;
        col_value_transpose text;
        var_req_execute record;
    begin
	EXECUTE 'DROP TABLE IF EXISTS _test_pivoted';
	EXECUTE 'DROP TABLE IF EXISTS "inter_TR04.1"';
	EXECUTE 'CREATE TABLE "inter_TR04.1" as
	select
		''NON_COLLECTIF''::text as uniq,
		ro.localite_site,
		sum(nombre_de_logements::int) as sum
	from requete_optimum as ro
	where (date_pose_pb != NULL or date_pose_pb != '''') and nombre_de_logements::int < 4
	group by ro.localite_site';

	requete := quote_literal(e'select * from "inter_TR04.1"');
	col_uniq := quote_literal(e'uniq');
	col_transpose := quote_literal(e'localite_site');
	col_value_transpose := quote_literal(e'#.sum');
	FOR var_req_execute in select count(*)::int as len from "inter_TR04.1" limit 1
		LOOP
			if var_req_execute.len > 0 then
				EXECUTE 'DROP TABLE IF EXISTS "TR04.1"';
				EXECUTE 'select colpivot(''_test_pivoted'', '||
					requete||',array['||col_uniq||'], array['||col_transpose||'], '||col_value_transpose||', null)';
				EXECUTE 'CREATE TABLE "TR04.1" as ' || 'select * from _test_pivoted';
			else
					EXECUTE 'DROP TABLE IF EXISTS "TR04.1"';
					EXECUTE 'CREATE TABLE "TR04.1" (vide text)';
			end if;
		END LOOP;
    end;
$$ language plpgsql volatile;

select * from "TR04.1"();

--TR05.1
create or replace function "TR05.1"(
) returns void as $$
    declare
        requete text;
        col_uniq text;
        col_transpose text;
        col_value_transpose text;
        var_req_execute record;
    begin
	EXECUTE 'DROP TABLE IF EXISTS _test_pivoted';
	EXECUTE 'DROP TABLE IF EXISTS "inter_TR05.1"';
	EXECUTE 'CREATE TABLE "inter_TR05.1" as
	select
		''COLLECTIF''::text as uniq,
		ro.localite_site,
		sum(nombre_de_logements::int) as sum
	from requete_optimum as ro
	where (date_pose_pb != NULL or date_pose_pb != '''') and
		nombre_de_logements::int > 3
	group by ro.localite_site';

	requete := quote_literal(e'select * from "inter_TR05.1"');
	col_uniq := quote_literal(e'uniq');
	col_transpose := quote_literal(e'localite_site');
	col_value_transpose := quote_literal(e'#.sum');
	FOR var_req_execute in select count(*)::int as len from "inter_TR05.1" limit 1
		LOOP
			if var_req_execute.len > 0 then
				EXECUTE 'DROP TABLE IF EXISTS "TR05.1"';
				EXECUTE 'select colpivot(''_test_pivoted'', '||
					requete||',array['||col_uniq||'], array['||col_transpose||'], '||col_value_transpose||', null)';
				EXECUTE 'CREATE TABLE "TR05.1" as ' || 'select * from _test_pivoted';
			else
					EXECUTE 'DROP TABLE IF EXISTS "TR05.1"';
					EXECUTE 'CREATE TABLE "TR05.1" (vide text)';
			end if;
		END LOOP;
    end;
$$ language plpgsql volatile;

-- select * from "TR05.1"();

--TR06.1
create or replace function "TR06.1"(
) returns void as $$
    declare
        requete text;
        col_uniq text;
        col_transpose text;
        col_value_transpose text;
        var_req_execute record;
    begin
	EXECUTE 'DROP TABLE IF EXISTS _test_pivoted';
	EXECUTE 'DROP TABLE IF EXISTS "inter_TR06.1"';
	EXECUTE 'CREATE TABLE "inter_TR06.1" as
		select
		''SIGNE''::text as uniq,
		ro.localite_site,
		sum(nombre_de_logements::int) as sum
	from requete_optimum as ro
	where nombre_de_logements::int > 3 and libelle_site_etat_negociation_syndic  in (''DENONCE'', ''REFUSE'')
	group by ro.localite_site';

	requete := quote_literal(e'select * from "inter_TR06.1"');
	col_uniq := quote_literal(e'uniq');
	col_transpose := quote_literal(e'localite_site');
	col_value_transpose := quote_literal(e'#.sum');
	--LOOP
	FOR var_req_execute in select count(*)::int as len from "inter_TR06.1" limit 1
		LOOP
			if var_req_execute.len > 0 then

				EXECUTE 'DROP TABLE IF EXISTS "TR06.1"';
				EXECUTE 'select colpivot(''_test_pivoted'', '||
					requete||',array['||col_uniq||'], array['||col_transpose||'], '||col_value_transpose||', null)';
				EXECUTE 'CREATE TABLE "TR06.1" as ' || 'select * from _test_pivoted';
			else
				EXECUTE 'DROP TABLE IF EXISTS "TR06.1"';
				EXECUTE 'CREATE TABLE "TR06.1" (vide text)';
			end if;
		END LOOP;
	--end loop
    end;
$$ language plpgsql volatile;

-- select * from "TR06.1"();

--TR07.1
create or replace function "TR07.1"(
) returns void as $$
    declare
        requete text;
        col_uniq text;
        col_transpose text;
        col_value_transpose text;
        var_req_execute record;
    begin
	EXECUTE 'DROP TABLE IF EXISTS _test_pivoted';
	EXECUTE 'DROP TABLE IF EXISTS "inter_TR07.1"';
	EXECUTE 'CREATE TABLE "inter_TR07.1" as
		select
			''SOMME_PRISES''::text as uniq,
			ca.localite_site as nom_commune,
			sum(nombre_de_logements::int) as sum
		from "Optimum" as ca
		--nro_de_rattachement Option Request
		where zone = ''EXP_P3_PER''
		group by localite_site';

	requete := quote_literal(e'select * from "inter_TR07.1"');
	col_uniq := quote_literal(e'uniq');
	col_transpose := quote_literal(e'nom_commune');
	col_value_transpose := quote_literal(e'#.sum');
	--LOOP
	FOR var_req_execute in select count(*)::int as len from "inter_TR07.1" limit 1
		LOOP
			if var_req_execute.len > 0 then

				EXECUTE 'DROP TABLE IF EXISTS "TR07.1"';
				EXECUTE 'select colpivot(''_test_pivoted'', '||
					requete||',array['||col_uniq||'], array['||col_transpose||'], '||col_value_transpose||', null)';
				EXECUTE 'CREATE TABLE "TR07.1" as ' || 'select * from _test_pivoted';
			else
				EXECUTE 'DROP TABLE IF EXISTS "TR07.1"';
				EXECUTE 'CREATE TABLE "TR07.1" (vide text)';
			end if;
		END LOOP;
	--end loop
    end;
$$ language plpgsql volatile;

select * from "TR07.1"();


--TR08.1
create or replace function "TR08.1"(
) returns void as $$
    declare
        requete text;
        col_uniq text;
        col_transpose text;
        col_value_transpose text;
        var_req_execute record;
    begin
	EXECUTE 'DROP TABLE IF EXISTS _test_pivoted';
	EXECUTE 'DROP TABLE IF EXISTS "inter_TR08.1"';
	EXECUTE 'CREATE TABLE "inter_TR08.1" as
		select
			*
		from "inter_TR02.1"';

	/*requete := quote_literal(e'select * from "inter_TR08.1"');
	col_uniq := quote_literal(e'uniq');
	col_transpose := quote_literal(e'localite_site');
	col_value_transpose := quote_literal(e'#.sum');*/
	--LOOP
	FOR var_req_execute in select count(*)::int as len from "inter_TR08.1" limit 1
		LOOP
			if var_req_execute.len > 0 then

				EXECUTE 'DROP TABLE IF EXISTS "TR08.1"';
				/*EXECUTE 'select colpivot(''_test_pivoted'', '||
					requete||',array['||col_uniq||'], array['||col_transpose||'], '||col_value_transpose||', null)';*/
				EXECUTE 'CREATE TABLE "TR08.1" as ' || 'select * from "inter_TR08.1"';
			else
				EXECUTE 'DROP TABLE IF EXISTS "TR08.1"';
				EXECUTE 'CREATE TABLE "TR08.1" (vide text)';
			end if;
		END LOOP;
	--end loop
    end;
$$ language plpgsql volatile;

-- select * from "TR08.1"();

--TR09.1
create or replace function "TR09.1"(
) returns void as $$
    declare
        requete text;
        col_uniq text;
        col_transpose text;
        col_value_transpose text;
        var_req_execute record;
    begin
	EXECUTE 'DROP TABLE IF EXISTS _test_pivoted';
	EXECUTE 'DROP TABLE IF EXISTS "inter_TR09.1"';
	EXECUTE 'CREATE TABLE "inter_TR09.1" as
	select
		--''Somme_de_prises_raccordables_(TR07.1)''::text as uniq,
		ro.localite_site,
		sum(ro.nombre_de_logements::int) as sum,
		--max(tr.sum) as tr07,
		round(((100::int)/sum(tr.sum))*sum(tr2.sum),2) as percent
	from requete_optimum as ro
	left join "inter_TR07.1" as tr on tr.nom_commune = ro.localite_site
	left join "inter_TR08.1" as tr2 on tr2.localite_site = ro.localite_site
	where (ro.date_pose_pb != NULL or ro.date_pose_pb != '''')
	group by ro.localite_site
	union all
	select
		--''Somme_de_prises_PB_POSE_(TR08.1)''::text as uniq,
		ro.localite_site,
		sum(ro.nombre_de_logements::int) as sum,
		--max(tr2.sum) as tr08,
		round(((100::int)/sum(tr.sum))*sum(tr2.sum),2) as percent
	from requete_optimum as ro
	left join "inter_TR07.1" as tr on tr.nom_commune = ro.localite_site
	left join "inter_TR08.1" as tr2 on tr2.localite_site = ro.localite_site
	where (ro.date_pose_pb != NULL or ro.date_pose_pb != '''')
	group by ro.localite_site';

	requete := quote_literal(e'select * from "inter_TR09.1"');
	col_uniq := quote_literal(e'localite_site');
	col_transpose := quote_literal(e'localite_site');
	col_value_transpose := quote_literal(e'#.percent');

	FOR var_req_execute in select count(*)::int as len from "inter_TR09.1" limit 1
		LOOP
			if var_req_execute.len > 0 then

				EXECUTE 'DROP TABLE IF EXISTS "TR09.1"';
				/*EXECUTE 'select colpivot(''_test_pivoted'', '||
					requete||',array['||col_uniq||'], array['||col_transpose||'], '||col_value_transpose||', null)';
				EXECUTE 'CREATE TABLE "TR09.1" as ' || 'select * from _test_pivoted';*/
				EXECUTE 'CREATE TABLE "TR09.1" as ' || 'select distinct * from "inter_TR09.1"';
			else
				EXECUTE 'DROP TABLE IF EXISTS "TR09.1"';
				EXECUTE 'CREATE TABLE "TR09.1" (vide text)';
			end if;
		END LOOP;
    end;
$$ language plpgsql volatile;

-- select * from "TR09.1"();


--TE01.1
create or replace function "TE01.1"(
) returns void as $$
    declare
        requete text;
        col_uniq text;
        col_transpose text;
        col_value_transpose text;
        var_req_execute record;
    begin


	EXECUTE 'DROP TABLE IF EXISTS _test_pivoted';
	EXECUTE 'DROP TABLE IF EXISTS "inter_TE01.1"';
	EXECUTE 'CREATE TABLE "inter_TE01.1" as
		select
			distinct --''id_processus_particulier''::text as uniq,
			localite_site as localite_site,
			array_agg(num_dossier_site) as num_dossier_site,
			array_agg(distinct date_pose_pb ORDER BY date_pose_pb DESC) as date_pose_pb,
			count(id_processus_particulier) as id_processus_particulier
		from requete_optimum as ro
		where (date_pose_pb != NULL or date_pose_pb != '''') and date_pose_pb::date >  CURRENT_DATE - INTERVAL ''6 months'' and 
			nombre_de_logements::int < 4
			---Avoir avec la condition
		group by ro.localite_site';
	requete := quote_literal(e'select * from "inter_TE01.1"');
	col_uniq := quote_literal(e'localite_site');
	col_transpose := quote_literal(e'localite_site');
	col_value_transpose := quote_literal(e'#.id_processus_particulier');

	FOR var_req_execute in select count(*)::int as len from "inter_TE01.1" limit 1
		LOOP
			if var_req_execute.len > 0 then

				EXECUTE 'DROP TABLE IF EXISTS "TE01.1"';
				/*EXECUTE 'select colpivot(''_test_pivoted'', '||
					requete||',array['||col_uniq||'], array['||col_transpose||'], '||col_value_transpose||', null)';
				EXECUTE 'CREATE TABLE "TE01.1" as ' || 'select * from _test_pivoted';*/
				EXECUTE 'CREATE TABLE "TE01.1" as ' || 'select distinct * from "inter_TE01.1"';
			else
				EXECUTE 'DROP TABLE IF EXISTS "TE01.1"';
				EXECUTE 'CREATE TABLE "TE01.1" (vide text)';
			end if;
		END LOOP;
    end;
$$ language plpgsql volatile;

select * from "TE01.1"();

--TE02.1
create or replace function "TE02.1"(
) returns void as $$
    declare
        requete text;
        col_uniq text;
        col_transpose text;
        col_value_transpose text;
        var_req_execute record;
    begin


	EXECUTE 'DROP TABLE IF EXISTS _test_pivoted';
	EXECUTE 'DROP TABLE IF EXISTS "inter_TE02.1"';
	EXECUTE 'CREATE TABLE "inter_TE02.1" as
		select
			--''unique''::text as uniq,
			ca.nom_commune as nom_commune,
			case when min(tr.percent) > 85 then ''OK'' else ''KO'' end as message,
			array_agg(distinct tr.percent) percent_number
		from "Calendrier" as ca
		left join "inter_TR09.1" as tr on tr.localite_site = ca.nom_commune
		group by ca.nom_commune';
	requete := quote_literal(e'select * from "inter_TE02.1"');
	col_uniq := quote_literal(e'uniq');
	col_transpose := quote_literal(e'nom_commune');
	col_value_transpose := quote_literal(e'#.percent');

	FOR var_req_execute in select count(*)::int as len from "inter_TE02.1" limit 1
		LOOP
			if var_req_execute.len > 0 then

				EXECUTE 'DROP TABLE IF EXISTS "TE02.1"';
				/*EXECUTE 'select colpivot(''_test_pivoted'', '||
					requete||',array['||col_uniq||'], array['||col_transpose||'], '||col_value_transpose||', null)';
				EXECUTE 'CREATE TABLE "TE02.1" as ' || 'select * from _test_pivoted';*/
				EXECUTE 'CREATE TABLE "TE02.1" as ' || 'select distinct * from "inter_TE02.1"';
			else
				EXECUTE 'DROP TABLE IF EXISTS "TE02.1"';
				EXECUTE 'CREATE TABLE "TE02.1" (vide text)';
			end if;
		END LOOP;
    end;
$$ language plpgsql volatile;

-- select * from "TE02.1"();


--TE03.1
create or replace function "TE03.1"(
) returns void as $$
    declare
        requete text;
        col_uniq text;
        col_transpose text;
        col_value_transpose text;
        var_req_execute record;
    begin


	EXECUTE 'DROP TABLE IF EXISTS _test_pivoted';
	EXECUTE 'DROP TABLE IF EXISTS "inter_TE03.1"';
	EXECUTE 'CREATE TABLE "inter_TE03.1" as
		select
			''unique''::text as uniq,
			localite_site as localite_site,
			sum(nombre_de_logements::int) sum
		from "Extraction_MESC_ARCEP"
		where (mesc_arcep_site != NULL or mesc_arcep_site != '''')
		group by localite_site';
	requete := quote_literal(e'select * from "inter_TE03.1"');
	col_uniq := quote_literal(e'uniq');
	col_transpose := quote_literal(e'localite_site');
	col_value_transpose := quote_literal(e'#.sum');

	FOR var_req_execute in select count(*)::int as len from "inter_TE03.1" limit 1
		LOOP
			if var_req_execute.len > 0 then

				EXECUTE 'DROP TABLE IF EXISTS "TE03.1"';
				EXECUTE 'select colpivot(''_test_pivoted'', '||
					requete||',array['||col_uniq||'], array['||col_transpose||'], '||col_value_transpose||', null)';
				EXECUTE 'CREATE TABLE "TE03.1" as ' || 'select * from _test_pivoted';
			else
				EXECUTE 'DROP TABLE IF EXISTS "TE03.1"';
				EXECUTE 'CREATE TABLE "TE03.1" (vide text)';
			end if;
		END LOOP;
    end;
$$ language plpgsql volatile;

-- select * from "TE03.1"();


--MANUEL
-- DROP TABLE IF EXISTS "MANUEL";
-- CREATE TABLE "MANUEL" as
-- select
-- 	commune,semaine
-- from "Raccordement"
-- where (semaine = '% dÃ©chec sur 8S glissantes');

--TE04.1
create or replace function "TE04.1"(
) returns void as $$
    declare
        requete text;
        col_uniq text;
        col_transpose text;
        col_value_transpose text;
        var_req_execute record;
    begin
	EXECUTE 'DROP TABLE IF EXISTS _test_pivoted';
	EXECUTE 'DROP TABLE IF EXISTS "inter_TE04.1"';
	EXECUTE 'CREATE TABLE "inter_TE04.1" as
		select
			array_agg(localite_site) as localite_site,
			num_dossier_site as num_dossier_site,
			--array_agg(localite_site) as localite_site,
			array_agg(date_pose_pb) as date_pose_pb,
			array_agg(id_processus_particulier) as id_processus_particulier,
			array_agg(libelle_site_etat_negociation_syndic) as libelle_site_etat_negociation_syndic
		from requete_optimum as ro
		/*where (date_pose_pb != NULL or date_pose_pb != '''') and
			id_processus_particulier like ''%DSP_ATHD_PHASE2_PER_RAC%'' and nombre_de_logements::int > 4 and
			libelle_site_etat_negociation_syndic not in  (''%DENONCE%'' ,''%REFUS SYNDIC%'',''%SIGNE%'')*/
		where (date_pose_pb = NULL or date_pose_pb = '''') and nombre_de_logements::int > 3 and
			libelle_site_etat_negociation_syndic in  (''SIGNE'')
		group by ro.num_dossier_site';
	requete := quote_literal(e'select * from "inter_TE04.1"');
	col_uniq := quote_literal(e'uniq');
	col_transpose := quote_literal(e'localite_site');
	col_value_transpose := quote_literal(e'#.sum');

	FOR var_req_execute in select count(*)::int as len from "inter_TE04.1" limit 1
		LOOP
			if var_req_execute.len > 0 then

				EXECUTE 'DROP TABLE IF EXISTS "TE04.1"';
				EXECUTE 'CREATE TABLE "TE04.1" as ' || 'select * from "inter_TE04.1"';
			else
				EXECUTE 'DROP TABLE IF EXISTS "TE04.1"';
				EXECUTE 'CREATE TABLE "TE04.1" (vide text)';
			end if;
		END LOOP;
    end;
$$ language plpgsql volatile;

-- select * from "TE04.1"();

--TE04.2
create or replace function "TE04.2"(
) returns void as $$
    declare
        requete text;
        col_uniq text;
        col_transpose text;
        col_value_transpose text;
        var_req_execute record;
    begin
	EXECUTE 'DROP TABLE IF EXISTS _test_pivoted';
	EXECUTE 'DROP TABLE IF EXISTS "inter_TE04.2"';
	EXECUTE 'CREATE TABLE "inter_TE04.2" as
		select
			array_agg(localite_site) as localite_site,
			num_dossier_site as num_dossier_site,
			array_agg(date_pose_pb) as date_pose_pb,
			array_agg(id_processus_particulier) as id_processus_particulier,
			array_agg(libelle_site_etat_negociation_syndic) as libelle_site_etat_negociation_syndic
		from requete_optimum as ro
		where (date_pose_pb != NULL or date_pose_pb != '''') and nombre_de_logements::int >= 4
		group by ro.num_dossier_site';
	requete := quote_literal(e'select * from "inter_TE04.2"');
	col_uniq := quote_literal(e'uniq');
	col_transpose := quote_literal(e'localite_site');
	col_value_transpose := quote_literal(e'#.sum');

	FOR var_req_execute in select count(*)::int as len from "inter_TE04.2" limit 1
		LOOP
			if var_req_execute.len > 0 then

				EXECUTE 'DROP TABLE IF EXISTS "TE04.2"';
				EXECUTE 'CREATE TABLE "TE04.2" as ' || 'select * from "inter_TE04.2"';
			else
				EXECUTE 'DROP TABLE IF EXISTS "TE04.2"';
				EXECUTE 'CREATE TABLE "TE04.2" (vide text)';
			end if;
		END LOOP;
    end;
$$ language plpgsql volatile;

select * from "TE04.2"();

--OC01.1
create or replace function "OC01.1"(
) returns void as $$
    declare
        requete text;
        col_uniq text;
        col_transpose text;
        col_value_transpose text;
        var_req_execute record;
    begin
	EXECUTE 'DROP TABLE IF EXISTS _test_pivoted';
	EXECUTE 'DROP TABLE IF EXISTS "inter_OC01.1"';
	EXECUTE 'CREATE TABLE "inter_OC01.1" as
		select
			*, case when percent > 85 then ''OK'' else ''KO'' end as message
		from "TR03.1"';
	requete := quote_literal(e'select * from "inter_OC01.1"');
	col_uniq := quote_literal(e'uniq');
	col_transpose := quote_literal(e'localite_site');
	col_value_transpose := quote_literal(e'#.sum');

	FOR var_req_execute in select count(*)::int as len from "inter_OC01.1" limit 1
		LOOP
			if var_req_execute.len > 0 then

				EXECUTE 'DROP TABLE IF EXISTS "OC01.1"';
				EXECUTE 'CREATE TABLE "OC01.1" as ' || 'select * from "inter_OC01.1"';
			else
				EXECUTE 'DROP TABLE IF EXISTS "OC01.1"';
				EXECUTE 'CREATE TABLE "OC01.1" (vide text)';
			end if;
		END LOOP;
    end;
$$ language plpgsql volatile;

-- select * from "OC01.1"();

--OC02.1
create or replace function "OC02.1"(
) returns void as $$
    declare
        requete text;
        col_uniq text;
        col_transpose text;
        col_value_transpose text;
        var_req_execute record;
    begin
	EXECUTE 'DROP TABLE IF EXISTS _test_pivoted';
	EXECUTE 'DROP TABLE IF EXISTS "inter_OC02.1"';
	EXECUTE 'CREATE TABLE "inter_OC02.1" as
		select
			ROW_NUMBER () OVER (ORDER BY '''') as id_cles,
			case when 
				SUM (st_area (ST_SymDifference (tr.geom, ro.geom))) = 0 then ''OK''
			else ''KO'' end as mess_error
		from "PDD_Zone_PER_Phase2" as ro
		left join "Couverture_FTTH_Phase2" as tr on ST_DWithin(tr.geom, ro.geom,1)
		where st_area (ST_SymDifference (tr.geom, ro.geom)) > 0
		group by ST_SymDifference (tr.geom, ro.geom)';

	requete := quote_literal(e'select * from "inter_OC02.1"');
	col_uniq := quote_literal(e'uniq');
	col_transpose := quote_literal(e'localite_site');
	col_value_transpose := quote_literal(e'#.sum');

	FOR var_req_execute in select count(*)::int as len from "inter_OC02.1" limit 1
		LOOP
			if var_req_execute.len > 0 then

				EXECUTE 'DROP TABLE IF EXISTS "OC02.1"';
				EXECUTE 'CREATE TABLE "OC02.1" as ' || 'select * from "inter_OC02.1"';
			else
				EXECUTE 'DROP TABLE IF EXISTS "OC02.1"';
				EXECUTE 'CREATE TABLE "OC02.1" (vide text)';
			end if;
		END LOOP;
    end;
$$ language plpgsql volatile;

select * from "OC02.1"();


--OC03.1
create or replace function "OC03.1"(
) returns void as $$
    declare
        requete text;
        col_uniq text;
        col_transpose text;
        col_value_transpose text;
        var_req_execute record;
    begin

	EXECUTE 'DROP TABLE IF EXISTS _test_pivoted';
	EXECUTE 'DROP TABLE IF EXISTS "inter_OC03.1"';
	EXECUTE 'CREATE TABLE "inter_OC03.1" as
		select
			*, case when percent > 85 then ''OK'' else ''KO'' end as message
		from "TR09.1" as ro';

	requete := quote_literal(e'select * from "inter_OC02.1"');
	col_uniq := quote_literal(e'uniq');
	col_transpose := quote_literal(e'localite_site');
	col_value_transpose := quote_literal(e'#.sum');

	FOR var_req_execute in select count(*)::int as len from "inter_OC03.1" limit 1
		LOOP
			if var_req_execute.len > 0 then

				EXECUTE 'DROP TABLE IF EXISTS "OC03.1"';
				EXECUTE 'CREATE TABLE "OC03.1" as ' || 'select * from "inter_OC03.1"';
			else
				EXECUTE 'DROP TABLE IF EXISTS "OC03.1"';
				EXECUTE 'CREATE TABLE "OC03.1" (vide text)';
			end if;
		END LOOP;
    end;
$$ language plpgsql volatile;

-- select * from "OC03.1"();

---IG01.1
DROP TABLE IF EXISTS "IG01.1";
CREATE TABLE "IG01.1" as
with intermediare as (select
	ip.nom_site_pf_pb,
	count(ip.nom_du_pt_pb)::int,
	array_agg( distinct ip.nom_du_pt_pb) nom_du_pt_pb,
	array_length(array_agg( distinct ip.nom_du_pt_pb), 1) as array_length,
	ip.adresse_ou_sous_adresse_site_pf_pb,
	array_agg( distinct ip.nom_commune_pm) nom_commune_pm,
	array_agg( distinct ip.nom_du_pm_reg) nom_du_pm_reg,
	array_agg( distinct ip.nom_du_pa_reg) nom_du_pa_reg,
	array_agg( distinct ip.nom_du_pf_pb) nom_du_pf_pb
from requete_ipon ip
group by ip.nom_site_pf_pb, ip.adresse_ou_sous_adresse_site_pf_pb)
select * from intermediare where count >=2 and array_length > 1;

-- IG01.2
DROP TABLE IF EXISTS "IG01.2";
with tab_requete_ipon as (
	select nom_commune_pm, 
	nom_du_pf_pb,
	description_pf_pb,
	nom_du_pt_pb,
	nom_site_pf_pb,
	position_d_equipement_pt_pb,
	nom_sissi_local_technique_pt_pb,
	adresse_ou_sous_adresse_site_pf_pb	
	from requete_ipon),

	-- CH:en chambre
	check_chambre as (
	select 
		length(nom_site_pf_pb) length,
		array_to_string(REGEXP_MATCHES(nom_site_pf_pb::text, '[\w]{2}'), ',')::text = 'CH' check_nature,
		array_to_string(REGEXP_MATCHES(nom_site_pf_pb::text, '[A-Za-z0-9/]{5}$'), ',')::text ~* '[A-Za-z]' nbre_digit,
		* 
	from tab_requete_ipon
	where position_d_equipement_pt_pb = 'CHAMBRE' ),

	-- DF:poteau EDF
	check_df_poteau as (
	select 
		length(nom_site_pf_pb) length,
		array_to_string(REGEXP_MATCHES(nom_site_pf_pb::text, '[\w]{2}'), ',')::text = 'AP' check_nature,
		array_to_string(REGEXP_MATCHES(nom_site_pf_pb::text, '[A-Za-z0-9/E]{6}$'), ',')::text ~* '[A-Za-z]' nbre_digit,
		* 
	from tab_requete_ipon
	where position_d_equipement_pt_pb = 'AERIEN POTEAU ENEDIS' ),

	-- PO:poteau FT
	check_poteau_ft as (
	select 
		length(nom_site_pf_pb) length,
		array_to_string(REGEXP_MATCHES(nom_site_pf_pb::text, '[\w]{2}'), ',')::text = 'AP' check_nature,
		array_to_string(REGEXP_MATCHES(nom_site_pf_pb::text, '[A-Za-z0-9/]{7}$'), ',')::text ~* '[A-Za-z]' nbre_digit,
		* 
	from tab_requete_ipon
	where position_d_equipement_pt_pb = 'AERIEN POTEAU ORANGE' ),

	-- Immeuble
	check_immeuble as (
	select 
		length(nom_site_pf_pb) length,
		array_to_string(REGEXP_MATCHES(nom_site_pf_pb::text, '[\w]{3}'), ',')::text = 'IMB' check_nature,
		array_to_string(REGEXP_MATCHES(nom_site_pf_pb::text, '[A-Za-z0-9/]{7}$'), ',')::text ~* '[A-Za-z]' nbre_digit,
		* 
	from tab_requete_ipon
	where position_d_equipement_pt_pb in ('FACADE COTE RUE', 'IMMEUBLE GAINE TECHNIQUE', 'IM:imb apparent'))
	

	select distinct * into "IG01.2" from (
	select distinct * from check_chambre where (check_nature is false or nbre_digit is true or length != 8 or nom_site_pf_pb != nom_sissi_local_technique_pt_pb) union all
	select distinct * from check_df_poteau where (check_nature is false or nbre_digit is true or length != 10 or nom_site_pf_pb != nom_sissi_local_technique_pt_pb) union all
	select distinct * from check_poteau_ft where (check_nature is false or nbre_digit is true or length != 10 or nom_site_pf_pb != nom_sissi_local_technique_pt_pb) union all
	select distinct * from check_immeuble where (check_nature is false or length != 16 or (nom_sissi_local_technique_pt_pb != 'facade' and left(nom_sissi_local_technique_pt_pb, 3) != 'LOC')) order by position_d_equipement_pt_pb ) as t;


---IG02.1
DROP TABLE IF EXISTS "IG02.1";
CREATE TABLE "IG02.1" as
with intermediare as (select
	ip.nom_site_pf_pb,
	count(ip.nature_travaux)::int count,
	array_agg(ip.nom_du_pt_pb) nom_du_pt_pb,
	array_agg(ip.position_d_equipement_pt_pb) position_d_equipement_pt_pb,
	array_agg(distinct ip.code_imb_zone_d_influence_pf_pb_selon_les_adresses) code_imb_zone_d_influence_pf_pb_selon_les_adresses,
	array_agg(ip.DESCRIPTION_PF_PB) description_pf_pb
from requete_ipon ip
where position_d_equipement_pt_pb like '%CHAMBRE%' and nature_travaux like '%FACADE%'
group by ip.nom_site_pf_pb)
select * from intermediare;

---IG03.1
create or replace function "IG03.1"(
) returns void as $$
    declare
        requete text;
        col_uniq text;
        col_transpose text;
        col_value_transpose text;
        var_req_execute record;
    begin

	EXECUTE 'DROP TABLE IF EXISTS _test_pivoted';
	EXECUTE 'DROP TABLE IF EXISTS "inter_IG03.1"';
	EXECUTE 'CREATE TABLE "inter_IG03.1" as
		select
			distinct ad.id_metier_, ad.nb_logemen,---ad.*,
			case 
				when st_distance(bp.geom,ad.geom) is null then 0
			else st_distance(bp.geom,ad.geom)*1.3 end as distance,
			case 
				when bp.id_metier_ is null then ''Boite non Incluse dans ZPBO''
			else bp.id_metier_::text end as bp_id_metier_,
			zn.id_metier_ as zn_id_metier,
			ip.adductabilite,
			ip.adduction,
			ip.raccordable_sur_demande
		from t_adresse_gfi ad
		left join ftth_zone_eligibilite zn on st_contains(zn.geom,ad.geom)
		left join t_ebp_gfi bp on st_contains(zn.geom,bp.geom)
		left join requete_ipon ip on ip.code_imb_zone_d_influence_pf_pb_selon_les_adresses = ad.id_metier_
		where st_distance(bp.geom,ad.geom)*1.3 > 100 or ( bp.geom is null or zn.geom is null)
		';

	requete := quote_literal(e'select * from "inter_IG03.1"');
	col_uniq := quote_literal(e'uniq');
	col_transpose := quote_literal(e'localite_site');
	col_value_transpose := quote_literal(e'#.sum');

	FOR var_req_execute in select count(*)::int as len from "inter_IG03.1" limit 1
		LOOP
			if var_req_execute.len > 0 then

				EXECUTE 'DROP TABLE IF EXISTS "IG03.1"';
				EXECUTE 'CREATE TABLE "IG03.1" as ' || 'select distinct * from "inter_IG03.1"';
			else
				EXECUTE 'DROP TABLE IF EXISTS "IG03.1"';
				EXECUTE 'CREATE TABLE "IG03.1" (vide text)';
			end if;
		END LOOP;
    end;
$$ language plpgsql volatile;

select * from "IG03.1"();


---IG04.1
create or replace function "IG04.1"(
) returns void as $$
    declare
        requete text;
        col_uniq text;
        col_transpose text;
        col_value_transpose text;
        var_req_execute record;
    begin
	EXECUTE 'DROP TABLE IF EXISTS _test_pivoted';
	EXECUTE 'DROP TABLE IF EXISTS "inter_IG04.1"';
	EXECUTE 'CREATE TABLE "inter_IG04.1" as
		with recur_ig04 as (
		select
			---''Somme_de_Nombre_de_logements''::text as uniq,
			op.localite_site as localite_site,
			sum(op.nombre_de_logements::int) as sum
		from requete_optimum op
		group by op.localite_site)
		select *, (select  sum(sum) as total from "recur_ig04") from recur_ig04';

	requete := quote_literal(e'select * from "inter_IG04.1"');
	col_uniq := quote_literal(e'total');
	col_transpose := quote_literal(e'localite_site');
	col_value_transpose := quote_literal(e'#.sum');
	FOR var_req_execute in select count(*)::int as len from "inter_IG04.1" limit 1
		LOOP
			if var_req_execute.len > 0 then
				EXECUTE 'DROP TABLE IF EXISTS "IG04.1"';
				EXECUTE 'select colpivot(''_test_pivoted'', '||
					requete||',array['||col_uniq||'], array['||col_transpose||'], '||col_value_transpose||', null)';
				EXECUTE 'CREATE TABLE "IG04.1" as ' || 'select * from _test_pivoted';
			else
					EXECUTE 'DROP TABLE IF EXISTS "IG04.1"';
					EXECUTE 'CREATE TABLE "IG04.1" (vide text)';

			end if;
		END LOOP;
    end;
$$ language plpgsql volatile;

-- select * from "IG04.1"();

---IG06.1

CREATE or replace FUNCTION array_sum(NUMERIC[]) returns numeric AS 
$$
  SELECT sum(unnest) FROM (select unnest($1)) as foo;
$$
LANGUAGE sql;

CREATE or replace FUNCTION array_sum_int(int[]) returns int AS 
$$
  SELECT sum(unnest)::int FROM (select unnest($1)) as foo;
$$
LANGUAGE sql;

---IG06.3
DROP TABLE IF EXISTS "IG06.3";
CREATE TABLE "IG06.3" as
with intermediare_igo6 as (
select
	array_agg(distinct ip.nom_commune_pm) nom_commune_pm,
	ip.nom_du_pt_pb, 
	array_agg(distinct ip.code_imb_zone_d_influence_pf_pb_selon_les_adresses) as code_imb_zone_d_influence_pf_pb_selon_les_adresses,
	array_agg(distinct(description_pf_pb)),
	---sum(replace(ip.nb_el_du_code_immeuble, Null, '0')::int) nb_el_du_code_immeuble,
	array_to_string(array_agg(DISTINCT (ip.nom_site_pf_pb)),';') nom_site_pf_pb,
	array_to_string(array_agg(DISTINCT (ip.position_d_equipement_pt_pb)),';') position_d_equipement_pt_pb,
	array_agg(CASE
			WHEN ip.nb_el_du_code_immeuble IS NULL or ip.nb_el_du_code_immeuble = '' THEN
				0
			ELSE
				ip.nb_el_du_code_immeuble::int
		END) as nb_el_du_code_immeuble_replace,
	--count(ip.nb_el_du_code_immeuble) + ((count(ip.nb_el_du_code_immeuble) * 20)::float/100) as vingtpourcen,
	array_to_string(array_agg(distinct case when ip_pt.nombre_pt is null then 0 else ip_pt.nombre_pt::int end),';') as nombre_pt_ipon_file
from requete_ipon ip
	left join table_data_ipon_pt ip_pt on ip_pt.nom_pt = ip.nom_du_pt_pb
group by ip.nom_du_pt_pb)
select 
	
	*,
	array_sum_int(nb_el_du_code_immeuble_replace) as nb_el_du_code_immeuble_sum, 
	array_sum_int(nb_el_du_code_immeuble_replace) + ((array_sum_int(nb_el_du_code_immeuble_replace) * 20)::float/100) as vingtpourcen
from intermediare_igo6;
---where array_sum_int(nb_el_du_code_immeuble_replace) + ((array_sum_int(nb_el_du_code_immeuble_replace) * 20)::float/100)::float > nombre_pt_ipon_file::float;

---IG06.1
DROP TABLE IF EXISTS "IG06.1";
CREATE TABLE "IG06.1" as
select
	*
from "IG06.3"
where nb_el_du_code_immeuble_sum + ((nb_el_du_code_immeuble_sum * 20)::float/100)::float > nombre_pt_ipon_file::float;

---IG06.2
DROP TABLE IF EXISTS "IG06.2";
CREATE TABLE "IG06.2" as
select 
	distinct imb.id_metier_, imb.nb_logemen, imb.batiment, zn.id_metier_ as id_metier_zone
from ftth_site_immeuble imb
	join ftth_zone_eligibilite zn on st_within(imb.geom, zn.geom);
	
---IG07.1
DROP TABLE IF EXISTS "IG07.1";
-- CREATE TABLE "IG07.1" as
-- select
-- 	ip.description_du_site_pa ,
-- 	---sum(replace(ip.nb_el_du_code_immeuble, Null, '0')::int) nb_el_du_code_immeuble,
-- 	array_agg(CASE
-- 			WHEN ip.nb_el_du_code_immeuble IS NULL or ip.nb_el_du_code_immeuble = '' THEN
-- 				0
-- 			ELSE
-- 				ip.nb_el_du_code_immeuble::int
-- 		END) as nb_el_du_code_immeuble_replace,
-- 	array_sum(array_agg(CASE
-- 		WHEN ip.nb_el_du_code_immeuble IS NULL or ip.nb_el_du_code_immeuble = '' THEN
-- 			0
-- 		ELSE
-- 			ip.nb_el_du_code_immeuble::int
-- 		END)) as nb_el_du_code_immeuble_sum,
-- 	array_to_string(array_agg(DISTINCT (ip.nom_site_pf_pb)),';') nom_site_pf_pa,
-- 	array_to_string(array_agg(DISTINCT (ip.position_d_equipement_pt_pa)),';') position_d_equipement_pt_pa
-- from requete_ipon ip
-- group by ip.description_du_site_pa;

---SI01.1
DROP TABLE IF EXISTS "SI01.1";
CREATE TABLE "SI01.1" as
select
	pft.id_metier_, pft.type_site, pft.id_metie_1, pft.code_com, zft.id_metier_ as id_metier_zone
from ftth_pf pft
	left join ftth_zone_eligibilite zft on pft.id_metier_ = zft.id_metier_
where zft.id_metier_ is null and pft.id_metier_ like '%PB%';


---SI01.2
DROP TABLE IF EXISTS "SI01.2";
CREATE TABLE "SI01.2" as

with intersect_siteimmeuble_zonel as 
(select
	sit_imb.id_metier_, sit_imb.nb_logemen, sit_imb.batiment,
	zft.id_metier_ as id_metier_zone
from ftth_site_immeuble sit_imb
	 left join ftth_zone_eligibilite zft on st_intersects(sit_imb.geom,zft.geom)
where zft.geom is not null)
select 
	inter.*,
	reqip.adresse_ou_sous_adresse_site_pf_pb,
	reqip.nom_site_pf_pb,
	reqip.description_pf_pb,
	reqip.nom_du_pt_pb,
	reqip.nom_du_pf_pb,
	reqip.code_imb_zone_d_influence_pf_pb_selon_les_adresses,
	reqip.nb_el_du_code_immeuble,
	reqip.description_du_site_commentaires
from intersect_siteimmeuble_zonel as inter
	left join requete_ipon as reqip on inter.id_metier_ = reqip.code_imb_zone_d_influence_pf_pb_selon_les_adresses
where reqip.code_imb_zone_d_influence_pf_pb_selon_les_adresses is null or 
	right(inter.id_metier_zone, 5) != replace(left(reqip.description_pf_pb, 8), left(reqip.description_pf_pb, 3),'');

--- SI01.3
DROP TABLE IF EXISTS "SI01.3";
-- CREATE TABLE "SI01.3" as
with intersect_siteimmeuble_zonel as 
(select
	sit_imb.id_metier_, sit_imb.nb_logemen, sit_imb.batiment,
	zft.id_metier_ as id_metier_zone
from ftth_site_immeuble sit_imb
	 left join ftth_zone_eligibilite zft on st_intersects(sit_imb.geom,zft.geom)
where zft.geom is not null),
group_id_metier_zone as (
select 
	reqip.code_imb_zone_d_influence_pf_pb_selon_les_adresses,
	array_to_string(array_agg(distinct reqip.description_pf_pb), ',') description_pf_pb,
	array_to_string(array_agg(distinct inter.id_metier_), ',') id_metier_,
	array_to_string(array_agg(distinct inter.id_metier_zone), ',') id_metier_zone,
	array_to_string(array_agg(inter.nb_logemen), ',') nb_logemen
from intersect_siteimmeuble_zonel as inter
	left join requete_ipon as reqip on inter.id_metier_ = reqip.code_imb_zone_d_influence_pf_pb_selon_les_adresses

where reqip.description_pf_pb is not null and reqip.description_pf_pb != ''
group by reqip.code_imb_zone_d_influence_pf_pb_selon_les_adresses
order by reqip.code_imb_zone_d_influence_pf_pb_selon_les_adresses)

select distinct * into "SI01.3" from group_id_metier_zone
where description_pf_pb ~ right(id_metier_zone, 5) is false;
	
---SI02.1
DROP TABLE IF EXISTS "SI02.1";
CREATE TABLE "SI02.1" as
select
	ad.id_metier_,
	ad.code_com,
	ad.nom_com,
	ad.nb_logemen,
	ro.localite_site, 
	ro.num_dossier_site,
	ro.nombre_de_logements,
	ro.id_processus_particulier,
	ro.code_regroupement_technique
from t_adresse_gfi ad
full outer join requete_optimum as ro on ro.num_dossier_site = ad.id_metier_
where (ro.num_dossier_site is null or ro.num_dossier_site = '') or (ad.id_metier_ is null or ad.id_metier_ = '');

---SI03.1
DROP TABLE IF EXISTS "SI03.1";
CREATE TABLE "SI03.1" as
select
	bp.id_metier_,
	bp.type_site,
	bp.id_metie_1,
	bp.statut_ftt,
	bp.type_pf,
	bp.code_com
from t_ebp_gfi bp
where statut_ftt not like '%D%';

--SI04.1
create or replace function "SI04.1"(
) returns void as $$
    declare
        requete text;
        col_uniq text;
        col_transpose text;
        col_value_transpose text;
        var_req_execute record;
    begin

	EXECUTE 'DROP TABLE IF EXISTS _test_pivoted';
	EXECUTE 'DROP TABLE IF EXISTS "inter_OC02.1"';
	EXECUTE 'CREATE TABLE "inter_OC02.1" as
		select
			*
		from "Optimum" as ro
		where nombre_de_logements::int >3';

	requete := quote_literal(e'select * from "inter_OC02.1"');
	col_uniq := quote_literal(e'uniq');
	col_transpose := quote_literal(e'localite_site');
	col_value_transpose := quote_literal(e'#.sum');

	FOR var_req_execute in select count(*)::int as len from "inter_OC02.1" limit 1
		LOOP
			if var_req_execute.len > 0 then

				EXECUTE 'DROP TABLE IF EXISTS "SI04.1"';
				EXECUTE 'CREATE TABLE "SI04.1" as ' || 'select * from "inter_OC02.1"';
			else
				EXECUTE 'DROP TABLE IF EXISTS "SI04.1"';
				EXECUTE 'CREATE TABLE "SI04.1" (vide text)';
			end if;
		END LOOP;
    end;
$$ language plpgsql volatile;

select * from "SI04.1"();

---SI05.1
DROP TABLE IF EXISTS "SI05.1";
CREATE TABLE "SI05.1" as
select
	distinct ip.nom_commune_pm,
	ip.nom_du_pm_reg,
	ip.nom_du_pa_reg,
	ip.nom_du_pf_pb,
	ip.position_d_equipement_pt_pb,
	ip.hauteur_par_rapport_au_sol_pt_pb,
	ip.nom_site_pf_pb,
	ip.nom_du_pt_pb
from requete_ipon ip
where (ip.hauteur_par_rapport_au_sol_pt_pb is NULL or ip.hauteur_par_rapport_au_sol_pt_pb = '') or
	(ip.position_d_equipement_pt_pb like 'AERIEN POTEAU%' and ip.hauteur_par_rapport_au_sol_pt_pb like '%HH : h inf  1,8 m%') or
	(ip.position_d_equipement_pt_pb = 'IMMEUBLE GAINE TECHNIQUE' and ip.hauteur_par_rapport_au_sol_pt_pb not like '%HH : h inf  1,8 m%') or 
	(ip.position_d_equipement_pt_pb = 'CHAMBRE' and ip.hauteur_par_rapport_au_sol_pt_pb not like '%HH : h inf  1,8 m%');

---SI06.1
DROP TABLE IF EXISTS "SI06.1";
CREATE TABLE "SI06.1" as
with rbal_avec_pdd as(
select
	rb.*
from "RBAL_Phase2" rb
	join "PDD_Zone_PER_Phase2" zn on st_contains(zn.geom,rb.geom)
)
select rbal.* from rbal_avec_pdd rbal
	left join t_adresse_gfi ad on ST_DWithin(ad.geom,rbal.geom,0.1)
where ad.geom is null;

-- SI07.1
DROP TABLE IF EXISTS "SI07.1";
CREATE TABLE "SI07.1" as
select * from "inter_IG03.1";

---SI08.1
create or replace function "SI08.1"(
) returns void as $$
    declare
        requete text;
        col_uniq text;
        col_transpose text;
        col_value_transpose text;
        var_req_execute record;
    begin

	EXECUTE 'DROP TABLE IF EXISTS _test_pivoted';
	EXECUTE 'DROP TABLE IF EXISTS "inter_SI08.1"';
	EXECUTE 'CREATE TABLE "inter_SI08.1" as
		select
			distinct
			ip.code_commune_pm,
			ip.nom_commune_pm,
			ip.nom_du_pm_reg,
			ip.nom_du_pa_reg,
			ip.nom_du_pf_pa,
			ip.nom_du_pt_pa,
			ip.nom_site_pf_pa,
			ip.nom_du_pf_pb,
			ip.etat_production_pf_pb,
			ip.description_pf_pb,
			ip.etat_physique_pt_pb,
			ip.nom_du_pt_pb,
			ip.nom_site_pf_pb,
			ip.description_du_site_pb
		from requete_ipon ip
		where (ip.etat_production_pf_pb not like ''%Déployé%'' or ip.etat_physique_pt_pb not like ''%Actif%'');';

	requete := quote_literal(e'select * from "inter_SI08.1"');
	col_uniq := quote_literal(e'uniq');
	-- col_transpose := quote_literal(e'localite_site');
	col_value_transpose := quote_literal(e'#.sum');

	FOR var_req_execute in select count(*)::int as len from "inter_SI08.1" limit 1
		LOOP
			if var_req_execute.len > 0 then

				EXECUTE 'DROP TABLE IF EXISTS "SI08.1"';
				EXECUTE 'CREATE TABLE "SI08.1" as ' || 'select * from "inter_SI08.1"';
			else
				EXECUTE 'DROP TABLE IF EXISTS "SI08.1"';
				EXECUTE 'CREATE TABLE "SI08.1" (vide text)';
			end if;
		END LOOP;
    end;
$$ language plpgsql volatile;

select * from "SI08.1"();

--SI10.1
create or replace function "SI10.1"(
) returns void as $$
    declare
        requete text;
        col_uniq text;
        col_transpose text;
        col_value_transpose text;
        var_req_execute record;
    begin

	EXECUTE 'DROP TABLE IF EXISTS _test_pivoted';
	EXECUTE 'DROP TABLE IF EXISTS "inter_OC02.1"';
	EXECUTE 'CREATE TABLE "inter_OC02.1" as
		select
			*
		from requete_optimum as ro
		where bloque like ''%1%'';';

	requete := quote_literal(e'select * from "inter_OC02.1"');
	col_uniq := quote_literal(e'uniq');
	col_transpose := quote_literal(e'localite_site');
	col_value_transpose := quote_literal(e'#.sum');

	FOR var_req_execute in select count(*)::int as len from "inter_OC02.1" limit 1
		LOOP
			if var_req_execute.len > 0 then

				EXECUTE 'DROP TABLE IF EXISTS "SI10.1"';
				EXECUTE 'CREATE TABLE "SI10.1" as ' || 'select * from "inter_OC02.1"';
			else
				EXECUTE 'DROP TABLE IF EXISTS "SI10.1"';
				EXECUTE 'CREATE TABLE "SI10.1" (vide text)';
			end if;
		END LOOP;
    end;
$$ language plpgsql volatile;

select * from "SI10.1"();

---SI11.1
DROP TABLE IF EXISTS "SI11.1";
CREATE TABLE "SI11.1" as
select
	distinct NOM_COMMUNE_PM,
	NOM_DU_PM_REG,
	NOM_DU_PA_REG,
	NOM_DU_PF_PA,
	NOM_DU_PF_PB,
	DESCRIPTION_PF_PB,
	NOM_SITE_PF_PB,
	POSITION_D_EQUIPEMENT_PT_PB,
	adresse_ou_sous_adresse_site_pf_pb
from requete_ipon ip
where ip.position_d_equipement_pt_pb like '%FACADE%'
order by ip.position_d_equipement_pt_pb;

---SI12.1
DROP TABLE IF EXISTS "SI12.1";
CREATE TABLE "SI12.1" as
select 
	distinct NOM_DU_PF_PB, DESCRIPTION_PF_PB, NOM_DU_PT_PB, NOM_SITE_PF_PB, 
	POSITION_D_EQUIPEMENT_PT_PB, ADRESSE_OU_SOUS_ADRESSE_SITE_PF_PB
from requete_ipon;

---SI12.2
DROP TABLE IF EXISTS "SI12.2";
CREATE TABLE "SI12.2" as
select 
	distinct id_metier_, type_site, id_metie_1,code_com
from ftth_pf;

-- SI13.1
DROP TABLE IF EXISTS "SI13.1";
WITH
conf as
	(select 0.1 as buf),
zsb as
	(select zs.id_metier_, ST_Buffer(zs.geom, -conf.buf::float) as geom
		from ftth_zone_eligibilite as zs, conf)
SELECT    
    distinct zs1.* into "SI13.1"
from   ftth_zone_eligibilite as zs1 
	LEFT JOIN zsb as zsb2 ON zs1.id_metier_ <> zsb2.id_metier_
where  ST_Intersects (zs1.geom, zsb2.geom);

-- IA01.1
DROP TABLE IF EXISTS "IA01.1";
CREATE TABLE "IA01.1" as
select 
	ref_cable,
	statut_ftt,
	type_longu,
	longueur,
	diametre,
	nb_fibre,
	type_cable,
	id_metier_,
	type_site_,
	id_metier1,
	type_site1
from ftth_cable
where statut_ftt != 'D' or type_longu != 'T';

-- IA01.2
DROP TABLE IF EXISTS "IA01.3";
CREATE TABLE "IA01.3" as
select 
	ref_cable,
	statut_ftt,
	type_longu,
	longueur,
	diametre,
	nb_fibre,
	type_cable,
	id_metier_,
	type_site_,
	id_metier1,
	type_site1

from ftth_cable
where statut_ftt = 'D' and type_longu = 'T';

DROP TABLE IF EXISTS "IA01.2";
CREATE TABLE "IA01.2" as
with tab_ftth_cable as (
	select 
		*
	from "IA01.3" )
		
	
select 'Construction fourreaux'::text, (
		select coalesce(sum(longueur::float),0) total_longueur  from tab_ftth_cable
			where type_site_ in ('Armoire', 'Chambre FTTH', 'NRA FTTH')) +
		(select coalesce(sum(longueur::float),0) total_longueur  from tab_ftth_cable
			where type_site_ in ('Appui télécom FTTH', 'Appui commun FTTH', 'Immeuble FTTH') and type_site1 in ('Chambre FTTH', 'NRA FTTH', 'Armoire'))
		as nature
		
union all 

select 'utilisation appui aeriens orange'::text, 
		(select coalesce(sum(longueur::float),0) total_longueur  from tab_ftth_cable
			where type_site_ in ('Appui télécom FTTH') and type_site1 in ('Appui télécom FTTH', 'Appui commun FTTH', 'Immeuble FTTH')) +

		(select coalesce(sum(longueur::float),0) total_longueur  from tab_ftth_cable
			where type_site_ in ('Appui commun FTTH', 'Immeuble FTTH') and type_site1 in ('Appui télécom FTTH'))
		as nature
		
union all

select 'utilisation appui aeriens enedis'::text, (
		select coalesce(sum(longueur::float),0) total_longueur  from tab_ftth_cable
			where type_site_ in ('Appui commun FTTH') and type_site1 in ('Appui commun FTTH')) as nature
			
union all

select 'utilisation autre(facade, immeuble)'::text, (
		select coalesce(sum(longueur::float),0) total_longueur  from tab_ftth_cable
			where type_site_ in ('Immeuble FTTH') and type_site1 in ('Immeuble FTTH')) as nature
			
union all

select 'Lineaire deploye cable optique NRO-SRO'::text, (
		select coalesce(sum(longueur::float),0) total_longueur  from tab_ftth_cable
			where type_cable = 'T') as nature
			
union all

select 'Lineaire deploye cable optique SRO-PBO'::text, (
		select coalesce(sum(longueur::float),0) total_longueur  from tab_ftth_cable
			where type_cable in ('1', '2')) as nature
			
union all

select 'Lineaire deploye cable optique PBO-DTIO'::text, (
		select coalesce(sum(longueur::float),0) total_longueur  from tab_ftth_cable
			where type_cable = '3') as nature
			
union all

select 'Lineaire deploye fibre optique Collectes NRO-SRO + SRO-PBO'::text, coalesce(sum(nb_fibre::float),0)  nb_fibre from tab_ftth_cable
		where type_cable  in ('T', '1', '2')
		
union all

select 'Lineaire deploye fibre optique Collectes PBO-DTIO'::text, coalesce(sum(nb_fibre::float),0)  nb_fibre from tab_ftth_cable
		where type_cable  in ('3')
		
union all

select 'Typologie des raccordements interieur egale Table requete ipon'::text, coalesce(count(nature_travaux),0) from requete_ipon
		where nature_travaux  in ('INDETERMINE')
		
union all

select 'Typologie des souterrain interieur egale Table requete ipon'::text, coalesce(count(nature_travaux),0) from requete_ipon
		where nature_travaux  in ('SOUTERRAIN')
		
union all

select 'Typologie des raccordements Aerien/facade == Table requete ipon'::text, coalesce(count(nature_travaux),0) from requete_ipon
		where nature_travaux  in ('AERIEN', 'AEROSOUTERRAIN', 'FACADE')
-- Grant pour les tables creees par le script
--GRANT ALL ON SCHEMA lfd TO adn_ing;

/*
SELECT
	'ALTER TABLE lfd.'||'"'||table_name||'" OWNER TO '||'adn_ing;'
	table_name
FROM information_schema.tables
WHERE table_schema = 'lfd'*/