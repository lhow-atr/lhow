# Changelog Notes
## Tags
v_2023_01_03    Tags Version v_2023_01_03
v_2023_01_16    Tags Version v_2023_01_16
v_2023_01_17    Tags Version v_2023_01_17
## Commits
- Correction erreur mise a jour plugin (af07676) (Babacar FASSA) (2023-01-17)
- Correction erreur qmessageBox et ajout le changelog dans la documentation (b7b128a) (Babacar FASSA) (2023-01-16)
- Migration vers qgis3.22 version finale avec ajout de la methode du deploiement continu ainsi que la documentation avec mkdocs et la creation de tag a chaque modifications (4d8af96) (Babacar FASSA) (2023-01-03)
- Migration vers qgis3.22 version finale avec ajout de la methode du deploiement continu ainsi que la documentation avec mkdocs et la creation de tag a chaque modifications (c80d1ca) (Babacar FASSA) (2023-01-03)
- Migration vers qgis3.22 version finale avec ajout de la methode du deploiement continu ainsi que la documentation avec mkdocs (7e0a435) (Babacar FASSA) (2022-12-30)
- IMP: Correction des bugs sur la creation de lapplication excel pour win32.client ainsi que gestion des erreurs (85369c9) (Babacar) (2021-07-01)
- IMP: Ajout des tables manquantes pour l'export ainsi que Ajout d'une nouvelle requete pour le DEO (48ab333) (Babacar) (2021-07-01)
- IMP: Correction de la metadonnnée pour le deploiement (c43cc71) (Babacar) (2021-06-30)
- Initial commit (cfccaae) (Babacar) (2021-06-29)
## Merges
## AUTHORS
- Babacar
- Babacar FASSA
