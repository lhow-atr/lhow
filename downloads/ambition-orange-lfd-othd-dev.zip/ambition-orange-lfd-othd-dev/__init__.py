# -*- coding: utf-8 -*-
# pyuic5 test_ui.ui -o test_ui.py
def classFactory(iface):
    from .class_file_general_menu import ClassGeneraleMenu
    return ClassGeneraleMenu(iface)