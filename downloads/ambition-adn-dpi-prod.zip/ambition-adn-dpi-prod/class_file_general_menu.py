from .class_file_global_menu import *
from .vidange_cache_qgis import *
from .forms.check_dpigetinfo_form import *
from .forms.check_dpigetinfo_form_v2 import *
from .forms.check_dpivisiteterrain_form import *
from .forms.check_dpivisiteterrain_form_v2 import *
from .forms.calcul_synthese_dpi_form import *


class ClassGeneraleMenu:
    def __init__(self, iface):
        self.iface = iface
        self.name_menu_projet = var_class_init_custom_menu_bar.funct_add_submenu_projet_to_global(ambition_menu, 'ADN')
        self.name_group_dpi = "A.2. Contrôle TERRAIN"
    def initGui(self):
        # PIQUETAGE Submenu
        res_vidange = function_delete_cache_qgis()
        if res_vidange[1] is False:
            QMessageBox.warning(QWidget(), "Message dexecution de requete", 'Le cache nest pas vide ... ' +
                                str(res_vidange))
        self.piquetage_menu = var_class_init_custom_menu_bar.func_add_submenu_group_to_projet(self.name_menu_projet,
                                                                                              self.name_group_dpi)
        var_class_init_custom_menu_bar.func_add_action_menu(self.piquetage_menu,
                                                            "A.2.1 Conversion des fiches XLSX en XLS",
                                                            self.exe_class_checkdpigetinfo_dialog)
        # var_class_init_custom_menu_bar.func_add_action_menu(self.piquetage_menu,
        #                                                     "A.2.2 Intégration des caractéristiques d'appuis",
        #                                                     self.exe_class_checkdpigetinfo_dialog)
        # var_class_init_custom_menu_bar.func_add_action_menu(self.piquetage_menu,
        #                                                     "A.2.3 Intégration des contre-relevés terrain",
        #                                                     self.exe_class_checkdpiVt_dialog)
        var_class_init_custom_menu_bar.func_add_action_menu(self.piquetage_menu,
                                                            "A.2.2 Intégration des caractéristiques d'appuis",
                                                            self.exe_class_checkdpigetinfo_dialog_v2)
        var_class_init_custom_menu_bar.func_add_action_menu(self.piquetage_menu,
                                                            "A.2.3 Intégration des contre-relevés terrain",
                                                            self.exe_class_checkdpiVt_dialog_v2)
        var_class_init_custom_menu_bar.func_add_action_menu(self.piquetage_menu,
                                                            "A.2.4 Création des audits de synthèse",
                                                            self.exe_class_dialogue_synthese_globale_dpi)

    def unload(self):
        self.iface.removePluginMenu(self.name_group_dpi, self.piquetage_menu.menuAction())

    def exe_class_checkdpigetinfo_dialog(self):
        self.execheckdpigetinfo = class_checkdpigetinfo_dialog(self.iface)
        self.execheckdpigetinfo.exec_()

    def exe_class_checkdpigetinfo_dialog_v2(self):
        self.checkdpigetinfo_v2 = class_checkdpigetinfo_dialog_v2(self.iface)
        self.checkdpigetinfo_v2.exec_()

    def exe_class_checkdpiVt_dialog_v2(self):
        self.checkdpiVt_dialog_v2 = class_checkdpiVt_dialog_v2(self.iface)
        self.checkdpiVt_dialog_v2.exec_()

    def exe_class_dialogue_synthese_globale_dpi(self):
        self.exe_synthese = ClassDialogueSyntheseGlobaleDpi(self.iface)
        self.exe_synthese.exec_()

# self.piquetage_menu = var_class_init_custom_menu_bar.func_add_submenu_group_to_projet(submenuadn, 'PIQUETAGE')
# self.designe_menu = var_class_init_custom_menu_bar.func_add_submenu_group_to_projet(submenuadn, 'Controle Designe')
# self.boites_menu = var_class_init_custom_menu_bar.func_add_submenu_group_to_projet(submenuadn, 'Controle Boites')
# var_class_init_custom_menu_bar.func_add_action_menu(self.piquetage_menu, "A.1.1 Import de données", self.exe_class_checkdpigetinfo_dialog)
# var_class_init_custom_menu_bar.func_add_action_menu(self.designe_menu, "A.1.1 Controle des Designs", self.exe_class_checkdpigetinfo_dialog)
# var_class_init_custom_menu_bar.func_add_action_menu(self.boites_menu, "A.1.1 Controle des Designs", self.exe_class_checkdpigetinfo_dialog)
