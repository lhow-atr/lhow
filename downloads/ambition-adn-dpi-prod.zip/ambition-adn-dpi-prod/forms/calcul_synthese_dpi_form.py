# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'C:\Users\babacar.fassa\Downloads\dialog_lfd_for_bf\dialog_lfd.ui'
#
# Created by: PyQt5 UI code generator 5.11.3
#
# WARNING! All changes made in this file will be lost!

import sys
from pathlib import Path

from qgis import gui
from qgis.PyQt import QtWidgets, QtCore
from qgis.PyQt.QtWidgets import QApplication, QMessageBox, QWidget
from qgis.gui import QgsFileWidget, QgsDateTimeEdit
from qgis.utils import iface

# app = QApplication(sys.argv)
folder_plugin = str(Path(__file__).parent.parent)
sys.path.append(folder_plugin)
from scripts_python.create_synthese_audit import *


class UiDialog(object):
    def functionCreateLabel(self, varDialog, varNameLabel, varNameTextLabel):
        varLabel = QtWidgets.QLabel(varDialog)
        varLabel.setObjectName(varNameLabel)
        varLabel.setText(varNameTextLabel)
        return varLabel
    
    def functionCreateObjetVariableQLineEdit(self, varDialog, varNameObjet):
        varObjetVariable = QtWidgets.QLineEdit(varDialog)
        varObjetVariable.setObjectName(varNameObjet)
        return varObjetVariable

    def functionCreateObjetVariableDateTime(self, varDialog, varNameObjet):
        varObjetVariableDate = QgsDateTimeEdit(varDialog)
        varObjetVariableDate.setObjectName(varNameObjet)
        return varObjetVariableDate

    def functionCreateObjetvariableQgsFileWidget(self, varDialog, varNameObjet):
        varObjetVariableFile = QgsFileWidget(varDialog)
        varObjetVariableFile.setObjectName(varNameObjet)
        return varObjetVariableFile
        
    def setupUi(self, Dialog):
        Dialog.setObjectName("Dialog")
        # Dialog.resize(662, 519)
        Dialog.setWindowTitle("Traitement DPI Synthese")   
        Dialog.setWindowModality(QtCore.Qt.ApplicationModal)
        Dialog.setEnabled(True)
        Dialog.resize(800, 800)
        Dialog.setMouseTracking(False) 

        # Partie de la creation dun container de dessin de la boite de dialog
        self.verticalLayoutWidget = QtWidgets.QWidget(Dialog)
        self.verticalLayoutWidget.setGeometry(QtCore.QRect(30, 30, 700, 700))
        self.verticalLayoutWidget.setObjectName("verticalLayoutWidget")

        # Partie de la creation sous container
        self.verticalLayout = QtWidgets.QVBoxLayout(self.verticalLayoutWidget)
        self.verticalLayout.setContentsMargins(0, 0, 0, 0)
        self.verticalLayout.setObjectName("verticalLayout")

        # Partie de la creation d'une Grille pour organiser les labels et leur object
        self.gridLayout = QtWidgets.QGridLayout()
        self.gridLayout.setObjectName("gridLayout")

        # Partie Creation des Labels des chemins des dossiers
        self.varLabelFilesynthese = self.functionCreateLabel(self.verticalLayoutWidget, "varFilesynthese", "Fichier D'entrée :")
        self.varLabelDossierCible = self.functionCreateLabel(self.verticalLayoutWidget, "varDossierCible", "Dossier cible :")
        # Partie Creation des objets des chemins des dossiers
        self.varPathFilesynthese = self.functionCreateObjetvariableQgsFileWidget(self.verticalLayoutWidget, "varPathFilesynthese", )
        self.varCibleDirectory = self.functionCreateObjetvariableQgsFileWidget(self.verticalLayoutWidget, "varCibleDirectory")
        

        # Deuxieme argument == Numero la ligne et troisieme argument == Numero la colonne
        self.gridLayout.addWidget(self.varLabelFilesynthese, 0, 0)
        self.gridLayout.addWidget(self.varLabelDossierCible, 0, 1)
        # Ligne Numero Deux sur la boite de dialogue
        self.gridLayout.addWidget(self.varPathFilesynthese, 1, 0)
        self.gridLayout.addWidget(self.varCibleDirectory, 1, 1)       

        # Partie Description Text
        self.textBrowser = QtWidgets.QTextBrowser(self.verticalLayoutWidget)
        self.textBrowser.setGeometry(QtCore.QRect(20, 140, 621, 311))
        self.textBrowser.setObjectName("textBrowser")
        self.textBrowser.setHtml(
            # Ouverture Parametrage du HTML
            """
            <!DOCTYPE html>
            <html lang="en">
            <head>
                <meta charset="UTF-8">
                <title>Title</title>
                <style type="text/css">
                    div, li {text-indent: 25px; font-size:11pt}
                    body {text-align: justify; font: sans-serif;}
                </style>
            </head>
            <body>
            """
            # Corp du text
            """
            <h3> Objectifs: </h3>
                <div> Ce module permet de créer la synthése globale et par ZSRO des audits DPI.</div>
            <h3> Données en entrée: </h3>
                <div> Les données d'entrée correspondent à un fichier excel contenant des onglets dont les derniers caractéres se terminent par: 
                    <ol>
                        <li> <h5> AER_ORANGE </h5> </li>
                        <li> <h5> AER_ENEDIS </h5> </li>
                    </ol>
                </div>
            <h3> Résultat: </h3>
                <div> Le livrable est analysé afin d'extraire les synthéses. Un fichier de sortie est créé avec le nom:
                    <ol>
                        <li> resultat_brut_synthese.xlsx </li>
                    </ol>
                </div>
            <h3> Contraintes: </h3>
                <div> Le fichier d'entré doit respecter le format considérant comme modéle de développement, en fonction des messages d'erreurs on pourra voir des informations détaillées sur la typologie d'erreur.</div>
            <h3> Restrictions:</h3>
                <ol>
                  <li> Renseigner le fichier d'entrée </li>
                  <li> Renseigner le dossier de cible </li>
                </ol>
            """
            # Fin Parametrage du HTML
            """
            < / body >
            < / html > """
        )

         # Ajout de la grille dans le vertitcallayout
        self.verticalLayout.addLayout(self.gridLayout)
        # Ajout du textBrowser dans le vertitcallayout
        self.verticalLayout.addWidget(self.textBrowser)

        # Partie de la creation du Nom button_box
        self.buttonBox = QtWidgets.QDialogButtonBox(self.verticalLayoutWidget)
        self.buttonBox.setOrientation(QtCore.Qt.Horizontal)
        self.buttonBox.setStandardButtons(
            QtWidgets.QDialogButtonBox.Cancel | QtWidgets.QDialogButtonBox.Ok)
        self.buttonBox.setObjectName("button_box")
        
        # Ajout du button_box dans le vertitcallayout
        self.verticalLayout.addWidget(self.buttonBox)
        self.buttonBox.accepted.connect(Dialog.accept)
        self.buttonBox.rejected.connect(Dialog.reject)
        QtCore.QMetaObject.connectSlotsByName(Dialog)


class ClassGeneralDialog(QtWidgets.QDialog):
    def __init__(self, iface):
        QtWidgets.QDialog.__init__(self)
        self.iface = iface

    @staticmethod
    def get_version_plugin():
        folder_metada = open(f"{folder_plugin}\metadata.txt")
        for line in folder_metada:
            if str(line)[:7] == 'version':
                get_version = line.split('=')[1]
                folder_metada.close()
                return get_version


class ClassDialogueSyntheseGlobaleDpi(ClassGeneralDialog, UiDialog):
    def __init__(self, iface):
        ClassGeneralDialog.__init__(self, iface)
        self.setupUi(self)
        self.setWindowTitle("DESIGN" + str(self.get_version_plugin()) + " - Création des Synthéses des Audits DPI ")
        # self.varPathFilesynthese.setStorageMode(gui.QgsFileWidget.GetDirectory)
        self.varPathFilesynthese.setStorageMode(gui.QgsFileWidget.GetFile)
        self.varCibleDirectory.setStorageMode(gui.QgsFileWidget.GetDirectory)
        self.buttonBox.button(QtWidgets.QDialogButtonBox.Ok).clicked.connect(self.run)
        
    
    def run(self):

        path_file_synthese = str(self.varPathFilesynthese.filePath())
        path_export_res = str(self.varCibleDirectory.filePath())

        # Check Directory
        is_file_synthese = os.path.isfile(path_file_synthese)
        is_directory_export = os.path.isdir(path_export_res)
        if is_file_synthese and is_directory_export:
            SyntheseAuditDpi(path_file_synthese, path_export_res)
        else:
            QMessageBox.critical(QWidget(), "Message Execution Plugin", 'Veillez rensigner tous les bons chemins')

# baba_dialog = ClassDialogueSyntheseGlobaleDpi(iface)
# baba_dialog.show()
# sys.exit(app.exec_())