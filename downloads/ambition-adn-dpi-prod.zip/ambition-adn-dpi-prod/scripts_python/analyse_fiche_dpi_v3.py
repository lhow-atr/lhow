# -*- coding: utf-8 -*-
import csv
import json
import re

import psycopg2
import psycopg2.extras
from osgeo import ogr, osr
import xlrd
import xlwt
from qgis.PyQt.QtCore import *
from qgis.PyQt.QtGui import *
from qgis.PyQt.QtWidgets import *
from qgis.core import *
from qgis.utils import *
from pathlib import Path

folder_plugin = str(Path(__file__).parent.parent)
sys.path.append(folder_plugin)
from bdd.params_connexion import *

# folder_plugin = r'C:\Users\babacar.fassa\Documents\GitHub\adn-dpi'
# sys.path.append(folder_plugin)
# from bdd.params_connexion import *


try:
    import openpyxl
    from openpyxl import Workbook
    from openpyxl import load_workbook
except(Exception,) as error:
    # https://stackoverflow.com/questions/42974450/iterate-over-worksheets-rows-columns
    # https://www.soudegesu.com/en/post/python/cell-excel-with-openpyxl/
    import subprocess

    subprocess.check_call(['pip', 'install', 'openpyxl'])  # 'python', '-m',
    import openpyxl

# app = QApplication(sys.argv)


# Class General des functions
class GeneralFunctions:
    global DB, user, MP, host, port

    # Constructeur des variables qui change
    def __init__(self, var_connection):
        self.connection = var_connection

    # Declaration de la variable pour les messages derreur
    w = QWidget()

    # Function pour la progession bar1
    def progress_bar(self, name_etape):
        prog = QProgressDialog(name_etape + ' : Veillez Patienter', 'Cancel', 0, 100)
        prog.setWindowModality(Qt.WindowModal)
        prog.setMinimumDuration(1)
        return prog

    # Function pour la progession bar2
    def progress_processing(self, index, count_entite, progress_dialog):
        f = int(index + 1)
        pcnt = int(f / count_entite * 100 / 1)
        progress_dialog.setValue(pcnt)

    # Function pour executer une requete sql dans la base
    def function_execute_requete(self, requete_execute, req_fetch):
        connection = self.connection
        curs = connection.cursor()
        try:
            curs.execute(requete_execute)
            if req_fetch:
                data_req = [row for row in curs.fetchall()]
                if data_req:
                    return data_req
        except(Exception, psycopg2.DatabaseError) as error:
            QMessageBox.warning(self.w, "Message dexecution de requete",
                                'Requete Non Executer : ' + str(error) + ' ; ' + str(requete_execute))
        connection.commit()
        curs.close()

    # Function pour la creation de la table a_appuibt
    def function_creatTable_a_appuibt(self, schema, a_appuibt):
        req = f"""set search_path TO {schema}, public;
            DROP TABLE IF EXISTS {a_appuibt};
            CREATE TABLE {a_appuibt}
            (
                ab_mcd_etiquet text,
                ab_mcd_cable text,
                ab_mcd_zsro text,
                ab_mcd_gest text,
                ab_mcd_a_struc text,
                ab_mcd_nature text,
                ab_mcd_eta text,
                ab_mcd_rac text,
                ab_eco_codeext text,
                ab_eco_etude text,
                ab_eco_insee text,
                ab_eco_commune text,
                ab_eco_struct text,
                ab_eco_type text,
                ab_eco_annee text,
                ab_eco_x text,
                ab_eco_y text,
                ab_eco_rac_bt text,
                ab_eco_rac_tel text,
                ab_eco_malt text,
                ab_eco_iacm text,
                ab_eco_ras_hta text,
                ab_eco_ras_bt text,
                ab_eco_ep text,
                ab_eco_cb_bt text,
                ab_eco_cb_cu text,
                ab_eco_cb_fo text,
                ab_eco_rac_reel text,
                ab_eco_eta_com text,
                ab_eco_dan_avt text,
                ab_eco_com_com text,
                ab_eco_visuel_com text,
                ab_efi_codefiche text,
                ab_efi_prive text,
                ab_efi_surplomb text,
                ab_efi_elagage text,
                ab_efi_inv text,
                ab_efi_hlibre text,
                ab_efi_visuel text,
                ab_efi_vertica text,
                ab_efi_jaune text,
                ab_efi_mobilis text,
                ab_efi_gravur text,
                ab_efi_ras_ft text,
                ab_efi_orien text,
                ab_efi_anc_bt text,
                ab_efi_anc_ft text,
                ab_efi_com_etl text,
                ab_moe_nat_tvx text,
                ab_moe_environ text,
                ab_moe_val text,
                ab_moe_com text,
                geom geometry(Point,2154),
                name_schema text,
                ab_mcd_pt_comment text,
                attachment text
            );
            ---ALTER TABLE a_appuibt OWNER to postgres;
            ALTER TABLE {a_appuibt} OWNER to adn_ing;
            GRANT INSERT, SELECT ON TABLE {a_appuibt} TO adn_ing;
            GRANT ALL ON TABLE {a_appuibt} TO postgres;
            GRANT ALL ON TABLE {a_appuibt} TO adn_ing;
            CREATE INDEX a_abt_gidx_{a_appuibt}
                ON {a_appuibt} USING btree (geom);"""
        self.function_execute_requete(req, '')

    # Function insertion dans table a_appuibt avec Fiches
    def function_insert_a_appuibt(self, schema, text_inf_insert, table_name):
        req = f"""INSERT INTO {schema}.{table_name}(
                ab_mcd_etiquet,ab_mcd_cable,ab_mcd_zsro,ab_mcd_gest,ab_mcd_a_struc,
                ab_mcd_nature,ab_mcd_eta,ab_mcd_rac,ab_eco_codeext,ab_eco_etude,
                ab_eco_insee,ab_eco_commune,ab_eco_struct,ab_eco_type,ab_eco_annee,
                ab_eco_x,ab_eco_y,ab_eco_rac_bt,ab_eco_rac_tel,ab_eco_malt,ab_eco_iacm,
                ab_eco_ras_hta,ab_eco_ras_bt,ab_eco_ep,ab_eco_cb_bt,ab_eco_cb_cu,
                ab_eco_cb_fo,ab_eco_rac_reel,ab_eco_eta_com,ab_eco_dan_avt,ab_eco_com_com,
                ab_eco_visuel_com,ab_efi_codefiche,ab_efi_prive,ab_efi_surplomb,ab_efi_elagage,
                ab_efi_inv,ab_efi_hlibre,ab_efi_visuel,ab_efi_vertica,ab_efi_jaune,ab_efi_mobilis,
                ab_efi_gravur,ab_efi_ras_ft,ab_efi_orien,ab_efi_anc_bt,ab_efi_anc_ft,ab_efi_com_etl,
                ab_moe_nat_tvx,ab_moe_environ,ab_moe_val,ab_moe_com, geom, name_schema, ab_mcd_pt_comment, attachment)
                    VALUES {text_inf_insert};"""  # , geom
        self.function_execute_requete(req, '')

    # Function pour la creation de la table a_appuift
    def function_creatTable_a_appuift(self, schema, a_appuift):
        req = f"""set search_path TO {schema}, public;
            DROP TABLE IF EXISTS {a_appuift};
            CREATE TABLE {a_appuift}
            (
                af_mcd_etiquet text, 
                af_mcd_cable text, 
                af_mcd_zsro text, 
                af_mcd_gest text, 
                af_mcd_nature text, 
                af_mcd_a_struc text, 
                af_mcd_rac text, 
                af_mcd_eta text, 
                af_mcd_enedis text,
                af_ec6_codeext text, 
                af_ec6_etude text, 
                af_ec6_struct text, 
                af_ec6_inv text, 
                af_ec6_visuel text, 
                af_ec6_vertica text, 
                af_ec6_flambe text, 
                af_ec6_voisin text, 
                af_ec6_pointe text, 
                af_ec6_secouss text, 
                af_ec6_percu text, 
                af_ec6_jaune text, 
                af_ec6_mobilis text, 
                af_ec6_ebp text, 
                af_ec6_ras text, 
                af_ec6_cable text, 
                af_ec6_eta text, 
                af_ec6_nat_tvx text, 
                af_ec6_environ text, 
                af_ec6_vois_el text, 
                af_ec6_strat text, 
                af_ec6_rehau text, 
                af_ec6_str_tvx text, 
                af_ec6_nature text, 
                af_owf_nature text, 
                af_ec6_dan_apr text, 
                af_ec6_com_etl text, 
                af_val_moe text, 
                af_com_moe text, 
                attachment text, 
                geom geometry(Point,2154),
                name_schema text,
                af_mcd_pt_comment text, 
                af_mcd_etiquet_gespot text, 
                af_mcd_etiquet_c3a text, 
                af_c3a_numero_c3a text, 
                af_c3a_travaux_appui text, 
                af_c7_travaux_appui text,
                af_ec6_prive text
            );
            ---ALTER TABLE a_appuift OWNER to postgres;
            ALTER TABLE {a_appuift} OWNER to adn_ing;
            GRANT INSERT, SELECT ON TABLE {a_appuift} TO adn_ing;
            GRANT ALL ON TABLE {a_appuift} TO postgres;
            GRANT ALL ON TABLE {a_appuift} TO adn_ing;
            CREATE INDEX a_aft_gidx_{a_appuift} ON {a_appuift}  USING btree (geom);"""
        self.function_execute_requete(req, '')

    # Function insertion dans table a_appuift avec Fiches
    def function_insert_a_appuift(self, schema, text_inf_insert, table_name):
        req = f"""INSERT INTO {schema}.{table_name}(
                af_mcd_etiquet,af_mcd_cable, af_mcd_zsro, af_mcd_gest, af_mcd_nature, af_mcd_a_struc, af_mcd_rac, 
                af_mcd_eta,af_mcd_enedis,
                af_ec6_codeext, af_ec6_etude, af_ec6_struct, af_ec6_inv, af_ec6_visuel,
                af_ec6_vertica, af_ec6_flambe, af_ec6_voisin, af_ec6_pointe,
                af_ec6_secouss, af_ec6_percu, af_ec6_jaune, af_ec6_mobilis,
                af_ec6_ebp, af_ec6_ras, af_ec6_cable, af_ec6_eta, af_ec6_nat_tvx,
                af_ec6_environ, af_ec6_vois_el, af_ec6_strat, af_ec6_rehau,
                af_ec6_str_tvx, af_ec6_nature, af_owf_nature, af_ec6_dan_apr, af_ec6_com_etl,
                af_val_moe, af_com_moe, attachment, geom, name_schema, 
                af_mcd_pt_comment, af_mcd_etiquet_gespot, af_mcd_etiquet_c3a, af_c3a_numero_c3a, af_c3a_travaux_appui, af_c7_travaux_appui, af_ec6_prive)
                    VALUES {text_inf_insert};"""
        self.function_execute_requete(req, '')

    # Function get value pour les fiches comac
    def function_getvalue(self, var_value, var_type_get):
        return_var_value = '-1'
        if var_type_get == '':
            return_var_value = var_value
        if var_type_get == 'NC':
            if var_value == '':
                return_var_value = 'NC'
            else:
                return_var_value = var_value
        if var_type_get == 'SO':
            if var_value == '':
                return_var_value = 'SO'
            else:
                return_var_value = var_value
        if var_type_get == 'ab_ras_bt':
            if var_value == '0':
                return_var_value = 'NON'
            elif var_value == '':
                return_var_value = 'SO'
            else:
                return_var_value = 'OUI'
        return return_var_value

    # Function pour recuperer les pt du MCD
    def function_get_ptech_mcd(self, schema):
        # return list_attribut_all_fiches
        req_pt = """SET search_path = """ + schema + """, public;
            select pt.pt_code, pt.pt_etiquet, pt.pt_nature, pt.pt_etat, pt.pt_a_struc, 
                pt.pt_typelog,pt.pt_typephy, pt_gest, 'ST_GeomFromText('||quote_literal(st_astext(nd.geom))||',2154)' as geom, 
                pt_comment
            from t_ptech pt
                join t_noeud nd on nd.nd_code=pt.pt_nd_code"""
        list_req_pt = self.function_execute_requete(req_pt, 'bab')
        return list_req_pt

    # Function pour recuperer les pt du MCD
    def function_get_ptech_cable_mcd(self, schema):
        # return list_attribut_all_fiches
        req_pt = """SET search_path = """ + schema + """, public;
            select 
                distinct pt.pt_code, 
                array_agg(distinct cb.cb_etiquet||'_'||cb_capafo||'FO') af_mcd_cable, 
                array_agg( distinct cb.cb_typelog) cb_typelog,
                --- array_agg(distinct right(left(cb.cb_etiquet, 10),4)) af_mcd_zsro,
                array_agg(distinct 
                    case 
                        when left(cb.cb_etiquet, 3) in ('CTR', 'CDI')
                            then right(left(cb.cb_etiquet, 10),4) 
                        when left(cb.cb_etiquet, 3) in ('CAB')
                            then left(cb.cb_etiquet,5) 
                    end
                    ) af_mcd_zsro,
                array_agg(distinct 
                    case 
                        when left(cb.cb_etiquet, 3) in ('CDA')
                            then 'OUI'
                        else 'NON'
                    end
                    ) af_mcd_rac,
                array_agg(distinct 
                    case 
                        when left(cb.cb_etiquet, 3) in ('CDI', 'CTR')
                            then 'OUI'
                        else 'NON'
                    end
                    ) af_mcd_cdi_ctr
            from t_ptech pt
                join t_noeud nd on nd.nd_code=pt.pt_nd_code
                join t_cableline cl on st_dwithin (nd.geom,cl.geom,0.1)
                join t_cable cb on cb.cb_code = cl.cl_cb_code
            group by pt.pt_code, pt.pt_etiquet, pt.pt_nature, pt.pt_etat, pt.pt_a_struc, pt.pt_typelog,pt.pt_typephy,
            pt_gest, nd.geom """
        list_req_pt = self.function_execute_requete(req_pt, 'bab')
        return list_req_pt

    # Function pour identifier les pt pour remplacement
    def function_remplace_pt(self, schema):
        requete_remplace = """SET search_path = """ + schema + """, public;
        drop table if exists "troncon_enedis";
        create table "troncon_enedis" as
        select
            tvf.*
        from troncon_lineaire."TRONCON_ENEDIS_07-26" as tvf
            join t_znro as zn on ST_DWithin(zn.geom,tvf.geom, 5);
        select 
            pt.pt_code, ene.id, 'PCOM'::text as type_ligne
        from t_ptech pt
            join t_noeud nd on nd.nd_code=pt.pt_nd_code
            join troncon_enedis ene on ST_DWithin(nd.geom,ene.geom, 5) 
        where type_ligne = 'AÃ©rien'
        order by pt_code"""
        list_requete_remplace_pt = self.function_execute_requete(requete_remplace, 'bab')
        return list_requete_remplace_pt

    # Function pour exporter les donnees des appuis a_appuibt
    def function_Export_appuis_hors_OK(self, schema, table_name, key, rename_table, path_folder):
        connection = self.connection
        # import qgis.core
        a_appuift_nok = """ drop table if exists """ + schema + """.a_appuift_export; select * into """ + schema + """.a_appuift_export from """ + schema + """.a_appuift"""  # where upper(af_eta_mcd) != 'OK'
        a_appuibt_nok = """ drop table if exists """ + schema + """.a_appuibt_export; select * into """ + schema + """.a_appuibt_export from """ + schema + """.a_appuibt"""  # where upper(ab_eta_mcd) != 'OK'

        self.function_execute_requete(a_appuift_nok, '')
        self.function_execute_requete(a_appuibt_nok, '')
        connection.commit()

        uri = QgsDataSourceUri()
        uri.setConnection(host, port, DB, user, MP)
        uri.setDataSource(schema, table_name, "geom", '', key)  # (schema, table_name, "geom")#Shape UTF-8 LATIN1
        layer = QgsVectorLayer(uri.uri(False), rename_table, "postgres")
        if layer.isValid():
            chem_rep_export = path_folder + '/' + layer.name() + ".shp"
            QgsVectorFileWriter.writeAsVectorFormat(layer, chem_rep_export, "UTF-8", layer.crs(), 'ESRI Shapefile')

    # Partie des fonctions pour les retours terrains
    # Function pour la creation de la table a_appuift_vt
    def function_creatTable_a_appuift_vt(self, schema):
        req = """set search_path TO """ + schema + """, public;
        DROP INDEX if exists a_aft_gidx_ft_vt;
        DROP TABLE IF EXISTS a_appuift_vt;
        CREATE TABLE a_appuift_vt
        (
            af_mcd_etiquet text, 
            af_mcd_cable text, 
            af_mcd_zsro text, 
            af_mcd_gest text, 
            af_mcd_nature text, 
            af_mcd_a_struc text, 
            af_mcd_rac text, 
            af_mcd_eta text, 
            af_mcd_enedis text,
            af_ec6_codeext text, 
            af_ec6_etude text, 
            af_ec6_struct text, 
            af_ec6_inv text, 
            af_ec6_visuel text, 
            af_ec6_vertica text, 
            af_ec6_flambe text, 
            af_ec6_voisin text, 
            af_ec6_pointe text, 
            af_ec6_secouss text, 
            af_ec6_percu text, 
            af_ec6_jaune text, 
            af_ec6_mobilis text, 
            af_ec6_ebp text, 
            af_ec6_ras text, 
            af_ec6_cable text, 
            af_ec6_eta text, 
            af_ec6_nat_tvx text, 
            af_ec6_environ text, 
            af_ec6_vois_el text, 
            af_ec6_strat text, 
            af_ec6_rehau text, 
            af_ec6_str_tvx text, 
            af_ec6_nature text, 
            af_owf_nature text, 
            af_ec6_dan_apr text, 
            af_ec6_com_etl text, 
            af_val_moe text, 
            af_com_moe text, 
            attachment text, 
            geom geometry(Point,2154)
        );
        ALTER TABLE a_appuift_vt
            OWNER to adn_ing;
        GRANT INSERT, SELECT ON TABLE a_appuift_vt TO adn_ing;
        GRANT ALL ON TABLE a_appuift_vt TO adn_ing;
        CREATE INDEX a_aft_gidx_ft_vt
            ON a_appuift_vt  USING btree (geom);"""
        self.function_execute_requete(req, '')

    # Function pour la creation de la table a_appuibt_vt
    def function_creatTable_a_appuibt_vt(self, schema):
        req = """set search_path TO """ + schema + """, public;
        DROP TABLE IF EXISTS a_appuibt_vt;
        CREATE TABLE a_appuibt_vt
        (
            ab_etiquet text,
            ab_a_struc text,
            ab_nature text,
            ab_eta_mcd text,
            ab_rac_mcd text,
            ab_codeext text,
            ab_etude text,
            ab_struct text,
            ab_type text,
            ab_annee text,
            ab_rac_bt text,
            ab_rac_tel text,
            ab_malt text,
            ab_iacm text,
            ab_ras_hta text,
            ab_ras_bt text,
            ab_ep text,
            ab_cb_bt text,
            ab_cb_cu text,
            ab_cb_fo text,
            ab_rac_reel text,
            ab_eta_com text,
            ab_dan_avt text,
            ab_com_com text,
            ab_visuel_com text,
            ab_codefiche text,
            ab_prive text,
            ab_surplomb text,
            ab_elagage text,
            ab_inv text,
            ab_hlibre text,
            ab_visuel text,
            ab_vertica text,
            ab_jaune text,
            ab_mobilis text,
            ab_gravur text,
            ab_ras_ft text,
            ab_orien text,
            ab_anc_bt text,
            ab_anc_ft text,
            ab_com_etl text,
            ab_nat_tvx text,
            ab_environ text,
            ab_val_moe text,
            ab_com_moe text,
            attachment text,
            geom geometry(Point,2154)
        );
        ALTER TABLE a_appuibt_vt
            OWNER to adn_ing;
        GRANT INSERT, SELECT ON TABLE a_appuibt_vt TO adn_ing;
        GRANT ALL ON TABLE a_appuibt_vt TO adn_ing;
        CREATE INDEX a_abt_vt_gidx
            ON a_appuibt_vt  USING btree (geom);"""
        self.function_execute_requete(req, '')

    # Function insertion dans table a_appuibt_vt
    def function_insert_a_appuibt_vt(self, schema, text_inf_insert):
        req_truncate = """Truncate table """ + schema + """.a_appuibt_vt CASCADE;"""
        req_insert = """INSERT INTO """ + schema + """.a_appuibt_vt(
            ab_etiquet, ab_a_struc, ab_nature, ab_eta_mcd, ab_rac_mcd, ab_codeext, 
            ab_etude, ab_struct, ab_type, ab_annee, ab_rac_bt, ab_rac_tel, 
            ab_malt, ab_iacm, ab_ras_hta, ab_ras_bt, ab_ep, ab_cb_bt, ab_cb_cu, 
            ab_cb_fo, ab_rac_reel, ab_eta_com, ab_dan_avt, ab_com_com, ab_visuel_com, 
            ab_codefiche, ab_prive, ab_surplomb, ab_elagage, ab_inv, ab_hlibre, 
            ab_visuel, ab_vertica, ab_jaune, ab_mobilis, ab_gravur, ab_ras_ft, 
            ab_orien, ab_anc_bt, ab_anc_ft, ab_com_etl, ab_nat_tvx, ab_environ, 
            ab_val_moe, ab_com_moe, attachment, geom)
                VALUES """ + text_inf_insert + """;"""  # , geom
        self.function_execute_requete(req_truncate, '')
        self.function_execute_requete(req_insert, '')

    # Update des attributs avec la valeuu NULL
    def function_update_values_Null(self, schema_etude):
        req_update = """select 
            'UPDATE '||t.table_schema||'.'||t.table_name||' set '||t.column_name||' = ''''  WHERE '||t.column_name||' =''NULL'';',t.column_name, t.table_name table_name,''
        from information_schema.columns as t
        WHERE t.table_schema = '""" + schema_etude + """' and t.table_name in ('a_appuibt_vt','a_appuift_vt') and t.column_name not in ('geom', 'af_ec6_str_tvx')"""

        list_filed_update_null = self.function_execute_requete(req_update, 'bab')
        for index_update, update in enumerate(list_filed_update_null):
            self.function_execute_requete(update[0], '')

    # Function pour la creation de la table a_appuibt_delta
    def function_creatTable_a_appuibt_delta(self, schema):
        req = """set search_path TO """ + schema + """, public;
        DROP TABLE IF EXISTS a_appuibt_delta;
        CREATE TABLE a_appuibt_delta
        (
            ab_mcd_etiquet text,
            ab_mcd_cable text,
            ab_mcd_zsro text,
            ab_mcd_gest text,
            ab_mcd_a_struc text,
            ab_mcd_nature text,
            ab_mcd_eta text,
            ab_mcd_rac text,
            ab_eco_codeext text,
            ab_eco_etude text,
            ab_eco_insee text,
            ab_eco_commune text,
            ab_eco_struct text,
            ab_eco_type text,
            ab_eco_annee text,
            ab_eco_x text,
            ab_eco_y text,
            ab_eco_rac_bt text,
            ab_eco_rac_tel text,
            ab_eco_malt text,
            ab_eco_iacm text,
            ab_eco_ras_hta text,
            ab_eco_ras_bt text,
            ab_eco_ep text,
            ab_eco_cb_bt text,
            ab_eco_cb_cu text,
            ab_eco_cb_fo text,
            ab_eco_rac_reel text,
            ab_eco_eta_com text,
            ab_eco_dan_avt text,
            ab_eco_com_com text,
            ab_eco_visuel_com text,
            ab_efi_codefiche text,
            ab_efi_prive text,
            ab_efi_surplomb text,
            ab_efi_elagage text,
            ab_efi_inv text,
            ab_efi_hlibre text,
            ab_efi_visuel text,
            ab_efi_vertica text,
            ab_efi_jaune text,
            ab_efi_mobilis text,
            ab_efi_gravur text,
            ab_efi_ras_ft text,
            ab_efi_orien text,
            ab_efi_anc_bt text,
            ab_efi_anc_ft text,
            ab_efi_com_etl text,
            ab_moe_nat_tvx text,
            ab_moe_environ text,
            ab_moe_val text,
            ab_moe_com text,
            name_schema text,
            ab_mcd_pt_comment text,
            attachment text,
            geom geometry(Point,2154)
        );
        ALTER TABLE a_appuibt_delta
            OWNER to adn_ing;
        GRANT INSERT, SELECT ON TABLE a_appuibt_delta TO adn_ing;
        GRANT ALL ON TABLE a_appuibt_delta TO adn_ing;
        CREATE INDEX a_a_appuibt_delta
            ON a_appuibt_delta  USING btree (geom);"""
        self.function_execute_requete(req, '')

    # Function pour la creation de la table a_appuift_delta
    def function_creatTable_a_appuift_delta(self, schema):
        req = """set search_path TO """ + schema + """, public;
        DROP TABLE IF EXISTS a_appuift_delta;
        CREATE TABLE a_appuift_delta
        (
            af_mcd_etiquet text, 
            af_mcd_cable text, 
            af_mcd_zsro text, 
            af_mcd_gest text, 
            af_mcd_nature text, 
            af_mcd_a_struc text, 
            af_mcd_rac text, 
            af_mcd_eta text, 
            af_mcd_enedis text,
            af_ec6_codeext text, 
            af_ec6_etude text, 
            af_ec6_struct text, 
            af_ec6_inv text, 
            af_ec6_visuel text, 
            af_ec6_vertica text, 
            af_ec6_flambe text, 
            af_ec6_voisin text, 
            af_ec6_pointe text, 
            af_ec6_secouss text, 
            af_ec6_percu text, 
            af_ec6_jaune text, 
            af_ec6_mobilis text, 
            af_ec6_ebp text, 
            af_ec6_ras text, 
            af_ec6_cable text, 
            af_ec6_eta text, 
            af_ec6_nat_tvx text, 
            af_ec6_environ text, 
            af_ec6_vois_el text, 
            af_ec6_strat text, 
            af_ec6_rehau text, 
            af_ec6_str_tvx text, 
            af_ec6_nature text, 
            af_owf_nature text, 
            af_ec6_dan_apr text, 
            af_ec6_com_etl text, 
            af_val_moe text, 
            af_com_moe text, 
            attachment text, 
            name_schema text,
            af_mcd_pt_comment text, 
            af_mcd_etiquet_gespot text, 
            af_mcd_etiquet_c3a text, 
            af_c3a_numero_c3a text, 
            af_c3a_travaux_appui text, 
            af_c7_travaux_appui text,
            af_ec6_prive text,
            geom geometry(Point,2154)
        );
        ALTER TABLE a_appuift_delta
            OWNER to adn_ing;
        GRANT INSERT, SELECT ON TABLE a_appuift_delta TO adn_ing;
        GRANT ALL ON TABLE a_appuift_delta TO adn_ing;
        CREATE INDEX a_a_appuift_delta
            ON a_appuift_delta  USING btree (geom);"""
        self.function_execute_requete(req, '')

    # Function insertion dans table a_appuibt_delta
    def function_insert_a_appuibt_delta(self, schema, text_inf_insert):
        req_truncate = """Truncate table """ + schema + """.a_appuibt_delta CASCADE;"""
        req_insert = """INSERT INTO """ + schema + """.a_appuibt_delta(
            ab_mcd_etiquet,ab_mcd_cable,ab_mcd_zsro,ab_mcd_gest,ab_mcd_a_struc,
            ab_mcd_nature,ab_mcd_eta,ab_mcd_rac,ab_eco_codeext,ab_eco_etude,
            ab_eco_insee,ab_eco_commune,ab_eco_struct,ab_eco_type,ab_eco_annee,
            ab_eco_x,ab_eco_y,ab_eco_rac_bt,ab_eco_rac_tel,ab_eco_malt,ab_eco_iacm,
            ab_eco_ras_hta,ab_eco_ras_bt,ab_eco_ep,ab_eco_cb_bt,ab_eco_cb_cu,
            ab_eco_cb_fo,ab_eco_rac_reel,ab_eco_eta_com,ab_eco_dan_avt,ab_eco_com_com,
            ab_eco_visuel_com,ab_efi_codefiche,ab_efi_prive,ab_efi_surplomb,ab_efi_elagage,
            ab_efi_inv,ab_efi_hlibre,ab_efi_visuel,ab_efi_vertica,ab_efi_jaune,ab_efi_mobilis,
            ab_efi_gravur,ab_efi_ras_ft,ab_efi_orien,ab_efi_anc_bt,ab_efi_anc_ft,ab_efi_com_etl,
            ab_moe_nat_tvx,ab_moe_environ,ab_moe_val,ab_moe_com, name_schema, ab_mcd_pt_comment, attachment, geom)
                VALUES """ + text_inf_insert + """;"""  # , geom
        # print(req_insert)
        self.function_execute_requete(req_truncate, '')
        self.function_execute_requete(req_insert, '')
    
    # Function insertion dans table a_appuift_delta
    def function_insert_a_appuift_delta(self, schema, text_inf_insert):
        req_truncate = """Truncate table """ + schema + """.a_appuift_delta CASCADE;"""
        req_insert = """INSERT INTO """ + schema + """.a_appuift_delta(
            af_mcd_etiquet,af_mcd_cable, af_mcd_zsro, af_mcd_gest, af_mcd_nature, af_mcd_a_struc, af_mcd_rac, 
            af_mcd_eta,af_mcd_enedis,
            af_ec6_codeext, af_ec6_etude, af_ec6_struct, af_ec6_inv, af_ec6_visuel,
            af_ec6_vertica, af_ec6_flambe, af_ec6_voisin, af_ec6_pointe,
            af_ec6_secouss, af_ec6_percu, af_ec6_jaune, af_ec6_mobilis,
            af_ec6_ebp, af_ec6_ras, af_ec6_cable, af_ec6_eta, af_ec6_nat_tvx,
            af_ec6_environ, af_ec6_vois_el, af_ec6_strat, af_ec6_rehau,
            af_ec6_str_tvx, af_ec6_nature, af_owf_nature, af_ec6_dan_apr, af_ec6_com_etl,
            af_val_moe, af_com_moe, attachment, name_schema, 
            af_mcd_pt_comment, af_mcd_etiquet_gespot, af_mcd_etiquet_c3a, af_c3a_numero_c3a, af_c3a_travaux_appui, 
            af_c7_travaux_appui, af_ec6_prive, geom)
                VALUES """ + text_inf_insert + """;"""  # , geom
        # print(req_insert)
        self.function_execute_requete(req_truncate, '')
        self.function_execute_requete(req_insert, '')

    # Funciton de creations des noms des groups
    def function_create_groupe_name(self, name_groupe):
        root = QgsProject.instance().layerTreeRoot()
        group = root.findGroup(name_groupe)
        root.removeChildNode(group)
        shapeGroup = root.addGroup(name_groupe)
        return shapeGroup

    # Function pour ajouter les tables dans leur groupe respectif
    def function_add_layer_group(self, layer_to_add, groupe_name):
        QgsProject.instance().addMapLayer(layer_to_add, False)
        groupe_name.insertChildNode(0, QgsLayerTreeLayer(layer_to_add))

    # Function Suppression du group ajoute dans QGis
    def functiondelete_layer_qgis(self, name_groupe):
        root = QgsProject.instance().layerTreeRoot()
        group = root.findGroup(name_groupe)
        if group is not None:
            root.removeChildNode(group)

    # Function recuperation des index columns editable
    def function_cond_value_ft(self, var_cellule, type_return):
        var_NC = 'NC'
        var_oui = 'OUI'
        var_non = 'NON'
        if type_return == 'cond_null_nc':
            if var_cellule:
                return var_cellule
            else:
                return var_NC

        elif type_return == 'cond_null_so':
            if var_cellule:
                return str(var_cellule).upper()
            else:
                return 'SO'

        elif type_return == 'cond_oui_non_nc':
            if str(var_cellule).upper() == var_oui:
                return var_oui
            elif str(var_cellule).upper() == var_non:
                return var_non
            else:
                return var_NC

        elif type_return == 'BMP_TER':
            if str(var_cellule).upper() in ('BMP', 'TER'):
                return str(var_cellule).upper()
            else:
                return var_NC

        elif type_return == 'af_ec6_inv':
            if str(var_cellule).upper() in (
            'INV', ' IN1', 'IN2', 'IN3', 'IN4', 'IN5', 'IN6', 'IN7', 'IN8', 'IN9', 'NON'):
                return str(var_cellule).upper()
            else:
                return var_NC

        elif type_return == 'af_ec6_strat':
            if str(var_cellule).upper() in ('TRM', 'TDL', 'TCR', 'SPC', 'SPB', 'ENF', 'PCH', 'PCG', 'PCP', 'NON'):
                return str(var_cellule).upper()
            else:
                return var_NC

        elif type_return == 'cond_non_so_nc':
            if str(var_cellule) == '0':
                return var_non
            elif not var_cellule:
                return 'SO'
            else:
                return var_oui

        elif type_return == 'ab_eco_rac_reel':
            if str(var_cellule).upper().replace(' ', '').find('-2F-'.upper()) != -1:
                return var_oui
            else:
                return var_non

        else:
            return '-2'

    # Function af_ec6_str_tvx
    def funtion_af_ec6_str_tvx(self, var_af_ec6_nat_tvx, var_af_ec6_str_tvx):
        var_NC = 'NC'
        if str(var_af_ec6_nat_tvx).upper() in ('REMPLACEMENT', 'RENFORCEMENT'):
            return str(var_af_ec6_str_tvx).upper()
        elif not var_af_ec6_nat_tvx:
            return var_NC
        else:
            return 'NULL'

    # Fonction pour calculer af_owf_nature
    def function_af_ofw_nature(self, af_ec6_environ, af_ec6_vois_el, af_ec6_inv, af_ec6_strat):
        if str(af_ec6_environ).upper() == 'BMP' and not str(af_ec6_vois_el).upper() not in ('NON', 'NC'):
            return 'PMET'
        elif str(af_ec6_environ).upper() == 'BMP' and str(af_ec6_vois_el).upper() not in ('NON', 'NC'):
            return 'PCOM'
        elif str(af_ec6_inv).upper() not in ('NON', 'NC') and str(af_ec6_strat).upper() not in ('NON', 'NC'):
            if str(af_ec6_environ).upper() == 'BMP' and not str(af_ec6_vois_el).upper() not in ('NON', 'NC'):
                return 'PMET'
            elif str(af_ec6_environ).upper() == 'BMP' and str(af_ec6_vois_el).upper() not in ('NON', 'NC'):
                return 'PCOM'
            else:
                return 'PBOI'
        else:
            return 'PBOI'

    # Fonction appuis mobilisable
    def function_appuis_mobilisable(self, ab_eco_visuel_com, ab_eco_eta_com):
        if str(ab_eco_visuel_com).upper() == 'BON ÉTAT' and str(ab_eco_eta_com).upper() == 'OK':
            return 'Utilisable'
        else:
            return 'Non utilisable'

    # Function pour creer la table l_appuift
    def function_create_table_l_appuift(self, fichier_appuis, schema_name):
        if fichier_appuis:
            try:
                wb = load_workbook(filename=fichier_appuis)
                sheets = wb.sheetnames
                ws = wb[sheets[-1]]
                sheet = ws
                col_count = sheet.max_column + 1
                column_names = {}
                for c in range(1, col_count):
                    heading = sheet.cell(row=1, column=c).value
                    column_names[c] = heading

                list_name_attribut = list(column_names.values())
                requete_set_drop = "set search_path to " + schema_name + ", public; DROP TABLE if exists l_appuift;"
                create_table = "CREATE TABLE l_appuift (" + ' text,'.join(list_name_attribut) + ' text' + ");"
                insert_table = "INSERT INTO l_appuift(" + ', '.join(list_name_attribut) + ") VALUES "

                list_insert = []
                for r, row_cells in enumerate(sheet.iter_rows(min_row=2), 2):
                    row = {}
                    for c in range(1, col_count):
                        cell_content = sheet.cell(row=r, column=c)
                        celle_value = str(cell_content.value).replace('None', '').upper()
                        row[column_names[c]] = celle_value
                    list_insert.append(str(tuple(row.values())))
            except:
                QMessageBox.warning(self.w, "Message Open File", 'Error Open File' + str(error))
        else:
            requete_finale = """set search_path to """ + schema_name + """, public; DROP TABLE if exists l_appuift;CREATE TABLE l_appuift (l_af_gespot text,l_af_carac text,l_af_capft text,l_af_description text,l_af_fn_gi text,l_af_fn_pi text,l_af_type text);INSERT INTO l_appuift(l_af_gespot, l_af_carac, l_af_capft, l_af_description, l_af_fn_gi, l_af_fn_pi, l_af_type) VALUES ('197', '', '197', 'BOIS SIMPLE TYPE EDF 190 DAN 7 M', '190', '190', 'PBOI'),('198', '', '198', 'BOIS SIMPLE TYPE EDF 190 DAN 8 M', '190', '190', 'PBOI'),('B36', '', 'B36', 'BOIS TRIPLE (2 JAMBES DE FORCES) 6 M', '600', '300', 'PBOI'),('B37', '', 'B37', 'BOIS TRIPLE (2 JAMBES DE FORCES) 7 M', '800', '400', 'PBOI'),('B38', '', 'B38', 'BOIS TRIPLE (2 JAMBES DE FORCES) 8 M', '900', '400', 'PBOI'),('B30', '', 'B30', 'BOIS TRIPLE (2 JAMBES DE FORCES) 10 M', '900', '400', 'PBOI'),('BC6', '', 'BC6', 'BOIS COUPLE SIMPLE 6 M', '270', '200', 'PBOI'),('BC7', '', 'BC7', 'BOIS COUPLE SIMPLE 7 M', '350', '260', 'PBOI'),('BC8', '', 'BC8', 'BOIS COUPLE SIMPLE 8 M', '350', '260', 'PBOI'),('BH0', 'HAU', 'BH0 S30', 'BOIS HAUBANÉ SIMPLE 30° 10 M', '375', '130', 'PBOI'),('BH2', 'HAU', 'BH2 S30', 'BOIS HAUBANÉ SIMPLE 30° 12 M', '375', '130', 'PBOI'),('BH6', 'HAU', 'BH6 D30', 'BOIS HAUBANÉ DOUBLE 30° 6 M', '750', '100', 'PBOI'),('BH7', 'HAU', 'BH7 D30', 'BOIS HAUBANÉ DOUBLE 30° 7 M', '750', '130', 'PBOI'),('BH8', 'HAU', 'BH8 D30', 'BOIS HAUBANÉ DOUBLE 30° 8 M', '750', '130', 'PBOI'),('BM6', '', 'BM6', 'BOIS MOISÉ (OU JUMELÉS) 6 M', '250', '200', 'PBOI'),('BM7', '', 'BM7', 'BOIS MOISÉ (OU JUMELÉS) 7 M', '325', '260', 'PBOI'),('BM8', '', 'BM8', 'BOIS MOISÉ (OU JUMELÉS) 8 M', '325', '260', 'PBOI'),('BP6', '', 'BP6', 'BOIS PORTIQUE (JUMELÉS ENTRETOISES) 6 M', '250', '200', 'PBOI'),('BP7', '', 'BP7', 'BOIS PORTIQUE (JUMELÉS ENTRETOISES) 7 M', '325', '260', 'PBOI'),('BP8', '', 'BP8', 'BOIS PORTIQUE (JUMELÉS ENTRETOISES) 8 M', '325', '260', 'PBOI'),('BR6', '', 'BR6', 'BOIS SIMPLE REHAUSSÉ 6 M', '100', '100', 'PBOI'),('BR7', '', 'BR7', 'BOIS SIMPLE REHAUSSÉ 7 M', '130', '130', 'PBOI'),('BR8', '', 'BR8', 'BOIS SIMPLE REHAUSSÉ 8 M', '130', '130', 'PBOI'),('BS0', '', 'BS0', 'BOIS SIMPLE 10 M', '160', '160', 'PBOI'),('BS2', '', 'BS2', 'BOIS SIMPLE 12 M', '160', '160', 'PBOI'),('BS6', '', 'BS6', 'BOIS SIMPLE 6 M', '100', '100', 'PBOI'),('BS7', '', 'BS7', 'BOIS SIMPLE 7 M', '130', '130', 'PBOI'),('BS8', '', 'BS8', 'BOIS SIMPLE 8 M', '130', '130', 'PBOI'),('CS7', '', 'CS7', 'BÉTON SIMPLE 7 M', '250', '', 'PBET'),('CS8', '', 'CS8', 'BÉTON SIMPLE 8 M', '250', '', 'PBET'),('EDF', '', 'EDF', 'POTEAU ÉLECTRIQUE RÉTROCÉDÉ', '', '', 'PIND'),('FR7', '', 'FR7', 'COMPOSITE RENFORCÉ R1 400 DAN 7 M', '400', '400', 'PCOM'),('FR8', '', 'FR8', 'COMPOSITE RENFORCÉ R1 400 DAN 8 M', '400', '400', 'PCOM'),('FS7', '', 'FS7', 'COMPOSITE SIMPLE 175 DAN 7 M', '175', '175', 'PCOM'),('FS8', '', 'FS8', 'COMPOSITE SIMPLE 175 DAN 8 M', '175', '175', 'PCOM'),('M36', '', 'M36', 'MÉTAL TRIPLE (2 JAMBES DE FORCES) 6 M', '900', '450', 'PMET'),('M37', '', 'M37', 'MÉTAL TRIPLE (2 JAMBES DE FORCES) 7 M', '900', '450', 'PMET'),('M38', '', 'M38', 'MÉTAL TRIPLE (2 JAMBES DE FORCES) 8 M', '900', '450', 'PMET'),('M47', '', 'M47', 'MÉTAL RENFORCÉ R1 400 DAN (2019) 7 M', '400', '400', 'PMET'),('M48', '', 'M48', 'MÉTAL RENFORCÉ R1 400 DAN (2019) 8 M', '400', '400', 'PMET'),('MC6', 'ANC', 'MC6 ANC MAX', 'MÉTAL COUPLE ANCRÉ OUVERTURE MAX 6 M', '1500', '750', 'PMET'),('MC7', 'ANC', 'MC7 ANC MAX', 'MÉTAL COUPLE ANCRÉ OUVERTURE MAX 7 M', '1500', '750', 'PMET'),('MC8', 'ANC', 'MC8 ANC MAX', 'MÉTAL COUPLE ANCRÉ OUVERTURE MAX 8 M', '1500', '750', 'PMET'),('MF7', '', 'MF7', 'MÉTAL RENFORCÉ R1 300 DAN 7 M', '300', '300', 'PMET'),('MF8', '', 'MF8', 'MÉTAL RENFORCÉ R1 300 DAN 8 M', '300', '300', 'PMET'),('MH6', 'HAU', 'MH6 D30', 'MÉTAL HAUBANÉ DOUBLE 30° 6 M', '375', '140', 'PMET'),('MH7', 'HAU', 'MH7 D30', 'MÉTAL HAUBANÉ DOUBLE 30° 7 M', '375', '175', 'PMET'),('MH8', 'HAU', 'MH8 D30', 'MÉTAL HAUBANÉ DOUBLE 30° 8 M', '375', '175', 'PMET'),('MI6', '', 'MI6', 'MÉTAL SIMPLE LIGNE 140 DAN 6 M', '140', '140', 'PMET'),('MI7', '', 'MI7', 'MÉTAL SIMPLE LIGNE 175 DAN 7 M', '175', '175', 'PMET'),('MI8', '', 'MI8', 'MÉTAL SIMPLE LIGNE 175 DAN 8 M', '175', '175', 'PMET'),('ML6', '', 'ML6', 'MÂT LORRAIN SIMPLE 90 DAN 6 M', '90', '90', 'PIND'),('ML7', '', 'ML7', 'MÂT LORRAIN SIMPLE 90 DAN 7 M', '90', '90', 'PIND'),('ML8', '', 'ML8', 'MÂT LORRAIN SIMPLE 90 DAN 8 M', '90', '90', 'PIND'),('MM6', '', 'MM6', 'MÉTAL MOISÉ OU MÂT LORRAIN MOISÉ 6 M', '140', '140', 'PMET'),('MM7', '', 'MM7', 'MÉTAL MOISÉ OU MÂT LORRAIN MOISÉ 7 M', '175', '175', 'PMET'),('MM8', '', 'MM8', 'MÉTAL MOISÉ OU MÂT LORRAIN MOISÉ 8 M', '175', '175', 'PMET'),('MR6', '', 'MR6', 'MÉTAL SIMPLE REHAUSSÉ 6 M', '140', '140', 'PMET'),('MR7', '', 'MR7', 'MÉTAL SIMPLE REHAUSSÉ 7 M', '175', '175', 'PMET'),('MR8', '', 'MR8', 'MÉTAL SIMPLE REHAUSSÉ 8 M', '175', '175', 'PMET'),('MS6', '', 'MS6', 'MÉTAL SIMPLE 140 DAN 6 M', '140', '140', 'PMET'),('MS7', '', 'MS7', 'MÉTAL SIMPLE 175 DAN 7 M', '175', '175', 'PMET'),('MS8', '', 'MS8', 'MÉTAL SIMPLE 175 DAN 8 M', '175', '175', 'PMET'),('MT6', '', 'MT6', 'MÉTAL SIMPLE TIRAGE 220 DAN 6 M', '220', '220', 'PMET'),('MT7', '', 'MT7', 'MÉTAL SIMPLE TIRAGE 250 DAN 7 M', '250', '250', 'PMET'),('MT8', '', 'MT8', 'MÉTAL SIMPLE TIRAGE 330 DAN 8 M', '330', '330', 'PMET'),('MX6', '', 'MX6', 'MÉTAL SIMPLE X 90 DAN 6 M', '90', '90', 'PMET'),('MX7', '', 'MX7', 'MÉTAL SIMPLE X 90 DAN 7 M', '90', '90', 'PMET'),('MX8', '', 'MX8', 'MÉTAL SIMPLE X 90 DAN 8 M', '90', '90', 'PMET'),('ORT', '', 'ORT', 'POTEAU OPÉRATEUR RÉSEAU TIERS', '', '', 'PIND'),('POT', '', 'POT', 'POTELET MÂT LORRAIN SUR MUR OU FAÇADE', '', '', 'POTL'),('XC6', 'ANC', 'XC6 ANC MAX', 'MÉTAL COUPLE X ANCRÉ OUVERTURE MAX 6 M', '1500', '750', 'PMET'),('XC7', 'ANC', 'XC7 ANC MAX', 'MÉTAL COUPLE X ANCRÉ OUVERTURE MAX 7 M', '1500', '750', 'PMET'),('XC8', 'ANC', 'XC8 ANC MAX', 'MÉTAL COUPLE X ANCRÉ OUVERTURE MAX 8 M', '1500', '750', 'PMET')"""
            self.function_execute_requete(requete_finale, '')
            return requete_finale
            # QMessageBox.warning(self.w, "Message Open File", 'No File Selected' + str(error))

    # Function GetDictList
    def function_getdict_list(self, var_data_dict):
        cmp_af_eta_cap = 0
        dict_name_af_eta_cap = {}
        liste_unique_color = []
        # print(var_data_dict)
        for index_dict in range(0, len(var_data_dict)):
            # Duplication code fiche pour cables multiples pour concatener
            var_cmp_af_eta_cap_key = ''.join(list(var_data_dict[index_dict].keys()))  # [var_num_appui_index]
            var_cmp_af_eta_cap_value = ''.join(list(var_data_dict[index_dict].values()))  # [var_valuecol_index]
            if var_cmp_af_eta_cap_key != '':
                var_value = str(var_cmp_af_eta_cap_value)
                # print('dict', ';', var_value, ';', var_cmp_af_eta_cap_key)
                # if var_value in ('(247, 150, 70)', '(250, 170, 70)'):  # orange
                #     var_cmp_af_eta_cap_value = 'OK'
                # elif var_value == '(146, 208, 80)':  # vert
                #     var_cmp_af_eta_cap_value = 'OK'
                # else:
                #     var_cmp_af_eta_cap_value = 'INSUFFISANT'
                dict_name_af_eta_cap[str(var_cmp_af_eta_cap_key)] = [var_cmp_af_eta_cap_value]
                # print(var_cmp_af_eta_cap_key, ';', var_cmp_af_eta_cap_value)

            # if var_cmp_af_eta_cap_key != '':
            #     cmp_af_eta_cap = var_cmp_af_eta_cap_key
            #     dict_name_af_eta_cap[str(var_cmp_af_eta_cap_key)] = [var_cmp_af_eta_cap_value]
            # else:
            #     var_cmp_af_eta_cap_key = cmp_af_eta_cap
            #     dict_name_af_eta_cap[str(var_cmp_af_eta_cap_key)].append(var_cmp_af_eta_cap_value)
        # list_uniq_val = []
        # for val in dict_name_af_eta_cap.values():
        #     while 'None' in val:
        #         val.remove('None')
        # for val in dict_name_af_eta_cap.values():
        #     # val = list(dict.fromkeys(val))
        #     for index in range(0, len(val)):
        #         # (247, 150, 70) == orange; (146, 208, 80) == vert; (250, 170, 70) == rouge
        #         var_value = str(val[index])
        #         if var_value in ('(247, 150, 70)', '(250, 170, 70)'):# orange
        #             val[index] = 'OK'
        #         elif var_value == '(146, 208, 80)':# vert
        #             val[index] = 'OK'
        #         else:
        #             val[index] = 'INSUFFISANT'
        # print(val[index])
        # print(dict_name_af_eta_cap)
        return dict_name_af_eta_cap

    # Function Delta
    def function_deltat_vt_check(self, var_list_export_a_appui_bt, var_list_vt_a_appui_bt, var_table_name,
                                  var_schema, list_index_vt):
        list_export_a_appui_bt = var_list_export_a_appui_bt
        list_vt_a_appui_bt = var_list_vt_a_appui_bt
        bar_progress = self.progress_bar('Execution Delta export/VT')
        repl_rec = None
        diff_vt = 'NC_VT'
        for index_export in range(0, len(list_export_a_appui_bt)):
            list_val_export = tuple([repl_rec if str(sub).replace(' ', '') == '' else sub for sub in list_export_a_appui_bt[index_export]])
            list_val_export_vt_diff = ''
            dict_index_change_terrain = {}
            for index_vt in range(0, len(list_vt_a_appui_bt)):
                val_vt = tuple([repl_rec if sub == '' else sub for sub in list_vt_a_appui_bt[index_vt]])
                if list_val_export[0] == val_vt[0] and list_val_export != val_vt and len(val_vt) == len(list_val_export):  # and index_export == index_vt and list_val_export != val_vt
                    for index_exp in range(0, len(list_val_export)):
                        val_detail_ex = list_val_export[index_exp]
                        val_detail_vt = val_vt[index_exp]
                        if str(val_detail_ex).lower().replace(' ', '') != str(val_detail_vt).lower().replace(' ', '') and index_exp != len(list_val_export) - 1:  # Ignorer Geometrie et Nom schema
                            list_val_export_vt_diff = list(val_vt)
                            if list_val_export[0] in dict_index_change_terrain:
                                dict_index_change_terrain[list_val_export[0]].append(index_exp)
                            else:
                                dict_index_change_terrain[list_val_export[0]] = [index_exp]
            if list_val_export_vt_diff != '':
                list_index_change_terrain = set(list(dict_index_change_terrain.values())[0])
                for index_change_vt in list_index_change_terrain:
                    if index_change_vt in list_index_vt:
                        list_val_export_vt_diff[index_change_vt] = f"{diff_vt}"
                list_val_export_vt_diff[-1] = f"ST_SetSRID('{list_val_export_vt_diff[-1]}'::geometry,2154)"
                list_export_a_appui_bt[index_export] = list_val_export_vt_diff
            self.progress_processing(index_export, len(list_export_a_appui_bt), bar_progress)
            if bar_progress.wasCanceled():
                iface.messageBar().pushMessage('Info', 'Action Cancelled', level=Qgis.Info)
                break
        text_insert_deltat = ','.join(
            [str(tuple([NULL if sub == repl_rec else sub for sub in i])).replace('"', '') for i in list_export_a_appui_bt])
        if var_table_name == 'a_appuibt':
            self.function_creatTable_a_appuibt_delta(var_schema)
            self.function_insert_a_appuibt_delta(var_schema, text_insert_deltat)
        elif var_table_name == 'a_appuift':
            self.function_creatTable_a_appuift_delta(var_schema)  # Creation Table a_appuift
            self.function_insert_a_appuift_delta(var_schema, text_insert_deltat)

    # Function pour exporter les tables deltas de BT et FT
    def function_Export_appuis_delta(self, schema, table_name, key, rename_table, path_folder):
        # import qgis.core
        uri = QgsDataSourceUri()
        uri.setConnection(host, port, DB, user, MP)
        uri.setDataSource(schema, table_name, "geom", '', key)  # (schema, table_name, "geom")#Shape
        layer = QgsVectorLayer(uri.uri(False), rename_table, "postgres")
        if layer.isValid():
            chem_rep_export = path_folder + '/' + layer.name() + ".shp"
            QgsVectorFileWriter.writeAsVectorFormat(layer, chem_rep_export, "LATIN1", layer.crs(), 'ESRI Shapefile')

    # Function pour ajouter des feuilles dans EXCEl
    def function_create_sheet(self, wb, sheet_name, list_user_export, Header):
        # Execution de la bar
        bar_progress = self.progress_bar('Export des erreurs de Controls')
        ws_workbook = wb.add_sheet(sheet_name, cell_overwrite_ok=True)
        # print('Workbook', ';', ws_workbook)
        if list_user_export:
            for index_liste, k in enumerate(list_user_export):
                for colx, value in enumerate(k):
                    ws_workbook.write(index_liste + 1, colx, str(value))
                self.progress_processing(index_liste, len(list_user_export), bar_progress)
                if bar_progress.wasCanceled():
                    iface.messageBar().pushMessage('Info', 'Action Cancelled', level=Qgis.Info)
                    break
        colIdx = 0  # Start from Column 0
        font_style = xlwt.XFStyle()
        font_style.font.bold = True
        for indData in Header:
            col = ws_workbook.col(colIdx)
            col.width = 256 * 20
            ws_workbook.write(0, colIdx, indData, font_style)  # Insert in First Row ( Row 0)
            colIdx = colIdx + 1

    # Function pour exporter les fichiers de mauavis format
    def function_export_error_fichier(self, var_list_erreur, var_folder_export_error_fichier, var_type, var_name_file):
        if var_list_erreur:
            xlsfile_res = var_folder_export_error_fichier + "/" + var_name_file + str(var_type) + ".xls"
            wb = xlwt.Workbook(encoding="UTF-8")
            for index_erreur in range(0, len(var_list_erreur)):
                var_val = [[i] for i in var_list_erreur[index_erreur][0][2]] + [[var_list_erreur[index_erreur][0][1]]]
                name_sheet = str(var_list_erreur[index_erreur][0][0]).replace(' ', '').replace('_', '').replace('-',
                                                                                                                '')[:31]
                # print('Sheet', ';', name_sheet)
                self.function_create_sheet(wb, name_sheet, var_val, ['Colonne'])
            wb.save(xlsfile_res)

    # Function pour exporter les informations des fiches
    def function_export_infos_fiches(self, var_list_erreur, var_folder_export_error_fichier, var_type, column):
        if var_list_erreur:
            xlsfile_res = var_folder_export_error_fichier + "/" + 'Informations_Fiches_' + str(var_type) + ".xls"
            wb = xlwt.Workbook(encoding="UTF-8")
            name_sheet = var_type
            self.function_create_sheet(wb, name_sheet, var_list_erreur, column)
            wb.save(xlsfile_res)

    # function pour creer le fichier de la trame audit
    def function_creation_trame_audi(self, Fichier_appuis):
        if Fichier_appuis:
            name_file = str(os.path.splitext(os.path.basename(Fichier_appuis))[0]).replace("'", '').upper()
            data_dict = []
            var_list_erreur_model = []
            try:
                wb = load_workbook(filename=Fichier_appuis)
                sheets = wb.sheetnames
                ws = wb[sheets[0]]
                sheet = ws
                col_count = sheet.max_column + 1
                row_count = sheet.max_row
                column_names = {}
                for c in range(1, col_count):
                    heading = sheet.cell(row=1, column=c).value
                    column_names[c] = heading
                # print(list(column_names.values()))
                for row in ws.iter_rows(min_row=2, max_row=4):
                    row_dict = {}
                    for cell in row:
                        # print(f"col {cell.col_idx}：{cell.value}")
                        row_dict[column_names[cell.col_idx]] = str(cell.value).replace('None', '')
                    data_dict.append(row_dict)
            except:
                var_list_erreur_model.append(
                    ['Error_Open_' + name_file, ['Erreur douverture du fichier donc pas de tratitement sur ce fichier'],
                     [Fichier_appuis]])

            list_data_dict_export = []
            for index in range(0, len(data_dict)):
                values_name_column = data_dict[index].values()
                list_values_column = list(values_name_column)
                list_data_dict_export.append(list_values_column)
            print(len(list_data_dict_export[0]))
            return list_data_dict_export
        else:
            list_trame_model = [['\nRenseigner la\nRéférence de ZSRO', "\nRenseigner la\nRéférence de l'étude\nCAPFT",
                                 '\nRenseigner le\nType détude\n\nORANGE, pour ORANGE',
                                 "\nRenseigner le\nNuméro d'appui\n\nCohérence de nommage:\nFT_[N°GESPOT], calculé\nERDFYXXX, appui ERDF non calculé au global",
                                 "\nRenseigner le\nRésultat du contrôle visuel\nréalisé par l'entreprise\n\nOUI, Bon état\nNON, Mauvais état\n",
                                 "\nRenseigner le\nRésultat de l'étude\nréalisée par l'entreprise\n\nOK, Bon état\nINSUFFISANT, Insuffisant\n",
                                 '\nRenseigner\nEnvironnement\n\n\nTER, Pleine Terre\nBMP, Béton Macadam Pavé\n',
                                 '\nRenseigner si\nAbsence Etiquette Jaune\n\n\nOUI,\nNON',
                                 '\nRenseigner si\nAppui stratégique\n\n\nTRM, TDL , …\nNON\n',
                                 '\nRenseigner si\nAppui inaccessible\n\n\nINV, IN1, …\nNON',
                                 "\nRenseigner la\nNature des travaux\nproposé par l'entreprise\n\nRECALAGE,\nRENFORCEMENT,\nREMPLACEMENT",
                                 "\nRenseigner l'\nInstallation de réhausse\nproposé par l'entreprise\n\nOUI,\nNON",
                                 "\nRenseigner la\nNature de l'appui\nproposé par l'entreprise\n\nPBOI, Poteau Bois\nPMET, Poteau Métal\nPCOM, Poteau Composite",
                                 "\nRenseigner la\nNature de l'appui\npreconisé par OWF\n\nPBOI, Poteau Bois\nPMET, Poteau Métal\nPCOM, Poteau Composite",
                                 "\nRenseigner le\nRésultat de l'étude\nréalisé par l'entreprise\n\nOK, Bon état\nME, Mauvais état\nHS, Insuffisant",
                                 "\nIndiquer\nsi l'appui est\nmobilisable en l'etat\nsuite à l'étude\nréalisé par l'entreprise\n\nOK . OK > OK\nME + (TRAVAUX) > KO\nHS . (TRAVAUX)  > KO",
                                 "\nRenseigner le\nType de fibre à poser\nsur l'appui",
                                 "\nIndiquer\nla coherence entre le\nMCD et l'etude CAPFT\n(Cable)\n\n\n\n(Majeur, si erreur dans CAPFT)",
                                 'vide1',
                                 "\nIndiquer\nsi coherence des caracteristiques d'appui\nentre la Fiche d'Appui, l'etude CAPFT et les Photos\n\n\n(Majeur, si erreur dans CAPFT)",
                                 "\nIndiquer\nla cohérence du\n contrôle visuel entre  les photos, la fiche d'Appui, l'etude COMAC\n\n\n(Majeur, si erreur dans CAPFT)",
                                 "\nIndiquer\nsi presence des \nphotos de l'appui \ndans la fiche d'Appui\n\n(Mineur, si pas de travaux sur l'appui)\n(Majeur, si fiche à fournir avant travaux)",
                                 "\nIndiquer\nsi coherence des\néquipements Existants entre la Fiche d'Appui, l'etude CAPFT et les Photos\n\n(Majeur, si  équipement\nà poser)",
                                 "\nIndiquer\nComplétude de la \nfiche d'Appui\n\n\n(Mineur, si environnement, adresse et pas de travaux)\n\n(Majeur, si etat de l'appui ou equipement à poser)",
                                 "\nSynthèse\nde la cohérence de la\nfiche d'Appui \navec l'étude CAPFT\n\n(Mineur, si abscence de fiche d'appui)\n(Majeur, si  équipement\nà poser, ou travaux)",
                                 "\nIndiquer\nla cohérence de la \nnature cable existant\nentre la fiche d'Appui, l'etude CAPFT\n\n\n(Majeur, si erreur dans CAPFT)",
                                 "\nIndiquer\nla cohérence du\nnombre de cable existant\nentre la fiche d'Appui, l'etude CAPFT\n\n\n(Majeur, si erreur dans CAPFT)",
                                 "\nIndiquer\nla cohérence de\nl'orientation de la ligne\nentre le SIG, les photos\net l'etude CAPFT\n(angles >20g, longueur)\n\n(Majeur, si erreur dans CAPFT)",
                                 "\nIndiquer\nla cohérence de\nl'orientation de l'appui\nentre les photos\net l'etude CAPFT\n\n\n(Majeur, si erreur dans CAPFT)",
                                 '\nSynthèse\nde la cohérence de la\ndescription de la ligne dans CAPFT\n(Existant et Projeté)\n\n\n(Majeur, si erreur dans CAPFT)',
                                 "\nIndiquer\nla cohérence des\nhauteurs d'ancrage\ndans l'etude CAPFT\n(Haute, Standard, Basse)\n\n(Mineur,  sur existant)\n(Majeur, sur fibre à poser)",
                                 "\nIndiquer\nla cohérence de\nla pose de rehausse\ndans l'etude CAPFT\n\n\n(Mineur, si 15cm de libre en tete d'appui, pas de réhausse)",
                                 '\nIndiquer\nsi le choix des travaux à réaliser\nest cohérent', 'vide2',
                                 "\nIndiquer\nsi l'appui est susceptible d'être utilisé\n\nOK, si mobilisable\n\nKO, si non mobilisable",
                                 "faire la synthèse de l'étude en indiquant: \nétude à revoir\nvalidée en état\nétude raccordement\nétude CFI",
                                 'indiquer que les réserves majeures1', 'indiquer que les réserves majeures2',
                                 'indiquer que les réserves majeures3', 'indiquer que les réserves majeures4'],
                                ['', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '',
                                 'ETUDE AERIENNE - incoherence MCD : majeur',
                                 'ETUDE AERIENNE - Défaut version : majeur', 'APPUI - Incoherence description : majeur',
                                 'APPUI - Incoherence controle visuel : mineur', 'APPUI -  Defaut photos : majeur',
                                 'APPUI - Defaut presence/absence RAS : mineur\nAPPUI - Defaut presence/absence BOITIER : mineur',
                                 'APPUI - Defaut remplissage ; mineur\nAPPUI - Proximite reseau electrique : majeur\nAPPUI - Defaut presence/absence BOITIER à poser : mineur\nAPPUI - Defaut respect hauteur de ligne : mineur',
                                 '', 'CABLES - Defaut nature : majeur (influence négative sur le calcul)',
                                 'CABLES - Defaut nombre : majeur (influence négative sur le calcul)',
                                 'ETUDE AERIENNE - Defaut orientation de la ligne : majeur',
                                 "APPUI - Defaut orientation de l'appui : majeur", '',
                                 'CABLES - Incoherence ecart des lignes existantes : mineur\nCABLES - Incoherence ecart des lignes à poser : majeur',
                                 'APPUI - Defaut réhausse :mineur', 'majeur', '', '',
                                 'étude à revoir\nétude raccordement\nétude CFI\nvalidée en état', '', '', '', ''],
                                ['af_mcd_zsro (cf. plugin)', 'af_ec6_etude (cf. plugin)', 'af_mcd_gest (cf. plugin)',
                                 'af_mcd_etiquet (cf. plugin)', 'af_ec6_mobilis (cf. plugin)',
                                 'af_ec6_eta (cf. plugin)', 'af_ec6_environ (cf. plugin)', 'af_ec6_jaune (cf. plugin)',
                                 'af_ec6_strat (cf. plugin)', 'af_ec6_inv (cf. plugin)', 'af_ec6_nat_tvx (cf. plugin)',
                                 'af_ec6_rehau (cf. plugin)', 'af_ec6_nature (cf. plugin)',
                                 'af_owf_nature (cf. plugin)', 'af_mcd_eta (cf. plugin)', 'fx( af_visuel & af_eta_mcd)',
                                 'af_mcd_cable (cf. plugin)', '', '', '', '', '', '', '', '', '', '', '', '', '', '',
                                 '', '', '', '', '', '', '', '', ''],
                                ['Référence de ZSRO\n(zs_refpm)', "Référence de l'étude\n(EFT_xxx_xxx.xls)",
                                 "Type de l'étude\n(Orange)", 'Point technique\n(pt_etiquet)',
                                 'Appui Utilisable\n(cf. Annexe C6)', "Résultat de l'étude\n(cf. Annexe C6)",
                                 "Environnement de l'appui\n(cf. Annexe C6)",
                                 'Absence Etiquette Jaune\n(cf. Annexe C6)', 'Appui stratégique\n(cf. Annexe C6)',
                                 'Appui Inaccessible\n(cf. Annexe C6)', 'Nature des travaux\n(cf. Annexe C6)',
                                 'Pose de réhausse\n(cf. Annexe C6)', "Nature de l'appui\n(cf. Annexe C6)",
                                 "Nature de l'appui \n( calculé )", "\nRésultat de l'étude\n(cf. MCD)",
                                 '\nAppui Mobilisable\nfx( E & F)', '\nType de fibre\n(cb_capa_fo)',
                                 '\nCohérence\nSIG\n(Oui/Majeur)', 'Cohérence version CAPFT',
                                 "\nCohérence\nDescription de l'appui\n(Oui/Majeur)",
                                 '\nCohérence\nContrôle Visuel\n(Oui/Mineur)', '\nCohérence\nPhotos\n(Oui/Majeur)',
                                 '\nCohérence\nEquipements Existants\n(Oui/Mineur/Majeur)',
                                 "\nRemplissage de la\nFiche d'Appui\n(Oui/Mineur/Majeur)",
                                 "\nCohérence\nFiche d'Appui\n(Oui/Mineur/Majeur)",
                                 '\nCohérence\nNature du cable\n(Oui/Majeur)',
                                 '\nCohérence\nNombre de cable\n(Oui/Majeur)',
                                 '\nCohérence\nOrientation de la ligne\n(Oui/Majeur)',
                                 "\nCohérence\nOrientation de l'appui\n(Oui/Majeur)",
                                 '\nCohérence\nDescription de la ligne \n(Oui/Mineur/Majeur)',
                                 'Cohérence\nécart des lignes\n(Oui/Mineur/Majeur)',
                                 '\nCohérence\nPose de réhausse\n(Oui/Mineur)', 'travaux à réaliser',
                                 'Contre Relevé terrain', "reste une possibilité de mobiliser l'appui",
                                 "Synthèse de l'étude DEO", 'Commentaires DEO', 'Commentaires DEO', 'Commentaires DEO',
                                 'Commentaires DEO']]
            for index in range(0, len(list_trame_model)):
                print(len(list_trame_model[index]), ';', list_trame_model[index])
            return list_trame_model
    
    # function creation des dictionnaires
    @staticmethod
    def function_create_dict(var_dict, var_val_key, var_val_value):
        if var_val_key not in var_dict:
            var_dict[var_val_key] = [var_val_value]
        else:
            var_dict[var_val_key].append(var_val_value)


# Class Traitement DPI
class TraitementDpi:
    # Constructeur des variables qui change
    def __init__(self, var_schema, var_path_folder_comac, var_connection, var_path_folder_ft, var_path_export, 
        var_path_folder_c3a, var_path_folder_c7, var_choix_c3a_c7):
        self.schema = var_schema
        self.path_folder_comac = var_path_folder_comac
        self.path_folder_ft = var_path_folder_ft
        self.path_folder_c3a = var_path_folder_c3a
        self.path_folder_c7 = var_path_folder_c7
        self.choix_c3a_c7 = var_choix_c3a_c7
        self.path_export = var_path_export
        self.connection = var_connection
        self.generalfunctions = GeneralFunctions(self.connection)
        self.error_open = 'Error_Open_'
        self.var_incoherence_nom_entete = 'Incoherence Nom Entete'
        self.var_incoherence_long_entete = 'Incoherence Longueur Entete'
        self.var_name_sheet_c3a = 'Commandes Fermes'
        self.var_name_sheet_c7 = 'Commande'
        self.cursor_bd = self.connection.cursor()

    # function pour recuperer les info de la fiche comac
    def function_recperation_info_fiches_appuis_Comac_old(self, Fichier_appuis):
        ab_codeext = '-1'
        ab_etude = os.path.basename(Fichier_appuis).replace("'", '').replace('"', '')
        ab_struct = '-1'
        ab_type = '-1'
        ab_annee = '-1'
        ab_rac_bt = '-1'
        ab_rac_tel = '-1'
        ab_malt = '-1'
        ab_iacm = '-1'
        ab_ras_hta = '-1'
        ab_ras_bt = '-1'
        ab_ep = '-1'
        ab_cb_bt = '-1'
        ab_cb_cu = '-1'
        ab_cb_fo = '-1'
        ab_rac_reel = '-1'
        ab_eta_com = '-1'
        ab_dan_avt = '-1'
        ab_com_com = '-1'
        ab_visuel_com = '-1'
        if Fichier_appuis:
            workbook = xlrd.open_workbook(Fichier_appuis, on_demand=True)
            worksheet = workbook.sheet_by_index(0)
            var_entet_ref = ['NUMÉRO', 'N°                 DANS             LÉTUDE', 'TENSION ÉLEC.', 'TYPE DE POTEAU',
                             'HAUTEUR TOTALE', 'SURIMPLANTATION', 'HAUTEUR HORS SOL', 'CLASSE',
                             'EFFORT                       (KN)', 'ANNÉE', 'COORDONNÉE "X"', 'COORDONNÉE "Y"',
                             'COORDONNÉE "Z"', 'CONDUCTEUR', 'ANGLE DE PIQUETAGE DE LA LIGNE',
                             'ANGLE ORIENTATION  DU SUPPORT', 'BRANCHT  ELEC AÉRIEN', 'BRCHT\nTEL/FIBRE',
                             'DESCENTE DE TERRE', 'H61', 'IAT', 'IACM', 'RAS HTA SIMPLE', 'RAS HTA DOUBLE', 'RAS BT',
                             'PRÉSENCE ÉCLAIRAGE PUBLIC', 'TYPE DE LIGNE -RÉSEAU                  -EN NAPPE',
                             'NB TRAVERSES EXISTANTES', 'NB TRAVERSES À POSER', 'BOÎTIER  ',
                             'PRÉSENCE DE RACCORDEMENTS', 'DESCENTE DE TERRE', 'COMMENTAIRES',
                             'TYPE DE LIGNE -RÉSEAU                  -EN NAPPE', 'NB TRAVERSES EXISTANTES',
                             'NB TRAVERSES À POSER', 'BOÎTIER  ', 'PRÉSENCE DE RACCORDEMENTS', 'DESCENTE DE TERRE',
                             'COMMENTAIRES', 'TYPE DE LIGNE -RÉSEAU                  -EN NAPPE',
                             'NB TRAVERSES EXISTANTES', 'NB TRAVERSES À POSER', 'BOÎTIER  ',
                             'PRÉSENCE DE RACCORDEMENTS', 'COMMENTAIRES', '', 'CONCLUSION',
                             'TAUX                  DUTILISATION EN %', 'PINCE FUSIBLE', 'COMMENTAIRES',
                             'ETAT APPARENT', 'COMMENTAIRES', 'PHOTOS', 'PHOTOS', 'PHOTOS', 'PHOTOS', 'PHOTOS',
                             'AUTORISATION UTILISATION DU POTEAU', 'OBSERVATIONS']
            # list_fa_comac = range(2, worksheet.nrows)
            # data = []
            data_finale = []
            first_row = []  # Header
            var_list_erreur_model = []
            for col in range(worksheet.ncols):
                first_row.append(str(worksheet.cell_value(2, col)).replace('.0', '').upper().replace("'", ''))
            data_dict = []
            # Verfication des colonnes absentes par rapport au modele
            var_entite_file_not_in_ref = []
            for index_file in range(0, len(first_row)):
                var_entite_file = first_row[index_file]
                if var_entite_file not in var_entet_ref:
                    var_entite_file_not_in_ref.append(var_entite_file)

            # Ne prendre que les entites presentes dans le modele
            var_compare_entete_by_ref = len(var_entet_ref) == len(first_row)
            if var_compare_entete_by_ref and not var_entite_file_not_in_ref:
                for row in range(3, worksheet.nrows):
                    elm = {}
                    for col in range(worksheet.ncols):
                        if col in (0, 3, 4, 7, 8, 9, 13, 16, 17, 18, 21, 22, 24, 25, 47, 48, 50, 51):  # ,26,40
                            # (0,3,4,7,8,9,13,16,17,18,21,22,24,25,26,40,47,48)
                            elm[first_row[col]] = str(worksheet.cell_value(row, col))
                        elif col == 26:
                            elm[first_row[col] + '_AA'] = str(worksheet.cell_value(row, col))
                        elif col == 40:
                            elm[first_row[col] + '_AO'] = str(worksheet.cell_value(row, col))
                        # print (elm)
                    if len(elm) == 20:
                        data_dict.append(elm)

                column_taux = 'TAUX                  DUTILISATION EN %'
                column_conclusion = 'CONCLUSION'
                column_type_ligne = 'TYPE DE LIGNE -RÉSEAU                  -EN NAPPE'
                column_commentaires = 'Commentaires'
                column_etat_apparent = 'Etat apparent'

                for index_dict, value in enumerate(data_dict):
                    ab_haut = '-1'
                    ab_class = '-1'
                    ab_effort = '-1'
                    for index_value, (key, var_value) in enumerate(value.items()):
                        data_recup = str(var_value.replace('.0', '').upper().replace("'", ''))
                        if index_value == 0:
                            ab_codeext = self.generalfunctions.function_getvalue(data_recup, 'NC')
                        if index_value == 2:
                            ab_haut = self.generalfunctions.function_getvalue(data_recup, 'NC')
                        if index_value == 3:
                            ab_class = self.generalfunctions.function_getvalue(data_recup, 'NC')
                        if index_value == 4:
                            ab_effort = self.generalfunctions.function_getvalue(data_recup, 'NC')
                        ab_struct = ab_haut + ' ' + ab_class + ' ' + ab_effort
                        if index_value == 1:
                            ab_type = self.generalfunctions.function_getvalue(data_recup, 'NC')
                        if index_value == 5:
                            ab_annee = self.generalfunctions.function_getvalue(data_recup, 'NC')
                        if index_value == 7:
                            ab_rac_bt = self.generalfunctions.function_getvalue(data_recup, 'NC')
                        if index_value == 8:
                            ab_rac_tel = self.generalfunctions.function_getvalue(data_recup, 'NC')
                        if index_value == 9:
                            ab_malt = self.generalfunctions.function_getvalue(data_recup, 'SO')
                        if index_value == 10:
                            ab_iacm = self.generalfunctions.function_getvalue(data_recup, 'SO')
                        if index_value == 11:
                            ab_ras_hta = self.generalfunctions.function_getvalue(data_recup, 'SO')
                        if index_value == 12:
                            ab_ras_bt = self.generalfunctions.function_getvalue(data_recup, 'ab_ras_bt')
                        if index_value == 13:
                            ab_ep = self.generalfunctions.function_getvalue(data_recup, 'SO')
                        if index_value == 6:
                            ab_cb_bt = self.generalfunctions.function_getvalue(data_recup, '')
                        if index_value == 14:
                            ab_cb_cu = data_recup  # function_getvalue(data_recup,'')
                        if key == column_type_ligne + '_AO' and index_value == 15:
                            ab_cb_fo = self.generalfunctions.function_getvalue(data_recup, 'NC')
                        elif key != column_type_ligne + '_AO' and index_value == 15:
                            ab_cb_fo = 'NC'
                        if ' -2F-' in ab_cb_fo:
                            ab_rac_reel = 'OUI'
                        elif ' -2F-' not in ab_cb_fo:
                            ab_rac_reel = 'NON'
                        if key == column_commentaires and index_value == 16:
                            ab_com_com = self.generalfunctions.function_getvalue(data_recup, 'NC')
                        elif key != column_commentaires and index_value == 16:
                            ab_com_com = 'NC'
                        if key == column_etat_apparent and index_value == 17:
                            ab_visuel_com = self.generalfunctions.function_getvalue(data_recup, 'NC')
                        elif key != column_etat_apparent and index_value == 17:
                            ab_visuel_com = 'NC'
                        if key == column_conclusion and index_value == 18:
                            ab_eta_com = self.generalfunctions.function_getvalue(data_recup, 'NC')
                        elif key != column_conclusion and index_value == 18:
                            ab_eta_com = 'NC'
                        if key == column_taux and index_value == 19:
                            ab_dan_avt = self.generalfunctions.function_getvalue(data_recup, 'NC')
                        elif key != column_taux and index_value == 19:
                            ab_dan_avt = 'NC'

                    data_finale.append([ab_codeext, ab_etude, ab_struct, ab_type, ab_annee, ab_rac_bt, ab_rac_tel,
                                        ab_malt, ab_iacm, ab_ras_hta, ab_ras_bt, ab_ep, ab_cb_bt,
                                        ab_cb_cu, ab_cb_fo, ab_rac_reel, ab_eta_com, ab_dan_avt, ab_com_com,
                                        ab_visuel_com])
            else:
                #     0 == Nom Fichier; 1 == reference du modele de dev; 2 == valeur fichier etude
                var_list_erreur_model.append([ab_etude, var_entet_ref, var_entite_file_not_in_ref])
            return data_finale, var_list_erreur_model

    # function pour recuperer les info de la fiche comac
    def function_recperation_info_fiches_appuis_Comac(self, Fichier_appuis):
        if Fichier_appuis:
            name_file = str(os.path.splitext(os.path.basename(Fichier_appuis))[0]).replace("'", '').upper()
            var_entet_ref = ['Numéro', "N°                 dans             l'étude", 'Tension élec.', 'Type de poteau',
                             'Hauteur totale', 'Surimplantation', 'Hauteur hors sol', 'Classe',
                             'Effort                       (kN)', 'Année', 'Coordonnée "X"', 'Coordonnée "Y"',
                             'Coordonnée "Z"', 'Conducteur', 'Angle de piquetage de la ligne',
                             'Angle orientation  du support', 'Brancht  elec aérien', 'Brcht\nTel/Fibre',
                             'Descente de terre', 'H61', 'IAT', 'IACM', 'RAS HTA simple', 'RAS HTA double', 'RAS BT',
                             'Présence éclairage public', 'Type de ligne -réseau                  -en nappe',
                             'Nb Traverses existantes', 'Nb Traverses à poser', 'Boîtier  ',
                             'Présence de raccordements', 'Descente de terre', 'Commentaires',
                             'Type de ligne -réseau                  -en nappe', 'Nb Traverses existantes',
                             'Nb Traverses à poser', 'Boîtier  ', 'Présence de raccordements', 'Descente de terre',
                             'Commentaires', 'Type de ligne -réseau                  -en nappe',
                             'Nb Traverses existantes', 'Nb Traverses à poser', 'Boîtier  ',
                             'Présence de raccordements', 'Commentaires', None, 'Conclusion',
                             "Taux                  d'utilisation en %", 'Pince fusible', 'Commentaires',
                             'Etat apparent', 'Commentaires', 'Photos', 'Photos', 'Photos', 'Photos', 'Photos',
                             'Autorisation utilisation du poteau', 'Observations']
            # 1: 'Numéro', 2: "N°                 dans             l'étude", 3: 'Tension élec.', 4: 'Type de poteau', 5: 'Hauteur totale', 6: 'Surimplantation', 7: 'Hauteur hors sol', 8: 'Classe', 9: 'Effort                       (kN)', 10: 'Année', 11: 'Coordonnée "X"', 12: 'Coordonnée "Y"', 13: 'Coordonnée "Z"', 14: 'Conducteur', 15: 'Angle de piquetage de la ligne', 16: 'Angle orientation  du support', 17: 'Brancht  elec aérien', 18: 'Brcht\nTel/Fibre', 19: 'Descente de terre', 20: 'H61', 21: 'IAT', 22: 'IACM', 23: 'RAS HTA simple', 24: 'RAS HTA double', 25: 'RAS BT', 26: 'Présence éclairage public', 27: 'Type de ligne -réseau                  -en nappe', 28: 'Nb Traverses existantes', 29: 'Nb Traverses à poser', 30: 'Boîtier  ', 31: 'Présence de raccordements', 32: 'Descente de terre', 33: 'Commentaires', 34: 'Type de ligne -réseau                  -en nappe', 35: 'Nb Traverses existantes', 36: 'Nb Traverses à poser', 37: 'Boîtier  ', 38: 'Présence de raccordements', 39: 'Descente de terre', 40: 'Commentaires', 41: 'Type de ligne -réseau                  -en nappe', 42: 'Nb Traverses existantes', 43: 'Nb Traverses à poser', 44: 'Boîtier  ', 45: 'Présence de raccordements', 46: 'Commentaires', 47: None, 48: 'Conclusion', 49: "Taux                  d'utilisation en %", 50: 'Pince fusible', 51: 'Commentaires', 52: 'Etat apparent', 53: 'Commentaires', 54: 'Photos', 55: 'Photos', 56: 'Photos', 57: 'Photos', 58: 'Photos', 59: 'Autorisation utilisation du poteau', 60: 'Observations'
            data_dict = []
            var_list_col_fiche_ft = []
            var_list_erreur_model = []  #
            try:
                wb = load_workbook(filename=Fichier_appuis)
                sheets = wb.sheetnames
                ws = wb[sheets[0]]
                sheet = ws
                col_count = sheet.max_column + 1
                row_count = sheet.max_row
                column_names = {}
                for c in range(1, col_count):
                    heading = sheet.cell(row=3, column=c).value
                    column_names[c] = heading

                # Verfication des colonnes absentes par rapport au modele
                var_entite_file_not_in_ref = []
                list_val_dict = list(column_names.values())
                for index_file in range(0, len(list_val_dict)):
                    var_entite_file = list_val_dict[index_file]
                    if var_entite_file not in var_entet_ref:
                        var_entite_file_not_in_ref.append(var_entite_file)

                # Ne prendre que les entites presentes dans le modele
                var_compare_entete_by_ref = len(var_entet_ref) == len(list_val_dict)
                #     0 == Nom Fichier; 1 == reference du modele de dev; 2 == valeur fichier etude
                if var_entite_file_not_in_ref:
                    var_list_erreur_model.append([name_file, var_entet_ref, var_entite_file_not_in_ref])
                if var_compare_entete_by_ref:
                    dict_entet_fiche = {}
                    list_double_entete = []
                    for index_entet, entet in enumerate(list_val_dict):
                        dict_entet_fiche[index_entet] = entet

                    # Ligne pour recuperation de INSEE et Comunne
                    data_dict_insee_commune = []
                    for r, row_cells in enumerate(sheet.iter_rows(min_row=0, max_row=1), 1):
                        row = {}
                        for c in range(1, col_count):
                            cell_content = sheet.cell(row=r, column=c)
                            celle_value = str(cell_content.value).replace('None', '').upper()
                            if c not in list_double_entete:
                                row[c] = celle_value
                                list_double_entete.append(c)
                            else:
                                row[str(c) + str(c)] = celle_value
                                list_double_entete.append(str(c) + str(c))
                        data_dict_insee_commune = [list(row.values())[4], list(row.values())[8]]

                    ab_eco_commune = self.generalfunctions.function_cond_value_ft(
                        str(data_dict_insee_commune[0]).replace("'", ''), 'cond_null_nc')
                    ab_eco_insee = self.generalfunctions.function_cond_value_ft(str(data_dict_insee_commune[1]),
                                                                                'cond_null_nc')

                    for r, row_cells in enumerate(sheet.iter_rows(min_row=4), 4):
                        row = {}
                        for c in range(1, col_count):
                            cell_content = sheet.cell(row=r, column=c)
                            celle_value = str(cell_content.value).replace('None', '').upper()
                            # row[column_names[c]] = celle_value
                            if column_names[c] not in list_double_entete:
                                row[column_names[c]] = celle_value
                                list_double_entete.append(column_names[c])
                            else:
                                row[str(column_names[c]) + str(c)] = celle_value
                                list_double_entete.append(str(column_names[c]) + str(c))
                        data_dict.append(row)

                    for index_dict in range(0, len(data_dict)):
                        var_list_val = list(data_dict[index_dict].values())
                        ab_eco_codeext = self.generalfunctions.function_cond_value_ft(var_list_val[0], 'cond_null_nc')
                        ab_eco_etude = self.generalfunctions.function_cond_value_ft(name_file, 'cond_null_nc')
                        concat_ab_eco_struct = str(var_list_val[4]) + ' ' + str(var_list_val[7]) + ' ' + str(
                            var_list_val[8])
                        ab_eco_struct = self.generalfunctions.function_cond_value_ft(concat_ab_eco_struct,
                                                                                     'cond_null_nc')
                        ab_eco_type = self.generalfunctions.function_cond_value_ft(var_list_val[3], 'cond_null_nc')
                        ab_eco_annee = self.generalfunctions.function_cond_value_ft(var_list_val[9], 'cond_null_nc')
                        ab_eco_x = self.generalfunctions.function_cond_value_ft(var_list_val[10], 'cond_null_nc')
                        ab_eco_y = self.generalfunctions.function_cond_value_ft(var_list_val[11], 'cond_null_nc')
                        ab_eco_rac_bt = self.generalfunctions.function_cond_value_ft(var_list_val[16], 'cond_null_nc')
                        ab_eco_rac_tel = self.generalfunctions.function_cond_value_ft(var_list_val[17], 'cond_null_nc')
                        ab_eco_malt = self.generalfunctions.function_cond_value_ft(var_list_val[18], 'cond_null_so')
                        ab_eco_iacm = self.generalfunctions.function_cond_value_ft(var_list_val[21], 'cond_null_so')
                        ab_eco_ras_hta = self.generalfunctions.function_cond_value_ft(var_list_val[22], 'cond_null_so')
                        ab_eco_ras_bt = self.generalfunctions.function_cond_value_ft(var_list_val[24], 'cond_non_so_nc')
                        ab_eco_ep = self.generalfunctions.function_cond_value_ft(var_list_val[25], 'cond_null_so')
                        ab_eco_cb_bt = self.generalfunctions.function_cond_value_ft(var_list_val[13], 'cond_null_so')
                        ab_eco_cb_cu = self.generalfunctions.function_cond_value_ft(var_list_val[26], 'cond_null_so')
                        ab_eco_cb_fo = self.generalfunctions.function_cond_value_ft(var_list_val[40], 'cond_null_nc')
                        ab_eco_rac_reel = self.generalfunctions.function_cond_value_ft(ab_eco_cb_fo, 'ab_eco_rac_reel')
                        ab_eco_eta_com = self.generalfunctions.function_cond_value_ft(var_list_val[47], 'cond_null_nc')
                        ab_eco_dan_avt = self.generalfunctions.function_cond_value_ft(var_list_val[48], 'cond_null_nc')
                        ab_eco_com_com = self.generalfunctions.function_cond_value_ft(var_list_val[50], 'cond_null_nc')
                        ab_eco_visuel_com = self.generalfunctions.function_cond_value_ft(var_list_val[51],
                                                                                         'cond_null_nc')
                        var_list_col_fiche_ft.append(
                            [ab_eco_codeext, ab_eco_etude, ab_eco_insee, ab_eco_commune, ab_eco_struct,
                             ab_eco_type, ab_eco_annee, ab_eco_x, ab_eco_y, ab_eco_rac_bt, ab_eco_rac_tel,
                             ab_eco_malt, ab_eco_iacm, ab_eco_ras_hta, ab_eco_ras_bt, ab_eco_ep,
                             ab_eco_cb_bt, ab_eco_cb_cu, ab_eco_cb_fo, ab_eco_rac_reel, ab_eco_eta_com,
                             ab_eco_dan_avt, ab_eco_com_com, ab_eco_visuel_com])

                else:
                    #     0 == Nom Fichier; 1 == reference du modele de dev; 2 == valeur fichier etude
                    var_list_erreur_model.append(
                        [self.error_open + name_file, [var_entet_ref], [var_entite_file_not_in_ref]])
                    # 0 == var_list_col_fiche_ft; 1 == var_list_erreur_model
            except:
                var_list_erreur_model.append(
                    [self.error_open + name_file,
                     ['Erreur douverture du fichier donc pas de tratitement sur ce fichier'],
                     [Fichier_appuis]])
            return var_list_col_fiche_ft, var_list_erreur_model

    # function pour boucler sur les fiches dans le repertoire choisi
    def function_attribut_all_fiches(self):
        path_folder_comac = self.path_folder_comac
        list_all_fiches = []
        list_attribut_all_fiches = []
        list_fichier_erreur = []
        if path_folder_comac:
            bar_progress = self.generalfunctions.progress_bar(
                'Execution en Masse de la recuperation des informations des exports Comac')
            for file_etude in os.listdir(path_folder_comac):
                chemin = path_folder_comac
                name, ext = os.path.splitext(file_etude)
                if ext in ('.xls', '.xlsx', '.xlsm', '.ExportComac'):
                    chem_etude = chemin + '/' + file_etude
                    # print (file_etude,';',chem_etude)
                    attr_name = [chem_etude, file_etude.split(".")[0]]
                    file_size = os.path.getsize(chem_etude)
                    if file_size > 0:
                        list_all_fiches.append(attr_name)

            for index_fich_ap, fich_ap in enumerate(list_all_fiches):
                attribut_fiches_finale_list, error_fiche_model = self.function_recperation_info_fiches_appuis_Comac(
                    fich_ap[0])
                if error_fiche_model:
                    list_fichier_erreur.append(error_fiche_model)
                for res_FA in attribut_fiches_finale_list:
                    # attribut_fiches_finale = res_FA  # +[fich_ap[1]]
                    attribut_fiches_finale2 = res_FA
                    list_attribut_all_fiches.append(attribut_fiches_finale2)
                self.generalfunctions.progress_processing(index_fich_ap, len(list_all_fiches), bar_progress)
                if bar_progress.wasCanceled():
                    iface.messageBar().pushMessage('Info', 'Action Cancelled', level=Qgis.Info)
                    break
        # column_entete = ['ab_codeext', 'ab_etude', 'ab_struct', 'ab_type', 'ab_annee', 'ab_rac_bt', 'ab_rac_tel',
        #                  'ab_malt', 'ab_iacm', 'ab_ras_hta', 'ab_ras_bt', 'ab_ep', 'ab_cb_bt', 'ab_cb_cu', 'ab_cb_fo',
        #                  'ab_rac_reel', 'ab_eta_com', 'ab_dan_avt', 'ab_com_com', 'ab_visuel_com']
        # self.generalfunctions.function_export_infos_fiches(list_attribut_all_fiches, self.path_export, 'Info_BT',
        #                                                    column_entete)
        return list_attribut_all_fiches, list_fichier_erreur

    # Function pour lecture fichier pour C3A
    def function_recperation_info_fiches_appuis_c3a(self, fichier_appuis):
        list_sheet_data = []
        var_list_erreur_model = []
        var_list_all_erreur_traitement = []
        if fichier_appuis:
            try:
                bar_progress = self.generalfunctions.progress_bar('Extraction des informations du fichier C3A')
                # data_only ignores loading formulas and instead loads only the resulting values.
                var_file_name = os.path.basename(fichier_appuis)
                wb = load_workbook(filename=fichier_appuis, data_only=True)
                sheets_all = wb.sheetnames
                var_entet_ref = ['Numéro de prestation', 
                'Type : Chambre Orange = C,    Appui Orange = A,    Potelet Orange = P,    Immeuble = IMB,    Façade = F,    Chambre Tiers = CT,    Appui tiers = AT,    Potelet Tiers = PT', 
                'Numéro chambre ou de poteau ou de Potelet (code INSEE/N° chambre ou code INSEE/ N° de poteau ou code INSEE/ N° de Potelet)', 
                'Type : Chambre Orange = C,    Appui Orange = A,    Potelet Orange = P,    Immeuble = IMB,    Façade = F,    Chambre Tiers = CT,    Appui tiers = AT,    Potelet Tiers = PT', 
                'Numéro chambre ou de poteau ou de Potelet (code INSEE/N° chambre ou code INSEE/N° de poteau ou code INSEE/ N° de Potelet)', 
                'Longueur du tronçon ou de la portée en domaine public (m)', "Diamètre de l'alvéole prévue d'être utilisée par l'opérateur (mm)", ' Tubage rigide pour convenance', 'Diamètre du tube à installer (mm)', 'Diamètre du câble à poser (mm)', 'Commentaires opérateur', "Percement de la chambre A ou remplacement ou renforcement de l'appui aérien A", "Percement de la chambre B ou remplacement ou renforcement de l'appui aérien B", 'Installation de manchons ou PEO ou PMSB ou PB : chambre ou appui aérien (A ou B)', 'Refus de la réservation']
                
                # Partie Parcours des sheets et les fusionner
                for index_loop in range(len(sheets_all)):
                    index_sheet = sheets_all[index_loop]
                    # Prendre que les les sheets dont les dix derniers digits = AER_ORANGE
                    if str(index_sheet) == self.var_name_sheet_c3a:
                        sheet = wb[index_sheet]
                        col_count = sheet.max_column + 1
                        column_names = {}
                        for c in range(1, col_count):
                            heading = sheet.cell(row=11, column=c).value
                            column_names[c] = heading

                        # Verfication des colonnes absentes par rapport au modele
                        list_val_dict = list(column_names.values())
                        for index_file in range(0, len(var_entet_ref)):
                            var_entite_file = var_entet_ref[index_file]
                            if var_entite_file not in list_val_dict:
                                var_insert = [var_file_name, [var_entite_file], [index_sheet, self.var_incoherence_nom_entete]]
                                if var_insert not in var_list_erreur_model:
                                    var_list_erreur_model.append(var_insert)

                        # Ne prendre que les entites presentes dans le modele
                        if not var_list_erreur_model:
                            sheet_values = sheet.iter_rows(min_row=12)
                            for r, row_cells in enumerate(sheet_values, 12):
                                row = {}
                                for c in range(1, col_count):
                                    cell_content = sheet.cell(row=r, column=c)
                                    celle_value = str(cell_content.value).replace('None', '').replace("'", '')
                                    row[str(index_sheet)] = str(var_file_name)
                                    row[c] = celle_value
                                    # row[column_names[c]] = celle_value
                                var_num_prestation = row[1]
                                var_type_chambre_a = row[2]
                                var_type_chambre_b = row[4]
                                var_num_chambre_a = row[3]
                                var_num_chambre_b = row[5]
                                var_percmt_chambre_a = row[12]
                                var_percmt_chambre_b = row[13]
                                var_prepar_append = [var_file_name, var_num_prestation, var_type_chambre_a, var_type_chambre_b, var_num_chambre_a, 
                                var_num_chambre_b, var_percmt_chambre_a, var_percmt_chambre_b]
                                list_sheet_data.append(var_prepar_append)
                    self.generalfunctions.progress_processing(index_loop, len(sheets_all), bar_progress)
                    if bar_progress.wasCanceled():
                        iface.messageBar().pushMessage('Info', 'Action Cancelled', level=Qgis.Info)
                        break
            except Exception as error:
                exc_type, exc_obj, exc_tb = sys.exc_info()
                var_list_all_erreur_traitement.append(
                    ['function_recperation_info_fiches_appuis_c3a', exc_type, exc_obj, exc_tb.tb_lineno, error])
        else:
            var_list_all_erreur_traitement.append(['function_recperation_info_fiches_appuis_c3a', '', '', '',
                 'Erreur douverture du fichier donc pas de tratitement sur ce fichier'])
        return list_sheet_data, var_list_all_erreur_traitement, var_list_erreur_model

    # function pour boucler sur les fiches dans le repertoire choisi
    def function_attribut_all_fiches_c3a(self):
        list_fichier_erreur = []
        try:
            path_folder_c3a = self.path_folder_c3a
            list_all_fiches = []
            list_attribut_all_fiches = []
            if path_folder_c3a:
                bar_progress = self.generalfunctions.progress_bar('Execution en Masse de la recuperation des informations des exports C3a')
                for file_etude in os.listdir(path_folder_c3a):
                    chemin = path_folder_c3a
                    name, ext = os.path.splitext(file_etude)
                    if ext in ('.xlsx'):
                        chem_etude = chemin + '/' + file_etude
                        attr_name = [chem_etude, file_etude.split(".")[0]]
                        file_size = os.path.getsize(chem_etude)
                        if file_size > 0:
                            list_all_fiches.append(attr_name)
                for index_fich_ap, fich_ap in enumerate(list_all_fiches):
                    attribut_fiches_finale_list, error_traitement, error_fiche_model = self.function_recperation_info_fiches_appuis_c3a(fich_ap[0])
                    if error_fiche_model:
                        list_fichier_erreur.append(error_fiche_model)
                    if error_traitement:
                        list_fichier_erreur.append(error_traitement)
                    for res_FA in attribut_fiches_finale_list:
                        list_attribut_all_fiches.append(res_FA)
                    self.generalfunctions.progress_processing(index_fich_ap, len(list_all_fiches), bar_progress)
                    if bar_progress.wasCanceled():
                        iface.messageBar().pushMessage('Info', 'Action Cancelled', level=Qgis.Info)
                        break
            return list_attribut_all_fiches, list_fichier_erreur
        except Exception as error:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            list_fichier_erreur.append(['function_attribut_all_fiches_c3a', exc_type, exc_obj, exc_tb.tb_lineno, error])

    # Function pour lecture fichier pour C7
    def function_recperation_info_fiches_appuis_c7(self, fichier_appuis):
        list_sheet_data = []
        var_list_erreur_model = []
        var_list_all_erreur_traitement = []
        if fichier_appuis:
            try:
                bar_progress = self.generalfunctions.progress_bar('Extraction des informations du fichier C7')
                # data_only ignores loading formulas and instead loads only the resulting values.
                var_file_name = os.path.basename(fichier_appuis)
                wb = load_workbook(filename=fichier_appuis, data_only=True)
                sheets_all = wb.sheetnames
                
                # Partie Parcours des sheets et les fusionner
                for index_loop in range(len(sheets_all)):
                    index_sheet = sheets_all[index_loop]
                    # Prendre que les les sheets dont les dix derniers digits = AER_ORANGE
                    if str(index_sheet) == self.var_name_sheet_c7:
                        sheet = wb[index_sheet]
                        col_count = sheet.max_column + 1
                        column_names = {}
                        for c in range(1, col_count):
                            heading = sheet.cell(row=17, column=c).value
                            column_names[c] = heading

                        # Verfication de la longueur colonnes par rapport au modele
                        list_val_dict = list(column_names.values())
                        if len(list_val_dict) != 15:
                            var_list_erreur_model.append([var_file_name, list_val_dict, [index_sheet, self.var_incoherence_long_entete]])

                        # Ne prendre que les entites presentes dans le modele
                        if not var_list_erreur_model:
                            sheet_values = sheet.iter_rows(min_row=18)
                            for r, row_cells in enumerate(sheet_values, 18):
                                row = {}
                                for c in range(1, col_count):
                                    cell_content = sheet.cell(row=r, column=c)
                                    celle_value = str(cell_content.value).replace('None', '').replace("'", '')
                                    row[str(index_sheet)] = str(var_file_name)
                                    row[c] = celle_value
                                    # row[column_names[c]] = celle_value
                                var_list_row = list(row.values())
                                var_len_cinq_premier = len(var_list_row[:5]) # Longueur des 5 premiers elements
                                var_index_rempli = [[x, var_list_row[5:][x]] for x in range(var_len_cinq_premier) if var_list_row[5:][x]]
                                if var_index_rempli:
                                    var_index_col_remonte = var_index_rempli[0][0] # Recuperation de lindex de la colonne a remonter
                                    if var_index_col_remonte in column_names: # Verification si lindex de la colonne a remonter existe dans lentete
                                        var_prepar_append = [var_list_row[0], var_list_row[1], column_names[var_index_col_remonte + var_len_cinq_premier]]
                                        list_sheet_data.append(var_prepar_append)
                    self.generalfunctions.progress_processing(index_loop, len(sheets_all), bar_progress)
                    if bar_progress.wasCanceled():
                        iface.messageBar().pushMessage('Info', 'Action Cancelled', level=Qgis.Info)
                        break
            except Exception as error:
                exc_type, exc_obj, exc_tb = sys.exc_info()
                var_list_all_erreur_traitement.append(
                    ['function_recperation_info_fiches_appuis_c7', exc_type, exc_obj, exc_tb.tb_lineno, f"{error}_{fichier_appuis}"])
        else:
            var_list_all_erreur_traitement.append(['function_recperation_info_fiches_appuis_c7', '', '', '',
                'Erreur douverture du fichier donc pas de tratitement sur ce fichier'])
        return list_sheet_data, var_list_all_erreur_traitement, var_list_erreur_model

    # function pour boucler sur les fiches dans le repertoire choisi
    def function_attribut_all_fiches_c7(self):
        list_fichier_erreur = []
        try:
            list_all_fiches = []
            list_attribut_all_fiches = []
            if self.path_folder_c7:
                bar_progress = self.generalfunctions.progress_bar('Execution en Masse de la recuperation des informations des exports C7')
                for file_etude in os.listdir(self.path_folder_c7):
                    chemin = self.path_folder_c7
                    name, ext = os.path.splitext(file_etude)
                    if ext in ('.xlsx'):
                        chem_etude = chemin + '/' + file_etude
                        attr_name = [chem_etude, file_etude.split(".")[0]]
                        file_size = os.path.getsize(chem_etude)
                        if file_size > 0:
                            list_all_fiches.append(attr_name)
                for index_fich_ap, fich_ap in enumerate(list_all_fiches):
                    attribut_fiches_finale_list, error_traitement, error_fiche_model = self.function_recperation_info_fiches_appuis_c7(fich_ap[0])
                    if error_fiche_model:
                        list_fichier_erreur.append(error_fiche_model)
                    if error_traitement:
                        list_fichier_erreur.append(error_traitement)
                    for res_FA in attribut_fiches_finale_list:
                        list_attribut_all_fiches.append(res_FA)
                    self.generalfunctions.progress_processing(index_fich_ap, len(list_all_fiches), bar_progress)
                    if bar_progress.wasCanceled():
                        iface.messageBar().pushMessage('Info', 'Action Cancelled', level=Qgis.Info)
                        break
            # print(list_fichier_erreur)
            # print(list_attribut_all_fiches)
            return list_attribut_all_fiches, list_fichier_erreur
        except Exception as error:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            list_fichier_erreur.append(['function_attribut_all_fiches_c7', exc_type, exc_obj, exc_tb.tb_lineno, error])

    # function pour comparer les fiches comac et le mcd
    def function_compare_mcd_comac_fa(self):
        schema = self.schema
        bar_progress = self.generalfunctions.progress_bar('Execution de la function_compare_mcd_comac_fa')
        list_ptech = self.generalfunctions.function_get_ptech_mcd(schema)
        list_ptech_cables = self.generalfunctions.function_get_ptech_cable_mcd(schema)
        list_comac, list_fichier_erreur = self.function_attribut_all_fiches()
        list_bt = []
        # function_appuis_BT_Parcours_directory(path_folder_BT, var_FA)
        list_res_export = []
        list_res_export_trame = []

        for index_mcd, mcd in enumerate(list_ptech):
            # mcd[5] == 'T' and mcd[6] == 'A' and (mcd[1][10:12] in ('BT', 'EP') and mcd[1][:3] == 'POT' and len(mcd[1][-7:]) == 7)
            if mcd[6] == 'A' and (mcd[1][10:12] in ('BT', 'EP') and mcd[1][:3] == 'POT' and len(mcd[1][-7:]) == 7):
                ab_mcd_etiquet = mcd[1]
                ab_mcd_pt_comment = mcd[9]
                ab_mcd_cable = ''
                ab_mcd_zsro = ''
                ab_mcd_gest = mcd[7]
                ab_mcd_a_struc = self.generalfunctions.function_cond_value_ft(mcd[4], 'cond_null_nc')
                ab_mcd_nature = self.generalfunctions.function_cond_value_ft(mcd[2], 'cond_null_nc')
                ab_mcd_eta = self.generalfunctions.function_cond_value_ft(mcd[3], 'cond_null_nc')
                ab_mcd_rac = 'NON'
                if str(ab_mcd_gest) == 'OR000000000130':
                    ab_mcd_gest = 'ENEDIS'
                else:
                    ab_mcd_gest = 'NC'
                var_cable_appui = []
                for pt_cable in list_ptech_cables:
                    if pt_cable[0] == mcd[0]:  # and 'DI' in pt_cable[2]
                        var_cable_appui = pt_cable[5]
                        ab_mcd_cable = str(','.join(pt_cable[1]))
                        convert_none_ab_mcd_zsro = ['' if sub == None else sub for sub in pt_cable[3]]
                        # if convert_none_ab_mcd_zsro:
                        ab_mcd_zsro = str(','.join([x for x in convert_none_ab_mcd_zsro if x]))
                    if pt_cable[0] == mcd[0] and 'OUI' in pt_cable[4]:  # 'RA' in pt_cable[2]:
                        ab_mcd_rac = 'OUI'

                ab_eco_codeext = 'NC_COMAC'
                ab_eco_etude = 'NC_COMAC'
                ab_eco_insee = 'NC_COMAC'
                ab_eco_commune = 'NC_COMAC'
                ab_eco_struct = 'NC_COMAC'
                ab_eco_type = 'NC_COMAC'
                ab_eco_annee = 'NC_COMAC'
                ab_eco_x = 'NC_COMAC'
                ab_eco_y = 'NC_COMAC'
                ab_eco_rac_bt = 'NC_COMAC'
                ab_eco_rac_tel = 'NC_COMAC'
                ab_eco_malt = 'NC_COMAC'
                ab_eco_iacm = 'NC_COMAC'
                ab_eco_ras_hta = 'NC_COMAC'
                ab_eco_ras_bt = 'NC_COMAC'
                ab_eco_ep = 'NC_COMAC'
                ab_eco_cb_bt = 'NC_COMAC'
                ab_eco_cb_cu = 'NC_COMAC'
                ab_eco_cb_fo = 'NC_COMAC'
                ab_eco_rac_reel = 'NC_COMAC'
                ab_eco_eta_com = 'NC_COMAC'
                ab_eco_dan_avt = 'NC_COMAC'
                ab_eco_com_com = 'NC_COMAC'
                ab_eco_visuel_com = 'NC_COMAC'

                ab_efi_codefiche = 'NC_FICHE'
                ab_efi_prive = 'NC_FICHE'
                ab_efi_surplomb = 'NC_FICHE'
                ab_efi_elagage = 'NC_FICHE'
                ab_efi_inv = 'NC_FICHE'
                ab_efi_hlibre = 'NC_FICHE'
                ab_efi_visuel = 'NC_FICHE'
                ab_efi_vertica = 'NC_FICHE'
                ab_efi_jaune = 'NC_FICHE'
                ab_efi_mobilis = 'NC_FICHE'
                ab_efi_gravur = 'NC_FICHE'
                ab_efi_ras_ft = 'NC_FICHE'
                ab_efi_orien = 'NC_FICHE'
                ab_efi_anc_bt = 'NC_FICHE'
                ab_efi_anc_ft = 'NC_FICHE'
                ab_efi_com_etl = 'NC_FICHE'

                ab_moe_nat_tvx = ''
                ab_moe_environ = ''
                ab_moe_val = ''
                ab_moe_com = ''

                attachment = ''
                for comac in list_comac:
                    if str(mcd[1]).upper().replace('_', '').find(str(comac[0].upper()).replace('_', '')) != -1:
                        ab_eco_codeext = comac[0]
                        ab_eco_etude = comac[1]
                        ab_eco_insee = comac[2]
                        ab_eco_commune = comac[3]
                        ab_eco_struct = comac[4]
                        ab_eco_type = comac[5]
                        ab_eco_annee = comac[6]
                        ab_eco_x = comac[7]
                        ab_eco_y = comac[8]
                        ab_eco_rac_bt = comac[9]
                        ab_eco_rac_tel = comac[10]
                        ab_eco_malt = comac[11]
                        ab_eco_iacm = comac[12]
                        ab_eco_ras_hta = comac[13]
                        ab_eco_ras_bt = comac[14]
                        ab_eco_ep = comac[15]
                        ab_eco_cb_bt = comac[16]
                        ab_eco_cb_cu = comac[17]
                        ab_eco_cb_fo = comac[18]
                        ab_eco_rac_reel = comac[19]
                        ab_eco_eta_com = comac[20]
                        ab_eco_dan_avt = comac[21]
                        ab_eco_com_com = comac[22]
                        ab_eco_visuel_com = comac[23]
                # Exporter tous les appuis hormis ceux qui ont que des cables RAC
                if 'OUI' in var_cable_appui:
                    list_res_export.append(
                        [ab_mcd_etiquet, ab_mcd_cable, ab_mcd_zsro, ab_mcd_gest, ab_mcd_a_struc, ab_mcd_nature, ab_mcd_eta,
                        ab_mcd_rac,
                        ab_eco_codeext, ab_eco_etude, ab_eco_insee, ab_eco_commune, ab_eco_struct,
                        ab_eco_type, ab_eco_annee, ab_eco_x, ab_eco_y, ab_eco_rac_bt, ab_eco_rac_tel,
                        ab_eco_malt, ab_eco_iacm, ab_eco_ras_hta, ab_eco_ras_bt, ab_eco_ep,
                        ab_eco_cb_bt, ab_eco_cb_cu, ab_eco_cb_fo, ab_eco_rac_reel, ab_eco_eta_com,
                        ab_eco_dan_avt, ab_eco_com_com, ab_eco_visuel_com,
                        ab_efi_codefiche, ab_efi_prive, ab_efi_surplomb, ab_efi_elagage, ab_efi_inv, ab_efi_hlibre,
                        ab_efi_visuel, ab_efi_vertica, ab_efi_jaune, ab_efi_mobilis, ab_efi_gravur, ab_efi_ras_ft,
                        ab_efi_orien, ab_efi_anc_bt, ab_efi_anc_ft, ab_efi_com_etl, ab_moe_nat_tvx,
                        ab_moe_environ, ab_moe_val, ab_moe_com, mcd[8], schema, ab_mcd_pt_comment, attachment])
                    appuis_mobilisable = self.generalfunctions.function_appuis_mobilisable(ab_eco_visuel_com, ab_eco_eta_com)
                    list_res_export_trame.append([ab_mcd_zsro, ab_eco_etude, ab_mcd_gest, ab_mcd_etiquet, ab_mcd_a_struc,
                                                '', ab_eco_commune, ab_eco_insee, ab_mcd_etiquet[:4], ab_eco_type,
                                                ab_eco_annee, ab_eco_x, ab_eco_y, ab_eco_visuel_com, ab_eco_dan_avt,
                                                ab_eco_eta_com, ab_mcd_eta, appuis_mobilisable, ab_mcd_cable])
            self.generalfunctions.progress_processing(index_mcd, len(list_ptech), bar_progress)
            if bar_progress.wasCanceled():
                iface.messageBar().pushMessage('Info', 'Action Cancelled', level=Qgis.Info)
                break
        
        for index_comac in range(len(list_comac)):
            comac = list_comac[index_comac]
            ab_eco_codeext = comac[0]
            if ab_eco_codeext != 'NC':
                ab_eco_etude = comac[1]
                ab_eco_insee = comac[2]
                ab_eco_commune = comac[3]
                ab_eco_struct = comac[4]
                ab_eco_type = comac[5]
                ab_eco_annee = comac[6]
                ab_eco_x = comac[7]
                ab_eco_y = comac[8]
                ab_eco_rac_bt = comac[9]
                ab_eco_rac_tel = comac[10]
                ab_eco_malt = comac[11]
                ab_eco_iacm = comac[12]
                ab_eco_ras_hta = comac[13]
                ab_eco_ras_bt = comac[14]
                ab_eco_ep = comac[15]
                ab_eco_cb_bt = comac[16]
                ab_eco_cb_cu = comac[17]
                ab_eco_cb_fo = comac[18]
                ab_eco_rac_reel = comac[19]
                ab_eco_eta_com = comac[20]
                ab_eco_dan_avt = comac[21]
                ab_eco_com_com = comac[22]
                ab_eco_visuel_com = comac[23]

                ab_efi_codefiche = 'NC_FICHE'
                ab_efi_prive = 'NC_FICHE'
                ab_efi_surplomb = 'NC_FICHE'
                ab_efi_elagage = 'NC_FICHE'
                ab_efi_inv = 'NC_FICHE'
                ab_efi_hlibre = 'NC_FICHE'
                ab_efi_visuel = 'NC_FICHE'
                ab_efi_vertica = 'NC_FICHE'
                ab_efi_jaune = 'NC_FICHE'
                ab_efi_mobilis = 'NC_FICHE'
                ab_efi_gravur = 'NC_FICHE'
                ab_efi_ras_ft = 'NC_FICHE'
                ab_efi_orien = 'NC_FICHE'
                ab_efi_anc_bt = 'NC_FICHE'
                ab_efi_anc_ft = 'NC_FICHE'
                ab_efi_com_etl = 'NC_FICHE'

                ab_moe_nat_tvx = ''
                ab_moe_environ = ''
                ab_moe_val = ''
                ab_moe_com = ''

                ab_mcd_etiquet = f"NC_MCD_PT_COMMENT_{index_comac}"
                ab_mcd_pt_comment = 'NC_MCD_PT_COMMENT'
                ab_mcd_cable = 'NC_MCD_PT_COMMENT'
                ab_mcd_zsro = 'NC_MCD_PT_COMMENT'
                ab_mcd_gest = 'NC_MCD_PT_COMMENT'
                ab_mcd_a_struc = 'NC_MCD_PT_COMMENT'
                ab_mcd_nature = 'NC_MCD_PT_COMMENT'
                ab_mcd_eta = 'NC_MCD_PT_COMMENT'
                ab_mcd_rac = 'NC_MCD_PT_COMMENT'
                ab_mcd_geom = "ST_GeomFromText('POINT(793581.137931592 6393324.72495102)',2154)"

                attachment = ''

                for index_mcd, mcd in enumerate(list_ptech):
                    if str(mcd[9]).upper().replace('_', '').find(str(ab_eco_codeext.upper()).replace('_', '')) != -1:
                        if mcd[6] == 'A' and (mcd[1][10:12] in ('BT', 'EP') and mcd[1][:3] == 'POT' and len(mcd[1][-7:]) == 7):
                            ab_mcd_etiquet = mcd[1]
                            ab_mcd_pt_comment = mcd[9]
                            ab_mcd_cable = ''
                            ab_mcd_zsro = ''
                            ab_mcd_gest = mcd[7]
                            ab_mcd_a_struc = self.generalfunctions.function_cond_value_ft(mcd[4], 'cond_null_nc')
                            ab_mcd_nature = self.generalfunctions.function_cond_value_ft(mcd[2], 'cond_null_nc')
                            ab_mcd_eta = self.generalfunctions.function_cond_value_ft(mcd[3], 'cond_null_nc')
                            ab_mcd_rac = 'NON'
                            ab_mcd_geom = mcd[8]
                            if str(ab_mcd_gest) == 'OR000000000130':
                                ab_mcd_gest = 'ENEDIS'
                            else:
                                ab_mcd_gest = 'NC'
                list_res_export.append(
                    [ab_mcd_etiquet, ab_mcd_cable, ab_mcd_zsro, ab_mcd_gest, ab_mcd_a_struc, ab_mcd_nature, ab_mcd_eta,
                     ab_mcd_rac,
                     ab_eco_codeext, ab_eco_etude, ab_eco_insee, ab_eco_commune, ab_eco_struct,
                     ab_eco_type, ab_eco_annee, ab_eco_x, ab_eco_y, ab_eco_rac_bt, ab_eco_rac_tel,
                     ab_eco_malt, ab_eco_iacm, ab_eco_ras_hta, ab_eco_ras_bt, ab_eco_ep,
                     ab_eco_cb_bt, ab_eco_cb_cu, ab_eco_cb_fo, ab_eco_rac_reel, ab_eco_eta_com,
                     ab_eco_dan_avt, ab_eco_com_com, ab_eco_visuel_com,
                     ab_efi_codefiche, ab_efi_prive, ab_efi_surplomb, ab_efi_elagage, ab_efi_inv, ab_efi_hlibre,
                     ab_efi_visuel, ab_efi_vertica, ab_efi_jaune, ab_efi_mobilis, ab_efi_gravur, ab_efi_ras_ft,
                     ab_efi_orien, ab_efi_anc_bt, ab_efi_anc_ft, ab_efi_com_etl, ab_moe_nat_tvx,
                     ab_moe_environ, ab_moe_val, ab_moe_com, ab_mcd_geom, schema, ab_mcd_pt_comment, attachment])
        return list_res_export, list_fichier_erreur, list_res_export_trame

    # Execution de la function_compare_mcd_comac_fa
    def function_execute_compare_mcd_comac(self):
        schema = self.schema
        list_insert_res, list_fichier_erreur, list_res_export_trame = self.function_compare_mcd_comac_fa()
        list_trame_model = [
            ['ab_mcd_zsro (cf. plugin DPI)', 'ab_eco_etude\n(cf. plugin DPI)', 'ab_mcd_gest\n(cf. plugin DPI)',
             'ab_mcd_etiquet\n(cf. plugin DPI)', '', 'ab_eco_visuel_com\n(cf. plugin DPI)',
             'ab_mcd_eta\n(cf. plugin DPI)',
             '= SI ( ab_eco_visuel_com = "Bon état" & ab_eco_eta_com = " OK ", " Utilisable", sinon "Non utilisable")',
             'ab_mcd_cable\n(cf. plugin DPI)', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '',
             '', '', ''], ['SRO', 'Nom Etude', 'Nom Gestionnaire', 'Etiquette Appui',
                           'ETUDE AERIENNE - Défaut modélisation canton : majeur', 'Classement ENEDIS',
                           'Etat Appui MCD', '', '', 'ETUDE AERIENNE - Défaut hypothèse climatique : majeur',
                           'APPUI - Incoherence description : majeur',
                           'APPUI - Defaut presence/absence EP : mineur\nAPPUI - Defaut presence/absence RAS : mineur\nAPPUI - Defaut presence/absence BOITIER : mineur',
                           'APPUI -  Defaut photos : majeur', 'APPUI - Incoherence controle visuel : mineur', '',
                           'CABLES - Defaut nature : majeur (influence négative sur le calcul)',
                           'CABLES - Defaut nombre : majeur (influence négative sur le calcul)',
                           'ETUDE AERIENNE - Defaut orientation de la ligne : majeur',
                           "APPUI - Defaut orientation de l'appui : majeur", '',
                           'CABLES - Incoherence ecart des lignes existantes : mineur\nCABLES - Incoherence ecart des lignes à poser : majeur',
                           'CABLES  - Defaut fleche usuelle : majeur', 'CABLES - Defaut hauteur de ligne : majeur',
                           'CABLES - Defaut parallelisme : majeur\nCABLES - Croissement de reseau ; majeur', '',
                           'CABLES  - Incoherence branchements modelises : majeur', '', '',
                           'étude à revoir\nétude raccordement\nétude CFI\nvalidée en état\n', ''],
            ['\nRéférence de ZSRO\n(zs_refpm)', "\nRéférence de l'étude\n(EBT_xxx_xxx,pcm)",
             "\nType de l'étude\n(EBT / EP)", 'Point technique\n(pt_etiquet)', 'Cohérence modélisation Canton',
             "Contrôle Visuel\n(cf, fiche d'appui)", "Résultat de l'étude\n(pt_etat)", 'Appui Mobilisable\nfx( E & F)',
             '\nType de fibre\n(cb_capa_fo)', 'Cohérence Hypothèse Climatique',
             "Cohérence\nDescription de l'appui\n(Oui/Majeur)", 'Cohérence\nEquipements Existants\n(Oui/Mineur)',
             'Cohérence\nPhotos\n(Oui/Majeur)', 'Cohérence\nContrôle Visuel\n(Oui/Mineur)',
             "Cohérence\nde l'Appui\n(Oui/Mineur/Majeur)", 'Cohérence\nNature du cable\n(Oui/Majeur)',
             'Cohérence\nNombre de cable\n(Oui/Majeur)', 'Cohérence\nOrientation de la ligne\n(Oui/Majeur)',
             "Cohérence\nOrientation de l'appui\n(Oui/Majeur)",
             'Cohérence\nDescription de la ligne \n(Oui/Mineur/Majeur)',
             'Cohérence\nécart des lignes\n(Oui/Mineur/Majeur)', 'Cohérence\nFlèche Usuelle\n(Oui/Majeur)',
             'Cohérence\nHauteur de ligne\n(Oui//Majeur)', 'Cohérence\nParallélisme de la ligne\n(Oui/Majeur)',
             'Cohérence\nParametres de la ligne \n(Oui/Mineur/Majeur)',
             'Cohérence des branchements\nnon modélisés \n(Oui/Majeur)', 'Contre Relevé terrain',
             "reste une possibilité de mobiliser l'appui", "Synthèse de l'étude DEO", 'Commentaires']]

        bar_progress = self.generalfunctions.progress_bar('Execution de linsertion dans la table a_appui_bt')
        for index_insert, insert_bt in enumerate(list_insert_res):
            text_inf_insert = str(tuple(insert_bt)).replace('"', '').replace('None', "''")
            self.generalfunctions.function_insert_a_appuibt(schema, text_inf_insert, 'a_appuibt')
            self.generalfunctions.progress_processing(index_insert, len(list_insert_res), bar_progress)
            if bar_progress.wasCanceled():
                iface.messageBar().pushMessage('Info', 'Action Cancelled', level=Qgis.Info)
                break

        # Export des resultats en execel
        entete_column = ['ab_mcd_etiquet', 'ab_mcd_cable', 'ab_mcd_zsro', 'ab_mcd_gest', 'ab_mcd_a_struc',
                         'ab_mcd_nature', 'ab_mcd_eta', 'ab_mcd_rac', 'ab_eco_codeext', 'ab_eco_etude',
                         'ab_eco_insee', 'ab_eco_commune', 'ab_eco_struct', 'ab_eco_type', 'ab_eco_annee',
                         'ab_eco_x', 'ab_eco_y', 'ab_eco_rac_bt', 'ab_eco_rac_tel', 'ab_eco_malt',
                         'ab_eco_iacm', 'ab_eco_ras_hta', 'ab_eco_ras_bt', 'ab_eco_ep', 'ab_eco_cb_bt',
                         'ab_eco_cb_cu', 'ab_eco_cb_fo', 'ab_eco_rac_reel', 'ab_eco_eta_com', 'ab_eco_dan_avt',
                         'ab_eco_com_com', 'ab_eco_visuel_com', 'ab_efi_codefiche', 'ab_efi_prive', 'ab_efi_surplomb',
                         'ab_efi_elagage', 'ab_efi_inv', 'ab_efi_hlibre', 'ab_efi_visuel', 'ab_efi_vertica',
                         'ab_efi_jaune', 'ab_efi_mobilis', 'ab_efi_gravur', 'ab_efi_ras_ft', 'ab_efi_orien',
                         'ab_efi_anc_bt', 'ab_efi_anc_ft', 'ab_efi_com_etl', 'ab_moe_nat_tvx', 'ab_moe_environ',
                         'ab_moe_val', 'ab_moe_com', 'geom', 'name_schema', 'ab_mcd_pt_comment']
        self.generalfunctions.function_export_infos_fiches(list_insert_res, self.path_export, 'Info_BT', entete_column)

        # Preparation des listes pour exporter les erreur
        list_error_open_fiche = []
        list_fichier_erreur_finale = []
        for index_error_open in list_fichier_erreur:
            # Error open file
            if index_error_open[0][0][:11] == self.error_open:
                list_error_open_fiche.append(index_error_open)
            # Error Format
            else:
                list_fichier_erreur_finale.append(index_error_open)

        # Exportation de la trame
        len_list_trame_model = len(list_trame_model[0])  # len(list_trame_model)
        for index_trame in range(0, len(list_res_export_trame)):
            len_list_res_export_trame = len(list_res_export_trame[index_trame])
            difference_list_trame_export = len_list_trame_model - len_list_res_export_trame
            if difference_list_trame_export == 11:
                list_res_export_trame[index_trame] = list_res_export_trame[index_trame] + [
                    ''] * difference_list_trame_export
                list_trame_model.append(list_res_export_trame[index_trame])
            # else:
            #     return QMessageBox.warning(self.generalfunctions.w, "Message de trame",
            #                                'Probleme de longueur entre la trame et la donnnee')
        entete = ['\nRenseigner la\nRéférence de ZSRO', "\nRenseigner la\nRéférence de l'étude\nCOMAC",
                  '\nRenseigner le\nType détude\n\nEBT, pour ENEDIS\nEP, pour Eclairage Public',
                  "Renseigner le\nNuméro d'appui\n\nCohérence de nommage:\nBT_YXXX, calculé\nNC_YXXX, non calculé dans cette étude\nNC_AXXX, appui adjacent non calculé au global",
                  None, None, None, None, None, None, None, None, None,
                  "\nRenseigner le\nRésultat du contrôle visuel\nréalisé par l'entreprise\n\nOK, Bon état\nME, Mauvais état\n",
                  "\nRenseigner le\nRésultat de l'étude\nréalisé par l'entreprise\n\nOK, Bon état\nHS, A changer\n",
                  None,
                  "\nRenseigner le\nRésultat de l'étude\nréalisé par l'entreprise\n\nOK, Bon état\nHS, A changer\n",
                  "\nIndiquer\nsi l'appui est\nmobilisable en l'etat\nsuite à l'étude\nréalisé par l'entreprise\n\nOK , OK > OK\nHS + ME > KO\nHS , ME > KO",
                  "\nRenseigner le\nType de fibre à poser\nsur l'appui",
                  "\nIndiquer\nla coherence entre le\nMCD et l'etude COMAC\n(Cable)\n\n\n\n(Majeur, si erreur dans COMAC)",
                  "\nIndiquer\nla coherence entre le\nMCD et l'etude COMAC\n(Cable)\n\n\n\n(Majeur, si erreur dans COMAC)",
                  "\nIndiquer\nla coherence entre le\nMCD et l'etude COMAC\n(Cable)\n\n\n\n(Majeur, si erreur dans COMAC)",
                  None,
                  "\nIndiquer\nsi coherence des caracteristiques d'appui\nentre la Fiche d'Appui, l'etude COMAC et les Photos\n\n(Majeur, si erreur dans COMAC)",
                  "\nIndiquer\nsi coherence des\néquipements Existants entre la Fiche d'Appui, l'etude COMAC et les Photos\n\n",
                  "\nIndiquer\nsi presence des photos de l'appui dans la fiche d'Appui, l'etude COMAC\n\n(Majeur, si erreur dans COMAC)",
                  "\nIndiquer\nla cohérence du\n contrôle visuel entre  les photos, la fiche d'Appui, l'etude COMAC\n\n\n",
                  "\nSynthèse\nde la cohérence de renseignements de l'appui\n\n",
                  "\nIndiquer\nla cohérence de la \nnature cable existant\nentre la fiche d'Appui, l'etude COMAC\n\n\n(Majeur, si erreur dans COMAC)",
                  "\nIndiquer\nla cohérence du\nnombre de cable existant\nentre la fiche d'Appui, l'etude COMAC\n\n\n(Majeur, si erreur dans COMAC)",
                  "\nIndiquer\nla cohérence de\nl'orientation de la ligne\nentre le SIG, les photos\net l'etude COMAC\n\n\n(Majeur, si erreur dans COMAC)",
                  "\nIndiquer\nla cohérence de\nl'orientation de l'appui\nentre le SIG, les photos\net l'etude COMAC\n\n\n(Majeur, si erreur dans COMAC)",
                  '\nSynthèse\nde la cohérence de la\ndescription de la ligne dans COMAC\n\n\n\n(Majeur, si erreur dans COMAC)',
                  "\nIndiquer\nla cohérence des\nhauteurs d'ancrage\ndans l'etude COMAC\n\n(Mineur,  sur existant)\n\n(Majeur, si pas de reserve pour la pose de la fibre)",
                  "\nIndiquer\nla cohérence de la\nFlèche Usuelle\ndans l'etude COMAC\n\n(Majeur, si concerne la ligne BT, cf, Photos)",
                  "\nIndiquer\nla cohérence des\nhauteurs de ligne\ndans l'etude COMAC\n\n(Majeur, sur fibre en  traversee de route)",
                  "\nIndiquer\nla cohérence du\nparallélisme de la ligne\ndans l'etude COMAC\n\n(Majeur, si sur BT ou si croisement télécom)",
                  '\nSynthèse\nde la cohérence des\nparametres de la ligne\ndans COMAC\n\n\n\n(Majeur, si erreur dans COMAC)',
                  "\nIndiquer\nsi les branchements\nne sont pas décrits dans\nl'étude COMAC\n\n\n",
                  'Insérer les commentaires du contre relevé terrain',
                  "\nIndiquer\nsi l'appui est susceptible d'être utilisé\n\nOK, si mobilisable\n\nKO, si non mobilisable",
                  "faire la synthèse de l'étude en indiquant: \nétude à revoir\nvalidée en état\nétude raccordement\nétude CFI",
                  'indiquer que les réserves majeures', 'indiquer que les réserves majeures',
                  'indiquer que les réserves majeures', 'indiquer que les réserves majeures',
                  'indiquer que les réserves majeures', 'indiquer que les réserves majeures']
        self.generalfunctions.function_export_infos_fiches(list_trame_model, self.path_export, 'Info_BT_Trame', entete)
        return list_fichier_erreur_finale, list_error_open_fiche

    # function pour recuperer les info de la fiche comac
    def function_recperation_info_fiches_appuis_ft(self, Fichier_appuis):
        # global xlwings
        if Fichier_appuis:
            name_file = str(os.path.splitext(os.path.basename(Fichier_appuis))[0]).replace("'", '').upper()
            var_entet_ref = ['N° appui', "Type d'appui (format GESPOT)", "Adresse de l'appui (N°, rue ou lieu dit)",
                             'Latitude\n(WGS84)', 'Longitude\n(WGS84)', 'Contrôle visuel OK',
                             'Contrôle verticalité OK et absence étiquette orange', 'Contrôle flamblement OK',
                             'Respect voisinage réseau électrique', 'Contrôle pointe carrée OK',
                             'Contrôle secousses OK', 'Contrôle percussion OK', 'Absence étiquette jaune',
                             "Appui utilisable en l'état", "Milieu environnant de l'appui",
                             'Voisinage électrique appui', 'Appui stratégique', 'Appui inaccessible véhicule',
                             'Nom du câble', 'Longueur portée', 'Angle en grade', 'Hauteur nappe',
                             'Hauteur de flèche portée', 'Température du relevé flèche', 'N° appui destination',
                             'Forfait cuivre ', 'Forfait optique ', 'Effort disponible avant ajout câble',
                             'Effort disponible après ajout câble', 'Effort disponible Nouveau support',
                             "Type d'appui avant travaux", 'Nature des travaux', "Type d'appui aprés travaux",
                             'Nombre de poteau commandé', 'Installation réhausse', "Pose d'un boitier optique",
                             "Nombre de boitiers sur l'appui", 'transition souterraine',
                             'Distance avec transition existante', 'Installation dispositif de lovage', 'Commentaires']
            # {0: 'N° appui', 1: "Type d'appui (format GESPOT)", 2: "Adresse de l'appui (N°, rue ou lieu dit)",
            # 3: 'Latitude\n(WGS84)', 4: 'Longitude\n(WGS84)', 5: 'Contrôle visuel OK',
            # 6: 'Contrôle verticalité OK et absence étiquette orange', 7: 'Contrôle flamblement OK',
            # 8: 'Respect voisinage réseau électrique', 9: 'Contrôle pointe carrée OK', 10: 'Contrôle secousses OK',
            # 11: 'Contrôle percussion OK', 12: 'Absence étiquette jaune', 13: "Appui utilisable en l'état",
            # 14: "Milieu environnant de l'appui", 15: 'Voisinage électrique appui', 16: 'Appui stratégique',
            # 17: 'Appui inaccessible véhicule', 18: 'Nom du câble', 19: 'Longueur portée', 20: 'Angle en grade',
            # 21: 'Hauteur nappe', 22: 'Hauteur de flèche portée', 23: 'Température du relevé flèche',
            # 24: 'N° appui destination', 25: 'Forfait cuivre ', 26: 'Forfait optique ',
            # 27: 'Effort disponible avant ajout câble', 28: 'Effort disponible après ajout câble',
            # 29: 'Effort disponible Nouveau support', 30: "Type d'appui avant travaux", 31: 'Nature des travaux',
            # 32: "Type d'appui aprés travaux", 33: 'Nombre de poteau commandé', 34: 'Installation réhausse',
            # 35: "Pose d'un boitier optique", 36: "Nombre de boitiers sur l'appui", 37: 'transition souterraine',
            # 38: 'Distance avec transition existante', 39: 'Installation dispositif de lovage', 40: 'Commentaires'}
            data_dict = []
            var_list_col_fiche_ft = []
            var_list_erreur_model = []  #
            try:
                wb = load_workbook(filename=Fichier_appuis)
                sheets = wb.sheetnames
                ws = wb[sheets[-1]]
                sheet = ws
                col_count = sheet.max_column + 1
                column_names = {}
                for c in range(1, col_count):
                    heading = sheet.cell(row=8, column=c).value
                    column_names[c] = heading
                # Verfication des colonnes absentes par rapport au modele
                var_entite_file_not_in_ref = []
                list_val_dict = list(column_names.values())
                for index_file in range(0, len(list_val_dict)):
                    var_entite_file = list_val_dict[index_file]
                    if var_entite_file not in var_entet_ref:
                        var_entite_file_not_in_ref.append(var_entite_file)

                # Ne prendre que les entites presentes dans le modele
                var_compare_entete_by_ref = len(var_entet_ref) == len(list_val_dict)
                #     0 == Nom Fichier; 1 == reference du modele de dev; 2 == valeur fichier etude
                if var_entite_file_not_in_ref:
                    var_list_erreur_model.append([name_file, var_entet_ref, var_entite_file_not_in_ref])
                if var_compare_entete_by_ref:
                    dict_entet_fiche = {}
                    for index_entet, entet in enumerate(list_val_dict):
                        dict_entet_fiche[index_entet] = entet
                    for r, row_cells in enumerate(sheet.iter_rows(min_row=9), 9):
                        row = {}
                        for c in range(1, col_count):
                            cell_content = sheet.cell(row=r, column=c)
                            celle_value = str(cell_content.value).replace('None', '').replace("'", '').upper()
                            row[column_names[c]] = celle_value
                            if c == 29:
                                name_af_eta_cap = 'Effort disponible après ajout câble'
                                cell_color_af_eta_cap = cell_content.fill.start_color.index
                                # FFFAAA46 == orange; FF92D050 == vert
                                if cell_color_af_eta_cap in ('FFFAAA46', 'FF92D050'):
                                    cell_color_af_eta_cap = 'OK'
                                else:
                                    cell_color_af_eta_cap = 'INSUFFISANT'
                                row[name_af_eta_cap] = cell_color_af_eta_cap
                            elif c == 30:
                                name_af_dan_apr = 'Effort disponible Nouveau support'
                                cell_color_af_dan_apr = cell_content.fill.start_color.index
                                if cell_color_af_dan_apr in ('FFFAAA46', 'FF92D050'):
                                    cell_color_af_dan_apr = 'OK'
                                else:
                                    cell_color_af_dan_apr = 'INSUFFISANT'
                                row[name_af_dan_apr] = cell_color_af_dan_apr
                        data_dict.append(row)

                    cmp = '0'
                    dict_name_vable = {}
                    for index_dict in range(0, len(data_dict)):
                        # Duplication code fiche pour cables multiples pour concatener
                        var_current_number = list(data_dict[index_dict].values())[0]
                        var_af_cable = list(data_dict[index_dict].values())[18]
                        if var_current_number != '':
                            cmp = var_current_number
                            dict_name_vable[str(var_current_number)] = [
                                var_af_cable + ' vers ' + list(data_dict[index_dict].values())[24]]
                        else:
                            var_current_number = cmp
                            dict_name_vable[str(var_current_number)].append(
                                var_af_cable + ' vers ' + list(data_dict[index_dict].values())[24])

                    for index_dict in range(0, len(data_dict)):
                        # Duplication code fiche pour cablesmultiples
                        var_current_number = list(data_dict[index_dict].values())[0]
                        # print(data_dict[index_dict][dict_entet_ref[0]])
                        # Recuperation values par cellule et prendre les lignes dont la premiere colonne est != de nulle
                        if var_current_number != '':
                            var_list_val = data_dict[index_dict]  # list(data_dict[index_dict].values())
                            af_ec6_codeext = var_list_val[dict_entet_fiche[0]]  # var_list_val[0]
                            af_ec6_etude = name_file
                            if not af_ec6_etude:
                                af_ec6_etude = 'NC'
                            af_ec6_struct = var_list_val[dict_entet_fiche[1]]
                            af_ec6_inv = self.generalfunctions.function_cond_value_ft(
                                var_list_val[dict_entet_fiche[17]], 'af_ec6_inv')
                            af_ec6_visuel = self.generalfunctions.function_cond_value_ft(
                                var_list_val[dict_entet_fiche[5]], 'cond_oui_non_nc')
                            af_ec6_vertica = self.generalfunctions.function_cond_value_ft(
                                var_list_val[dict_entet_fiche[6]], 'cond_oui_non_nc')
                            af_ec6_flambe = self.generalfunctions.function_cond_value_ft(
                                var_list_val[dict_entet_fiche[7]], 'cond_oui_non_nc')

                            af_ec6_voisin = self.generalfunctions.function_cond_value_ft(
                                var_list_val[dict_entet_fiche[8]], 'cond_oui_non_nc')
                            af_ec6_pointe = self.generalfunctions.function_cond_value_ft(
                                var_list_val[dict_entet_fiche[9]], 'cond_oui_non_nc')
                            af_ec6_secouss = self.generalfunctions.function_cond_value_ft(
                                var_list_val[dict_entet_fiche[10]], 'cond_oui_non_nc')
                            af_ec6_percu = self.generalfunctions.function_cond_value_ft(
                                var_list_val[dict_entet_fiche[11]], 'cond_oui_non_nc')
                            af_ec6_jaune = self.generalfunctions.function_cond_value_ft(
                                var_list_val[dict_entet_fiche[12]], 'cond_oui_non_nc')
                            af_ec6_mobilis = self.generalfunctions.function_cond_value_ft(
                                var_list_val[dict_entet_fiche[13]], 'cond_oui_non_nc')

                            af_ec6_ebp = self.generalfunctions.function_cond_value_ft(
                                var_list_val[dict_entet_fiche[35]], 'cond_null_so')
                            af_ec6_ras = self.generalfunctions.function_cond_value_ft(
                                var_list_val[dict_entet_fiche[37]], 'cond_oui_non_nc')
                            af_ec6_cable = '/'.join(dict_name_vable[var_current_number])
                            af_ec6_eta = var_list_val[dict_entet_fiche[28]]
                            af_ec6_nat_tvx = str(var_list_val[dict_entet_fiche[31]]).upper()
                            af_ec6_environ = self.generalfunctions.function_cond_value_ft(
                                var_list_val[dict_entet_fiche[14]], 'cond_null_nc')

                            af_ec6_vois_el = self.generalfunctions.function_cond_value_ft(
                                str(var_list_val[dict_entet_fiche[15]]).upper(), 'cond_null_nc')
                            af_ec6_str_tvx = self.generalfunctions.funtion_af_ec6_str_tvx(af_ec6_nat_tvx, var_list_val[
                                dict_entet_fiche[32]])
                            af_ec6_dan_apr = var_list_val[dict_entet_fiche[29]]
                            af_ec6_com_etl = "'" + str(var_list_val[dict_entet_fiche[40]]).replace("'",
                                                                                                   '').upper() + "'"

                            af_ec6_strat = self.generalfunctions.function_cond_value_ft(
                                var_list_val[dict_entet_fiche[16]], 'af_ec6_strat')
                            af_ec6_rehau = str(var_list_val[dict_entet_fiche[34]]).upper()
                            af_ec6_nature = 'NC'
                            req_join = """set search_path to """ + self.schema + """, public; select * from l_appuift """
                            res_req = self.generalfunctions.function_execute_requete(req_join, 'bab')
                            for i in res_req:
                                if str(af_ec6_str_tvx).upper().find(
                                        str(i[0]).upper()) != -1:  # str(af_ec6_str_tvx) == str(i[0]):
                                    af_ec6_nature = i[6]

                            af_owf_nature = self.generalfunctions.function_af_ofw_nature(af_ec6_environ, af_ec6_vois_el,
                                                                                         af_ec6_inv, af_ec6_strat)
                            var_list_col_fiche_ft.append(
                                [af_ec6_codeext, af_ec6_etude, af_ec6_struct, af_ec6_inv, af_ec6_visuel
                                    , af_ec6_vertica, af_ec6_flambe, af_ec6_voisin, af_ec6_pointe
                                    , af_ec6_secouss, af_ec6_percu, af_ec6_jaune, af_ec6_mobilis
                                    , af_ec6_ebp, af_ec6_ras, af_ec6_cable, af_ec6_eta, af_ec6_nat_tvx
                                    , af_ec6_environ, af_ec6_vois_el, af_ec6_strat, af_ec6_rehau
                                    , af_ec6_str_tvx, af_ec6_nature, af_owf_nature, af_ec6_dan_apr, af_ec6_com_etl])
                else:
                    #     0 == Nom Fichier; 1 == reference du modele de dev; 2 == valeur fichier etude
                    var_list_erreur_model.append(
                        [self.error_open + name_file, [var_entet_ref], [var_entite_file_not_in_ref]])
                    # 0 == var_list_col_fiche_ft; 1 == var_list_erreur_model
            except Exception as error:
                var_list_erreur_model.append([f"{self.error_open}__{name_file}__{error}",
                                              ['Erreur douverture du fichier donc pas de tratitement sur ce fichier'],
                                              [Fichier_appuis]])
            # print(var_list_col_fiche_ft)
            return var_list_col_fiche_ft, var_list_erreur_model

    # function pour boucler sur les fiches dans le repertoire choisi
    def function_attribut_all_fiches_ft(self):
        path_folder_ft = self.path_folder_ft
        list_all_fiches = []
        list_attribut_all_fiches = []
        list_fichier_erreur = []
        # list_attribut_all_fiches_finale = []
        if path_folder_ft:
            bar_progress = self.generalfunctions.progress_bar(
                'Execution en Masse de la recuperation des informations des fiches FT')
            for file_etude in os.listdir(path_folder_ft):
                chemin = path_folder_ft
                name, ext = os.path.splitext(file_etude)
                if ext in ('.xls', '.xlsx', '.xlsm', '.ExportComac'):
                    chem_etude = chemin + '/' + file_etude
                    # print(file_etude,';',chem_etude)
                    attr_name = [chem_etude, file_etude.split(".")[0]]
                    file_size = os.path.getsize(chem_etude)
                    if file_size > 0:
                        list_all_fiches.append(attr_name)
            for index_fich_ap, fich_ap in enumerate(list_all_fiches):
                attribut_fiches_finale_list, error_fiche_model = self.function_recperation_info_fiches_appuis_ft(
                    fich_ap[0])
                # error_fiche_model = self.function_recperation_info_fiches_appuis_ft(fich_ap[0])[1]
                if error_fiche_model:
                    list_fichier_erreur.append(error_fiche_model)
                for res_FA in attribut_fiches_finale_list:
                    attribut_fiches_finale2 = res_FA
                    list_attribut_all_fiches.append(attribut_fiches_finale2)
                self.generalfunctions.progress_processing(index_fich_ap, len(list_all_fiches), bar_progress)
                if bar_progress.wasCanceled():
                    iface.messageBar().pushMessage('Info', 'Action Cancelled', level=Qgis.Info)
                    break
        return list_attribut_all_fiches, list_fichier_erreur

    # function pour comparer les fiches comac et le mcd
    def function_compare_mcd_ft_fiche(self):
        schema = self.schema
        list_ptech = self.generalfunctions.function_get_ptech_mcd(schema)
        list_ptech_cables = self.generalfunctions.function_get_ptech_cable_mcd(schema)
        list_ptech_remplace = self.generalfunctions.function_remplace_pt(schema)
        list_fiche_ft, list_fichier_erreur = self.function_attribut_all_fiches_ft()
        list_fiche_c3a, list_fichier_erreur_c3a = [], []
        list_fiche_c7, list_fichier_erreur_c7 = [], []
        if self.choix_c3a_c7 == True:
            list_fiche_c3a, list_fichier_erreur_c3a = self.function_attribut_all_fiches_c3a()
            list_fiche_c7, list_fichier_erreur_c7 = self.function_attribut_all_fiches_c7()

        list_res_export = []
        list_res_export_trame = []
        bar_progress = self.generalfunctions.progress_bar('Execution de la function_compare_mcd_ft_fiche')
        for index_mcd, mcd in enumerate(list_ptech):  # mcd[5] == 'T' and
            if mcd[6] == 'A' and (mcd[1][10:12] == 'FT' and mcd[1][:3] == 'POT' and len(mcd[1][4:9]) == 5):
                af_mcd_etiquet = mcd[1]
                af_mcd_pt_comment = mcd[9]
                af_mcd_etiquet_gespot = mcd[1][13:]
                af_mcd_etiquet_c3a = f"{mcd[1][4:9]}/{af_mcd_etiquet_gespot}"
                af_mcd_cable = ''
                af_mcd_zsro = ''
                af_mcd_gest = mcd[7]
                if af_mcd_gest == 'OR000000000142':
                    af_mcd_gest = 'ORANGE'
                else:
                    af_mcd_gest = 'NC'
                af_mcd_nature = self.generalfunctions.function_cond_value_ft(mcd[2], 'cond_null_nc')
                af_mcd_a_struc = self.generalfunctions.function_cond_value_ft(mcd[4], 'cond_null_nc')
                af_mcd_rac = 'NON'
                af_mcd_eta = self.generalfunctions.function_cond_value_ft(mcd[3], 'cond_null_nc')
                af_mcd_enedis = 'PMET'
                var_cable_appui = []
                for pt_cable in list_ptech_cables:
                    # str(mcd[1][:3]).upper() in ('CAB', 'CTR', 'CDI'):  and 'DI' in pt_cable[2]
                    if pt_cable[0] == mcd[0]:
                        var_cable_appui = pt_cable[5]
                        af_mcd_cable = str(','.join(pt_cable[1]))
                        convert_none_af_mcd_zsro = ['' if sub == None else sub for sub in pt_cable[3]]
                        # if convert_none_af_mcd_zsro:
                        af_mcd_zsro = str(','.join([x for x in convert_none_af_mcd_zsro if x]))
                    if pt_cable[0] == mcd[0] and 'OUI' in pt_cable[
                        4]:  # and str(mcd[1][:3]).upper() == 'CDA':  # 'RA' in pt_cable[2]:
                        af_mcd_rac = 'OUI'

                for pt_remplace in list_ptech_remplace:
                    if pt_remplace[0] == mcd[0]:
                        af_mcd_enedis = pt_remplace[2]

                af_ec6_codeext = 'NC_FICHE'
                af_ec6_etude = 'NC_FICHE'
                af_ec6_struct = 'NC_FICHE'
                af_ec6_inv = 'NC_FICHE'
                af_ec6_visuel = 'NC_FICHE'
                af_ec6_vertica = 'NC_FICHE'
                af_ec6_flambe = 'NC_FICHE'
                af_ec6_voisin = 'NC_FICHE'
                af_ec6_pointe = 'NC_FICHE'
                af_ec6_secouss = 'NC_FICHE'
                af_ec6_percu = 'NC_FICHE'
                af_ec6_jaune = 'NC_FICHE'
                af_ec6_mobilis = 'NC_FICHE'
                af_ec6_ebp = 'NC_FICHE'
                af_ec6_ras = 'NC_FICHE'
                af_ec6_cable = 'NC_FICHE'
                af_ec6_eta = 'NC_FICHE'
                af_ec6_nat_tvx = 'NC_FICHE'
                af_ec6_environ = 'NC_FICHE'
                af_ec6_vois_el = 'NC_FICHE'
                af_ec6_strat = 'NC_FICHE'
                af_ec6_rehau = 'NC_FICHE'
                af_ec6_str_tvx = 'NC_FICHE'
                af_ec6_nature = 'NC_FICHE'
                af_owf_nature = 'NC_FICHE'
                af_ec6_dan_apr = 'NC_FICHE'
                af_ec6_com_etl = 'NC_FICHE'
                af_val_moe = ''
                af_com_moe = ''
                attachment = ''
                af_ec6_prive = 'NON'

                for var_ft in list_fiche_ft:
                    if str(mcd[1]).upper().find(
                            str(var_ft[0]).replace(str(var_ft[0])[2:3], '').upper()
                            if str(var_ft[0])[:3].upper() == 'FT_' else str(var_ft[0]).upper()) != -1:
                        af_ec6_codeext = var_ft[0]
                        af_ec6_etude = var_ft[1]
                        af_ec6_struct = var_ft[2]
                        af_ec6_inv = var_ft[3]
                        af_ec6_visuel = var_ft[4]
                        af_ec6_vertica = var_ft[5]
                        af_ec6_flambe = var_ft[6]
                        af_ec6_voisin = var_ft[7]
                        af_ec6_pointe = var_ft[8]
                        af_ec6_secouss = var_ft[9]
                        af_ec6_percu = var_ft[10]
                        af_ec6_jaune = var_ft[11]
                        af_ec6_mobilis = var_ft[12]
                        af_ec6_ebp = var_ft[13]
                        af_ec6_ras = var_ft[14]
                        af_ec6_cable = var_ft[15]
                        af_ec6_eta = var_ft[16]
                        af_ec6_nat_tvx = var_ft[17]
                        af_ec6_environ = var_ft[18]
                        af_ec6_vois_el = var_ft[19]
                        af_ec6_strat = var_ft[20]
                        af_ec6_rehau = var_ft[21]
                        af_ec6_str_tvx = var_ft[22]
                        af_ec6_nature = var_ft[23]
                        af_owf_nature = var_ft[24]
                        af_ec6_dan_apr = var_ft[25]
                        af_ec6_com_etl = var_ft[26]

                # Partie C3A
                af_c3a_numero_c3a = 'NC_C3A'
                af_c3a_travaux_appui = 'NC_C3A'
                af_c7_travaux_appui = 'NC_C7'
                if self.choix_c3a_c7 == True:
                    dict_af_c3a_travaux_appui = {}
                    for index_c3a in range(len(list_fiche_c3a)):
                        var_value_brute_c3a = list_fiche_c3a[index_c3a]
                        if var_value_brute_c3a[4] == af_mcd_etiquet_c3a or var_value_brute_c3a[5] == af_mcd_etiquet_c3a:
                            af_c3a_numero_c3a = 'OUI'
                            self.generalfunctions.function_create_dict(dict_af_c3a_travaux_appui, af_mcd_etiquet_c3a, var_value_brute_c3a[6])
                            self.generalfunctions.function_create_dict(dict_af_c3a_travaux_appui, af_mcd_etiquet_c3a, var_value_brute_c3a[7])
                    for key, value in dict_af_c3a_travaux_appui.items():
                        if key == af_mcd_etiquet_c3a:
                            af_c3a_travaux_appui = '/'.join([x for x in value if x])

                    # Partie C7
                    for index_c7 in range(len(list_fiche_c7)):
                        if af_mcd_etiquet_gespot == list_fiche_c7[index_c7][1]:
                            af_c7_travaux_appui = list_fiche_c7[index_c7][2]
                # Exporter tous les appuis hormis ceux qui ont que des cables RAC
                if 'OUI' in var_cable_appui:
                    list_res_export.append([af_mcd_etiquet, af_mcd_cable, af_mcd_zsro, af_mcd_gest, af_mcd_nature,
                                            af_mcd_a_struc, af_mcd_rac, af_mcd_eta, af_mcd_enedis,
                                            af_ec6_codeext, af_ec6_etude, af_ec6_struct, af_ec6_inv, af_ec6_visuel,
                                            af_ec6_vertica, af_ec6_flambe, af_ec6_voisin, af_ec6_pointe,
                                            af_ec6_secouss, af_ec6_percu, af_ec6_jaune, af_ec6_mobilis,
                                            af_ec6_ebp, af_ec6_ras, af_ec6_cable, af_ec6_eta, af_ec6_nat_tvx,
                                            af_ec6_environ, af_ec6_vois_el, af_ec6_strat, af_ec6_rehau,
                                            af_ec6_str_tvx, af_ec6_nature, af_owf_nature, af_ec6_dan_apr, af_ec6_com_etl,
                                            af_val_moe, af_com_moe, attachment, mcd[8], schema, af_mcd_pt_comment, 
                                            af_mcd_etiquet_gespot, af_mcd_etiquet_c3a, af_c3a_numero_c3a, af_c3a_travaux_appui, 
                                            af_c7_travaux_appui, af_ec6_prive])

                    list_res_export_trame.append([af_mcd_zsro, af_ec6_etude, af_mcd_gest, af_mcd_etiquet, af_ec6_mobilis,
                                                af_mcd_eta, af_ec6_environ, af_ec6_jaune, af_ec6_strat, af_ec6_inv,
                                                af_ec6_nat_tvx, af_ec6_rehau, af_ec6_nature, af_owf_nature, af_mcd_eta,
                                                af_ec6_visuel, af_mcd_cable])
            self.generalfunctions.progress_processing(index_mcd, len(list_ptech), bar_progress)
            if bar_progress.wasCanceled():
                iface.messageBar().pushMessage('Info', 'Action Cancelled', level=Qgis.Info)
                break
        return list_res_export, list_fichier_erreur + list_fichier_erreur_c3a + list_fichier_erreur_c7, list_res_export_trame

    # Execution de la function_compare_mcd_ft_fiche
    def function_execute_comare_mcd_ft(self):
        schema = self.schema
        name_tabe_a_appuift = 'a_appuift'
        list_insert_res, list_fichier_erreur, list_res_export_trame = self.function_compare_mcd_ft_fiche()
        list_trame_model = [['', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '',
                             'ETUDE AERIENNE - incoherence MCD : majeur', 'ETUDE AERIENNE - Défaut version : majeur',
                             'APPUI - Incoherence description : majeur', 'APPUI - Incoherence controle visuel : mineur',
                             'APPUI -  Defaut photos : majeur',
                             'APPUI - Defaut presence/absence RAS : mineur\nAPPUI - Defaut presence/absence BOITIER : mineur',
                             'APPUI - Defaut remplissage ; mineur\nAPPUI - Proximite reseau electrique : majeur\nAPPUI - Defaut presence/absence BOITIER à poser : mineur\nAPPUI - Defaut respect hauteur de ligne : mineur',
                             '', 'CABLES - Defaut nature : majeur (influence négative sur le calcul)',
                             'CABLES - Defaut nombre : majeur (influence négative sur le calcul)',
                             'ETUDE AERIENNE - Defaut orientation de la ligne : majeur',
                             "APPUI - Defaut orientation de l'appui : majeur", '',
                             'CABLES - Incoherence ecart des lignes existantes : mineur\nCABLES - Incoherence ecart des lignes à poser : majeur',
                             'APPUI - Defaut réhausse :mineur', 'majeur', '', '',
                             'étude à revoir\nétude raccordement\nétude CFI\nvalidée en état', '', '', '', ''],
                            ['af_mcd_zsro (cf. plugin)', 'af_ec6_etude (cf. plugin)', 'af_mcd_gest (cf. plugin)',
                             'af_mcd_etiquet (cf. plugin)', 'af_ec6_mobilis (cf. plugin)', 'af_ec6_eta (cf. plugin)',
                             'af_ec6_environ (cf. plugin)', 'af_ec6_jaune (cf. plugin)', 'af_ec6_strat (cf. plugin)',
                             'af_ec6_inv (cf. plugin)', 'af_ec6_nat_tvx (cf. plugin)', 'af_ec6_rehau (cf. plugin)',
                             'af_ec6_nature (cf. plugin)', 'af_owf_nature (cf. plugin)', 'af_mcd_eta (cf. plugin)',
                             'fx( af_visuel & af_eta_mcd)', 'af_mcd_cable (cf. plugin)', '', '', '', '', '', '', '', '',
                             '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''],
                            ['Référence de ZSRO\n(zs_refpm)', "Référence de l'étude\n(EFT_xxx_xxx.xls)",
                             "Type de l'étude\n(Orange)", 'Point technique\n(pt_etiquet)',
                             'Appui Utilisable\n(cf. Annexe C6)', "Résultat de l'étude\n(cf. Annexe C6)",
                             "Environnement de l'appui\n(cf. Annexe C6)", 'Absence Etiquette Jaune\n(cf. Annexe C6)',
                             'Appui stratégique\n(cf. Annexe C6)', 'Appui Inaccessible\n(cf. Annexe C6)',
                             'Nature des travaux\n(cf. Annexe C6)', 'Pose de réhausse\n(cf. Annexe C6)',
                             "Nature de l'appui\n(cf. Annexe C6)", "Nature de l'appui \n( calculé )",
                             "\nRésultat de l'étude\n(cf. MCD)", '\nAppui Mobilisable\nfx( E & F)',
                             '\nType de fibre\n(cb_capa_fo)', '\nCohérence\nSIG\n(Oui/Majeur)',
                             'Cohérence version CAPFT', "\nCohérence\nDescription de l'appui\n(Oui/Majeur)",
                             '\nCohérence\nContrôle Visuel\n(Oui/Mineur)', '\nCohérence\nPhotos\n(Oui/Majeur)',
                             '\nCohérence\nEquipements Existants\n(Oui/Mineur/Majeur)',
                             "\nRemplissage de la\nFiche d'Appui\n(Oui/Mineur/Majeur)",
                             "\nCohérence\nFiche d'Appui\n(Oui/Mineur/Majeur)",
                             '\nCohérence\nNature du cable\n(Oui/Majeur)', '\nCohérence\nNombre de cable\n(Oui/Majeur)',
                             '\nCohérence\nOrientation de la ligne\n(Oui/Majeur)',
                             "\nCohérence\nOrientation de l'appui\n(Oui/Majeur)",
                             '\nCohérence\nDescription de la ligne \n(Oui/Mineur/Majeur)',
                             'Cohérence\nécart des lignes\n(Oui/Mineur/Majeur)',
                             '\nCohérence\nPose de réhausse\n(Oui/Mineur)', 'travaux à réaliser',
                             'Contre Relevé terrain', "reste une possibilité de mobiliser l'appui",
                             "Synthèse de l'étude DEO", 'Commentaires DEO', 'Commentaires DEO', 'Commentaires DEO',
                             'Commentaires DEO']]

        bar_progress = self.generalfunctions.progress_bar('Execution de linsertion dans la table a_appui_ft')
        for index_insert, insert_bt in enumerate(list_insert_res):
            text_inf_insert = str(tuple(insert_bt)).replace('"', '').replace('None', "''")
            self.generalfunctions.function_insert_a_appuift(schema, text_inf_insert, name_tabe_a_appuift)
            self.generalfunctions.progress_processing(index_insert, len(list_insert_res), bar_progress)
            if bar_progress.wasCanceled():
                iface.messageBar().pushMessage('Info', 'Action Cancelled', level=Qgis.Info)
                break

        # Preparation des listes pour exporter les erreur
        list_error_open_fiche = []
        list_fichier_erreur_finale = []
        for index_error_open in list_fichier_erreur:
            # Error open file
            if index_error_open[0][0][:11] == self.error_open:
                list_error_open_fiche.append(index_error_open)
            # Error Format
            else:
                list_fichier_erreur_finale.append(index_error_open)
        self.cursor_bd.execute("""SET search_path = """ + schema + """, public; select * from """ +
                               name_tabe_a_appuift + """ limit 1""")
        columns = list(self.cursor_bd.description)
        entete_column = []
        for index_col in columns:
            entete_column.append(index_col.name)
        self.generalfunctions.function_export_infos_fiches(list_insert_res, self.path_export, 'Info_FT', entete_column)

        # Exportation de la trame
        len_list_trame_model = len(list_trame_model[0])  # len(list_trame_model) 40
        for index_trame in range(0, len(list_res_export_trame)):
            len_list_res_export_trame = len(list_res_export_trame[index_trame])
            difference_list_trame_export = len_list_trame_model - len_list_res_export_trame
            if difference_list_trame_export == 23:
                list_res_export_trame[index_trame] = list_res_export_trame[index_trame] + [
                    ''] * difference_list_trame_export
                list_trame_model.append(list_res_export_trame[index_trame])
            # except:
            #     return QMessageBox.warning(self.generalfunctions.w, "Message de trame", 'Probleme de longueur entre la trame et la donnnee')
        entete = ['\nRenseigner la\nRéférence de ZSRO', "\nRenseigner la\nRéférence de l'étude\nCAPFT",
                  '\nRenseigner le\nType détude\n\nORANGE, pour ORANGE',
                  "\nRenseigner le\nNuméro d'appui\n\nCohérence de nommage:\nFT_[N°GESPOT], calculé\nERDFYXXX, appui ERDF non calculé au global",
                  "\nRenseigner le\nRésultat du contrôle visuel\nréalisé par l'entreprise\n\nOUI, Bon état\nNON, Mauvais état\n",
                  "\nRenseigner le\nRésultat de l'étude\nréalisée par l'entreprise\n\nOK, Bon état\nINSUFFISANT, Insuffisant\n",
                  '\nRenseigner\nEnvironnement\n\n\nTER, Pleine Terre\nBMP, Béton Macadam Pavé\n',
                  '\nRenseigner si\nAbsence Etiquette Jaune\n\n\nOUI,\nNON',
                  '\nRenseigner si\nAppui stratégique\n\n\nTRM, TDL , …\nNON\n',
                  '\nRenseigner si\nAppui inaccessible\n\n\nINV, IN1, …\nNON',
                  "\nRenseigner la\nNature des travaux\nproposé par l'entreprise\n\nRECALAGE,\nRENFORCEMENT,\nREMPLACEMENT",
                  "\nRenseigner l'\nInstallation de réhausse\nproposé par l'entreprise\n\nOUI,\nNON",
                  "\nRenseigner la\nNature de l'appui\nproposé par l'entreprise\n\nPBOI, Poteau Bois\nPMET, Poteau Métal\nPCOM, Poteau Composite",
                  "\nRenseigner la\nNature de l'appui\npreconisé par OWF\n\nPBOI, Poteau Bois\nPMET, Poteau Métal\nPCOM, Poteau Composite",
                  "\nRenseigner le\nRésultat de l'étude\nréalisé par l'entreprise\n\nOK, Bon état\nME, Mauvais état\nHS, Insuffisant",
                  "\nIndiquer\nsi l'appui est\nmobilisable en l'etat\nsuite à l'étude\nréalisé par l'entreprise\n\nOK . OK > OK\nME + (TRAVAUX) > KO\nHS . (TRAVAUX)  > KO",
                  "\nRenseigner le\nType de fibre à poser\nsur l'appui",
                  "\nIndiquer\nla coherence entre le\nMCD et l'etude CAPFT\n(Cable)\n\n\n\n(Majeur, si erreur dans CAPFT)",
                  'vide1',
                  "\nIndiquer\nsi coherence des caracteristiques d'appui\nentre la Fiche d'Appui, l'etude CAPFT et les Photos\n\n\n(Majeur, si erreur dans CAPFT)",
                  "\nIndiquer\nla cohérence du\n contrôle visuel entre  les photos, la fiche d'Appui, l'etude COMAC\n\n\n(Majeur, si erreur dans CAPFT)",
                  "\nIndiquer\nsi presence des \nphotos de l'appui \ndans la fiche d'Appui\n\n(Mineur, si pas de travaux sur l'appui)\n(Majeur, si fiche à fournir avant travaux)",
                  "\nIndiquer\nsi coherence des\néquipements Existants entre la Fiche d'Appui, l'etude CAPFT et les Photos\n\n(Majeur, si  équipement\nà poser)",
                  "\nIndiquer\nComplétude de la \nfiche d'Appui\n\n\n(Mineur, si environnement, adresse et pas de travaux)\n\n(Majeur, si etat de l'appui ou equipement à poser)",
                  "\nSynthèse\nde la cohérence de la\nfiche d'Appui \navec l'étude CAPFT\n\n(Mineur, si abscence de fiche d'appui)\n(Majeur, si  équipement\nà poser, ou travaux)",
                  "\nIndiquer\nla cohérence de la \nnature cable existant\nentre la fiche d'Appui, l'etude CAPFT\n\n\n(Majeur, si erreur dans CAPFT)",
                  "\nIndiquer\nla cohérence du\nnombre de cable existant\nentre la fiche d'Appui, l'etude CAPFT\n\n\n(Majeur, si erreur dans CAPFT)",
                  "\nIndiquer\nla cohérence de\nl'orientation de la ligne\nentre le SIG, les photos\net l'etude CAPFT\n(angles >20g, longueur)\n\n(Majeur, si erreur dans CAPFT)",
                  "\nIndiquer\nla cohérence de\nl'orientation de l'appui\nentre les photos\net l'etude CAPFT\n\n\n(Majeur, si erreur dans CAPFT)",
                  '\nSynthèse\nde la cohérence de la\ndescription de la ligne dans CAPFT\n(Existant et Projeté)\n\n\n(Majeur, si erreur dans CAPFT)',
                  "\nIndiquer\nla cohérence des\nhauteurs d'ancrage\ndans l'etude CAPFT\n(Haute, Standard, Basse)\n\n(Mineur,  sur existant)\n(Majeur, sur fibre à poser)",
                  "\nIndiquer\nla cohérence de\nla pose de rehausse\ndans l'etude CAPFT\n\n\n(Mineur, si 15cm de libre en tete d'appui, pas de réhausse)",
                  '\nIndiquer\nsi le choix des travaux à réaliser\nest cohérent', 'vide2',
                  "\nIndiquer\nsi l'appui est susceptible d'être utilisé\n\nOK, si mobilisable\n\nKO, si non mobilisable",
                  "faire la synthèse de l'étude en indiquant: \nétude à revoir\nvalidée en état\nétude raccordement\nétude CFI",
                  'indiquer que les réserves majeures1', 'indiquer que les réserves majeures2',
                  'indiquer que les réserves majeures3', 'indiquer que les réserves majeures4']
        self.generalfunctions.function_export_infos_fiches(list_trame_model, self.path_export, 'Info_FT_Trame', entete)
        return list_fichier_erreur_finale, list_error_open_fiche


# Class pour exporter des tables csv et shp dans bdd
class ExportMultiplesTablesCsvShp:

    w = QWidget()
    # Function initialisation
    def __init__(self, var_connection, var_schema, var_folder_export_data, var_list_table_export):
        # GeneralFunctions.__init__(self, self.connection)
        self.connection = var_connection
        global host, DB, user, MP, port
        self.schema = var_schema
        self.conn_string = f"PG: host={host} dbname={DB} user={user} password={MP} ACTIVE_SCHEMA={self.schema}"
        self.folder_export_data = var_folder_export_data
        self.list_table_export = var_list_table_export
        self.name_column_geom = 'geom'
        self.name_column_geom_wkb = 'geom_wkb'
        self.var_list_ignore_column = [self.name_column_geom, self.name_column_geom_wkb]
        self.name_srid = 2154
        self.db_cursor = self.connection.cursor()
        self.liste_error_traitement = []
        self.function_export_mutiples_tables()

    # Function Export all tables bdd dynamic
    def function_export_mutiples_tables(self):
        try:
            req_dynamic_table = f"""set search_path to {self.schema}, public;
                SELECT 
                    table_schema, 
                    table_name,
                    geom_table.f_table_schema,
                    geom_table.f_table_name,
                    geom_table.f_geometry_column,
                    geom_table.type
                FROM information_schema.tables 
                    left join (
                        select * from geometry_columns WHERE f_table_schema='{self.schema}'
                        ) as geom_table on geom_table.f_table_name = table_name
                WHERE table_schema='{self.schema}' and table_name in {self.list_table_export };"""
            self.db_cursor.execute(req_dynamic_table)  # 'a_appuibt_export', 'a_appuift_export'
            res_req_dynamic_table = self.db_cursor.fetchall()
            for index_row in range(len(res_req_dynamic_table)):
                var_row = res_req_dynamic_table[index_row]
                var_table_name = var_row[1]
                var_column_geom = var_row[4]
                if str(var_column_geom) != str(self.name_column_geom):  # Uniquement les csv
                    self.function_export_csv_bdd(var_table_name)
                elif str(var_column_geom) == str(self.name_column_geom):  # Uniquement les shp
                    self.function_create_shp_from_bdd(var_table_name)
                else:
                    self.liste_error_traitement.append(['function_export_mutiples_tables',
                                                        f'Le nom {var_column_geom} nest pas dans la condition'])
        except Exception as error:
            self.liste_error_traitement.append(['function_export_mutiples_tables',
                                               f"Partie Export en masse: Probleme dexecution des exports en masse..."
                                               f"{error}"])

    # Function Export CSV from BDD
    def function_export_csv_bdd(self, name_table):
        try:
            var_sql = f"COPY (SELECT * FROM {self.schema}.{name_table}) TO STDOUT WITH HEADER CSV DELIMITER ';'"
            with open(f"{self.folder_export_data}/{name_table}.csv", 'w') as var_file:
                self.db_cursor.copy_expert(var_sql, var_file)
        except Exception as error:
            self.liste_error_traitement.append(['function_export_csv_bdd',
                                                f"Probleme dexport sur cette table: {name_table}. Erreur : {error}"])

    # Recuperation du type de geometry de la table pour pouvoir creer le shape
    def function_get_geometry_type_from_pg(self, table_pg):
        try:
            # return the GeometryType from a Pg Table
            query = f"SELECT ST_AsText({self.name_column_geom})  FROM {self.schema}.{table_pg}"
            self.db_cursor.execute(query)
            res = self.db_cursor.fetchone()
            if res is None:  # Les tables vides sont converties en Polygon
                geometrytype = ogr.Geometry(ogr.wkbPolygon).GetGeometryType()
            else:
                # {geometrytype = ogr.CreateGeometryFromWkb(bytes(res[0])).GetGeometryType() # Avec ST_AsEWKB
                geometrytype = ogr.CreateGeometryFromWkt(res[0]).GetGeometryType()
            return geometrytype
        except Exception as error:
            self.liste_error_traitement.append(['function_get_geometry_type_from_pg',
                                                f"Probleme de recuperation de la geometrie sur cette table: {table_pg}"
                                                f". Erreur : {error}"])

    # Function pour recuperer tous les attributs, leur type, leur longueur ainsi que leur precision
    def function_get_pg_layerfield_types(self, table_pg):
        try:
            # return a Dictionary with Pg table field name and Ogr feature
            conn = ogr.Open(self.conn_string)
            layer = conn.GetLayer(table_pg)
            if layer is None:
                self.liste_error_traitement.append(['function_get_pg_layerfield_types',
                                                    f'Erreur Lecture de la table {table_pg}'])
            else:
                lyr_feature = layer.GetLayerDefn()
                pgtable_fields = {}
                for i in range(lyr_feature.GetFieldCount()):
                    field_name = lyr_feature.GetFieldDefn(i).GetName()
                    field_type_code = lyr_feature.GetFieldDefn(i).GetType()
                    field_width = lyr_feature.GetFieldDefn(i).GetWidth()
                    get_precision = lyr_feature.GetFieldDefn(i).GetPrecision()
                    if field_type_code == 11:
                        field_type_code = 9
                    pgtable_fields[f"{field_name[:7]}_{i}"] = field_type_code, field_width, get_precision
                conn.Destroy()
                return pgtable_fields
        except Exception as error:
            self.liste_error_traitement.append(['function_get_pg_layerfield_types',
                                                f"Probleme de recuperation des attributs sur cette table: {table_pg}"
                                                f".\nErreur : {error}"])
    
    # Function Get Data from BDD to Dict cursor_factory=psycopg2.extras.DictCursor
    def function_get_data_from_bdd_to_dict(self, table_pg):
        try:
            var_db_cursor = self.connection.cursor()
            query = f"SELECT *, ST_AsText ({self.name_column_geom}) as {self.name_column_geom_wkb}   FROM {self.schema}.{table_pg}"
            var_db_cursor.execute(query)
            res_data = var_db_cursor.fetchall()
            res_data_column = [i[0] for i in var_db_cursor.description]
            var_db_cursor.close()
            return res_data, res_data_column
        except Exception as error:
            self.liste_error_traitement.append(['function_get_data_from_bdd',
                                                f"Probleme de recuperation des entites en DICT "
                                                f"sur cette table: {table_pg}.\nErreur : {error}"])

    # Function Export Shapefile from BDD
    # https://github.com/francot/python-ogr-postgis-tools/blob/master/export_import_postgis_shp.py
    def function_create_shp_from_bdd(self, name_table):
        try:
            # using the above function, return a shpfile from Pg table
            # set up the shapefile driver
            driver = ogr.GetDriverByName("ESRI Shapefile")
            # create the data source
            data_source = driver.CreateDataSource(f"{self.folder_export_data}/{name_table}_export.shp")
            # create the spatial reference
            srs = osr.SpatialReference()
            srs.ImportFromEPSG(self.name_srid)
            # create the layer
            layer = data_source.CreateLayer(name_table, srs, self.function_get_geometry_type_from_pg(name_table))
            # Process the output dictionary from PgTableAsDict function and add features to the shapefile
            var_res_data_dict, var_data_column = self.function_get_data_from_bdd_to_dict(name_table)
            for index_col in range(len(var_data_column)):
                var_val_brute = var_data_column[index_col]
                var_normalise_name_column = var_val_brute
                if len(var_val_brute) > 10:
                    var_normalise_name_column = f"{var_val_brute[:7]}_{index_col}"
                var_field_name = ogr.FieldDefn(var_normalise_name_column, ogr.OFTString)
                var_field_name.SetWidth(254)
                if var_val_brute not in self.var_list_ignore_column:
                    layer.CreateField(var_field_name)
            feature = ogr.Feature(layer.GetLayerDefn())
            for index_dt in range(len(var_res_data_dict)):
                var_data_entite_list = var_res_data_dict[index_dt]
                for index_col in range(len(var_data_column)):
                    var_data_entite_val = var_data_entite_list[index_col]
                    var_val_brute = var_data_column[index_col]
                    var_normalise_name_column = var_val_brute
                    if len(var_val_brute) > 10:
                        var_normalise_name_column = f"{var_val_brute[:7]}_{index_col}"
                    if var_val_brute == self.name_column_geom_wkb:
                        geometrytype = ogr.CreateGeometryFromWkt(f"{var_data_entite_val}")
                        feature.SetGeometry(geometrytype)
                    else:
                        if var_val_brute not in self.var_list_ignore_column:
                            feature.SetField(var_normalise_name_column, f"{var_data_entite_val}"[:253])
                layer.CreateFeature(feature)
            feature.Destroy()
            data_source.Destroy()
        except Exception as error:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            self.liste_error_traitement.append(['function_create_shp_from_bdd',
                                                f"Probleme dexport du shp sur cette table: {name_table}."
                                                f". Erreur : ...{error} ... {exc_tb.tb_lineno}"])


# Class Import des donnees dans la BDD
class ImportMultiplesFilesCsvShp(GeneralFunctions):
    # Function initialisation
    def __init__(self, var_connection, var_schema, var_folder_data):
        # GeneralFunctions.__init__(var_connection)
        super(ImportMultiplesFilesCsvShp, self).__init__(var_connection)
        self.schema = var_schema
        self.folder_data = var_folder_data
        self.files_import = []
        self.list_error = []
        self.name_srid = 2154
        self.db_cursor = self.connection.cursor()
        self.function_import_mutiples_files()  # Execution des imports a linitialisation de la classe
        # self.connection.close()

    # Function Rename doublons name column
    @staticmethod
    def function_rename_column_name(var_list_column):
        dups = {}
        for i, val in enumerate(var_list_column):
            if val not in dups:
                # Store index of first occurrence and occurrence value
                dups[val] = [i, 1]
            else:
                # Special case for first occurrence
                if dups[val][1] == 1:
                    var_list_column[dups[val][0]] += str(dups[val][1])
                # Increment occurrence value, index value doesn't matter anymore
                dups[val][1] += 1
                # Use stored occurrence value
                var_list_column[i] += str(dups[val][1])
        return var_list_column

    # Function pour Importer des fichiers csv dans une BDD
    def function_insert_csv_bdd(self, var_file):
        try:
            # https://stackoverflow.com/questions/48085319/python-reading-and-writing-csv-files-with-utf-8-encoding
            with open(var_file, encoding="utf-8-sig", errors='ignore') as f:
                reader_file = csv.reader(f, delimiter=';')
                header = next(reader_file)
                file_name = '"' + os.path.basename(var_file).split('.')[0].replace(' ', '_').replace('-', '_').lower()\
                            + '_vt' + '"'
                # Creation de la table
                list_column = ["nan" if key == '' else re.sub('[^a-zA-Z]', '_', str(key)) for key in header]
                list_column_rename = self.function_rename_column_name(list_column)
                list_column_text = [str(key) + ' text' for key in list_column_rename]
                req_create_table = f"DROP TABLE IF EXISTS {self.schema}.{file_name};" \
                                   f"CREATE TABLE {self.schema}.{file_name}({','.join(list_column_text)})"
                self.db_cursor.execute(req_create_table)
                # Insertion des elements dans la table creee
                list_all_feature_insert = []
                for index in reader_file:
                    list_tuple = tuple(index)
                    list_replace_carac = [str(key).replace("'", '').replace('"', '') for key in list_tuple]
                    values_features = str(tuple(list_replace_carac))
                    list_all_feature_insert.append(values_features)
                if list_all_feature_insert:
                    var_req_insert = f"INSERT INTO {self.schema}.{file_name}({','.join(list_column_rename)})" \
                                     f"values{','.join(list_all_feature_insert)}"
                    self.db_cursor.execute(var_req_insert)
        except Exception as error:
            self.list_error.append(['function_insert_csv_bdd',
                                    f"Partie Import SHP: Probleme Import SHP...Le CSV {var_file} "
                                    f"nest pas importe...{error}"])

    # Function pour Importer des fichiers shp dans une BDD
    def function_insert_shp_bdd(self, var_shp):
        try:
            drv = ogr.GetDriverByName('ESRI Shapefile')
            file = drv.Open(var_shp, 0)
            if file is None:
                self.list_error.append(['function_insert_shp_bdd',
                                        f"Partie Import SHP: Probleme Import SHP...Le Shape {var_shp} "
                                        f"ne peut pas etre ouvert"])
            else:
                shape_feature = file.GetLayer(0)
                var_file_name = os.path.basename(var_shp).split('.')[0]
                # '"' + os.path.basename(var_shp).split('.')[0].replace(' ', '_').replace('-', '_').lower() + '_vt' + '"'
                dict_convert_type_field = {'String': 'character varying', 'Date': 'text',
                                           'Integer': 'Integer', 'Real': 'real', 'Integer64': 'Integer'}
                # Column_name et type
                list_column = []
                list_column_text = []
                for field in shape_feature.schema:
                    # print(field.name, ';', field.GetTypeName(), ';', field.GetType(), ';', field.GetWidth(), ';',
                    #       field.GetPrecision())
                    field_name = str(field.name).replace(' ', '_').replace('-', '_')
                    field_type_name = str(dict_convert_type_field[field.GetTypeName()])
                    field_width = str(field.GetWidth())
                    if field.GetTypeName() == 'String':
                        field_name_prepare = f"{field_name} {field_type_name}({str(field_width)})"
                    else:
                        field_name_prepare = f"{field_name} {field_type_name}"
                    list_column.append(field_name)
                    list_column_text.append(field_name_prepare)
                # Ajout de la colonne geometry
                list_column.append('geom')
                list_column_text.append('geom geometry')
                # Creation de la table
                req_create_table = f"DROP TABLE IF EXISTS {self.schema}.{var_file_name};" \
                                   f"CREATE TABLE {self.schema}.{var_file_name}({','.join(list_column_text)})"
                # Execution de la creation de la table
                self.db_cursor.execute(req_create_table)
                # Parcours du shape plus prepapration des donnees a inserer
                list_all_feature_insert = []
                for n in range(shape_feature.GetFeatureCount()):
                    feature_shp = shape_feature.GetFeature(n)
                    feature_json = json.loads(feature_shp.ExportToJson())
                    geaom_feature = f"ST_GeomFromText('{str(feature_shp.geometry())}', {self.name_srid})"
                    list_values_attributs = list(feature_json['properties'].values())
                    list_appen_geom_feature = [None if field is None else str(field).replace("'", '')
                                               for field in list_values_attributs]
                    list_appen_geom_feature.append(geaom_feature)
                    tuple_appen_geom_feature = str(tuple(list_appen_geom_feature)).replace('"', '')
                    list_all_feature_insert.append(tuple_appen_geom_feature)
                # Insertion des elements dans la table
                if list_all_feature_insert:
                    var_req_insert = f"INSERT INTO {self.schema}.{var_file_name}({','.join(list_column)}) " \
                                     f"values{','.join(list_all_feature_insert)}".replace('None', 'NULL')
                    self.db_cursor.execute(var_req_insert)
        except Exception as error:
            self.list_error.append(['function_insert_shp_bdd',
                                    f"Partie Import SHP: Probleme Import SHP...Le Shape {var_shp} nest pas importe"
                                    f"nest pas importe...{error}"])

    # Function Execution en masse des Imports des fichiers CSV/SHP dans une BDD
    def function_import_mutiples_files(self):
        try:
            if self.folder_data:
                # Creation du schema import
                self.db_cursor.execute(f"CREATE SCHEMA IF NOT EXISTS {self.schema};")
                folder_iterate = os.listdir(self.folder_data)
                bar_progress = self.progress_bar('Partie Import en Masse des donnees')
                for index_char_qgis, file_etude in enumerate(folder_iterate):
                    chemin = self.folder_data
                    name, ext = os.path.splitext(file_etude)
                    chem_etude = f"{chemin}/{file_etude}"
                    if ext == ".shp":
                        self.function_insert_shp_bdd(chem_etude)
                        self.files_import.append(file_etude)
                    # elif ext in (".dbf", ".cpg", ".prj", ".shx", ".log", ".sbn", ".sbx", ".qgz", ".qpj", ".qml"):
                    #     continue
                    # else:
                    #     self.list_error.append(['function_import_mutiples_files',
                    #                             f"Partie Import chaque table: Le fichier {name}_{ext} "
                    #                             f"ne sera pas importe puisse quil nest pas un csv ni un shape"])
                    self.progress_processing(index_char_qgis, len(folder_iterate), bar_progress)
                    if bar_progress.wasCanceled():
                        iface.messageBar().pushMessage('Info', 'Action Cancelled', level=Qgis.Info)
                        break
                self.connection.commit()
                self.db_cursor.close()
                # self.connection.close()
                return self.files_import
            else:
                self.list_error.append(['function_import_mutiples_files',
                                        f"Partie Import en masse: Probleme choix repertoire des donnees..."
                                        f"{self.folder_data}"])
        except Exception as error:
            self.list_error.append(['function_import_mutiples_files',
                                    f"Partie Import en masse: Probleme dexecution des imports en masse...{error}"])


def function_execute_class_traitementdpi(var_schema, var_path_folder_comac, var_path_folder_shp_export,
                                         var_path_folder_ft, var_path_folder_c3a, var_path_folder_c7, var_choix_c3a_c7):
    w = QWidget()
    try:
        # Partie Connexion a la base
        connection = function_connexion()  # psycopg2.connect(user=user, password=MP, host=host, port=port, database=DB)
    except Exception as error:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        return QMessageBox.warning(w, "Message de connexion de la base", f"Erreur de connexion de la base__{exc_tb.tb_lineno}__{error}")
    var_generalfunctions = GeneralFunctions(connection)  # Intinialisation Connexion
    var_drop = f"""SET search_path TO {var_schema}, public;
        GRANT ALL ON SCHEMA {var_schema} TO adn_ing;
        GRANT SELECT, INSERT, Update ON ALL TABLES IN SCHEMA {var_schema} TO adn_ing;
        ALTER DEFAULT PRIVILEGES IN SCHEMA {var_schema} GRANT SELECT, INSERT, UPDATE  ON TABLES TO adn_ing;"""
    var_generalfunctions.function_execute_requete(var_drop, '')
    var_generalfunctions.function_create_table_l_appuift('', var_schema)  # Creation de la table l_appuift

    # Partie creation de la table a_appuibt
    try:
        var_generalfunctions.function_creatTable_a_appuibt(var_schema, 'a_appuibt')  # Creation Table a_appuibt
        var_generalfunctions.function_creatTable_a_appuift(var_schema, 'a_appuift')  # Creation Table a_appuift
    except Exception as error:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        return QMessageBox.warning(w, "Message de Traitement", f"Erreur Execution creation des tables:__{exc_tb.tb_lineno}__{error}")

    # Partie Traitement DPI
    try:
        var_traitementdpi = TraitementDpi(var_schema, var_path_folder_comac, connection, var_path_folder_ft, var_path_folder_shp_export, 
        var_path_folder_c3a, var_path_folder_c7, var_choix_c3a_c7)
        res_traitement_bt, res_traitement_bt_list_error_open_fiche = var_traitementdpi.function_execute_compare_mcd_comac()  # Function Compare MCD / Comac
        res_traitement_ft, res_traitement_ft_error_open_fiche = var_traitementdpi.function_execute_comare_mcd_ft()  # Function Compare MCD / Fiches FT
    except Exception as error:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        return QMessageBox.warning(w, "Message de Traitement", f"Erreur Execution Traitement DPI: __{exc_tb.tb_lineno}__{error}")

    # Partie export des tables crees
    try:
        var_res_export = ExportMultiplesTablesCsvShp(connection, var_schema, var_path_folder_shp_export, tuple(['a_appuibt', 'a_appuift']))
        var_error_traitement = var_res_export.liste_error_traitement
    except Exception as error:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        return QMessageBox.warning(w, "Message Export des appuis", f"ERREUR Export des resultats Delta: __{exc_tb.tb_lineno}__{error}")

    # Partie pour exporter les erreur de format des fiches
    try:
        var_generalfunctions.function_export_error_fichier(res_traitement_bt, var_path_folder_shp_export, 'appuis_bt', 'Erreur_format_fichier_')
        var_generalfunctions.function_export_error_fichier(res_traitement_bt_list_error_open_fiche, var_path_folder_shp_export, 'appuis_bt', 'Erreur_open_fichier_')
        var_generalfunctions.function_export_error_fichier(res_traitement_ft, var_path_folder_shp_export, 'appuis_ft', 'Erreur_format_fichier_')
        var_generalfunctions.function_export_error_fichier(res_traitement_ft_error_open_fiche, var_path_folder_shp_export, 'appuis_ft', 'Erreur_open_fichier_')
    except Exception as error:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        return QMessageBox.warning(w, "Message Export des fiches", f"ERREUR Export des erreur format fiches: __{exc_tb.tb_lineno}__{error}")

    QMessageBox.information(w, "Message-Plugin", 'Execution du Traitement Reussi. Les Shapes Export sont exportes '
                                                 'dans le repertoire suivant : ' + var_path_folder_shp_export)
    connection.close()


class RetourVt(GeneralFunctions):
    # Constructeur des variables qui change
    def __init__(self, var_schema, var_folder_vt_data, var_folder_exporter_deltat):
        self.connection = function_connexion()
        super(RetourVt, self).__init__(self.connection)
        self.schema = var_schema
        self.folder_vt_data = var_folder_vt_data
        self.folder_exporter_deltat = var_folder_exporter_deltat
        self.db_cursor = self.connection.cursor()
        self.w = QWidget()
        self.a_appuift = 'a_appuift'
        self.a_appuibt = 'a_appuibt'
        self.a_appuibt_delta = 'a_appuibt_delta'
        self.a_appuift_delta = 'a_appuift_delta'
        self.column_geom = 'geom'

        self.function_check_deltat_export_vt()

        self.connection.close()
        self.db_cursor.close()

    # Function pour chargement des couches dans Qgis
    def function_chargement_layer_qgis(self):
        path_folder = self.path_folder
        bar_progress_char_qgis = self.generalfunctions.progress_bar('Chargement des donnees dans Qgis')
        if path_folder:
            # Declaration des noms des groupes a travers la function de creatino des groups
            shape_group = self.generalfunctions.function_create_groupe_name('SHAPE_Visite_terrain')
            folder_iterate = os.listdir(path_folder)
            for index_char_qgis, file_etude in enumerate(folder_iterate):
                chemin = path_folder
                name, ext = os.path.splitext(file_etude)
                chem_etude = chemin + '/' + file_etude
                if ext == ".shp" and name in ('a_appuift', 'a_appuibt'):
                    layer_shp_etude = QgsVectorLayer(chem_etude, name, 'ogr')
                    try:
                        self.generalfunctions.function_add_layer_group(layer_shp_etude, shape_group)
                    except(Exception) as error:
                        QMessageBox.warning(self.w, "Message dexecution de requete",
                                            'Erreur dexecution du chargement du shape dans Qgis' + name)
                self.generalfunctions.progress_processing(index_char_qgis, len(folder_iterate), bar_progress_char_qgis)
                if bar_progress_char_qgis.wasCanceled():
                    iface.messageBar().pushMessage('Info', 'Action Cancelled', level=Qgis.Info)
                    break

    # Function pour insertion des retours terrains
    def function_insert_a_appui_bt_ft_vt(self, layer_name_appui):
        schema = self.schema
        bar_progress_insert = self.generalfunctions.progress_bar('Insertion des donnees VT dans la BDD')
        len_maplayer = len(QgsProject.instance().mapLayers().values())
        for index_map, layers_name_mapLayers in enumerate(QgsProject.instance().mapLayers().values()):
            layer_name = layers_name_mapLayers.name()
            layer_features = layers_name_mapLayers.getFeatures()
            if layer_name == layer_name_appui:  # 'a_appuibt':
                list_insert_entite = []
                if layers_name_mapLayers.type() == QgsMapLayer.VectorLayer:
                    layer_not_empty = len(list(layer_features))
                    if layer_not_empty > 0:
                        # list_insert_entite = []
                        layer_features = layers_name_mapLayers.getFeatures()
                        for index_layer, layer in enumerate(layer_features):
                            geome_text = layer.geometry().asWkt()
                            if geome_text:  # 'NULL' if field == NULL else
                                attr_insert = str(
                                    tuple(['NULL' if field == NULL else str(field).replace("'", '').replace(
                                        '"', '') for field in layer.attributes()]) + tuple(['ST_GeomFromText(' + "'" +
                                                                                            geome_text + "'" + ',2154)'])).replace(
                                    '"', '')
                                # print(attr_insert)
                                # break
                                list_insert_entite.append(attr_insert)
                req_insert_finale = ','.join(list_insert_entite)
                if layer_name_appui == 'a_appuibt':
                    self.generalfunctions.function_insert_a_appuibt_vt(schema, req_insert_finale)
                elif layer_name_appui == 'a_appuift':
                    self.generalfunctions.function_insert_a_appuift(schema, req_insert_finale, 'a_appuift_vt')
            self.generalfunctions.progress_processing(index_map, len_maplayer, bar_progress_insert)
            if bar_progress_insert.wasCanceled():
                iface.messageBar().pushMessage('Info', 'Action Cancelled', level=Qgis.Info)
                break
    
    # Function check Delta
    def function_check_deltat_export_vt(self):
        list_bt_nc_vt = [12, 13, 14, 17, 18, 19, 20, 21, 22, 23, 24, 25, 31]
        list_ft_nc_vt = [9, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 26, 27, 28, 29, 30, 32]
        try:
            # Partie Import Data Retour Terrain
            var_retour_terrain = ImportMultiplesFilesCsvShp(self.connection, self.schema, self.folder_vt_data)
            var_erreur_import_vt = var_retour_terrain.list_error
            if var_erreur_import_vt:
                QMessageBox.warning(self.w, "Message Erreur Import VT", f"{str(var_erreur_import_vt)}")
            else:
                # Partie Delta FT
                a_appuift_export = f"""set search_path to {self.schema}, public;
                    ALTER TABLE {self.a_appuift} ADD COLUMN IF NOT EXISTS geom_second geometry(Geometry,2154);
                    UPDATE {self.a_appuift} SET geom_second = {self.column_geom};
                    ALTER TABLE {self.a_appuift} DROP COLUMN IF EXISTS {self.column_geom};
                    ALTER TABLE {self.a_appuift} RENAME COLUMN geom_second TO {self.column_geom};
                    select * from {self.a_appuift} order by af_mcd_etiquet;
                    """
                a_appuift_vt = f"""set search_path to {self.schema}, public; select * from {self.a_appuift}_export order by af_mcd__0;"""
                self.db_cursor.execute(a_appuift_export)
                list_export_a_appui_ft = self.db_cursor.fetchall()
                self.db_cursor.execute(a_appuift_vt)
                list_vt_a_appui_ft = self.db_cursor.fetchall()
                self.function_deltat_vt_check(list_export_a_appui_ft, list_vt_a_appui_ft, self.a_appuift, self.schema, list_ft_nc_vt)

                # Partie Delta BT
                a_appuibt_export = f"""set search_path to {self.schema}, public; 
                    ALTER TABLE {self.a_appuibt} ADD COLUMN IF NOT EXISTS geom_second geometry(Geometry,2154);
                    UPDATE {self.a_appuibt} SET geom_second = {self.column_geom};
                    ALTER TABLE {self.a_appuibt} DROP COLUMN IF EXISTS {self.column_geom};
                    ALTER TABLE {self.a_appuibt} RENAME COLUMN geom_second TO {self.column_geom};
                    select * from {self.a_appuibt} order by ab_mcd_etiquet"""
                a_appuibt_vt = f"""set search_path to {self.schema}, public; select * from {self.a_appuibt}_export order by ab_mcd__0;"""
                self.db_cursor.execute(a_appuibt_export)
                list_export_a_appui_bt = self.db_cursor.fetchall()
                self.db_cursor.execute(a_appuibt_vt)
                list_vt_a_appui_bt = self.db_cursor.fetchall()
                self.function_deltat_vt_check(list_export_a_appui_bt, list_vt_a_appui_bt, self.a_appuibt, self.schema, list_bt_nc_vt)

                # Partie Export Delta
                var_res_export = ExportMultiplesTablesCsvShp(self.connection, self.schema, self.folder_exporter_deltat, tuple([self.a_appuibt_delta, self.a_appuift_delta]))
                var_erreur_export_deltat = var_res_export.liste_error_traitement
                if var_erreur_export_deltat:
                    QMessageBox.warning(self.w, "Message Erreur Export Deltat", f"{str(var_erreur_export_deltat)}")
                else:
                    QMessageBox.information(self.w, "Message Fin", f"Succes")
                                                    
        except Exception as error:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            QMessageBox.warning(self.w, "Message de Traitement", f"Erreur Traitement Global Retour Terrain Delta: {exc_tb.tb_lineno}___{str(error)}")


def function_execute_retourvt(var_schema, path_folder_shp_vt, path_folder_shp_export_delta):
    w = QWidget()

    list_error = []
    list_bt_nc_vt = [12, 13, 14, 17, 18, 19, 20, 21, 22, 23, 24, 25, 31]
    list_ft_nc_vt = [9, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 26, 27, 28, 29, 30, 32]
    try:
        var_connection = function_connexion()

        # Partie Import retour Terrain
        var_connexion = GeneralFunctions(var_connection)
        var_retour_terrain = ImportMultiplesFilesCsvShp(var_connexion.connection, var_schema, path_folder_shp_vt)
        var_error_vt = var_retour_terrain.list_error
        list_error = var_error_vt

        # Partie Delta FT
        a_appuift_export = f"""set search_path to {var_schema}, public;
            select * from a_appuift order by af_mcd_etiquet;"""
        a_appuift_vt = f"""set search_path to {var_schema}, public;
            --- Suppression coloumn schema Pour le creer apres column geometrie pour garder la meme structure que les exports 
            ALTER TABLE a_appuift_vt DROP COLUMN IF EXISTS name_schem;
            ALTER TABLE a_appuift_vt DROP COLUMN IF EXISTS name_schema;
            ALTER TABLE a_appuift_vt ADD COLUMN IF NOT EXISTS name_schema text;
            select * from a_appuift_vt order by af_mcd_eti;"""
        list_export_a_appui_ft = var_connexion.function_execute_requete(a_appuift_export, 'req_fetch')
        list_vt_a_appui_ft = var_connexion.function_execute_requete(a_appuift_vt, 'req_fetch')
        var_connexion.function_deltat_vt_check(list_export_a_appui_ft, list_vt_a_appui_ft, 'a_appuift',
                                                var_schema, list_ft_nc_vt)

        # Partie Delta BT
        a_appuibt_export = f"""set search_path to {var_schema}, public;
            select * from a_appuibt order by ab_mcd_etiquet"""
        a_appuibt_vt = f"""set search_path to {var_schema}, public;
            --- Suppression coloumn schema Pour le creer apres column geometrie pour garder la meme structure que les exports 
            ALTER TABLE a_appuibt_vt DROP COLUMN IF EXISTS name_schem;
            ALTER TABLE a_appuibt_vt DROP COLUMN IF EXISTS name_schema;
            ALTER TABLE a_appuibt_vt ADD COLUMN IF NOT EXISTS name_schema text;
            select * from a_appuibt_vt order by ab_mcd_eti;"""
        list_export_a_appui_bt = var_connexion.function_execute_requete(a_appuibt_export, 'req_fetch')
        list_vt_a_appui_bt = var_connexion.function_execute_requete(a_appuibt_vt, 'req_fetch')
        var_connexion.function_deltat_vt_check(list_export_a_appui_bt, list_vt_a_appui_bt, 'a_appuibt',
                                                var_schema, list_bt_nc_vt)

        # Partie Export Delta
        var_res_export = ExportMultiplesTablesCsvShp(var_connection, var_schema, path_folder_shp_export_delta,
                                                     tuple(['a_appuibt_delta', 'a_appuift_delta']))
        var_error_traitement = var_res_export.liste_error_traitement
        list_error = var_error_traitement
        var_connection.close()

        QMessageBox.information(w, "Message-Plugin", f"Execution du Traitement Reussi. Les Shapes Delta sont "
                                                     f"exportes dans le repertoire suivant : "
                                                     f"{path_folder_shp_export_delta}")
    except Exception as error:
        QMessageBox.warning(w, "Message de Traitement", f"Erreur Traitement Global Retour Terrain Delta: "
                                                        f"{str(error)}...\n{str(list_error)}")


# schema = 'pr_baba_test_3_14_exe_v_20210920'
# chemin_folder_racine = r'V:\SIG\ADN\DPI\Spec\Model_dev\routine_controle_ca_comac'
# path_folder_Comac = chemin_folder_racine + '\export comac'
# path_folder_ft = chemin_folder_racine + '\export c6'
# path_folder_c3a = chemin_folder_racine + '\export c3a'
# path_folder_c7 = chemin_folder_racine + '\export c7'
# folder_shp_export = chemin_folder_racine + '\export'  # + '\export'
# folder_shp_export_vt = chemin_folder_racine + '\export/VT'  # + '\export'
# function_execute_class_traitementdpi(schema, path_folder_Comac, chemin_folder_racine, path_folder_ft, path_folder_c3a, path_folder_c7)
# # # # function_execute_retourvt(schema, path_folder_shp_export)


# function_execute_retourvt(schema, folder_shp_export_vt, folder_shp_export)