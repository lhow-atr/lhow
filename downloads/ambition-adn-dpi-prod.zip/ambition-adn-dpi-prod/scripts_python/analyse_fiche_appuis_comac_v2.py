import psycopg2
import xlrd
import xlwt
from qgis.PyQt.QtCore import *
from qgis.PyQt.QtGui import *
from qgis.PyQt.QtWidgets import *
from qgis.core import *
from qgis.utils import *
from xlrd import *


def function_DPI_get_inform(schema, var_FA, path_folder_FT, path_folder_BT, path_folder_Comac, path_folder_shp_export):
    # path_folder_FT= QFileDialog.getExistingDirectory(None, 'Selection Repertoire ou se trouve les fiches Appuis de FT')
    # path_folder_BT= QFileDialog.getExistingDirectory(None, 'Selection Repertoire ou se trouve les fiches Appuis de BT')
    # path_folder_Comac= QFileDialog.getExistingDirectory(None, 'Selection Repertoire ou se trouve les Exports Comac')
    # path_folder_shp_export= QFileDialog.getExistingDirectory(None, 'Selection Repertoire ou Exporter les shapes_appuis_BT_FT pour Visite Terrain')

    # Parameter connexion base
    # DB = 'MCD_ADN_sans_ct'#self.dlg.name_bdd.text()
    # user = 'adn_ing'
    # MP = 'password'
    # host = '192.168.30.194'
    # port = '5432'

    global DB, user, MP, host, port

    # schema = 'pr_3_4_exe_v_20191024'#pr_3_4_exe_v_20191024 #'pr_2_6_deo_v_20191014'#pr_2_6_test_deo_v_20191104

    FA_Classique = 'classique'
    FA_Non_Classique = 'Non_classique'

    # Declaration de la variable pour les messages derreur
    w = QWidget()

    # Function pour la progession bar1
    def progress_bar(name_etape):
        prog = QProgressDialog(name_etape + ' : Veillez Patienter', 'Cancel', 0, 100)
        prog.setWindowModality(Qt.WindowModal)
        prog.setMinimumDuration(1)
        return prog

    # Function pour la progession bar2
    def progress_processing(index, count_entite, progress_dialog):
        f = int(index + 1)
        pcnt = int(f / count_entite * 100 / 1)
        progress_dialog.setValue(pcnt)

    # Connexion a la base
    try:
        connection = psycopg2.connect(user=user, password=MP, host=host, port=port, database=DB)
    except(Exception, psycopg2.DatabaseError) as error:
        QMessageBox.warning(w, "Message de connexion de la base", 'Erreur de connexion de la base')

    # Function pour executer une requete sql dans la base
    def function_execute_requete(requete_execute, req_fetch, connection):
        curs = connection.cursor()
        try:
            curs.execute(requete_execute)
            if req_fetch:
                data_req = [row for row in curs.fetchall()]
                if data_req:
                    return data_req
        except(Exception, psycopg2.DatabaseError) as error:
            QMessageBox.warning(w, "Message dexecution de requete",
                                'Requete Non Executer : ' + str(error) + ' ; ' + str(requete_execute))
        curs.close()

    ##Function recuperation des informations des fiches appuis FT
    def function_recperation_info_fiches_appuis_FT_General(path_folder):
        # text_extension='extension'

        # Fichier_appuis=r'C:\Users\babacar.fassa\Documents\Plugins_Scripts\exe_fiche_Appui\Type_Fiches_Structure_Client\modele_dev\POT_26173_FT_240608.xlsx'

        # path_folder_FT= QFileDialog.getExistingDirectory(None, 'Selection Repertoire ou se trouve les fiches appuis de FT')
        # function pour retourner la valeur dune cellule
        def function_value_cellule(col, num_col, row, num_row, data):
            if col == num_col and row == num_row:
                return data

        # Function Get Color XLSX
        def getBGColor_xlsx(Fichier_appuis, colonne_sheet):
            wb = openpyxl.load_workbook(Fichier_appuis)  # faire des filtres sur les xlsx et xls
            index_sheet = wb.worksheets[0]  # wb['240608']
            cellule = index_sheet[colonne_sheet]  # 'W26'
            cell_color = cellule.fill.start_color.index  # code Color #FFFFC000 == Orange #FF92D050 == Vert
            af_dan_apr = 'INSUFFISANT'
            if cell_color in ('FF92D050', 'FFFFC000'):
                af_dan_apr = 'OUI'
            return af_dan_apr

        # Function Get Color XLSX
        def function_getColor_xlsx(Fichier_appuis, cell):
            # xl_workbook = xw.Book(Fichier_appuis)
            # color_cell=xw.Range(cell).color
            # print (xw.Range('U26').color,';',xw.Range('W26').color)
            app = xw.App(visible=False)
            xl_workbook = app.books.open(Fichier_appuis)
            # print(xw.Range('A10').color)
            color_cell = xw.Range(cell).color

            af_dan_apr = 'INSUFFISANT'
            if color_cell in ('(255, 192, 0)', '(146, 208, 80)'):
                af_dan_apr = 'OUI'
            return color_cell
            xl_workbook.close()  # Ya puedo cerrar el libro.
            app.kill()
            app.close()

        # Function Get Color XLS
        def getBGColor_xls(Fichier_appuis, row, col):
            wb = open_workbook(Fichier_appuis, formatting_info=True)
            sheet = wb.sheet_by_index(0)  # wb.sheet_by_name('a_appuift')
            xfx = sheet.cell_xf_index(row, col)
            xf = wb.xf_list[xfx]
            bgx = xf.background.pattern_colour_index  # 50 == Vert 51 == Orange
            pattern_colour = wb.colour_map[bgx]
            return_bgx = 'INSUFFISANT'
            # print (str(bgx),';',xfx)
            if str(bgx) in ('50', '51'):
                return_bgx = 'OUI'
            wb.release_resources()
            del wb
            return return_bgx

        # Function pour la concatenation des lignes et colonnes E et M
        def function_concate_af_cable(Fichier_appuis):
            # bar_progress=progress_bar('Execution de la function_concate_af_cable')
            xl_workbook = xlrd.open_workbook(Fichier_appuis)  # Fichier_appuis_nok[0] avec boite dialogue
            xl_sheet = xl_workbook.sheet_by_index(0)  # idx
            list_fa_ft = range(25, xl_sheet.nrows)
            headers = []
            sdata = []
            for index_row, row in enumerate(list_fa_ft):
                if row >= 25 and row <= 48:
                    values = []
                    for col in range(xl_sheet.ncols):
                        if col in (4, 12):  # column E et M
                            data = str(xl_sheet.cell(row, col).value).replace('.0', '').upper()
                            if data:
                                values.append(data)
                    if values:
                        sdata.append(values)
            # progress_processing(index_row,len(list_fa_ft),bar_progress)
            # if bar_progress.wasCanceled():
            # iface.messageBar().pushMessage('Info', 'Action Cancelled', level=Qgis.Info)
            # break
            list_concate_value = []
            for i in (sdata):
                concate_value = ','.join(i).replace(',', ' vers ')
                list_concate_value.append(concate_value)
            return_list_concate_value = ','.join(list_concate_value).replace(',', '<br>')
            return return_list_concate_value

        # Function pour convertir les xlsx to xls
        def function_conv_xlsx_to_xls(path_folder):
            bar_progress = progress_bar('Conversion des fichiers XLSX vers XLS')
            dir_path = path_folder
            cmp = 0
            list_test = glob(dir_path + "/*")
            for index_x, x in enumerate(list_test):
                cmp += 1
                name, ext = os.path.splitext(x)
                if ext == ".xlsx":
                    path1 = name + ext
                    path2 = name + '.xls'

                    ## Creation Excel (.xls)
                    xls_to_create = xlwt.Workbook()
                    sheet = xls_to_create.add_sheet('wedontcareaboutname')
                    xls_to_create.save(path2)

                    ## Paramètrage Excel
                    excel = win32.gencache.EnsureDispatch('Excel.Application')
                    excel.DisplayAlerts = False

                    ## Ouverture Excel (.xlsx)
                    excel_xlsx = excel.Workbooks.Open(path1)
                    excel_xlsx_sheet = excel_xlsx.Worksheets(1)

                    ## Ouverture Excel (.xls)
                    excel_xls = excel.Workbooks.Open(path2)
                    excel_xls_sheet = excel_xls.Worksheets.Add()
                    excel_xls_sheet.Name = excel_xlsx.Worksheets(1).Name
                    excel_xls_sheet = excel_xls.Worksheets(1)
                    excel_xls_sheet_to_delete = excel_xls.Worksheets('wedontcareaboutname')
                    excel_xls_sheet_to_delete.Delete()

                    excel_xlsx_sheet.Range("A1:AF100").Copy(excel_xls_sheet.Range("A%s:AF%s" % (1, 100)))
                    excel_xls.Save()
                    excel_xls.Close()
                    excel_xlsx.Close()
                progress_processing(index_x, len(glob(dir_path + "/*")), bar_progress)
                if bar_progress.wasCanceled():
                    iface.messageBar().pushMessage('Info', 'Action Cancelled', level=Qgis.Info)
                    break

            excel.Quit()

        def function_conv_xlsx_to_xls_openpyxl(path_folder):
            bar_progress = progress_bar('Conversion des fichiers XLSX vers XLS')
            list_test = glob(path_folder + "/*")
            for index_x, x in enumerate(list_test):
                name, ext = os.path.splitext(x)
                if ext == ".xlsx":
                    path1 = name + ext
                    path2 = name + '.xls'
                    workbook = openpyxl.load_workbook(path1)
                    outfile = f"{path2}"
                    workbook.save(outfile)
                progress_processing(index_x, len(list_test), bar_progress)
                if bar_progress.wasCanceled():
                    iface.messageBar().pushMessage('Info', 'Action Cancelled', level=Qgis.Info)
                    break

        # Function pour la creation de la table a_appuift
        def function_creatTable_a_appuift(schema):
            req = """set search_path TO """ + schema + """, public;
			DROP TABLE IF EXISTS a_appuift;
			CREATE TABLE a_appuift
			(
				af_etiquet text,
				af_nature text,
				af_a_struc text,
				af_codeext text,
				af_eta_mcd text,
				af_struct text,
				af_inv text,
				af_visuel text,
				af_vertica text,
				af_flambe text,
				af_voisin text,
				af_pointe text,
				af_secouss text,
				af_percu text,
				af_jaune text,
				af_mobilis text,
				af_ebp text,
				af_ras text,
				af_cable text,
				af_eta_cap text,
				af_nat_tvx text,
				af_environ text,
				af_vois_el text,
				af_str_tvx text,
				af_dan_apr text,
				af_com_etl text,
				af_val_moe text,
				af_com_moe text,
				attachment text,
				geom geometry(Point,2154)
			);
			---ALTER TABLE a_appuift OWNER to postgres;
			ALTER TABLE a_appuift OWNER to adn_ing;
			GRANT INSERT, SELECT ON TABLE a_appuift TO adn_ing;
			GRANT ALL ON TABLE a_appuift TO postgres;
			GRANT ALL ON TABLE a_appuift TO adn_ing;
			CREATE INDEX a_aft_gidx
				ON a_appuift  USING btree (geom);"""
            function_execute_requete(req, '', connection)

        # Function insertion dans table a_appuift avec Fiches
        def function_insert_a_appuift(schema, text_inf_insert):
            req = """INSERT INTO """ + schema + """.a_appuift(
				af_etiquet, af_nature, af_a_struc, af_codeext, af_eta_mcd, af_struct, 
				af_inv, af_visuel, af_vertica, af_flambe, af_voisin, af_pointe, 
				af_secouss, af_percu, af_jaune, af_mobilis, af_ebp, af_ras, af_cable, 
				af_eta_cap, af_nat_tvx, af_environ, af_vois_el, af_str_tvx, af_dan_apr, 
				af_com_etl, af_val_moe, af_com_moe,geom)
					VALUES """ + text_inf_insert + """;"""  # , geom
            function_execute_requete(req, '', connection)

        # Function insertion dans table a_appuift sans Fiches
        def function_insert_a_appuift_not_Fiche(schema, text_inf_insert):
            req = """INSERT INTO """ + schema + """.a_appuift(
				af_etiquet, af_nature, af_a_struc, af_codeext, af_eta_mcd,geom)
					VALUES """ + text_inf_insert + """;"""
            function_execute_requete(req, '', connection)

        # Function pour recuperer les pt du MCD
        def function_get_ptech_mcd(schema):
            # return list_attribut_all_fiches
            req_pt = """select pt.pt_code, pt.pt_etiquet, pt.pt_nature, pt.pt_etat, pt.pt_a_struc, 
				pt.pt_typelog,pt.pt_typephy,
				'ST_GeomFromText('||quote_literal(st_astext(nd.geom))||',2154)' as geom
					from """ + schema + """.t_ptech pt
						left join """ + schema + """.t_noeud nd on nd.nd_code=pt.pt_nd_code"""
            list_req_pt = function_execute_requete(req_pt, 'bab', connection)
            return list_req_pt

        # Function Extraction information dune fiche appuis
        def function_recperation_info_fiches_appuis_FT(Fichier_appuis, text_extension, name_fiche):
            #        bar_progress=progress_bar('Execution de la function_recperation_info_fiches_appuis_FT')
            xl_workbook = xlrd.open_workbook(Fichier_appuis)  # Fichier_appuis_nok[0] avec boite dialogue
            xl_sheet = xl_workbook.sheet_by_index(0)  # idx

            text_xls = '.xls'
            text_xlsx = '.xlsx'

            headers = []
            sdata = []
            sdata_util = []

            af_etiquet = name_fiche
            af_nature = '-1'
            af_a_struc = '-1'
            af_codeext = '-1'
            af_eta_mcd = '-1'
            af_struct = '-1'
            af_inv = '-1'
            af_visuel = '-1'
            af_vertica = '-1'
            af_flambe = '-1'
            af_voisin = '-1'
            af_pointe = '-1'
            af_secouss = '-1'
            af_percu = '-1'
            af_jaune = '-1'
            af_mobilis = '-1'
            af_ebp = '-1'
            af_ras = '-1'
            af_cable = function_concate_af_cable(Fichier_appuis)
            af_eta_cap = '-1'
            if text_extension == text_xlsx:
                af_eta_cap = '-1'  # function_getColor_xlsx(Fichier_appuis,'U26')#'-1'#getBGColor_xlsx(Fichier_appuis,'U26')
            elif text_extension == text_xls:
                af_eta_cap = '-1'  # getBGColor_xls(Fichier_appuis, 25, 20)
            af_nat_tvx = '-1'
            af_environ = '-1'
            af_vois_el = '-1'
            af_str_tvx = '-1'
            af_dan_apr = '-1'
            if text_extension == text_xlsx:
                af_dan_apr = '-1'  # function_getColor_xlsx(Fichier_appuis,'W26')#'-1'#getBGColor_xlsx(Fichier_appuis,'W26')
            elif text_extension == text_xls:
                af_dan_apr = '-1'  # getBGColor_xls(Fichier_appuis, 25, 22)
            af_com_etl = '-1'
            af_val_moe = ''
            af_com_moe = ''

            def function_get_val_cell_ft(var_xl_sheet, var_col_entite1, var_row_entite, var_type_get):
                list_fa_ft = range(0, var_xl_sheet.nrows)
                var_cell_recup = '-1'
                for index_row, row in enumerate(list_fa_ft):
                    for col in range(xl_sheet.ncols):
                        data = str(xl_sheet.cell(row, col).value).replace('.0', '').upper().replace("'", '')

                        if var_type_get == 'af_codeext_model':
                            if col == var_col_entite1 and row == var_row_entite:  # af_codeext
                                var_cell_recup = data

                        if var_type_get == 'af_inv_model':
                            if col == var_col_entite1 and row == var_row_entite:  # af_inv
                                if data == 'oui'.upper():
                                    var_cell_recup = 'OUI'
                                elif data == 'non'.upper():
                                    var_cell_recup = 'NON'
                                else:
                                    var_cell_recup = 'NC'

                        if var_type_get == 'af_vois_el_model':
                            if col == var_col_entite1 and row == var_row_entite:  # af_vois_el
                                if data:
                                    var_cell_recup = data
                                else:
                                    var_cell_recup = 'SO'

                        if var_type_get == 'af_nat_tvx_model':
                            if col == var_col_entite1 and row == var_row_entite:  # af_nat_tvx
                                if data == 'replacement'.upper():
                                    var_cell_recup = 'OUI'
                                elif data == 'renforcement'.upper():
                                    var_cell_recup = data
                                elif data == 'recalage'.upper():
                                    var_cell_recup = data
                                else:
                                    var_cell_recup = 'NC'

                        if var_type_get == 'af_environ_model':
                            if col == var_col_entite1 and row == var_row_entite:  # af_environ
                                if data in ('bmp'.upper(), 'ter'.upper()):
                                    var_cell_recup = data
                                else:
                                    var_cell_recup = 'NC'

                        if var_type_get == 'af_ebp':
                            if col == var_col_entite1 and row == var_row_entite:  # af_vois_el
                                if data in ('PB', 'PEO'):
                                    var_cell_recup = data
                                else:
                                    var_cell_recup = 'SO'
                return var_cell_recup

            af_codeext = function_get_val_cell_ft(xl_sheet, 3, 1, 'af_codeext_model')
            af_struct = function_get_val_cell_ft(xl_sheet, 2, 25, 'af_codeext_model')
            af_inv = function_get_val_cell_ft(xl_sheet, 22, 53, 'af_inv_model')
            af_visuel = function_get_val_cell_ft(xl_sheet, 9, 8, 'af_inv_model')
            af_vertica = function_get_val_cell_ft(xl_sheet, 9, 9, 'af_inv_model')
            af_flambe = function_get_val_cell_ft(xl_sheet, 9, 10, 'af_inv_model')
            af_voisin = function_get_val_cell_ft(xl_sheet, 9, 11, 'af_inv_model')
            af_pointe = function_get_val_cell_ft(xl_sheet, 20, 8, 'af_inv_model')
            af_secouss = function_get_val_cell_ft(xl_sheet, 20, 9, 'af_inv_model')
            af_percu = function_get_val_cell_ft(xl_sheet, 20, 10, 'af_inv_model')
            af_jaune = function_get_val_cell_ft(xl_sheet, 20, 11, 'af_inv_model')
            af_mobilis = function_get_val_cell_ft(xl_sheet, 22, 11, 'af_inv_model')
            af_vois_el = function_get_val_cell_ft(xl_sheet, 22, 52, 'af_vois_el_model')
            af_ebp = function_get_val_cell_ft(xl_sheet, 13, 17, 'af_ebp')
            af_ras = function_get_val_cell_ft(xl_sheet, 7, 18, 'af_inv_model')
            af_nat_tvx = function_get_val_cell_ft(xl_sheet, 12, 52, 'af_nat_tvx_model')
            af_environ = function_get_val_cell_ft(xl_sheet, 22, 51, 'af_environ_model')
            af_str_tvx = function_get_val_cell_ft(xl_sheet, 12, 51, 'af_codeext_model')
            af_com_etl = function_get_val_cell_ft(xl_sheet, 0, 54, 'af_codeext_model')

            return [af_etiquet, af_nature, af_a_struc, af_codeext, af_eta_mcd, af_struct, af_inv \
                , af_visuel, af_vertica, af_flambe, af_voisin, af_pointe, af_secouss, af_percu \
                , af_jaune, af_mobilis, af_ebp, af_ras, af_cable, af_eta_cap, af_nat_tvx \
                , af_environ, af_vois_el, af_str_tvx, af_dan_apr, af_com_etl, af_val_moe, af_com_moe]

        # Function parcours dossier des fiches appuis
        def function_create_analyse_fiche_appui_Parcours_directory_FT(path_folder):
            bar_progress = progress_bar('Execution de la function_create_analyse_fiche_appui_Parcours_directory_FT')
            list_all_fiches = []
            list_attribut_all_fiches_finale = []

            for file_etude in os.listdir(path_folder):
                chemin = path_folder
                name, ext = os.path.splitext(file_etude)
                if ext in ('.xls', '.xlsx'):  # ,'.xlsm' prendre que les extension xls et xlsx ,'.xlsx'
                    chem_etude = chemin + '/' + file_etude
                    # print (file_etude,';',chem_etude)
                    attr_name = [chem_etude, file_etude.split(".")[0], ext]
                    list_all_fiches.append(attr_name)

            for index_fich_ap, fich_ap in enumerate(list_all_fiches):
                if fich_ap[2] == '.xlsx':
                    attribut_fiches_finale = function_recperation_info_fiches_appuis_FT(fich_ap[0], fich_ap[2],
                                                                                        fich_ap[1])
                    list_attribut_all_fiches_finale.append(attribut_fiches_finale)
                elif fich_ap[2] == '.xls':
                    attribut_fiches_finale = function_recperation_info_fiches_appuis_FT(fich_ap[0], fich_ap[2],
                                                                                        fich_ap[1])
                    list_attribut_all_fiches_finale.append(attribut_fiches_finale)
                progress_processing(index_fich_ap, len(list_all_fiches), bar_progress)
                if bar_progress.wasCanceled():
                    iface.messageBar().pushMessage('Info', 'Action Cancelled', level=Qgis.Info)
                    break
            return list_attribut_all_fiches_finale

        if path_folder:

            # Execution de la function de conversion
            # function_conv_xlsx_to_xls_openpyxl(path_folder)

            bar_progress = progress_bar('Execution de la function Verification et insertion dans la table a_appuift')
            # Execute function_creatTable_a_appuift(schema)
            function_creatTable_a_appuift(schema)
            # Execute function_get_ptech_mcd(schema)
            list_req_pt = function_get_ptech_mcd(schema)
            list_etiquet_ptech = [etiquet[1] for etiquet in list_req_pt]

            list_fA = function_create_analyse_fiche_appui_Parcours_directory_FT(path_folder)

            for index_req_pt, var_req_pt in enumerate(list_req_pt):
                mcd_not_fa = 'KO'
                if var_req_pt[5] == 'T' and var_req_pt[6] == 'A' and ( \
                                var_req_pt[1][10:12] == 'FT' and var_req_pt[1][:3] == 'POT' and len(
                            var_req_pt[1][4:9]) == 5):
                    for inf_insert in list_fA:
                        if inf_insert[0] == var_req_pt[1]:
                            inf_insert[1] = var_req_pt[2]
                            inf_insert[2] = var_req_pt[4]
                            inf_insert[4] = var_req_pt[3]
                            mcd_not_fa = 'OK'
                            text_inf_insert = str(inf_insert + [var_req_pt[7]]).replace('[', '(').replace(']',
                                                                                                          ')').replace(
                                '"', '').replace('None', "''")
                            # Execution de la fonction Insertion des appuis avec fiches
                            # print (text_inf_insert,';',inf_insert)
                            function_insert_a_appuift(schema, text_inf_insert)
                    # break
                    if mcd_not_fa == 'KO':
                        var_insert_MD_NOT_FA = var_req_pt[1], var_req_pt[2], var_req_pt[4], 'Pas de Fiche Appui', \
                                               var_req_pt[3], var_req_pt[7]
                        var_insert_MD_NOT_FA_replace = str(var_insert_MD_NOT_FA).replace('"', '')
                # Execution de la function Insertion des appuis sans fiches
                # function_insert_a_appuift_not_Fiche(schema,var_insert_MD_NOT_FA_replace)
                progress_processing(index_req_pt, len(list_req_pt), bar_progress)
                if bar_progress.wasCanceled():
                    iface.messageBar().pushMessage('Info', 'Action Cancelled', level=Qgis.Info)
                    break

    # Fiches Appuis classique
    def function_recperation_info_fiches_appuis_BT_General(path_folder_BT, var_FA, path_folder_comac):

        # Function pour la creation de la table a_appuibt
        def function_creatTable_a_appuibt(schema):
            req = """set search_path TO """ + schema + """, public;
			DROP TABLE IF EXISTS a_appuibt;
			CREATE TABLE a_appuibt
			(
				ab_etiquet text,
				ab_a_struc text,
				ab_nature text,
				ab_eta_mcd text,
				ab_rac_mcd text,
				ab_codeext text,
				ab_etude text,
				ab_struct text,
				ab_type text,
				ab_annee text,
				ab_rac_bt text,
				ab_rac_tel text,
				ab_malt text,
				ab_iacm text,
				ab_ras_hta text,
				ab_ras_bt text,
				ab_ep text,
				ab_cb_bt text,
				ab_cb_cu text,
				ab_cb_fo text,
				ab_rac_reel text,
				ab_eta_com text,
				ab_dan_avt text,
				ab_com_com text,
				ab_visuel_com text,
				ab_codefiche text,
				ab_prive text,
				ab_surplomb text,
				ab_elagage text,
				ab_inv text,
				ab_hlibre text,
				ab_visuel text,
				ab_vertica text,
				ab_jaune text,
				ab_mobilis text,
				ab_gravur text,
				ab_ras_ft text,
				ab_orien text,
				ab_anc_bt text,
				ab_anc_ft text,
				ab_com_etl text,
				ab_nat_tvx text,
				ab_environ text,
				ab_val_moe text,
				ab_com_moe text,
				attachment text,
				geom geometry(Point,2154)
			);
			---ALTER TABLE a_appuibt OWNER to postgres;
			ALTER TABLE a_appuibt OWNER to adn_ing;
			GRANT INSERT, SELECT ON TABLE a_appuibt TO adn_ing;
			GRANT ALL ON TABLE a_appuibt TO postgres;
			GRANT ALL ON TABLE a_appuibt TO adn_ing;
			CREATE INDEX a_abt_gidx
				ON a_appuibt  USING btree (geom);"""
            function_execute_requete(req, '', connection)

        # Execution de la creation de la table
        function_creatTable_a_appuibt(schema)

        # Function insertion dans table a_appuift avec Fiches
        def function_insert_a_appuibt(schema, text_inf_insert):
            req = """INSERT INTO """ + schema + """.a_appuibt(
				ab_etiquet, ab_a_struc, ab_nature, ab_eta_mcd, ab_rac_mcd, ab_codeext, ab_etude, ab_struct, 
				ab_type, ab_annee, ab_rac_bt, ab_rac_tel, ab_malt, ab_iacm, ab_ras_hta, 
				ab_ras_bt, ab_ep, ab_cb_bt, ab_cb_cu, ab_cb_fo, ab_rac_reel, ab_eta_com, ab_dan_avt, ab_com_com, ab_visuel_com,
				ab_codefiche, ab_prive, ab_surplomb, ab_elagage, ab_inv, ab_hlibre, 
				ab_visuel, ab_vertica, ab_jaune, ab_mobilis, ab_gravur, ab_ras_ft, 
				ab_orien, ab_anc_bt, ab_anc_ft, ab_com_etl, ab_nat_tvx, ab_environ, 
				ab_val_moe, ab_com_moe, geom)
					VALUES """ + text_inf_insert + """;"""  # , geom
            function_execute_requete(req, '', connection)

        # Fichier_appuis=r'C:\Users\babacar.fassa\Documents\Plugins_Scripts\exe_fiche_Appui\Type_Fiches_Structure_Client\modele_dev\CLASSIQUE_IMOPTEL.xls'

        ab_etiquet = '-1'
        ab_a_struc = '-1'
        ab_nature = '-1'
        ab_eta_mcd = '-1'

        ab_codefiche = '-1'
        ab_prive = '-1'
        ab_surplomb = '-1'
        ab_elagage = '-1'
        ab_inv = '-1'
        ab_hlibre = '-1'
        ab_visuel = '-1'
        ab_vertica = '-1'
        ab_jaune = '-1'
        ab_mobilis = '-1'
        ab_gravur = '-1'
        ab_ras_ft = '-1'
        ab_orien = '-1'
        ab_anc_bt = '-1'
        ab_anc_ft = '-1'
        ab_com_etl = '-1'
        ab_nat_tvx = ''
        ab_environ = ''
        ab_val_moe = ''
        ab_com_moe = ''

        # function_recperation_info_fiches_appuis_Comac(Fichier_appuis_comac)
        list_attribut_all_fiches = []

        # path_folder_BT= QFileDialog.getExistingDirectory(None, 'Selection Repertoire ou se trouve les fiches appuis de BT')
        def function_appuis_BT_Parcours_directory(path_folder, var_FA):
            # Recuperation des infos des fiches appuis bt Non classic
            def function_recperation_info_fiches_appuis_BT_Non_Classic(Fichier_appuis):
                xl_workbook = xlrd.open_workbook(Fichier_appuis)  # Fichier_appuis_nok[0] avec boite dialogue
                xl_sheet = xl_workbook.sheet_by_index(0)  # idx
                sheet_names = xl_workbook.sheet_names()

                def function_getinfo_feuille_2(var_row_entite, var_col_entite1, var_col_entite2, var_type_get):
                    var_cell_recup = '-1'
                    if len(sheet_names) == 2:
                        xl_sheet_2 = xl_workbook.sheet_by_index(1)  # idx
                        list_fa_bt_classic_2 = range(0, xl_sheet_2.nrows)
                        for index_classic, row in enumerate(list_fa_bt_classic_2):
                            for col in range(xl_sheet_2.ncols):
                                data = str(xl_sheet_2.cell(row, col).value).replace('.0', '').upper().replace("'", '')
                                if var_type_get == 'var_Comp_Col':
                                    if row == var_row_entite and col in (var_col_entite1, var_col_entite2):
                                        if col == var_col_entite1:  # Col 40 8
                                            if data == 'x'.upper():
                                                var_cell_recup = 'OUI'
                                        elif col == var_col_entite2:  # Col 41 9
                                            if data == 'x'.upper():
                                                var_cell_recup = 'NON'
                                        else:
                                            var_cell_recup = 'NC'
                                if var_type_get == 'var_not_Comp_Col':
                                    if col == var_col_entite1 and row == var_row_entite:  # ab_codefiche
                                        if data:
                                            var_cell_recup = data
                                        else:
                                            var_cell_recup = 'NC'
                    return var_cell_recup

                def function_select_choose_cell_non_classic(var_xl_sheet, var_row_entite, var_col_entite1,
                                                            var_col_entite2, var_type_get, var_row_entite2):
                    var_cell_recup = '-1'
                    list_fa_bt_classic = range(0, var_xl_sheet.nrows)
                    for index_classic, row in enumerate(list_fa_bt_classic):
                        for col in range(var_xl_sheet.ncols):
                            data = str(var_xl_sheet.cell(row, col).value).replace('.0', '').upper().replace("'", '')
                            if var_type_get == 'var_Comp_Col':
                                if row == var_row_entite and col in (var_col_entite1, var_col_entite2):
                                    if col == var_col_entite1:  # Col 40 8
                                        if data == 'x'.upper():
                                            var_cell_recup = 'OUI'
                                    elif col == var_col_entite2:  # Col 41 9
                                        if data == 'x'.upper():
                                            var_cell_recup = 'NON'
                                    else:
                                        var_cell_recup = 'NC'
                            if var_type_get == 'var_not_Comp_Col':
                                if col == var_col_entite1 and row == var_row_entite:  # ab_codefiche
                                    if data:
                                        var_cell_recup = data
                                    else:
                                        var_cell_recup = 'NC'

                            if var_type_get == 'ab_mobilis':
                                if row in (7, 8, 17, 18):  # ,8,17,18
                                    if col == var_col_entite1 and row == 7:  # 7
                                        if data == 'x'.upper():
                                            var_cell_recup = 'OUI'
                                    elif col == var_col_entite1 and row == 8:  # 8
                                        if data == 'x'.upper():
                                            var_cell_recup = 'NON'
                                    if col == var_col_entite1 and row == 17:  # 17
                                        if data == 'x'.upper():
                                            var_cell_recup = 'OUI'
                                    elif col == var_col_entite1 and row == 18:  # 18
                                        if data == 'x'.upper():
                                            var_cell_recup = 'NON'
                                    elif var_cell_recup == '-1':
                                        var_cell_recup = 'NC'
                            if var_type_get == 'etat_appuis_info':
                                if col in (var_col_entite1, var_col_entite2) and row == var_row_entite:
                                    if col == var_col_entite1:  # Col 40 8
                                        if data == 'x'.upper():
                                            var_cell_recup = 'OUI'
                                    elif col == var_col_entite2:  # Col 41 9
                                        if data == 'x'.upper():
                                            var_cell_recup = 'NON'
                                    else:
                                        var_cell_recup = 'NC'
                                elif col in (var_col_entite1, var_col_entite2) and row == var_row_entite2:
                                    if col == var_col_entite1:  # Col 40 8
                                        if data == 'x'.upper():
                                            var_cell_recup = 'OUI'
                                    elif col == var_col_entite2:  # Col 41 9
                                        if data == 'x'.upper():
                                            var_cell_recup = 'NON'
                                    else:
                                        var_cell_recup = 'NC'
                                elif var_cell_recup == '-1':
                                    var_cell_recup = 'NC'

                    return var_cell_recup

                ab_codefiche = function_select_choose_cell_non_classic(xl_sheet, 1, 3, '', 'var_not_Comp_Col', '')
                ab_prive = function_getinfo_feuille_2(5, 1, 2, 'var_Comp_Col')
                #    ab_surplomb=function_select_choose_cell_non_classic(xl_sheet,40,8, 9,'var_Comp_Col')
                ab_elagage = function_getinfo_feuille_2(6, 1, 2, 'var_Comp_Col')
                ab_inv = function_getinfo_feuille_2(7, 1, 2, 'var_Comp_Col')
                #    ab_hlibre=function_select_choose_cell_non_classic(xl_sheet,43,8, 9,'var_Comp_Col')
                ab_visuel = function_select_choose_cell_non_classic(xl_sheet, 5, 6, 8, 'etat_appuis_info', 15)
                ab_vertica = function_select_choose_cell_non_classic(xl_sheet, 6, 6, 8, 'etat_appuis_info', 16)
                ab_jaune = function_select_choose_cell_non_classic(xl_sheet, 7, 6, 8, 'etat_appuis_info', 17)
                ab_mobilis = function_select_choose_cell_non_classic(xl_sheet, 17, 23, '', 'ab_mobilis', 18)
                #    ab_gravur=function_select_choose_cell_non_classic(xl_sheet,43,18,19,'var_Comp_Col','')
                #    ab_ras_ft=function_select_choose_cell_non_classic(xl_sheet,15,17, '','ab_ras_ft','')
                ab_orien = function_select_choose_cell_non_classic(xl_sheet, 17, 17, '', 'var_not_Comp_Col', '')
                ab_anc_bt = function_select_choose_cell_non_classic(xl_sheet, 22, 8, '', 'var_not_Comp_Col', '')
                ab_anc_ft = function_select_choose_cell_non_classic(xl_sheet, 23, 8, '', 'var_not_Comp_Col', '')
                #    ab_com_etl=function_select_choose_cell_non_classic(xl_sheet,46,0, '','var_not_Comp_Col','')
                return [ab_codefiche, ab_prive, ab_surplomb, ab_elagage, ab_inv, ab_hlibre, ab_visuel, \
                        ab_vertica, ab_jaune, ab_mobilis, ab_gravur, ab_ras_ft, ab_orien, ab_anc_bt, ab_anc_ft,
                        ab_com_etl]

            # Recuperation des infos des fiches appuis bt classic
            def function_recperation_info_fiches_appuis_BT_Classic(Fichier_appuis):
                xl_workbook = xlrd.open_workbook(Fichier_appuis)  # Fichier_appuis_nok[0] avec boite dialogue
                xl_sheet = xl_workbook.sheet_by_index(0)  # idx

                def function_select_choose_cell(var_xl_sheet, var_row_entite, var_col_entite1, var_col_entite2,
                                                var_type_get, var_ajout_ligne):
                    var_cell_recup = '-1'
                    list_fa_bt_classic = range(0, var_xl_sheet.nrows)
                    row_etat_env = '-1'
                    for index_classic, row in enumerate(list_fa_bt_classic):
                        for col in range(var_xl_sheet.ncols):
                            data = str(var_xl_sheet.cell(row, col).value).replace('.0', '').upper().replace("'", '')

                            if "ETAT DE LAPPUI ET ENVIRONNEMENT" in data:
                                row_etat_env = row
                            if var_type_get == 'var_Comp_Col_etat_env':
                                if row_etat_env != '-1':
                                    # print (row,';',col,';',var_xl_sheet.cell(row,col).value)
                                    if row == row_etat_env + var_ajout_ligne and col in (
                                    var_col_entite1, var_col_entite2):
                                        if col == var_col_entite1:  # Col 40 8
                                            if data == 'x'.upper():
                                                var_cell_recup = 'OUI'
                                        elif col == var_col_entite2:  # Col 41 9
                                            if data == 'x'.upper():
                                                var_cell_recup = 'NON'
                                        else:
                                            var_cell_recup = 'NC'
                                # print (row,';',col,';',data)
                            if var_type_get == 'var_not_Comp_Col_etat_env':
                                if row_etat_env != '-1':
                                    if col == var_col_entite1 and row == row_etat_env + var_ajout_ligne:  # ab_codefiche
                                        if data:
                                            var_cell_recup = data
                                        else:
                                            var_cell_recup = 'NC'

                            if var_type_get == 'var_Comp_Col':
                                if row == var_row_entite and col in (var_col_entite1, var_col_entite2):
                                    if col == var_col_entite1:  # Col 40 8
                                        if data == 'x'.upper():
                                            var_cell_recup = 'OUI'
                                    elif col == var_col_entite2:  # Col 41 9
                                        if data == 'x'.upper():
                                            var_cell_recup = 'NON'
                                    else:
                                        var_cell_recup = 'NC'
                            if var_type_get == 'var_not_Comp_Col':
                                if col == var_col_entite1 and row == var_row_entite:  # ab_codefiche
                                    if data:
                                        var_cell_recup = data
                                    else:
                                        var_cell_recup = 'NC'
                            if var_type_get == 'ab_ras_ft':  # ab_ras_ft
                                if col == var_col_entite1 and row == var_row_entite:  # ab_codefiche
                                    if data == 0:
                                        var_cell_recup = 'NON'
                                    elif data == '':
                                        var_cell_recup = 'NON'
                                    else:
                                        var_cell_recup = 'OUI'
                            if var_type_get == 'ab_orien':  # ab_orien
                                if col == 8 and row == 21:
                                    if data == 'x'.upper():
                                        var_cell_recup = 'ARRET'
                                elif col == 8 and row == 23:
                                    if data == 'x'.upper():
                                        var_cell_recup = 'ALIGNEMENT'
                                elif col == 18 and row == 21:
                                    if data == 'x'.upper():
                                        var_cell_recup = 'BISSECTRICE'
                                elif col == 18 and row == 23:
                                    if data == 'x'.upper():
                                        var_cell_recup = 'PARTICULIER'
                                elif var_cell_recup == '-1':
                                    var_cell_recup = 'NC'
                            if var_type_get == 'ab_anc_bt':  # ab_anc_bt
                                if col == var_col_entite1 and row == var_row_entite:
                                    if data:
                                        var_cell_recup = data[-7:]
                    return var_cell_recup

                ab_codefiche = function_select_choose_cell(xl_sheet, 4, 4, '', 'var_not_Comp_Col', '')
                ab_prive = function_select_choose_cell(xl_sheet, '', 8, 9, 'var_Comp_Col_etat_env', 2)
                ab_surplomb = function_select_choose_cell(xl_sheet, '', 8, 9, 'var_Comp_Col_etat_env', 3)
                ab_elagage = function_select_choose_cell(xl_sheet, '', 8, 9, 'var_Comp_Col_etat_env', 4)
                ab_inv = function_select_choose_cell(xl_sheet, '', 8, 9, 'var_Comp_Col_etat_env', 5)
                ab_hlibre = function_select_choose_cell(xl_sheet, '', 8, 9, 'var_Comp_Col_etat_env', 6)
                ab_visuel = function_select_choose_cell(xl_sheet, '', 18, 19, 'var_Comp_Col_etat_env', 2)
                ab_vertica = function_select_choose_cell(xl_sheet, '', 18, 19, 'var_Comp_Col_etat_env', 3)
                ab_jaune = function_select_choose_cell(xl_sheet, '', 18, 19, 'var_Comp_Col_etat_env', 4)
                ab_mobilis = function_select_choose_cell(xl_sheet, '', 18, 19, 'var_Comp_Col_etat_env', 5)
                ab_gravur = function_select_choose_cell(xl_sheet, '', 18, 19, 'var_Comp_Col_etat_env', 6)
                ab_ras_ft = function_select_choose_cell(xl_sheet, 15, 17, '', 'ab_ras_ft', '')
                ab_orien = function_select_choose_cell(xl_sheet, '', '', '', 'ab_orien', '')
                ab_anc_bt = function_select_choose_cell(xl_sheet, 18, 9, '', 'ab_anc_bt', '')
                ab_anc_ft = function_select_choose_cell(xl_sheet, 16, 5, '', 'ab_anc_bt', '')
                ab_com_etl = function_select_choose_cell(xl_sheet, '', 0, '', 'var_not_Comp_Col_etat_env', 9)

                return [ab_codefiche, ab_prive, ab_surplomb, ab_elagage, ab_inv, ab_hlibre, ab_visuel, \
                        ab_vertica, ab_jaune, ab_mobilis, ab_gravur, ab_ras_ft, ab_orien, ab_anc_bt, ab_anc_ft,
                        ab_com_etl]

            list_all_fiches = []
            if path_folder:
                bar_progress = progress_bar(
                    'Execution en Masse de la recuperation des informations dans les fiches appuis')
                for file_etude in os.listdir(path_folder):
                    chemin = path_folder
                    name, ext = os.path.splitext(file_etude)
                    if ext in ('.xls', '.xlsx', '.xlsm'):
                        chem_etude = chemin + '/' + file_etude
                        # print (file_etude,';',chem_etude)
                        attr_name = [chem_etude, file_etude.split(".")[0]]
                        file_size = os.path.getsize(chem_etude)
                        if file_size > 0:
                            list_all_fiches.append(attr_name)
                for index_fich_ap, fich_ap in enumerate(list_all_fiches):
                    if var_FA == FA_Classique:
                        attribut_fiches_finale = function_recperation_info_fiches_appuis_BT_Classic(fich_ap[0]) + [
                            fich_ap[1]]  # function_liste_appui(fich_ap)
                    elif var_FA == FA_Non_Classique:
                        attribut_fiches_finale = function_recperation_info_fiches_appuis_BT_Non_Classic(fich_ap[0]) + [
                            fich_ap[1]]  # function_liste_appui(fich_ap)
                    list_attribut_all_fiches.append(attribut_fiches_finale)
                    progress_processing(index_fich_ap, len(list_all_fiches), bar_progress)
                    if bar_progress.wasCanceled():
                        iface.messageBar().pushMessage('Info', 'Action Cancelled', level=Qgis.Info)
                        break
            # print (list_attribut_all_fiches)
            return list_attribut_all_fiches  # list_attribut_all_fiches_finale

        # Recuperation info fiches comac
        # Fichier_appuis_comac=r'C:\Users\babacar.fassa\Documents\Plugins_Scripts\exe_fiche_Appui\Type_Fiches_Structure_Client\modele_dev\EBT_024_07296_LABORIE_ExportComac.xlsx'
        # path_folder_Comac= QFileDialog.getExistingDirectory(None, 'Selection Repertoire ou se trouve les fiches Comac')
        def function_appuis_Comac_Parcours_directory_Comac(path_folder_comac):
            def function_recperation_info_fiches_appuis_Comac(Fichier_appuis):
                ab_codeext = '-1'
                ab_etude = os.path.basename(Fichier_appuis)
                ab_struct = '-1'
                ab_type = '-1'
                ab_annee = '-1'
                ab_rac_bt = '-1'
                ab_rac_tel = '-1'
                ab_malt = '-1'
                ab_iacm = '-1'
                ab_ras_hta = '-1'
                ab_ras_bt = '-1'
                ab_ep = '-1'
                ab_cb_bt = '-1'
                ab_cb_cu = '-1'
                ab_cb_fo = '-1'
                ab_rac_reel = '-1'
                ab_eta_com = '-1'
                ab_dan_avt = '-1'
                ab_com_com = '-1'
                ab_visuel_com = '-1'

                def function_getvalue(var_value, var_type_get):
                    return_var_value = '-1'
                    if var_type_get == '':
                        return_var_value = var_value
                    if var_type_get == 'NC':
                        if var_value == '':
                            return_var_value = 'NC'
                        else:
                            return_var_value = var_value
                    if var_type_get == 'SO':
                        if var_value == '':
                            return_var_value = 'SO'
                        else:
                            return_var_value = var_value
                    if var_type_get == 'ab_ras_bt':
                        if var_value == '0':
                            return_var_value = 'NON'
                        elif var_value == '':
                            return_var_value = 'SO'
                        else:
                            return_var_value = 'OUI'

                    return return_var_value

                if Fichier_appuis:
                    workbook = xlrd.open_workbook(Fichier_appuis, on_demand=True)
                    worksheet = workbook.sheet_by_index(0)
                    list_fa_comac = range(2, worksheet.nrows)
                    data = []
                    data_finale = []
                    first_row = []  # Header
                    for col in range(worksheet.ncols):
                        first_row.append(str(worksheet.cell_value(2, col)).replace('.0', '').upper().replace("'", ''))
                    data_dict = []
                    for row in range(3, worksheet.nrows):
                        elm = {}
                        for col in range(worksheet.ncols):
                            if col in (0, 3, 4, 7, 8, 9, 13, 16, 17, 18, 21, 22, 24, 25, 47, 48, 50, 51):  # ,26,40
                                # (0,3,4,7,8,9,13,16,17,18,21,22,24,25,26,40,47,48)
                                elm[first_row[col]] = str(
                                    worksheet.cell_value(row, col))  # .replace('.0','').upper().replace("'",''))
                            elif col == 26:
                                elm[first_row[col] + '_AA'] = str(worksheet.cell_value(row, col))
                            elif col == 40:
                                elm[first_row[col] + '_AO'] = str(worksheet.cell_value(row, col))
                        # print (elm)
                        if len(elm) == 20:
                            data_dict.append(elm)
                    # print (elm)
                    # print (data_dict)
                    column_taux = 'TAUX                  DUTILISATION EN %'
                    column_conclusion = 'CONCLUSION'
                    column_type_ligne = 'TYPE DE LIGNE -RÉSEAU                  -EN NAPPE'
                    column_commentaires = 'Commentaires'
                    column_etat_apparent = 'Etat apparent'

                    for index_dict, value in enumerate(data_dict):
                        ab_haut = '-1'
                        ab_class = '-1'
                        ab_effort = '-1'
                        for index_value, (key, var_value) in enumerate(value.items()):
                            data_recup = str(var_value.replace('.0', '').upper().replace("'", ''))
                            if index_value == 0:
                                ab_codeext = function_getvalue(data_recup, 'NC')
                            if index_value == 2:
                                ab_haut = function_getvalue(data_recup, 'NC')
                            if index_value == 3:
                                ab_class = function_getvalue(data_recup, 'NC')
                            if index_value == 4:
                                ab_effort = function_getvalue(data_recup, 'NC')
                            ab_struct = ab_haut + ' ' + ab_class + ' ' + ab_effort
                            if index_value == 1:
                                ab_type = function_getvalue(data_recup, 'NC')
                            if index_value == 5:
                                ab_annee = function_getvalue(data_recup, 'NC')
                            if index_value == 7:
                                ab_rac_bt = function_getvalue(data_recup, 'NC')
                            if index_value == 8:
                                ab_rac_tel = function_getvalue(data_recup, 'NC')
                            if index_value == 9:
                                ab_malt = function_getvalue(data_recup, 'SO')
                            if index_value == 10:
                                ab_iacm = function_getvalue(data_recup, 'SO')
                            if index_value == 11:
                                ab_ras_hta = function_getvalue(data_recup, 'SO')
                            if index_value == 12:
                                ab_ras_bt = function_getvalue(data_recup, 'ab_ras_bt')
                            if index_value == 13:
                                ab_ep = function_getvalue(data_recup, 'SO')
                            if index_value == 6:
                                ab_cb_bt = function_getvalue(data_recup, '')
                            if index_value == 14:
                                ab_cb_cu = data_recup  # function_getvalue(data_recup,'')
                            if key == column_type_ligne + '_AO' and index_value == 15:
                                ab_cb_fo = function_getvalue(data_recup, 'NC')
                            elif key != column_type_ligne + '_AO' and index_value == 15:
                                ab_cb_fo = 'NC'
                            if ' -2F-' in ab_cb_fo:
                                ab_rac_reel = 'OUI'
                            elif ' -2F-' not in ab_cb_fo:
                                ab_rac_reel = 'NON'
                            if key == column_commentaires and index_value == 16:
                                ab_com_com = function_getvalue(data_recup, 'NC')
                            elif key != column_commentaires and index_value == 16:
                                ab_com_com = 'NC'
                            if key == column_etat_apparent and index_value == 17:
                                ab_visuel_com = function_getvalue(data_recup, 'NC')
                            elif key != column_etat_apparent and index_value == 17:
                                ab_visuel_com = 'NC'
                            if key == column_conclusion and index_value == 18:
                                ab_eta_com = function_getvalue(data_recup, 'NC')
                            elif key != column_conclusion and index_value == 18:
                                ab_eta_com = 'NC'
                            if key == column_taux and index_value == 19:
                                ab_dan_avt = function_getvalue(data_recup, 'NC')
                            elif key != column_taux and index_value == 19:
                                ab_dan_avt = 'NC'

                        data_finale.append([ab_codeext, ab_etude, ab_struct, ab_type, ab_annee, ab_rac_bt, ab_rac_tel,
                                            ab_malt, ab_iacm, ab_ras_hta, ab_ras_bt, ab_ep, ab_cb_bt,
                                            ab_cb_cu, ab_cb_fo, ab_rac_reel, ab_eta_com, ab_dan_avt, ab_com_com,
                                            ab_visuel_com])
                    return data_finale

            list_all_fiches = []
            list_attribut_all_fiches = []
            list_attribut_all_fiches_finale = []

            if path_folder_comac:
                bar_progress = progress_bar('Execution en Masse de la recuperation des informations des exports Comac')
                for file_etude in os.listdir(path_folder_comac):
                    chemin = path_folder_comac
                    name, ext = os.path.splitext(file_etude)
                    if ext in ('.xls', '.xlsx', '.xlsm', '.ExportComac'):
                        chem_etude = chemin + '/' + file_etude
                        # print (file_etude,';',chem_etude)
                        attr_name = [chem_etude, file_etude.split(".")[0]]
                        file_size = os.path.getsize(chem_etude)
                        if file_size > 0:
                            list_all_fiches.append(attr_name)

                for index_fich_ap, fich_ap in enumerate(list_all_fiches):
                    attribut_fiches_finale_list = function_recperation_info_fiches_appuis_Comac(fich_ap[0])
                    for res_FA in attribut_fiches_finale_list:
                        attribut_fiches_finale = res_FA  # +[fich_ap[1]]
                        attribut_fiches_finale2 = res_FA
                        list_attribut_all_fiches.append(attribut_fiches_finale2)
                    progress_processing(index_fich_ap, len(list_all_fiches), bar_progress)
                    if bar_progress.wasCanceled():
                        iface.messageBar().pushMessage('Info', 'Action Cancelled', level=Qgis.Info)
                        break
            return list_attribut_all_fiches

        def function_compare_mcd_comac_fa(schema):
            bar_progress = progress_bar('Execution de la function_compare_mcd_comac_fa')

            # Function pour recuperer les pt du MCD
            def function_get_ptech_mcd(schema):
                # return list_attribut_all_fiches
                req_pt = """SET search_path = """ + schema + """, public;
					select distinct pt.pt_code, pt.pt_etiquet, pt.pt_nature, pt.pt_etat, pt.pt_a_struc, 
						pt.pt_typelog,pt.pt_typephy,'ST_GeomFromText('||quote_literal(st_astext(nd.geom))||',2154)' as geom
					from t_ptech pt
						join t_noeud nd on nd.nd_code=pt.pt_nd_code
						join t_cableline cl on st_dwithin (nd.geom,cl.geom,0.1)
						join t_cable cb on cb.cb_code = cl.cl_cb_code
					where cb.cb_typelog in('DI', 'TR', 'CO')"""
                list_req_pt = function_execute_requete(req_pt, 'bab', connection)
                return list_req_pt

            list_ptech = function_get_ptech_mcd(schema)
            list_comac = function_appuis_Comac_Parcours_directory_Comac(path_folder_comac)
            list_bt = function_appuis_BT_Parcours_directory(path_folder_BT, var_FA)
            list_res_export = []
            # print (list_comac)
            for index_mcd, mcd in enumerate(list_ptech):
                if mcd[5] == 'T' and mcd[6] == 'A' and ( \
                                mcd[1][10:12] in ('BT', 'EP') and mcd[1][:3] == 'POT' and len(mcd[1][-7:]) == 7):
                    res_cores_mcd_comac_fa = 'NOK'
                    ab_etiquet = mcd[1]
                    ab_a_struc = mcd[4]
                    ab_nature = mcd[2]
                    ab_eta_mcd = mcd[3]
                    ab_rac_mcd = 'NON'
                    ab_codeext = 'NC_COMAC'
                    ab_etude = 'NC_COMAC'
                    ab_struct = 'NC_COMAC'
                    ab_type = 'NC_COMAC'
                    ab_annee = 'NC_COMAC'
                    ab_rac_bt = 'NC_COMAC'
                    ab_rac_tel = 'NC_COMAC'
                    ab_malt = 'NC_COMAC'
                    ab_iacm = 'NC_COMAC'
                    ab_ras_hta = 'NC_COMAC'
                    ab_ras_bt = 'NC_COMAC'
                    ab_ep = 'NC_COMAC'
                    ab_cb_bt = 'NC_COMAC'
                    ab_cb_cu = 'NC_COMAC'
                    ab_cb_fo = 'NC_COMAC'
                    ab_rac_reel = 'NC_COMAC'
                    ab_eta_com = 'NC_COMAC'
                    ab_dan_avt = 'NC_COMAC'
                    ab_com_com = 'NC_COMAC'
                    ab_visuel_com = 'NC_COMAC'
                    ab_codefiche = ''
                    ab_prive = ''
                    ab_surplomb = ''
                    ab_elagage = ''
                    ab_inv = ''
                    ab_hlibre = ''
                    ab_visuel = ''
                    ab_vertica = ''
                    ab_jaune = ''
                    ab_mobilis = ''
                    ab_gravur = ''
                    ab_ras_ft = ''
                    ab_orien = ''
                    ab_anc_bt = ''
                    ab_anc_ft = ''
                    ab_com_etl = ''
                    ab_nat_tvx = ''
                    ab_environ = ''
                    ab_val_moe = ''
                    ab_com_moe = ''
                    for comac in list_comac:
                        attr_comac = comac[0].upper()
                        if comac[0].upper() == mcd[1][-7:].upper():
                            ab_codeext = comac[0]
                            ab_etude = comac[1]
                            ab_struct = comac[2]
                            ab_type = comac[3]
                            ab_annee = comac[4]
                            ab_rac_bt = comac[5]
                            ab_rac_tel = comac[6]
                            ab_malt = comac[7]
                            ab_iacm = comac[8]
                            ab_ras_hta = comac[9]
                            ab_ras_bt = comac[10]
                            ab_ep = comac[11]
                            ab_cb_bt = comac[12]
                            ab_cb_cu = comac[13]
                            ab_cb_fo = comac[14]
                            ab_rac_reel = comac[15]
                            ab_eta_com = comac[16]
                            ab_dan_avt = comac[17]
                            ab_com_com = comac[18]
                            ab_visuel_com = comac[19]

                    # for fa in list_bt:
                    # 	if mcd[1] == fa[16]: #fa[16][-7:].upper() == comac[0].upper():
                    # 		ab_codefiche=fa[0]
                    # 		ab_prive=fa[1]
                    # 		ab_surplomb=fa[2]
                    # 		ab_elagage=fa[3]
                    # 		ab_inv=fa[4]
                    # 		ab_hlibre=fa[5]
                    # 		ab_visuel=fa[6]
                    # 		ab_vertica=fa[7]
                    # 		ab_jaune=fa[8]
                    # 		ab_mobilis=fa[9]
                    # 		ab_gravur=fa[10]
                    # 		ab_ras_ft=fa[11]
                    # 		ab_orien=fa[12]
                    # 		ab_anc_bt=fa[13]
                    # 		ab_anc_ft=fa[14]
                    # 		ab_com_etl=fa[15]

                    list_res_export.append(
                        [ab_etiquet, ab_a_struc, ab_nature, ab_eta_mcd, ab_rac_mcd, ab_codeext, ab_etude, ab_struct,
                         ab_type,
                         ab_annee, ab_rac_bt, ab_rac_tel, ab_malt, ab_iacm, ab_ras_hta, ab_ras_bt,
                         ab_ep, ab_cb_bt, ab_cb_cu, ab_cb_fo, ab_rac_reel, ab_eta_com, ab_dan_avt, ab_com_com,
                         ab_visuel_com, ab_codefiche,
                         ab_prive, ab_surplomb, ab_elagage, ab_inv, ab_hlibre, ab_visuel, ab_vertica,
                         ab_jaune, ab_mobilis, ab_gravur, ab_ras_ft, ab_orien, ab_anc_bt, ab_anc_ft,
                         ab_com_etl, ab_nat_tvx, ab_environ, ab_val_moe, ab_com_moe, mcd[7]]
                        )
                progress_processing(index_mcd, len(list_ptech), bar_progress)
                if bar_progress.wasCanceled():
                    iface.messageBar().pushMessage('Info', 'Action Cancelled', level=Qgis.Info)
                    break
            return list_res_export

        # Execution de la function_compare_mcd_comac_fa
        list_insert_res = function_compare_mcd_comac_fa(schema)
        bar_progress = progress_bar('Execution de linsertion dans la table a_appui_bt')
        for index_insert, insert_bt in enumerate(list_insert_res):
            text_inf_insert = str(insert_bt).replace('[', '(').replace(']', ')').replace('"', '').replace('None', "''")
            function_insert_a_appuibt(schema, text_inf_insert)
            progress_processing(index_insert, len(list_insert_res), bar_progress)
            if bar_progress.wasCanceled():
                iface.messageBar().pushMessage('Info', 'Action Cancelled', level=Qgis.Info)
                break

    # Function pour recuperer la connexion de la base de donnee et rertourn lobjet de la couche
    def function_Export_appuis_hors_OK(DB, user, MP, host, port, schema, table_name, key, rename_table, path_folder):
        # import qgis.core
        a_appuift_nok = """ drop table if exists """ + schema + """.a_appuift_export; select * into """ + schema + """.a_appuift_export from """ + schema + """.a_appuift where upper(af_eta_mcd) != 'OK'"""
        a_appuibt_nok = """ drop table if exists """ + schema + """.a_appuibt_export; select * into """ + schema + """.a_appuibt_export from """ + schema + """.a_appuibt where upper(ab_eta_mcd) != 'OK'"""

        function_execute_requete(a_appuift_nok, '', connection)
        function_execute_requete(a_appuibt_nok, '', connection)
        connection.commit()

        uri = QgsDataSourceUri()
        uri.setConnection(host, port, DB, user, MP)
        uri.setDataSource(schema, table_name, "geom", '', key)  # (schema, table_name, "geom")#Shape
        layer = QgsVectorLayer(uri.uri(False), rename_table, "postgres")
        if layer.isValid():
            Chem_Rep_export = path_folder + '/' + layer.name() + ".shp"
            layer_bt_export = QgsVectorFileWriter.writeAsVectorFormat(layer, Chem_Rep_export, "LATIN1", layer.crs(),
                                                                      'ESRI Shapefile')

    # QgsProject.instance().addMapLayer(layer)
    # QMessageBox.information(w, "Message-Export", 'Le Shape est exporte dans le repertoire suivant : '+path_folder)

    # function_recperation_info_fiches_appuis_FT_General(path_folder_FT)
    function_recperation_info_fiches_appuis_BT_General(path_folder_BT, var_FA,
                                                       path_folder_Comac)  # FA_Non_Classique FA_Classique
    connection.commit()
    # Execution des exports des shapes appuis pour aller sur le terrain
    function_Export_appuis_hors_OK(DB, user, MP, host, port, schema, 'a_appuift_export', 'af_etiquet', 'a_appuift',
                                   path_folder_shp_export)
    function_Export_appuis_hors_OK(DB, user, MP, host, port, schema, 'a_appuibt_export', 'ab_etiquet', 'a_appuibt',
                                   path_folder_shp_export)
    connection.close()

    QMessageBox.information(w, "Message-Plugin",
                            'Execution du Traitement Reussi. Les Shapes pour terrain sont exportes dans le repertoire suivant : ' + path_folder_shp_export)


# function_DPI_get_inform('pr_1_13_deo_v_20191122','classique')

# Fichier_appuis=r'C:\Users\babacar.fassa\Documents\Plugins_Scripts\exe_fiche_Appui\Type_Fiches_Structure_Client\modele_dev\Audit_DPI_v191030.xlsx'
def function_retour_vt(schema, path_folder):
    # path_folder= QFileDialog.getExistingDirectory(None, 'Selection Repertoire ou se trouve les shapes des visites terrain')

    # Parameter connexion base
    # DB = 'MCD_ADN_sans_ct'#self.dlg.name_bdd.text()
    # user = 'adn_ing'
    # MP = 'password'
    # host = '192.168.30.194'
    # port = '5432'

    global DB, user, MP, host, port

    # schema = 'pr_3_4_exe_v_20191024'#pr_3_4_exe_v_20191024 #'pr_2_6_deo_v_20191014'#pr_2_6_test_deo_v_20191104

    # Declaration de la variable pour les messages derreur
    w = QWidget()

    # Function pour la progession bar1
    def progress_bar(name_etape):
        prog = QProgressDialog(name_etape + ' : Veillez Patienter', 'Cancel', 0, 100)
        prog.setWindowModality(Qt.WindowModal)
        prog.setMinimumDuration(1)
        return prog

    # Function pour la progession bar2
    def progress_processing(index, count_entite, progress_dialog):
        f = int(index + 1)
        pcnt = int(f / count_entite * 100 / 1)
        progress_dialog.setValue(pcnt)

    # Connexion a la base
    try:
        connection = psycopg2.connect(user=user, password=MP, host=host, port=port, database=DB)
    except(Exception, psycop2.DatabaseError) as error:
        QMessageBox.warning(w, "Message de connexion de la base", 'Erreur de connexion de la base')

    # Function pour executer une requete sql dans la base
    def function_execute_requete(requete_execute, req_fetch, connection):
        curs = connection.cursor()
        try:
            curs.execute(requete_execute)
            if req_fetch:
                data_req = [row for row in curs.fetchall()]
                if data_req:
                    return data_req
        except(Exception, psycopg2.DatabaseError) as error:
            QMessageBox.warning(w, "Message dexecution de requete",
                                'Requete Non Executer : ' + str(error) + ' ; ' + str(requete_execute))
        curs.close()

    # Function pour la creation de la table a_appuift_vt
    def function_creatTable_a_appuift_vt(schema):
        req = """set search_path TO """ + schema + """, public;
		DROP INDEX if exists a_aft_gidx_ft_vt;
		DROP TABLE IF EXISTS a_appuift_vt;
		CREATE TABLE a_appuift_vt
		(
			af_etiquet text,
			af_nature text,
			af_a_struc text,
			af_codeext text,
			af_eta_mcd text,
			af_struct text,
			af_inv text,
			af_visuel text,
			af_vertica text,
			af_flambe text,
			af_voisin text,
			af_pointe text,
			af_secouss text,
			af_percu text,
			af_jaune text,
			af_mobilis text,
			af_ebp text,
			af_ras text,
			af_cable text,
			af_eta_cap text,
			af_nat_tvx text,
			af_environ text,
			af_vois_el text,
			af_str_tvx text,
			af_dan_apr text,
			af_com_etl text,
			af_val_moe text,
			af_com_moe text,
			attachment text,
			geom geometry(Point,2154)
		);
		ALTER TABLE a_appuift_vt
			OWNER to adn_ing;
		GRANT INSERT, SELECT ON TABLE a_appuift_vt TO adn_ing;
		GRANT ALL ON TABLE a_appuift_vt TO adn_ing;
		CREATE INDEX a_aft_gidx_ft_vt
			ON a_appuift_vt  USING btree (geom);"""
        function_execute_requete(req, '', connection)
        connection.commit()

    # Function insertion dans table a_appuift_vt
    def function_insert_a_appuift_vt(schema, text_inf_insert):
        req = """INSERT INTO """ + schema + """.a_appuift_vt(
			af_etiquet, af_nature, af_a_struc, af_codeext, af_eta_mcd, af_struct, 
			af_inv, af_visuel, af_vertica, af_flambe, af_voisin, af_pointe, 
			af_secouss, af_percu, af_jaune, af_mobilis, af_ebp, af_ras, af_cable, 
			af_eta_cap, af_nat_tvx, af_environ, af_vois_el, af_str_tvx, af_dan_apr, 
			af_com_etl, af_val_moe, af_com_moe,attachment,geom)
				VALUES """ + text_inf_insert + """;"""  # , geom
        function_execute_requete(req, '', connection)
        connection.commit()

    # Function pour la creation de la table a_appuibt_vt
    def function_creatTable_a_appuibt_vt(schema):
        req = """set search_path TO """ + schema + """, public;
		DROP TABLE IF EXISTS a_appuibt_vt;
		CREATE TABLE a_appuibt_vt
		(
			ab_etiquet text,
			ab_a_struc text,
			ab_nature text,
			ab_eta_mcd text,
			ab_codeext text,
			ab_struct text,
			ab_type text,
			ab_annee text,
			ab_rac_bt text,
			ab_rac_tel text,
			ab_malt text,
			ab_iacm text,
			ab_ras_hta text,
			ab_ras_bt text,
			ab_ep text,
			ab_cb_bt text,
			ab_cb_cu text,
			ab_cb_fo text,
			ab_eta_com text,
			ab_dan_avt text,
			ab_codefiche text,
			ab_prive text,
			ab_surplomb text,
			ab_elagage text,
			ab_inv text,
			ab_hlibre text,
			ab_visuel text,
			ab_vertica text,
			ab_jaune text,
			ab_mobilis text,
			ab_gravur text,
			ab_ras_ft text,
			ab_orien text,
			ab_anc_bt text,
			ab_anc_ft text,
			ab_com_etl text,
			ab_nat_tvx text,
			ab_environ text,
			ab_val_moe text,
			ab_com_moe text,
			attachment text,
			geom geometry(Point,2154)
		);
		ALTER TABLE a_appuibt_vt
			OWNER to adn_ing;
		GRANT INSERT, SELECT ON TABLE a_appuibt_vt TO adn_ing;
		GRANT ALL ON TABLE a_appuibt_vt TO adn_ing;
		CREATE INDEX a_abt_vt_gidx
			ON a_appuibt_vt  USING btree (geom);"""
        function_execute_requete(req, '', connection)
        connection.commit()

    # Function insertion dans table a_appuibt_vt
    def function_insert_a_appuibt_vt(schema, text_inf_insert):
        req_truncate = """Truncate table """ + schema + """.a_appuibt_vt CASCADE;"""
        req_insert = """INSERT INTO """ + schema + """.a_appuibt_vt(
			ab_etiquet, ab_a_struc, ab_nature, ab_eta_mcd, ab_codeext, ab_struct, 
			ab_type, ab_annee, ab_rac_bt, ab_rac_tel, ab_malt, ab_iacm, ab_ras_hta, 
			ab_ras_bt, ab_ep, ab_cb_bt, ab_cb_cu, ab_cb_fo, ab_eta_com, ab_dan_avt, 
			ab_codefiche, ab_prive, ab_surplomb, ab_elagage, ab_inv, ab_hlibre, 
			ab_visuel, ab_vertica, ab_jaune, ab_mobilis, ab_gravur, ab_ras_ft, 
			ab_orien, ab_anc_bt, ab_anc_ft, ab_com_etl, ab_nat_tvx, ab_environ, 
			ab_val_moe, ab_com_moe, attachment,geom)
				VALUES """ + text_inf_insert + """;"""  # , geom
        function_execute_requete(req_truncate, '', connection)
        function_execute_requete(req_insert, '', connection)
        connection.commit()

    # Update des attributs avec la valeuu NULL
    def function_update_values_Null(schema_etude):
        req_update = """select 
			'UPDATE '||t.table_schema||'.'||t.table_name||' set '||t.column_name||' = ''''  WHERE '||t.column_name||' =''NULL'';',t.column_name, t.table_name table_name,''
		from information_schema.columns as t
		WHERE t.table_schema = '""" + schema_etude + """' and t.table_name in ('a_appuibt_vt','a_appuift_vt') and t.column_name != 'geom'"""

        list_filed_update_null = function_execute_requete(req_update, 'bab', connection)
        for index_update, update in enumerate(list_filed_update_null):
            function_execute_requete(update[0], '', connection)
        connection.commit()

    # Function pour la creation de la table a_appuibt_delta
    def function_creatTable_a_appuibt_delta(schema):
        req = """set search_path TO """ + schema + """, public;
		DROP TABLE IF EXISTS a_appuibt_delta;
		CREATE TABLE a_appuibt_delta
		(
			ab_etiquet text,
			ab_a_struc text,
			ab_nature text,
			ab_eta_mcd text,
			ab_codeext text,
			ab_struct text,
			ab_type text,
			ab_annee text,
			ab_rac_bt text,
			ab_rac_tel text,
			ab_malt text,
			ab_iacm text,
			ab_ras_hta text,
			ab_ras_bt text,
			ab_ep text,
			ab_cb_bt text,
			ab_cb_cu text,
			ab_cb_fo text,
			ab_eta_com text,
			ab_dan_avt text,
			ab_codefiche text,
			ab_prive text,
			ab_surplomb text,
			ab_elagage text,
			ab_inv text,
			ab_hlibre text,
			ab_visuel text,
			ab_vertica text,
			ab_jaune text,
			ab_mobilis text,
			ab_gravur text,
			ab_ras_ft text,
			ab_orien text,
			ab_anc_bt text,
			ab_anc_ft text,
			ab_com_etl text,
			ab_nat_tvx text,
			ab_environ text,
			ab_val_moe text,
			ab_com_moe text,
			attachment text,
			geom geometry(Point,2154)
		);
		ALTER TABLE a_appuibt_delta
			OWNER to adn_ing;
		GRANT INSERT, SELECT ON TABLE a_appuibt_delta TO adn_ing;
		GRANT ALL ON TABLE a_appuibt_delta TO adn_ing;
		CREATE INDEX a_a_appuibt_delta
			ON a_appuibt_delta  USING btree (geom);"""
        function_execute_requete(req, '', connection)
        connection.commit()

    # Function pour la creation de la table a_appuift_delta
    def function_creatTable_a_appuift_delta(schema):
        req = """set search_path TO """ + schema + """, public;
		DROP TABLE IF EXISTS a_appuift_delta;
		CREATE TABLE a_appuift_delta
		(
			af_etiquet text,
			af_nature text,
			af_a_struc text,
			af_codeext text,
			af_eta_mcd text,
			af_struct text,
			af_inv text,
			af_visuel text,
			af_vertica text,
			af_flambe text,
			af_voisin text,
			af_pointe text,
			af_secouss text,
			af_percu text,
			af_jaune text,
			af_mobilis text,
			af_ebp text,
			af_ras text,
			af_cable text,
			af_eta_cap text,
			af_nat_tvx text,
			af_environ text,
			af_vois_el text,
			af_str_tvx text,
			af_dan_apr text,
			af_com_etl text,
			af_val_moe text,
			af_com_moe text,
			attachment text,
			geom geometry(Point,2154)
		);
		ALTER TABLE a_appuift_delta
			OWNER to adn_ing;
		GRANT INSERT, SELECT ON TABLE a_appuift_delta TO adn_ing;
		GRANT ALL ON TABLE a_appuift_delta TO adn_ing;
		CREATE INDEX a_a_appuift_delta
			ON a_appuift_delta  USING btree (geom);"""
        function_execute_requete(req, '', connection)
        connection.commit()

    # Function insertion dans table a_appuibt_delta
    def function_insert_a_appuibt_delta(schema, text_inf_insert):
        req_truncate = """Truncate table """ + schema + """.a_appuibt_delta CASCADE;"""
        req_insert = """INSERT INTO """ + schema + """.a_appuibt_delta(
			ab_etiquet, ab_a_struc, ab_nature, ab_eta_mcd, ab_codeext, ab_struct, 
			ab_type, ab_annee, ab_rac_bt, ab_rac_tel, ab_malt, ab_iacm, ab_ras_hta, 
			ab_ras_bt, ab_ep, ab_cb_bt, ab_cb_cu, ab_cb_fo, ab_eta_com, ab_dan_avt, 
			ab_codefiche, ab_prive, ab_surplomb, ab_elagage, ab_inv, ab_hlibre, 
			ab_visuel, ab_vertica, ab_jaune, ab_mobilis, ab_gravur, ab_ras_ft, 
			ab_orien, ab_anc_bt, ab_anc_ft, ab_com_etl, ab_nat_tvx, ab_environ, 
			ab_val_moe, ab_com_moe, attachment,geom)
				VALUES """ + text_inf_insert + """;"""  # , geom
        # print (req_insert)
        function_execute_requete(req_truncate, '', connection)
        function_execute_requete(req_insert, '', connection)
        connection.commit()

    # Function insertion dans table a_appuift_vt
    def function_insert_a_appuift_delta(schema, text_inf_insert):
        req = """INSERT INTO """ + schema + """.a_appuift_delta(
			af_etiquet, af_nature, af_a_struc, af_codeext, af_eta_mcd, af_struct, 
			af_inv, af_visuel, af_vertica, af_flambe, af_voisin, af_pointe, 
			af_secouss, af_percu, af_jaune, af_mobilis, af_ebp, af_ras, af_cable, 
			af_eta_cap, af_nat_tvx, af_environ, af_vois_el, af_str_tvx, af_dan_apr, 
			af_com_etl, af_val_moe, af_com_moe,attachment,geom)
				VALUES """ + text_inf_insert + """;"""  # , geom
        function_execute_requete(req, '', connection)
        connection.commit()

    # Execution de la function_creatTable_a_appuibt_vt
    function_creatTable_a_appuibt_vt(schema)
    # Execution de la function_creatTable_a_appuift_vt
    function_creatTable_a_appuift_vt(schema)
    # Execution de la function_creatTable_a_appuibt_delta
    function_creatTable_a_appuibt_delta(schema)
    # Execution de la function_creatTable_a_appuift_delta
    function_creatTable_a_appuift_delta(schema)

    # Funciton de creations des noms des groups
    def function_create_groupe_name(name_groupe):
        root = QgsProject.instance().layerTreeRoot()
        group = root.findGroup(name_groupe)
        root.removeChildNode(group)
        shapeGroup = root.addGroup(name_groupe)
        return shapeGroup

    # Function pour ajouter les tables dans leur groupe respectif
    def function_add_layer_group(layer_to_add, groupe_name):
        QgsProject.instance().addMapLayer(layer_to_add, False)
        groupe_name.insertChildNode(0, QgsLayerTreeLayer(layer_to_add))

    # Function Suppression du group ajoute dans QGis
    def functiondelete_layer_qgis(name_groupe):
        root = QgsProject.instance().layerTreeRoot()
        group = root.findGroup(name_groupe)
        if group is not None:
            root.removeChildNode(group)

    # Function pour chargement des couches dans Qgis
    def function_chargement_layer_qgis(path_folder):
        bar_progress_char_qgis = progress_bar('Chargement des donnees dans Qgis')
        if path_folder:
            # Declaration des noms des groupes a travers la function de creatino des groups
            shape_group = function_create_groupe_name('SHAPE_Visite_terrain')
            folder_iterate = os.listdir(path_folder)
            for index_char_qgis, file_etude in enumerate(folder_iterate):
                chemin = path_folder
                name, ext = os.path.splitext(file_etude)
                chem_etude = chemin + '/' + file_etude
                if ext == ".shp" and name in ('a_appuift', 'a_appuibt'):
                    layer_shp_etude = QgsVectorLayer(chem_etude, name, 'ogr')
                    try:
                        function_add_layer_group(layer_shp_etude, shape_group)
                    except(Exception) as error:
                        QMessageBox.warning(w, "Message dexecution de requete",
                                            'Erreur dexecution du chargement du shape dans Qgis' + name)
                progress_processing(index_char_qgis, len(folder_iterate), bar_progress_char_qgis)
                if bar_progress_char_qgis.wasCanceled():
                    iface.messageBar().pushMessage('Info', 'Action Cancelled', level=Qgis.Info)
                    break

    # Function pour insertion des retours terrains
    def function_insert_a_appui_bt_ft_vt(schema, layer_name_appui):
        len_maplayer = len(QgsProject.instance().mapLayers().values())
        for index_map, layers_name_mapLayers in enumerate(QgsProject.instance().mapLayers().values()):
            layer_name = layers_name_mapLayers.name()
            layer_features = layers_name_mapLayers.getFeatures()
            if layer_name == layer_name_appui:  # 'a_appuibt':
                if layers_name_mapLayers.type() == QgsMapLayer.VectorLayer:
                    layer_not_empty = len(list(layer_features))
                    if layer_not_empty > 0:
                        list_insert_entite = []
                        layer_features = layers_name_mapLayers.getFeatures()
                        for index_layer, layer in enumerate(layer_features):
                            geome_text = layer.geometry().asWkt()
                            attr_insert = '-1'
                            replace_null_value = tuple(
                                ['NULL' if field in [NULL, '??'] else unicode(field).replace("'", '') for field in
                                 layer.attributes()])
                            if geome_text:
                                attr_insert = replace_null_value + ("ST_GeomFromText('" + geome_text + "',2154)",)
                            list_insert_entite.append(attr_insert)
                req_insert_finale = unicode(list_insert_entite).replace('[(', '(').replace(')]', ')').replace('"', '')
                if layer_name_appui == 'a_appuibt':
                    function_insert_a_appuibt_vt(schema, req_insert_finale)
                elif layer_name_appui == 'a_appuift':
                    function_insert_a_appuift_vt(schema, req_insert_finale)

    # Execution function du chargement des couches
    function_chargement_layer_qgis(path_folder)
    # Execution function insertion des retours terrain BT
    function_insert_a_appui_bt_ft_vt(schema, 'a_appuibt')
    # Execution function insertion des retours terrain FT
    function_insert_a_appui_bt_ft_vt(schema, 'a_appuift')
    # Execution function des mises a jours des valeurs NULL
    function_update_values_Null(schema)
    # Suppression des shapes ajoutes dans qgis
    functiondelete_layer_qgis('SHAPE_Visite_terrain')

    # Function pour recuperer les attributs editables
    def function_delta_vt_base(Fichier_appuis, col_feuille):
        def function_column_editable(Fichier_appuis, col_feuille):
            xl_workbook = xlrd.open_workbook(Fichier_appuis)  # Fichier_appuis_nok[0] avec boite dialogue
            xl_sheet = xl_workbook.sheet_by_index(col_feuille)  # idx
            sheet_names = xl_workbook.sheet_names()
            list_fa_bt_classic = range(0, xl_sheet.nrows)
            headers = []
            sdata = []
            for index_classic, row in enumerate(list_fa_bt_classic):
                values = []
                for col in range(xl_sheet.ncols):
                    data = str(xl_sheet.cell(row, col).value)  # .replace('.0','').upper().replace("'",'')
                    if col in (1, 2, 3, 4):
                        if row == 0:
                            headers.append(data)
                        else:
                            values.append(data)
                if values:
                    sdata.append(values)

            list_attribut_edit = []
            for index_classic, row in enumerate(sdata):
                if row[3] == 'éditable':
                    list_attribut_edit.append(row[0])
            return list_attribut_edit

        list_attribut_edit = ['ab_type', 'ab_annee', 'ab_prive', 'ab_surplomb', 'ab_elagage', \
                              'ab_inv', 'ab_hlibre', 'ab_visuel', 'ab_vertica', 'ab_jaune', 'ab_mobilis', \
                              'ab_gravur', 'ab_rac_bt', 'ab_rac_tel', 'ab_malt', 'ab_iacm', 'ab_ras_hta', \
                              'ab_ras_bt', 'ab_ras_ft', 'ab_ep', 'ab_orien', 'ab_nat_tvx', 'ab_environ', \
                              'ab_val_moe', 'ab_com_moe', 'attachment']

        list_attribut_edit_ft = ['af_etiquet', 'af_codeext', 'af_nature', 'af_a_struc'
            , 'af_codeext', 'af_inv', 'af_visuel', 'af_vertica'
            , 'af_flambe', 'af_voisin', 'af_pointe', 'af_secouss'
            , 'af_percu', 'af_jaune', 'af_mobilis', 'af_ebp']

        dict_list_attribut_edit = {}
        for index_j, j in enumerate(list_attribut_edit):
            dict_list_attribut_edit[index_j] = j

        column_edit = ','.join(list_attribut_edit)

        def function_create_table_delta(a_appuibt, a_appuibt_vt, type_insert):

            req_a_appui_bt = """select * from """ + schema + """.""" + a_appuibt
            list_req_a_appui_bt = function_execute_requete(req_a_appui_bt, 'req_fetch', connection)

            req_a_appui_bt_vt = """select * from """ + schema + """.""" + a_appuibt_vt
            list_req_a_appui_bt_vt = function_execute_requete(req_a_appui_bt_vt, 'req_fetch', connection)

            req_attribut_position = """SELECT 
				column_name as column_name_compare, 
				table_name as table_name_compare,
				ordinal_position
			FROM INFORMATION_SCHEMA.COLUMNS
				   WHERE table_schema = '""" + schema + """' AND table_name in ('""" + a_appuibt_vt + """')"""

            list_attribut_with_position = function_execute_requete(req_attribut_position, 'req_fetch', connection)

            def function_get_index_by_value_edit(list_attribut_with_position, var_get_index, var_bt_base, var_bt_vt,
                                                 type_return):
                # return_value='NC_VT'
                for index_pos, pos in enumerate(list_attribut_with_position):
                    if var_get_index == pos[0]:
                        if type_return == 'edit':
                            if var_bt_base[pos[2] - 1] != var_bt_vt[pos[2] - 1]:
                                return 'NC_VT'
                            elif var_bt_base[pos[2] - 1] == var_bt_vt[pos[2] - 1]:
                                return var_bt_base[pos[2] - 1]
                        elif type_return == 'not_edit':
                            return var_bt_base[pos[2] - 1]
                        elif type_return == 'vt_edit':
                            return var_bt_vt[pos[2] - 1]
                        else:
                            return '-2'

            list_insert_delta_bt = []
            list_insert_delta_ft = []
            bar_progress = progress_bar('Execution de la function de Delta')
            for index_bt_base, bt_base in enumerate(list_req_a_appui_bt):
                # Partie FT
                af_etiquet = function_get_index_by_value_edit(list_attribut_with_position, 'af_etiquet', bt_base, '',
                                                              'not_edit')
                af_codeext = function_get_index_by_value_edit(list_attribut_with_position, 'af_codeext', bt_base, '',
                                                              'not_edit')
                af_a_struc = function_get_index_by_value_edit(list_attribut_with_position, 'af_a_struc', bt_base, '',
                                                              'not_edit')
                af_cable = function_get_index_by_value_edit(list_attribut_with_position, 'af_cable', bt_base, '',
                                                            'not_edit')
                af_eta_mcd = function_get_index_by_value_edit(list_attribut_with_position, 'af_eta_mcd', bt_base, '',
                                                              'not_edit')
                af_eta_cap = function_get_index_by_value_edit(list_attribut_with_position, 'af_eta_cap', bt_base, '',
                                                              'not_edit')
                af_nat_tvx = function_get_index_by_value_edit(list_attribut_with_position, 'af_nat_tvx', bt_base, '',
                                                              'not_edit')
                af_str_tvx = function_get_index_by_value_edit(list_attribut_with_position, 'af_str_tvx', bt_base, '',
                                                              'not_edit')
                af_dan_apr = function_get_index_by_value_edit(list_attribut_with_position, 'af_dan_apr', bt_base, '',
                                                              'not_edit')
                af_com_etl = function_get_index_by_value_edit(list_attribut_with_position, 'af_com_etl', bt_base, '',
                                                              'not_edit')
                af_struct = function_get_index_by_value_edit(list_attribut_with_position, 'af_struct', bt_base, '',
                                                             'not_edit')

                af_nature = function_get_index_by_value_edit(list_attribut_with_position, 'af_nature', bt_base, '',
                                                             'not_edit')
                # af_codeext=function_get_index_by_value_edit(list_attribut_with_position,'af_codeext',bt_base,'','not_edit')
                af_inv = function_get_index_by_value_edit(list_attribut_with_position, 'af_inv', bt_base, '',
                                                          'not_edit')
                af_visuel = function_get_index_by_value_edit(list_attribut_with_position, 'af_visuel', bt_base, '',
                                                             'not_edit')
                af_vertica = function_get_index_by_value_edit(list_attribut_with_position, 'af_vertica', bt_base, '',
                                                              'not_edit')
                af_flambe = function_get_index_by_value_edit(list_attribut_with_position, 'af_flambe', bt_base, '',
                                                             'not_edit')
                af_voisin = function_get_index_by_value_edit(list_attribut_with_position, 'af_voisin', bt_base, '',
                                                             'not_edit')
                af_pointe = function_get_index_by_value_edit(list_attribut_with_position, 'af_pointe', bt_base, '',
                                                             'not_edit')
                af_secouss = function_get_index_by_value_edit(list_attribut_with_position, 'af_secouss', bt_base, '',
                                                              'not_edit')
                af_percu = function_get_index_by_value_edit(list_attribut_with_position, 'af_percu', bt_base, '',
                                                            'not_edit')
                af_jaune = function_get_index_by_value_edit(list_attribut_with_position, 'af_jaune', bt_base, '',
                                                            'not_edit')
                af_mobilis = function_get_index_by_value_edit(list_attribut_with_position, 'af_mobilis', bt_base, '',
                                                              'not_edit')
                af_ebp = function_get_index_by_value_edit(list_attribut_with_position, 'af_ebp', bt_base, '',
                                                          'not_edit')
                af_ras = function_get_index_by_value_edit(list_attribut_with_position, 'af_ras', bt_base, '',
                                                          'not_edit')
                af_environ = function_get_index_by_value_edit(list_attribut_with_position, 'af_environ', bt_base, '',
                                                              'not_edit')
                af_vois_el = function_get_index_by_value_edit(list_attribut_with_position, 'af_vois_el', bt_base, '',
                                                              'not_edit')
                af_val_moe = function_get_index_by_value_edit(list_attribut_with_position, 'af_val_moe', bt_base, '',
                                                              'not_edit')
                af_com_moe = function_get_index_by_value_edit(list_attribut_with_position, 'af_com_moe', bt_base, '',
                                                              'not_edit')
                attachment = function_get_index_by_value_edit(list_attribut_with_position, 'attachment', bt_base, '',
                                                              'not_edit')

                # Partie BT
                ab_etiquet = function_get_index_by_value_edit(list_attribut_with_position, 'ab_etiquet', bt_base, '',
                                                              'not_edit')
                ab_codeext = function_get_index_by_value_edit(list_attribut_with_position, 'ab_codeext', bt_base, '',
                                                              'not_edit')
                ab_codefiche = function_get_index_by_value_edit(list_attribut_with_position, 'ab_codefiche', bt_base,
                                                                '', 'not_edit')
                ab_a_struc = function_get_index_by_value_edit(list_attribut_with_position, 'ab_a_struc', bt_base, '',
                                                              'not_edit')
                ab_struct = function_get_index_by_value_edit(list_attribut_with_position, 'ab_struct', bt_base, '',
                                                             'not_edit')
                ab_nature = function_get_index_by_value_edit(list_attribut_with_position, 'ab_nature', bt_base, '',
                                                             'not_edit')
                ab_anc_bt = function_get_index_by_value_edit(list_attribut_with_position, 'ab_anc_bt', bt_base, '',
                                                             'not_edit')
                ab_anc_ft = function_get_index_by_value_edit(list_attribut_with_position, 'ab_anc_ft', bt_base, '',
                                                             'not_edit')
                ab_cb_bt = function_get_index_by_value_edit(list_attribut_with_position, 'ab_cb_bt', bt_base, '',
                                                            'not_edit')
                ab_cb_cu = function_get_index_by_value_edit(list_attribut_with_position, 'ab_cb_cu', bt_base, '',
                                                            'not_edit')
                ab_cb_fo = function_get_index_by_value_edit(list_attribut_with_position, 'ab_cb_fo', bt_base, '',
                                                            'not_edit')
                ab_eta_mcd = function_get_index_by_value_edit(list_attribut_with_position, 'ab_eta_mcd', bt_base, '',
                                                              'not_edit')
                ab_eta_com = function_get_index_by_value_edit(list_attribut_with_position, 'ab_eta_com', bt_base, '',
                                                              'not_edit')
                ab_dan_avt = function_get_index_by_value_edit(list_attribut_with_position, 'ab_dan_avt', bt_base, '',
                                                              'not_edit')
                ab_com_etl = function_get_index_by_value_edit(list_attribut_with_position, 'ab_com_etl', bt_base, '',
                                                              'not_edit')

                ab_type = function_get_index_by_value_edit(list_attribut_with_position, 'ab_type', bt_base, '',
                                                           'not_edit')
                ab_annee = function_get_index_by_value_edit(list_attribut_with_position, 'ab_annee', bt_base, '',
                                                            'not_edit')
                ab_prive = function_get_index_by_value_edit(list_attribut_with_position, 'ab_prive', bt_base, '',
                                                            'not_edit')
                ab_surplomb = function_get_index_by_value_edit(list_attribut_with_position, 'ab_surplomb', bt_base, '',
                                                               'not_edit')
                ab_elagage = function_get_index_by_value_edit(list_attribut_with_position, 'ab_elagage', bt_base, '',
                                                              'not_edit')
                ab_inv = function_get_index_by_value_edit(list_attribut_with_position, 'ab_inv', bt_base, '',
                                                          'not_edit')
                ab_hlibre = function_get_index_by_value_edit(list_attribut_with_position, 'ab_hlibre', bt_base, '',
                                                             'not_edit')
                ab_visuel = function_get_index_by_value_edit(list_attribut_with_position, 'ab_visuel', bt_base, '',
                                                             'not_edit')
                ab_vertica = function_get_index_by_value_edit(list_attribut_with_position, 'ab_vertica', bt_base, '',
                                                              'not_edit')
                ab_jaune = function_get_index_by_value_edit(list_attribut_with_position, 'ab_jaune', bt_base, '',
                                                            'not_edit')
                ab_mobilis = function_get_index_by_value_edit(list_attribut_with_position, 'ab_mobilis', bt_base, '',
                                                              'not_edit')
                ab_gravur = function_get_index_by_value_edit(list_attribut_with_position, 'ab_gravur', bt_base, '',
                                                             'not_edit')
                ab_rac_bt = function_get_index_by_value_edit(list_attribut_with_position, 'ab_rac_bt', bt_base, '',
                                                             'not_edit')
                ab_rac_tel = function_get_index_by_value_edit(list_attribut_with_position, 'ab_rac_tel', bt_base, '',
                                                              'not_edit')
                ab_malt = function_get_index_by_value_edit(list_attribut_with_position, 'ab_malt', bt_base, '',
                                                           'not_edit')
                ab_iacm = function_get_index_by_value_edit(list_attribut_with_position, 'ab_iacm', bt_base, '',
                                                           'not_edit')
                ab_ras_hta = function_get_index_by_value_edit(list_attribut_with_position, 'ab_ras_hta', bt_base, '',
                                                              'not_edit')
                ab_ras_bt = function_get_index_by_value_edit(list_attribut_with_position, 'ab_ras_bt', bt_base, '',
                                                             'not_edit')
                ab_ras_ft = function_get_index_by_value_edit(list_attribut_with_position, 'ab_ras_ft', bt_base, '',
                                                             'not_edit')
                ab_ep = function_get_index_by_value_edit(list_attribut_with_position, 'ab_ep', bt_base, '', 'not_edit')
                ab_orien = function_get_index_by_value_edit(list_attribut_with_position, 'ab_orien', bt_base, '',
                                                            'not_edit')
                ab_nat_tvx = function_get_index_by_value_edit(list_attribut_with_position, 'ab_nat_tvx', bt_base, '',
                                                              'not_edit')
                ab_environ = function_get_index_by_value_edit(list_attribut_with_position, 'ab_environ', bt_base, '',
                                                              'not_edit')
                ab_val_moe = function_get_index_by_value_edit(list_attribut_with_position, 'ab_val_moe', bt_base, '',
                                                              'not_edit')
                ab_com_moe = function_get_index_by_value_edit(list_attribut_with_position, 'ab_com_moe', bt_base, '',
                                                              'not_edit')
                attachment = function_get_index_by_value_edit(list_attribut_with_position, 'attachment', bt_base, '',
                                                              'not_edit')
                if list_req_a_appui_bt_vt:
                    for bt_vt in list_req_a_appui_bt_vt:
                        if bt_base[0] == bt_vt[0]:
                            # Attribut editable
                            # Partie FT
                            af_nature = function_get_index_by_value_edit(list_attribut_with_position, 'af_nature',
                                                                         bt_base, bt_vt, 'edit')
                            af_struct = function_get_index_by_value_edit(list_attribut_with_position, 'af_struct',
                                                                         bt_base, bt_vt, 'edit')
                            af_inv = function_get_index_by_value_edit(list_attribut_with_position, 'af_inv', bt_base,
                                                                      bt_vt, 'edit')
                            af_visuel = function_get_index_by_value_edit(list_attribut_with_position, 'af_visuel',
                                                                         bt_base, bt_vt, 'edit')
                            af_vertica = function_get_index_by_value_edit(list_attribut_with_position, 'af_vertica',
                                                                          bt_base, bt_vt, 'edit')
                            af_flambe = function_get_index_by_value_edit(list_attribut_with_position, 'af_flambe',
                                                                         bt_base, bt_vt, 'edit')
                            af_voisin = function_get_index_by_value_edit(list_attribut_with_position, 'af_voisin',
                                                                         bt_base, bt_vt, 'edit')
                            af_pointe = function_get_index_by_value_edit(list_attribut_with_position, 'af_pointe',
                                                                         bt_base, bt_vt, 'edit')
                            af_secouss = function_get_index_by_value_edit(list_attribut_with_position, 'af_secouss',
                                                                          bt_base, bt_vt, 'edit')
                            af_percu = function_get_index_by_value_edit(list_attribut_with_position, 'af_percu',
                                                                        bt_base, bt_vt, 'edit')
                            af_jaune = function_get_index_by_value_edit(list_attribut_with_position, 'af_jaune',
                                                                        bt_base, bt_vt, 'edit')
                            af_mobilis = function_get_index_by_value_edit(list_attribut_with_position, 'af_mobilis',
                                                                          bt_base, bt_vt, 'edit')
                            af_ebp = function_get_index_by_value_edit(list_attribut_with_position, 'af_ebp', bt_base,
                                                                      bt_vt, 'edit')
                            af_ras = function_get_index_by_value_edit(list_attribut_with_position, 'af_ras', bt_base,
                                                                      bt_vt, 'edit')
                            af_environ = function_get_index_by_value_edit(list_attribut_with_position, 'af_environ',
                                                                          bt_base, bt_vt, 'edit')
                            af_vois_el = function_get_index_by_value_edit(list_attribut_with_position, 'af_vois_el',
                                                                          bt_base, bt_vt, 'edit')
                            af_val_moe = function_get_index_by_value_edit(list_attribut_with_position, 'af_val_moe',
                                                                          bt_base, bt_vt, 'vt_edit')
                            af_com_moe = function_get_index_by_value_edit(list_attribut_with_position, 'af_com_moe',
                                                                          bt_base, bt_vt, 'vt_edit')
                            attachment = function_get_index_by_value_edit(list_attribut_with_position, 'attachment',
                                                                          bt_base, bt_vt, 'vt_edit')

                            # Partie BT
                            ab_type = function_get_index_by_value_edit(list_attribut_with_position, 'ab_type', bt_base,
                                                                       bt_vt, 'edit')
                            ab_annee = function_get_index_by_value_edit(list_attribut_with_position, 'ab_annee',
                                                                        bt_base, bt_vt, 'edit')
                            ab_prive = function_get_index_by_value_edit(list_attribut_with_position, 'ab_prive',
                                                                        bt_base, bt_vt, 'edit')
                            ab_surplomb = function_get_index_by_value_edit(list_attribut_with_position, 'ab_surplomb',
                                                                           bt_base, bt_vt, 'edit')
                            ab_elagage = function_get_index_by_value_edit(list_attribut_with_position, 'ab_elagage',
                                                                          bt_base, bt_vt, 'edit')
                            ab_inv = function_get_index_by_value_edit(list_attribut_with_position, 'ab_inv', bt_base,
                                                                      bt_vt, 'edit')
                            ab_hlibre = function_get_index_by_value_edit(list_attribut_with_position, 'ab_hlibre',
                                                                         bt_base, bt_vt, 'edit')
                            ab_visuel = function_get_index_by_value_edit(list_attribut_with_position, 'ab_visuel',
                                                                         bt_base, bt_vt, 'edit')
                            ab_vertica = function_get_index_by_value_edit(list_attribut_with_position, 'ab_vertica',
                                                                          bt_base, bt_vt, 'edit')
                            ab_jaune = function_get_index_by_value_edit(list_attribut_with_position, 'ab_jaune',
                                                                        bt_base, bt_vt, 'edit')
                            ab_mobilis = function_get_index_by_value_edit(list_attribut_with_position, 'ab_mobilis',
                                                                          bt_base, bt_vt, 'edit')
                            ab_gravur = function_get_index_by_value_edit(list_attribut_with_position, 'ab_gravur',
                                                                         bt_base, bt_vt, 'edit')
                            ab_rac_bt = function_get_index_by_value_edit(list_attribut_with_position, 'ab_rac_bt',
                                                                         bt_base, bt_vt, 'edit')
                            ab_rac_tel = function_get_index_by_value_edit(list_attribut_with_position, 'ab_rac_tel',
                                                                          bt_base, bt_vt, 'edit')
                            ab_malt = function_get_index_by_value_edit(list_attribut_with_position, 'ab_malt', bt_base,
                                                                       bt_vt, 'edit')
                            ab_iacm = function_get_index_by_value_edit(list_attribut_with_position, 'ab_iacm', bt_base,
                                                                       bt_vt, 'edit')
                            ab_ras_hta = function_get_index_by_value_edit(list_attribut_with_position, 'ab_ras_hta',
                                                                          bt_base, bt_vt, 'edit')
                            ab_ras_bt = function_get_index_by_value_edit(list_attribut_with_position, 'ab_ras_bt',
                                                                         bt_base, bt_vt, 'edit')
                            ab_ras_ft = function_get_index_by_value_edit(list_attribut_with_position, 'ab_ras_ft',
                                                                         bt_base, bt_vt, 'edit')
                            ab_ep = function_get_index_by_value_edit(list_attribut_with_position, 'ab_ep', bt_base,
                                                                     bt_vt, 'edit')
                            ab_orien = function_get_index_by_value_edit(list_attribut_with_position, 'ab_orien',
                                                                        bt_base, bt_vt, 'edit')
                            ab_nat_tvx = function_get_index_by_value_edit(list_attribut_with_position, 'ab_nat_tvx',
                                                                          bt_base, bt_vt, 'vt_edit')
                            ab_environ = function_get_index_by_value_edit(list_attribut_with_position, 'ab_environ',
                                                                          bt_base, bt_vt, 'vt_edit')
                            ab_val_moe = function_get_index_by_value_edit(list_attribut_with_position, 'ab_val_moe',
                                                                          bt_base, bt_vt, 'vt_edit')
                            ab_com_moe = function_get_index_by_value_edit(list_attribut_with_position, 'ab_com_moe',
                                                                          bt_base, bt_vt, 'vt_edit')
                            attachment = function_get_index_by_value_edit(list_attribut_with_position, 'attachment',
                                                                          bt_base, bt_vt, 'vt_edit')

                list_insert_delta_bt.append(
                    [ab_etiquet, ab_a_struc, ab_nature, ab_eta_mcd, ab_codeext, ab_struct, ab_type,
                     ab_annee, ab_rac_bt, ab_rac_tel, ab_malt, ab_iacm, ab_ras_hta, ab_ras_bt,
                     ab_ep, ab_cb_bt, ab_cb_cu, ab_cb_fo, ab_eta_com, ab_dan_avt, ab_codefiche,
                     ab_prive, ab_surplomb, ab_elagage, ab_inv, ab_hlibre, ab_visuel, ab_vertica,
                     ab_jaune, ab_mobilis, ab_gravur, ab_ras_ft, ab_orien, ab_anc_bt, ab_anc_ft,
                     ab_com_etl, ab_nat_tvx, ab_environ, ab_val_moe, ab_com_moe, attachment,
                     "ST_GeomFromText(st_astext('" + bt_base[-1] + "'),2154)"])

                list_insert_delta_ft.append(
                    [af_etiquet, af_nature, af_a_struc, af_codeext, af_eta_mcd, af_struct, af_inv
                        , af_visuel, af_vertica, af_flambe, af_voisin, af_pointe, af_secouss, af_percu
                        , af_jaune, af_mobilis, af_ebp, af_ras, af_cable, af_eta_cap, af_nat_tvx
                        , af_environ, af_vois_el, af_str_tvx, af_dan_apr, af_com_etl, af_val_moe, af_com_moe,
                     attachment,
                     "ST_GeomFromText(st_astext('" + bt_base[-1] + "'),2154)"])

                progress_processing(index_bt_base, len(list_req_a_appui_bt), bar_progress)
                if bar_progress.wasCanceled():
                    iface.messageBar().pushMessage('Info', 'Action Cancelled', level=Qgis.Info)
                    break
            if type_insert == 'a_appuibt':
                # Execution de linsertion du delta
                req_insert_delta_bt = unicode(list_insert_delta_bt).replace('[', '(').replace(']', ')').replace('"',
                                                                                                                '').replace(
                    'None', "''").replace('((', '(').replace(')))', '))')
                function_insert_a_appuibt_delta(schema, req_insert_delta_bt)
            elif type_insert == 'a_appuift':
                # Execution de linsertion du delta
                req_insert_delta_ft = unicode(list_insert_delta_ft).replace('[', '(').replace(']', ')').replace('"',
                                                                                                                '').replace(
                    'None', "''").replace('((', '(').replace(')))', '))')
                function_insert_a_appuift_delta(schema, req_insert_delta_ft)

        # Execution des functions de create des tables delta
        function_create_table_delta('a_appuibt', 'a_appuibt_vt', 'a_appuibt')
        function_create_table_delta('a_appuift', 'a_appuift_vt', 'a_appuift')

    function_delta_vt_base('Fichier_appuis', '3')

    # Function pour exporter les tables deltas de BT et FT
    def function_Export_appuis_delta(DB, user, MP, host, port, schema, table_name, key, rename_table, path_folder):
        # import qgis.core
        uri = QgsDataSourceUri()
        uri.setConnection(host, port, DB, user, MP)
        uri.setDataSource(schema, table_name, "geom", '', key)  # (schema, table_name, "geom")#Shape
        layer = QgsVectorLayer(uri.uri(False), rename_table, "postgres")
        if layer.isValid():
            Chem_Rep_export = path_folder + '/' + layer.name() + ".shp"
            layer_bt_export = QgsVectorFileWriter.writeAsVectorFormat(layer, Chem_Rep_export, "LATIN1", layer.crs(),
                                                                      'ESRI Shapefile')

    # QgsProject.instance().addMapLayer(layer)
    # QMessageBox.information(w, "Message-Export", 'Le Shape est exporte dans le repertoire suivant : '+path_folder)

    # Execution des exports des shapes appuis delta
    function_Export_appuis_delta(DB, user, MP, host, port, schema, 'a_appuift_delta', 'af_etiquet', 'a_appuift_delta',
                                 path_folder)
    function_Export_appuis_delta(DB, user, MP, host, port, schema, 'a_appuibt_delta', 'ab_etiquet', 'a_appuibt_delta',
                                 path_folder)
    connection.close()
    QMessageBox.information(w, "Message-Plugin",
                            'Execution du Traitement Reussi. Les Shapes Delta sont exportes dans le repertoire suivant : ' + path_folder)

# # Class General des functions
# class GeneralFunctions:
#     global DB, user, MP, host, port
#
#     # Constructeur des variables qui change
#     def __init__(self, var_connection):
#         self.connection = var_connection
#
#     # Declaration de la variable pour les messages derreur
#     w = QWidget()
#
#     # Function pour la progession bar1
#     def progress_bar(self, name_etape):
#         prog = QProgressDialog(name_etape + ' : Veillez Patienter', 'Cancel', 0, 100)
#         prog.setWindowModality(Qt.WindowModal)
#         prog.setMinimumDuration(1)
#         return prog
#
#     # Function pour la progession bar2
#     def progress_processing(self, index, count_entite, progress_dialog):
#         f = int(index + 1)
#         pcnt = int(f / count_entite * 100 / 1)
#         progress_dialog.setValue(pcnt)
#
#     # Function pour executer une requete sql dans la base
#     def function_execute_requete(self, requete_execute, req_fetch):
#         connection = self.connection
#         curs = connection.cursor()
#         try:
#             curs.execute(requete_execute)
#             if req_fetch:
#                 data_req = [row for row in curs.fetchall()]
#                 if data_req:
#                     return data_req
#         except(Exception, psycopg2.DatabaseError) as error:
#             QMessageBox.warning(self.w, "Message dexecution de requete",
#                                 'Requete Non Executer : ' + str(error) + ' ; ' + str(requete_execute))
#         connection.commit()
#         curs.close()
#
#     # Function pour la creation de la table a_appuibt
#     def function_creatTable_a_appuibt(self, schema):
#         req = """set search_path TO """ + schema + """, public;
#             DROP TABLE IF EXISTS a_appuibt;
#             CREATE TABLE a_appuibt
#             (
#                 ab_etiquet text,
#                 ab_a_struc text,
#                 ab_nature text,
#                 ab_eta_mcd text,
#                 ab_rac_mcd text,
#                 ab_codeext text,
#                 ab_etude text,
#                 ab_struct text,
#                 ab_type text,
#                 ab_annee text,
#                 ab_rac_bt text,
#                 ab_rac_tel text,
#                 ab_malt text,
#                 ab_iacm text,
#                 ab_ras_hta text,
#                 ab_ras_bt text,
#                 ab_ep text,
#                 ab_cb_bt text,
#                 ab_cb_cu text,
#                 ab_cb_fo text,
#                 ab_rac_reel text,
#                 ab_eta_com text,
#                 ab_dan_avt text,
#                 ab_com_com text,
#                 ab_visuel_com text,
#                 ab_codefiche text,
#                 ab_prive text,
#                 ab_surplomb text,
#                 ab_elagage text,
#                 ab_inv text,
#                 ab_hlibre text,
#                 ab_visuel text,
#                 ab_vertica text,
#                 ab_jaune text,
#                 ab_mobilis text,
#                 ab_gravur text,
#                 ab_ras_ft text,
#                 ab_orien text,
#                 ab_anc_bt text,
#                 ab_anc_ft text,
#                 ab_com_etl text,
#                 ab_nat_tvx text,
#                 ab_environ text,
#                 ab_val_moe text,
#                 ab_com_moe text,
#                 attachment text,
#                 geom geometry(Point,2154)
#             );
#             ---ALTER TABLE a_appuibt OWNER to postgres;
#             ALTER TABLE a_appuibt OWNER to adn_ing;
#             GRANT INSERT, SELECT ON TABLE a_appuibt TO adn_ing;
#             GRANT ALL ON TABLE a_appuibt TO postgres;
#             GRANT ALL ON TABLE a_appuibt TO adn_ing;
#             CREATE INDEX a_abt_gidx
#                 ON a_appuibt  USING btree (geom);"""
#         self.function_execute_requete(req, '')
#
#     # Function insertion dans table a_appuibt avec Fiches
#     def function_insert_a_appuibt(self, schema, text_inf_insert):
#         req = """INSERT INTO """ + schema + """.a_appuibt(
#                 ab_etiquet, ab_a_struc, ab_nature, ab_eta_mcd, ab_rac_mcd, ab_codeext, ab_etude, ab_struct,
#                 ab_type, ab_annee, ab_rac_bt, ab_rac_tel, ab_malt, ab_iacm, ab_ras_hta,
#                 ab_ras_bt, ab_ep, ab_cb_bt, ab_cb_cu, ab_cb_fo, ab_rac_reel, ab_eta_com, ab_dan_avt, ab_com_com, ab_visuel_com,
#                 ab_codefiche, ab_prive, ab_surplomb, ab_elagage, ab_inv, ab_hlibre,
#                 ab_visuel, ab_vertica, ab_jaune, ab_mobilis, ab_gravur, ab_ras_ft,
#                 ab_orien, ab_anc_bt, ab_anc_ft, ab_com_etl, ab_nat_tvx, ab_environ,
#                 ab_val_moe, ab_com_moe, geom)
#                     VALUES """ + text_inf_insert + """;"""  # , geom
#         self.function_execute_requete(req, '')
#
#     # Function pour la creation de la table a_appuift
#     def function_creatTable_a_appuift(self, schema):
#         req = """set search_path TO """ + schema + """, public;
#             DROP TABLE IF EXISTS a_appuift;
#             CREATE TABLE a_appuift
#             (
#                 af_etiquet text,
#                 af_r3_code text,
#                 af_gest text,
#                 af_nature text,
#                 af_a_struc text,
#                 ab_rac_mcd text,
#                 af_eta_mcd text,
#                 af_codeext text,
#                 af_etude text,
#                 af_struct text,
#                 af_inv text,
#                 af_visuel text,
#                 af_vertica text,
#                 af_flambe text,
#                 af_voisin text,
#                 af_pointe text,
#                 af_secouss text,
#                 af_percu text,
#                 af_jaune text,
#                 af_mobilis text,
#                 af_ebp text,
#                 af_ras text,
#                 af_cable text,
#                 af_eta_cap text,
#                 af_nat_tvx text,
#                 af_environ text,
#                 af_vois_el text,
#                 af_str_tvx text,
#                 af_dan_apr text,
#                 af_com_etl text,
#                 af_val_moe text,
#                 af_com_moe text,
#                 attachment text,
#                 geom geometry(Point,2154)
#             );
#             ---ALTER TABLE a_appuift OWNER to postgres;
#             ALTER TABLE a_appuift OWNER to adn_ing;
#             GRANT INSERT, SELECT ON TABLE a_appuift TO adn_ing;
#             GRANT ALL ON TABLE a_appuift TO postgres;
#             GRANT ALL ON TABLE a_appuift TO adn_ing;
#             CREATE INDEX a_aft_gidx
#                 ON a_appuift  USING btree (geom);"""
#         self.function_execute_requete(req, '')
#
#     # Function insertion dans table a_appuift avec Fiches
#     def function_insert_a_appuift(self, schema, text_inf_insert):
#         req = """INSERT INTO """ + schema + """.a_appuift(
#                 af_etiquet, af_r3_code, af_gest, af_nature, af_a_struc, ab_rac_mcd, af_eta_mcd, af_codeext,
#                 af_etude, af_struct, af_inv, af_visuel, af_vertica, af_flambe, af_voisin, af_pointe, af_secouss,
#                 af_percu, af_jaune, af_mobilis, af_ebp, af_ras, af_cable, af_eta_cap, af_nat_tvx, af_environ,
#                 af_vois_el, af_str_tvx, af_dan_apr, af_com_etl, af_val_moe, af_com_moe, attachment, geom)
#                     VALUES """ + text_inf_insert + """;"""  # , geom
#         self.function_execute_requete(req, '')
#
#     # Function get value pour les fiches comac
#     def function_getvalue(self, var_value, var_type_get):
#         return_var_value = '-1'
#         if var_type_get == '':
#             return_var_value = var_value
#         if var_type_get == 'NC':
#             if var_value == '':
#                 return_var_value = 'NC'
#             else:
#                 return_var_value = var_value
#         if var_type_get == 'SO':
#             if var_value == '':
#                 return_var_value = 'SO'
#             else:
#                 return_var_value = var_value
#         if var_type_get == 'ab_ras_bt':
#             if var_value == '0':
#                 return_var_value = 'NON'
#             elif var_value == '':
#                 return_var_value = 'SO'
#             else:
#                 return_var_value = 'OUI'
#         return return_var_value
#
#     # Function pour recuperer les pt du MCD
#     def function_get_ptech_mcd(self, schema):
#         # return list_attribut_all_fiches
#         req_pt = """SET search_path = """ + schema + """, public;
#             select distinct pt.pt_code, pt.pt_etiquet, pt.pt_nature, pt.pt_etat, pt.pt_a_struc,
#                 pt.pt_typelog,pt.pt_typephy,'ST_GeomFromText('||quote_literal(st_astext(nd.geom))||',2154)' as geom,
#                 pt_gest, cb.cb_r3_code
#             from t_ptech pt
#                 join t_noeud nd on nd.nd_code=pt.pt_nd_code
#                 join t_cableline cl on st_dwithin (nd.geom,cl.geom,0.1)
#                 join t_cable cb on cb.cb_code = cl.cl_cb_code
#             where cb.cb_typelog in('DI', 'TR', 'CO')"""
#         list_req_pt = self.function_execute_requete(req_pt, 'bab')
#         return list_req_pt
#
#     # Function pour exporter les donnees des appuis a_appuibt
#     def function_Export_appuis_hors_OK(self, schema, table_name, key, rename_table, path_folder):
#         connection = self.connection
#         # import qgis.core
#         # a_appuift_nok = """ drop table if exists """ + schema + """.a_appuift_export; select * into """ + schema + """.a_appuift_export from """ + schema + """.a_appuift where upper(af_eta_mcd) != 'OK'"""
#         a_appuibt_nok = """ drop table if exists """ + schema + """.a_appuibt_export; select * into """ + schema + """.a_appuibt_export from """ + schema + """.a_appuibt where upper(ab_eta_mcd) != 'OK'"""
#
#         # self.function_execute_requete(a_appuift_nok, '')
#         self.function_execute_requete(a_appuibt_nok, '')
#         connection.commit()
#
#         uri = QgsDataSourceUri()
#         uri.setConnection(host, port, DB, user, MP)
#         uri.setDataSource(schema, table_name, "geom", '', key)  # (schema, table_name, "geom")#Shape
#         layer = QgsVectorLayer(uri.uri(False), rename_table, "postgres")
#         if layer.isValid():
#             chem_rep_export = path_folder + '/' + layer.name() + ".shp"
#             QgsVectorFileWriter.writeAsVectorFormat(layer, chem_rep_export, "LATIN1", layer.crs(), 'ESRI Shapefile')
#
#     # Partie des fonctions pour les retours terrains
#     # Function pour la creation de la table a_appuift_vt
#     def function_creatTable_a_appuift_vt(self, schema):
#         req = """set search_path TO """ + schema + """, public;
#         DROP INDEX if exists a_aft_gidx_ft_vt;
#         DROP TABLE IF EXISTS a_appuift_vt;
#         CREATE TABLE a_appuift_vt
#         (
#             af_etiquet text,
#             af_r3_code text,
#             af_gest text,
#             af_nature text,
#             af_a_struc text,
#             ab_rac_mcd text,
#             af_eta_mcd text,
#             af_codeext text,
#             af_etude text,
#             af_struct text,
#             af_inv text,
#             af_visuel text,
#             af_vertica text,
#             af_flambe text,
#             af_voisin text,
#             af_pointe text,
#             af_secouss text,
#             af_percu text,
#             af_jaune text,
#             af_mobilis text,
#             af_ebp text,
#             af_ras text,
#             af_cable text,
#             af_eta_cap text,
#             af_nat_tvx text,
#             af_environ text,
#             af_vois_el text,
#             af_str_tvx text,
#             af_dan_apr text,
#             af_com_etl text,
#             af_val_moe text,
#             af_com_moe text,
#             attachment text,
#             geom geometry(Point,2154)
#         );
#         ALTER TABLE a_appuift_vt
#             OWNER to adn_ing;
#         GRANT INSERT, SELECT ON TABLE a_appuift_vt TO adn_ing;
#         GRANT ALL ON TABLE a_appuift_vt TO adn_ing;
#         CREATE INDEX a_aft_gidx_ft_vt
#             ON a_appuift_vt  USING btree (geom);"""
#         self.function_execute_requete(req, '')
#
#     # Function insertion dans table a_appuift_vt
#     def function_insert_a_appuift_vt(self, schema, text_inf_insert):
#         req = """INSERT INTO """ + schema + """.a_appuift_vt(
#             af_etiquet, af_r3_code, af_gest, af_nature, af_a_struc, ab_rac_mcd, af_eta_mcd, af_codeext,
#             af_etude, af_struct, af_inv, af_visuel, af_vertica, af_flambe, af_voisin, af_pointe, af_secouss,
#             af_percu, af_jaune, af_mobilis, af_ebp, af_ras, af_cable, af_eta_cap, af_nat_tvx, af_environ,
#             af_vois_el, af_str_tvx, af_dan_apr, af_com_etl, af_val_moe, af_com_moe, attachment, geom)
#                 VALUES """ + text_inf_insert + """;"""  # , geom
#         self.function_execute_requete(req, '')
#
#     # Function pour la creation de la table a_appuibt_vt
#     def function_creatTable_a_appuibt_vt(self, schema):
#         req = """set search_path TO """ + schema + """, public;
#         DROP TABLE IF EXISTS a_appuibt_vt;
#         CREATE TABLE a_appuibt_vt
#         (
#             ab_etiquet text,
#             ab_a_struc text,
#             ab_nature text,
#             ab_eta_mcd text,
#             ab_rac_mcd text,
#             ab_codeext text,
#             ab_etude text,
#             ab_struct text,
#             ab_type text,
#             ab_annee text,
#             ab_rac_bt text,
#             ab_rac_tel text,
#             ab_malt text,
#             ab_iacm text,
#             ab_ras_hta text,
#             ab_ras_bt text,
#             ab_ep text,
#             ab_cb_bt text,
#             ab_cb_cu text,
#             ab_cb_fo text,
#             ab_rac_reel text,
#             ab_eta_com text,
#             ab_dan_avt text,
#             ab_com_com text,
#             ab_visuel_com text,
#             ab_codefiche text,
#             ab_prive text,
#             ab_surplomb text,
#             ab_elagage text,
#             ab_inv text,
#             ab_hlibre text,
#             ab_visuel text,
#             ab_vertica text,
#             ab_jaune text,
#             ab_mobilis text,
#             ab_gravur text,
#             ab_ras_ft text,
#             ab_orien text,
#             ab_anc_bt text,
#             ab_anc_ft text,
#             ab_com_etl text,
#             ab_nat_tvx text,
#             ab_environ text,
#             ab_val_moe text,
#             ab_com_moe text,
#             attachment text,
#             geom geometry(Point,2154)
#         );
#         ALTER TABLE a_appuibt_vt
#             OWNER to adn_ing;
#         GRANT INSERT, SELECT ON TABLE a_appuibt_vt TO adn_ing;
#         GRANT ALL ON TABLE a_appuibt_vt TO adn_ing;
#         CREATE INDEX a_abt_vt_gidx
#             ON a_appuibt_vt  USING btree (geom);"""
#         self.function_execute_requete(req, '')
#
#     # Function insertion dans table a_appuibt_vt
#     def function_insert_a_appuibt_vt(self, schema, text_inf_insert):
#         req_truncate = """Truncate table """ + schema + """.a_appuibt_vt CASCADE;"""
#         req_insert = """INSERT INTO """ + schema + """.a_appuibt_vt(
#             ab_etiquet, ab_a_struc, ab_nature, ab_eta_mcd, ab_rac_mcd, ab_codeext,
#             ab_etude, ab_struct, ab_type, ab_annee, ab_rac_bt, ab_rac_tel,
#             ab_malt, ab_iacm, ab_ras_hta, ab_ras_bt, ab_ep, ab_cb_bt, ab_cb_cu,
#             ab_cb_fo, ab_rac_reel, ab_eta_com, ab_dan_avt, ab_com_com, ab_visuel_com,
#             ab_codefiche, ab_prive, ab_surplomb, ab_elagage, ab_inv, ab_hlibre,
#             ab_visuel, ab_vertica, ab_jaune, ab_mobilis, ab_gravur, ab_ras_ft,
#             ab_orien, ab_anc_bt, ab_anc_ft, ab_com_etl, ab_nat_tvx, ab_environ,
#             ab_val_moe, ab_com_moe, attachment, geom)
#                 VALUES """ + text_inf_insert + """;"""  # , geom
#         self.function_execute_requete(req_truncate, '')
#         self.function_execute_requete(req_insert, '')
#
#     # Update des attributs avec la valeuu NULL
#     def function_update_values_Null(self, schema_etude):
#         req_update = """select
#             'UPDATE '||t.table_schema||'.'||t.table_name||' set '||t.column_name||' = ''''  WHERE '||t.column_name||' =''NULL'';',t.column_name, t.table_name table_name,''
#         from information_schema.columns as t
#         WHERE t.table_schema = '""" + schema_etude + """' and t.table_name in ('a_appuibt_vt','a_appuift_vt') and t.column_name != 'geom'"""
#
#         list_filed_update_null = self.function_execute_requete(req_update, 'bab')
#         for index_update, update in enumerate(list_filed_update_null):
#             self.function_execute_requete(update[0], '')
#
#     # Function pour la creation de la table a_appuibt_delta
#     def function_creatTable_a_appuibt_delta(self, schema):
#         req = """set search_path TO """ + schema + """, public;
#         DROP TABLE IF EXISTS a_appuibt_delta;
#         CREATE TABLE a_appuibt_delta
#         (
#             ab_etiquet text,
#             ab_a_struc text,
#             ab_nature text,
#             ab_eta_mcd text,
#             ab_codeext text,
#             ab_struct text,
#             ab_type text,
#             ab_annee text,
#             ab_rac_bt text,
#             ab_rac_tel text,
#             ab_malt text,
#             ab_iacm text,
#             ab_ras_hta text,
#             ab_ras_bt text,
#             ab_ep text,
#             ab_cb_bt text,
#             ab_cb_cu text,
#             ab_cb_fo text,
#             ab_eta_com text,
#             ab_dan_avt text,
#             ab_codefiche text,
#             ab_prive text,
#             ab_surplomb text,
#             ab_elagage text,
#             ab_inv text,
#             ab_hlibre text,
#             ab_visuel text,
#             ab_vertica text,
#             ab_jaune text,
#             ab_mobilis text,
#             ab_gravur text,
#             ab_ras_ft text,
#             ab_orien text,
#             ab_anc_bt text,
#             ab_anc_ft text,
#             ab_com_etl text,
#             ab_nat_tvx text,
#             ab_environ text,
#             ab_val_moe text,
#             ab_com_moe text,
#             attachment text,
#             geom geometry(Point,2154)
#         );
#         ALTER TABLE a_appuibt_delta
#             OWNER to adn_ing;
#         GRANT INSERT, SELECT ON TABLE a_appuibt_delta TO adn_ing;
#         GRANT ALL ON TABLE a_appuibt_delta TO adn_ing;
#         CREATE INDEX a_a_appuibt_delta
#             ON a_appuibt_delta  USING btree (geom);"""
#         self.function_execute_requete(req, '')
#
#     # Function pour la creation de la table a_appuift_delta
#     def function_creatTable_a_appuift_delta(self, schema):
#         req = """set search_path TO """ + schema + """, public;
#         DROP TABLE IF EXISTS a_appuift_delta;
#         CREATE TABLE a_appuift_delta
#         (
#             af_etiquet text,
#             af_nature text,
#             af_a_struc text,
#             af_codeext text,
#             af_eta_mcd text,
#             af_struct text,
#             af_inv text,
#             af_visuel text,
#             af_vertica text,
#             af_flambe text,
#             af_voisin text,
#             af_pointe text,
#             af_secouss text,
#             af_percu text,
#             af_jaune text,
#             af_mobilis text,
#             af_ebp text,
#             af_ras text,
#             af_cable text,
#             af_eta_cap text,
#             af_nat_tvx text,
#             af_environ text,
#             af_vois_el text,
#             af_str_tvx text,
#             af_dan_apr text,
#             af_com_etl text,
#             af_val_moe text,
#             af_com_moe text,
#             attachment text,
#             geom geometry(Point,2154)
#         );
#         ALTER TABLE a_appuift_delta
#             OWNER to adn_ing;
#         GRANT INSERT, SELECT ON TABLE a_appuift_delta TO adn_ing;
#         GRANT ALL ON TABLE a_appuift_delta TO adn_ing;
#         CREATE INDEX a_a_appuift_delta
#             ON a_appuift_delta  USING btree (geom);"""
#         self.function_execute_requete(req, '')
#
#     # Function insertion dans table a_appuibt_delta
#     def function_insert_a_appuibt_delta(self, schema, text_inf_insert):
#         req_truncate = """Truncate table """ + schema + """.a_appuibt_delta CASCADE;"""
#         req_insert = """INSERT INTO """ + schema + """.a_appuibt_delta(
#             ab_etiquet, ab_a_struc, ab_nature, ab_eta_mcd, ab_codeext, ab_struct,
#             ab_type, ab_annee, ab_rac_bt, ab_rac_tel, ab_malt, ab_iacm, ab_ras_hta,
#             ab_ras_bt, ab_ep, ab_cb_bt, ab_cb_cu, ab_cb_fo, ab_eta_com, ab_dan_avt,
#             ab_codefiche, ab_prive, ab_surplomb, ab_elagage, ab_inv, ab_hlibre,
#             ab_visuel, ab_vertica, ab_jaune, ab_mobilis, ab_gravur, ab_ras_ft,
#             ab_orien, ab_anc_bt, ab_anc_ft, ab_com_etl, ab_nat_tvx, ab_environ,
#             ab_val_moe, ab_com_moe, attachment,geom)
#                 VALUES """ + text_inf_insert + """;"""  # , geom
#         # print (req_insert)
#         self.function_execute_requete(req_truncate, '')
#         self.function_execute_requete(req_insert, '')
#
#     # Function insertion dans table a_appuift_vt
#     def function_insert_a_appuift_delta(self, schema, text_inf_insert):
#         req = """INSERT INTO """ + schema + """.a_appuift_delta(
#             ab_etiquet, ab_a_struc, ab_nature, ab_eta_mcd, ab_rac_mcd, ab_codeext,
#             ab_etude, ab_struct, ab_type, ab_annee, ab_rac_bt, ab_rac_tel,
#             ab_malt, ab_iacm, ab_ras_hta, ab_ras_bt, ab_ep, ab_cb_bt, ab_cb_cu,
#             ab_cb_fo, ab_rac_reel, ab_eta_com, ab_dan_avt, ab_com_com, ab_visuel_com,
#             ab_codefiche, ab_prive, ab_surplomb, ab_elagage, ab_inv, ab_hlibre,
#             ab_visuel, ab_vertica, ab_jaune, ab_mobilis, ab_gravur, ab_ras_ft,
#             ab_orien, ab_anc_bt, ab_anc_ft, ab_com_etl, ab_nat_tvx, ab_environ,
#             ab_val_moe, ab_com_moe, attachment, geom)
#                 VALUES """ + text_inf_insert + """;"""  # , geom
#         self.function_execute_requete(req, '')
#
#     # Funciton de creations des noms des groups
#     def function_create_groupe_name(self, name_groupe):
#         root = QgsProject.instance().layerTreeRoot()
#         group = root.findGroup(name_groupe)
#         root.removeChildNode(group)
#         shapeGroup = root.addGroup(name_groupe)
#         return shapeGroup
#
#     # Function pour ajouter les tables dans leur groupe respectif
#     def function_add_layer_group(self, layer_to_add, groupe_name):
#         QgsProject.instance().addMapLayer(layer_to_add, False)
#         groupe_name.insertChildNode(0, QgsLayerTreeLayer(layer_to_add))
#
#     # Function Suppression du group ajoute dans QGis
#     def functiondelete_layer_qgis(self, name_groupe):
#         root = QgsProject.instance().layerTreeRoot()
#         group = root.findGroup(name_groupe)
#         if group is not None:
#             root.removeChildNode(group)
#
#     # Function recuperation des index columns editable
#     def function_get_index_by_value_edit(self, list_attribut_with_position, var_get_index, var_bt_base, var_bt_vt, type_return):
#         # return_value='NC_VT'
#         for index_pos, pos in enumerate(list_attribut_with_position):
#             if var_get_index == pos[0]:
#                 if type_return == 'edit':
#                     if var_bt_base[pos[2] - 1] != var_bt_vt[pos[2] - 1]:
#                         return 'NC_VT'
#                     elif var_bt_base[pos[2] - 1] == var_bt_vt[pos[2] - 1]:
#                         return var_bt_base[pos[2] - 1]
#                 elif type_return == 'not_edit':
#                     return var_bt_base[pos[2] - 1]
#                 elif type_return == 'vt_edit':
#                     return var_bt_vt[pos[2] - 1]
#                 else:
#                     return '-2'
#
#     # Function de recuperation des valeurs dans cellules des FT
#     def function_get_val_cell_ft(self, var_xl_sheet, var_col_entite1, var_row_entite, var_type_get):
#         list_fa_ft = range(0, var_xl_sheet.nrows)
#         var_cell_recup = '-1'
#         for index_row, row in enumerate(list_fa_ft):
#             for col in range(var_xl_sheet.ncols):
#                 data = str(var_xl_sheet.cell(row, col).value).replace('.0', '').upper().replace("'", '')
#                 if var_type_get == 'af_codeext_model':
#                     if col == var_col_entite1 and row == var_row_entite:  # af_codeext
#                         var_cell_recup = data
#                 if var_type_get == 'af_inv_model':
#                     if col == var_col_entite1 and row == var_row_entite:  # af_inv
#                         if data == 'oui'.upper():
#                             var_cell_recup = 'OUI'
#                         elif data == 'non'.upper():
#                             var_cell_recup = 'NON'
#                         else:
#                             var_cell_recup = 'NC'
#                 if var_type_get == 'af_vois_el_model':
#                     if col == var_col_entite1 and row == var_row_entite:  # af_vois_el
#                         if data:
#                             var_cell_recup = data
#                         else:
#                             var_cell_recup = 'SO'
#                 if var_type_get == 'af_nat_tvx_model':
#                     if col == var_col_entite1 and row == var_row_entite:  # af_nat_tvx
#                         if data == 'replacement'.upper():
#                             var_cell_recup = 'OUI'
#                         elif data == 'renforcement'.upper():
#                             var_cell_recup = data
#                         elif data == 'recalage'.upper():
#                             var_cell_recup = data
#                         else:
#                             var_cell_recup = 'NC'
#                 if var_type_get == 'af_environ_model':
#                     if col == var_col_entite1 and row == var_row_entite:  # af_environ
#                         if data in ('bmp'.upper(), 'ter'.upper()):
#                             var_cell_recup = data
#                         else:
#                             var_cell_recup = 'NC'
#                 if var_type_get == 'af_ebp':
#                     if col == var_col_entite1 and row == var_row_entite:  # af_vois_el
#                         if data in ('PB', 'PEO'):
#                             var_cell_recup = data
#                         else:
#                             var_cell_recup = 'SO'
#         return var_cell_recup
#
#     # Function pour exporter les tables deltas de BT et FT
#     def function_Export_appuis_delta(self, schema, table_name, key, rename_table, path_folder):
#         # import qgis.core
#         uri = QgsDataSourceUri()
#         uri.setConnection(host, port, DB, user, MP)
#         uri.setDataSource(schema, table_name, "geom", '', key)  # (schema, table_name, "geom")#Shape
#         layer = QgsVectorLayer(uri.uri(False), rename_table, "postgres")
#         if layer.isValid():
#             chem_rep_export = path_folder + '/' + layer.name() + ".shp"
#             QgsVectorFileWriter.writeAsVectorFormat(layer, chem_rep_export, "LATIN1", layer.crs(), 'ESRI Shapefile')


# [
#             ['FT0606', 'Chemin de la Ronde.xlsx', 'POT MIN', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON', 'A-N8227A-24F-70 vers FT0367/Liaison vers FT0367', 'OK', '', 'NC', 'SO',
#              'Non', 'OK', ''],
#             ['FT0367', 'Chemin de la Ronde.xlsx', 'BS7', 'NC', 'OUI', 'NON', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'NON', 'NC', 'Non', 'NON',
#              'A-N8227A-24F-70 vers FT0606/A-N8227A-24F-70 vers FT0029/Liaison vers FT0606/Liaison vers FT0029', '',
#              'BS7', 'NC', 'MI7 ', 'Non', '', 'DEL : Délité'],
#             ['FT0029', 'Chemin de la Ronde.xlsx', 'POT MIN', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON', 'A-N8227A-24F-70 vers FT0367/Liaison vers FT0367', '', '', 'NC', 'SO',
#              'Non', '', ''],
#             ['021790', 'CHEMIN DE VALPEYROUSE.xlsx', 'BC7 ', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON', 'P-TF303G-144F-80 vers BT0524/98-112-6     vers BT0524', 'OKINSUFFISANT',
#              'BC7 ', 'NC', 'BC7 ANC', 'Non', 'OKOK', ''],
#             ['288989', 'D868_3.xlsx', 'BS8', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NC',
#              'Non', 'NON', 'P-TF303G- 96F-80 vers 288983/98-8-6 vers 288983', 'OKINSUFFISANT', '', 'NC', 'SO', '',
#              'OK', ''],
#             ['288983', 'D868_3.xlsx', 'BC8 ', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NC',
#              'Non', 'NC',
#              'P-TF303G- 96F-80 vers 288989/P-TF303G- 96F-80 vers 288984/P-TF303G-288F-80 vers 289001/98-8-6 vers 288989/Liaison vers 289001/98-8-6 vers 288984/98-8-6 vers 288984/98-14-6 vers 288984',
#              'OK', '', 'NC', 'SO', 'PB', '', ''],
#             ['288984', 'D868_3.xlsx', 'BS7', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NC',
#              'Non', 'NON',
#              'P-TF303G- 96F-80 vers 288983/P-TF303G- 96F-80 vers 288985/98-8-6 vers 288983/98-8-6 vers 288983/98-14-6 vers 288983/98-8-6 vers 288985/98-8-6 vers 288985/98-14-6 vers 288985',
#              'INSUFFISANT', 'BS7', 'NC', 'FR7', 'Non', 'OK', ''],
#             ['288985', 'D868_3.xlsx', 'BH7 S30', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'NC', 'Non', 'NON',
#              'P-TF303G- 96F-80 vers 288984/P-TF303G- 96F-80 vers 288986/98-8-6     vers 288984/98-8-6     vers 288984/98-14-6     vers 288984/98-8-6     vers 288986/98-8-6 vers 288986/98-14-6 vers 288986',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['288986', 'D868_3.xlsx', 'MC7 MIN', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'NC', 'Non', 'NC',
#              'A-N9923A-12F-70 vers 288987/P-TF303G- 96F-80 vers 288985/98-8-6     vers 288985/98-8-6     vers 288987/98-14-6     vers 288985/Liaison vers 288987',
#              'INSUFFISANT', 'MC7 MIN', 'NC', 'FR7', 'PB', 'OK', ''],
#             ['288987', 'D868_3.xlsx', 'BM7', 'OUI', 'NON', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NON', 'NC',
#              'Non', 'NON',
#              'A-N9923A-12F-70 vers 288986/A-N9923A-12F-70 vers 288988/Liaison vers 288986/Liaison vers 288988',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['288988', 'D868_3.xlsx', 'BM8', 'OUI', 'NON', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NON', 'NC',
#              'Non', 'NON', 'A-N9923A-12F-70 vers 288987/Liaison vers 288987', 'OK', '', 'NC', 'SO', 'PB', '', ''],
#             ['289001', 'D868_3.xlsx', 'BC7', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NC',
#              'Non', 'NC', 'P-TF303G-288F-80 vers 288983/Liaison vers 288983', 'OK', '', 'NC', 'SO', '', '', ''],
#             ['273264', 'D86_1.xlsx', 'BS6', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NC',
#              'Non', 'NC', 'P-TF303G- 72F-80 vers 273263/98-8-6     vers 273263/98-8-6     vers 273263',
#              'OKINSUFFISANT', 'BS6', 'NC', 'FR7', 'PB', 'OKOK', ''],
#             ['273263', 'D86_1.xlsx', '198.0', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NC',
#              'Non', 'NON',
#              'P-TF303G- 72F-80 vers 273264/P-TF303G- 72F-80 vers 273262/98-8-6 vers 273264/98-8-6 vers 273264/98-8-6 vers 273262/98-8-6 vers 273262',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['273262', 'D86_1.xlsx', '198.0', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NC',
#              'Non', 'NON',
#              'P-TF303G- 72F-80 vers 273263/P-TF303G- 72F-80 vers 273261/98-8-6 vers 273263/98-8-6 vers 273263/98-8-6 vers 273261/98-8-6 vers 273261',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['273261', 'D86_1.xlsx', 'BS7', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NC',
#              'Non', 'NON',
#              'P-TF303G- 72F-80 vers 273262/P-TF303G- 72F-80 vers 273260/98-8-6 vers 273262/98-8-6 vers 273262/98-8-6 vers 273260/98-8-6 vers 273260',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['273260', 'D86_1.xlsx', 'BM7', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NC',
#              'Non', 'NON',
#              'P-TF303G- 72F-80 vers 273261/P-TF303G- 72F-80 vers 273259/98-8-6 vers 273261/98-8-6 vers 273261/98-8-6 vers 273259/98-8-6 vers 273259',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['273259', 'D86_1.xlsx', 'BC8 ', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NC',
#              'Non', 'NC',
#              'P-TF303G- 72F-80 vers 273260/P-TF303G- 72F-80 vers BT0488/98-8-6 vers 273260/98-8-6 vers 273260/98-8-6 vers BT0488',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['BT0488', 'D86_1.xlsx', 'EDF', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NC',
#              'Non', 'NON', 'P-TF303G- 72F-80 vers 273259/98-8-6 vers 273259', '', '', 'NC', 'SO', '', '', ''],
#             ['288975', 'D86_2 2.xlsx', 'BM7 ', 'OUI', 'NON', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NON', 'NON', 'NC',
#              'Non', 'NON', 'A-N8228A-36F-70 vers 288976/Liaison vers 288976', 'OKOK', 'BM7 ', 'NC', 'BS7', 'PB',
#              'OKOK', ''],
#             ['288976', 'D86_2 2.xlsx', 'BM7', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NC',
#              'Non', 'NON',
#              'A-N8228A-36F-70 vers 288975/A-N8228A-36F-70 vers 288978/A-N9923A-12F-70 vers 288977/Liaison vers 288975/Liaison vers 288977/98-8-6 vers 288978/98-8-6 vers 288978',
#              'OK', '', 'NC', 'SO', 'PB', '', ''],
#             ['288978', 'D86_2 2.xlsx', 'BS7', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NC',
#              'Non', 'NC',
#              'A-N8228A-36F-70 vers 288976/A-N8228A-36F-70 vers 195599/98-8-6 vers 288976/98-8-6 vers 288976/98-8-6 vers 195599/98-8-6 vers 195599',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['195599', 'D86_2 2.xlsx', 'BS8', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NC',
#              'Non', 'NON',
#              'A-N8228A-36F-70 vers 288978/A-N8228A-36F-70 vers 288979/98-8-6 vers 288978/98-8-6 vers 288978/98-8-6 vers 288979/98-8-6 vers 288979',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['288979', 'D86_2 2.xlsx', 'MI7 ', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NC',
#              'Non', 'NON',
#              'A-N8228A-36F-70 vers 195599/A-N8228A-36F-70 vers 288980/98-8-6 vers 195599/98-8-6 vers 195599/98-14-6 vers 288980',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['288980', 'D86_2 2.xlsx', 'BS6', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NC',
#              'Non', 'NON',
#              'A-N8228A-36F-70 vers 288979/A-N8228A-36F-70 vers 288981/98-14-6 vers 288979/98-14-6 vers 288981',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['288981', 'D86_2 2.xlsx', '197.0', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NC',
#              'Non', 'NON',
#              'A-N8228A-36F-70 vers 288980/A-N8228A-36F-70 vers 288982/98-14-6 vers 288980/98-14-6 vers 288982',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['288982', 'D86_2 2.xlsx', 'MI7 ', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NC',
#              'Non', 'NON',
#              'A-N8228A-36F-70 vers 288981/A-N8228A-36F-70 vers BT0147/98-14-6 vers 288981/98-14-6 vers BT0147',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['BT0147', 'D86_2 2.xlsx', 'EDF', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NC',
#              'Non', 'NON', 'A-N8228A-36F-70 vers 288982/98-14-6 vers 288982', '', '', 'NC', 'SO', '', '', ''],
#             ['288977', 'D86_2 2.xlsx', 'BS6', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NC',
#              'Non', 'NON',
#              'A-N9923A-12F-70 vers 288976/A-N9923A-12F-70 vers BT0275/Liaison vers 288976/Liaison vers BT0275',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['BT0275', 'D86_2 2.xlsx', 'EDF', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NC',
#              'Non', 'NON', 'A-N9923A-12F-70 vers 288977/Liaison vers 288977', '', '', 'NC', 'SO', '', '', ''],
#             ['287362', 'D86_2.xlsx', 'BC6', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NC',
#              'Non', 'NON', 'A-N9923A-12F-70 vers 287363/98-14-4 vers 287363/98-28-4 vers 287363', 'OKOK', '', 'NC',
#              'SO', '', 'OK', ''],
#             ['287363', 'D86_2.xlsx', 'BS6', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NC',
#              'Non', 'NON',
#              'A-N9923A-12F-70 vers 287362/A-N9923A-12F-70 vers 287364/98-14-4 vers 287362/98-28-4 vers 287362/98-14-4 vers 287364/98-28-4 vers 287364',
#              'OK', '', 'NC', 'SO', '', '', ''],
#             ['287364', 'D86_2.xlsx', 'MS7', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NC',
#              'Non', 'NON',
#              'A-N9923A-12F-70 vers 287363/A-N9923A-12F-70 vers 287365/98-14-4 vers 287363/98-28-4 vers 287363/98-14-4 vers 287365/98-28-4 vers 287365',
#              'OK', '', 'NC', 'SO', '', '', ''],
#             ['287365', 'D86_2.xlsx', 'MS7', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NC',
#              'Non', 'NON',
#              'A-N9923A-12F-70 vers 287364/A-N9923A-12F-70 vers FT0534/98-14-4 vers 287364/98-28-4 vers 287364/98-14-4 vers FT0534/98-28-4 vers FT0534',
#              'OK', '', 'NC', 'SO', '', '', ''],
#             ['FT0534', 'D86_2.xlsx', 'BS8', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NC',
#              'Non', 'NON',
#              'A-N9923A-12F-70 vers 287365/A-N9923A-12F-70 vers FT0618/98-14-4 vers 287365/98-28-4 vers 287365/98-14-4 vers FT0618/98-28-4 vers FT0618',
#              'OK', '', 'NC', 'SO', '', '', ''],
#             ['FT0618', 'D86_2.xlsx', 'BS6', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NC',
#              'Non', 'NON',
#              'A-N9923A-12F-70 vers FT0534/A-N9923A-12F-70 vers 287368/98-14-4 vers FT0534/98-28-4 vers FT0534/98-14-4 vers 287368/98-28-4 vers 287368',
#              'OK', '', 'NC', 'SO', '', '', ''],
#             ['287368', 'D86_2.xlsx', 'BS6', 'OUI', 'NON', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NON', 'NON', 'NC',
#              'Non', 'NON',
#              'A-N9923A-12F-70 vers FT0618/A-N9923A-12F-70 vers 284369/98-14-4 vers FT0618/98-28-4 vers FT0618/98-14-4 vers 284369/98-28-4 vers 284369',
#              'OK', 'BS6', 'NC', 'MI7 ', 'Non', 'OK', ''],
#             ['284369', 'D86_2.xlsx', 'BS6', 'OUI', 'NON', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NON', 'NON', 'NC',
#              'Non', 'NON',
#              'A-N9923A-12F-70 vers 287368/A-N9923A-12F-70 vers FT-ETA-001/98-14-4 vers 287368/98-28-4 vers 287368/98-56-4 vers FT-ETA-001',
#              'OK', 'BS6', 'NC', 'MI7 ', 'Non', 'OK', ''],
#             ['FT-ETA-001', 'D86_2.xlsx', 'MS6', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NC',
#              'Non', 'NON',
#              'A-N9923A-12F-70 vers 284369/A-N9923A-12F-70 vers 287371/98-56-4 vers 284369/98-56-4 vers 287371',
#              'OK', '', 'NC', 'SO', '', '', ''],
#             ['287371', 'D86_2.xlsx', 'BC6', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NC',
#              'Non', 'NON',
#              'A-N9923A-12F-70 vers FT-ETA-001/98-56-4 vers FT-ETA-001/98-28-4 vers FT0452/98-56-4 vers FT0452',
#              'INSUFFISANT', '', 'NC', 'SO', 'PB', '', 'Aucune solution proposée par CAP FT.'],
#             ['288983', 'D86_4.xlsx', 'BC8 ', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NC',
#              'Non', 'NC', 'P-TF303G- 96F-80 vers 288989/98-8-6 vers 288989', 'OKOK', '', 'NC', 'SO', 'PB', 'OK',
#              ''],
#             ['288989', 'D86_4.xlsx', 'BS8', 'OUI', 'NON', 'OUI', 'OUI', 'OUI', 'NON', 'OUI', 'NON', 'NON', 'NC',
#              'Non', 'NON',
#              'P-TF303G- 96F-80 vers 288983/P-TF303G- 96F-80 vers 288990/98-8-6 vers 288983/98-8-6 vers 288990',
#              'OK', 'BS8', 'NC', 'MI8 ', 'Non', 'OK', ''],
#             ['288990', 'D86_4.xlsx', 'BS6', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NC',
#              'Non', 'NON',
#              'P-TF303G- 96F-80 vers 288989/P-TF303G- 96F-80 vers 288991/98-8-6     vers 288989/98-8-6     vers 288991',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['288991', 'D86_4.xlsx', '198.0', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NC',
#              'Non', 'NON',
#              'P-TF303G- 96F-80 vers 288990/P-TF303G- 96F-80 vers 288992/98-8-6 vers 288990/98-8-6 vers 288992',
#              'OK', '', 'NC', 'SO', 'PB', '', ''],
#             ['288992', 'D86_4.xlsx', 'BS6', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NC',
#              'Non', 'NON',
#              'P-TF303G- 96F-80 vers 288991/P-TF303G- 96F-80 vers 288993/98-8-6 vers 288991/98-8-6 vers 288993',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['288993', 'D86_4.xlsx', 'BS7', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NC',
#              'Non', 'NON',
#              'P-TF303G- 96F-80 vers 288992/P-TF303G- 96F-80 vers 288995/98-8-6 vers 288992/98-8-6 vers 288995',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['288995', 'D86_4.xlsx', 'BS6', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NC',
#              'Non', 'NON',
#              'P-TF303G- 96F-80 vers 288993/P-TF303G- 96F-80 vers 288996/98-8-6 vers 288993/98-8-6 vers 288996',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['288996', 'D86_4.xlsx', 'MT7 ', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NC',
#              'Non', 'NON',
#              'P-TF303G- 96F-80 vers 288995/P-TF303G- 96F-80 vers 288997/98-8-6 vers 288995/98-8-6 vers 288997',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['288997', 'D86_4.xlsx', 'BS7', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NC',
#              'Non', 'NON',
#              'P-TF303G- 96F-80 vers 288996/P-TF303G- 96F-80 vers BT0489/98-8-6     vers 288996/98-8-6 vers BT0489',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['BT0489', 'D86_4.xlsx', 'EDF', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NC',
#              'Non', 'NON',
#              'P-TF303G- 96F-80 vers 288997/P-TF303G- 96F-80 vers 288998/98-8-6 vers 288997/98-8-6 vers 288998', '',
#              '', 'NC', 'SO', 'PB', '', ''],
#             ['288998', 'D86_4.xlsx', 'BS6', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NC',
#              'Non', 'NON',
#              'P-TF303G- 96F-80 vers BT0489/P-TF303G- 96F-80 vers 288999/98-8-6 vers BT0489/98-8-6 vers 288999',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['288999', 'D86_4.xlsx', 'BS7', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NC',
#              'Non', 'NON',
#              'P-TF303G- 96F-80 vers 288998/P-TF303G- 96F-80 vers 289000/98-8-6 vers 288998/98-8-6 vers 289000',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['289000', 'D86_4.xlsx', 'BS6', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NC',
#              'Non', 'NON',
#              'P-TF303G- 96F-80 vers 288999/P-TF303G- 96F-80 vers AX0010/98-8-6 vers 288999/Liaison vers AX0010',
#              'INSUFFISANT', 'BS6', 'NC', 'FR7', 'Non', 'OK', ''],
#             ['AX0010', 'D86_4.xlsx', 'BS8', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NC',
#              'Non', 'NON',
#              'P-TF303G- 96F-80 vers 289000/P-TF303G- 96F-80 vers 421193/Liaison vers 289000/Liaison vers 421193',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['421193', 'D86_4.xlsx', 'BS6', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NC',
#              'Non', 'NON',
#              'P-TF303G- 96F-80 vers AX0010/P-TF303G- 96F-80 vers 273266/Liaison vers AX0010/Liaison vers 273266',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['273266', 'D86_4.xlsx', 'MI8 ', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NC',
#              'Non', 'NON',
#              'P-TF303G- 96F-80 vers 421193/P-TF303G- 96F-80 vers 273267/Liaison vers 421193/Liaison vers 273267',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['273267', 'D86_4.xlsx', 'BS7', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NC',
#              'Non', 'NON',
#              'P-TF303G- 96F-80 vers 273266/P-TF303G- 96F-80 vers 273268/A-N9923A-12F-70 vers FT0167/Liaison vers 273266/Liaison vers FT0167/Liaison vers 273268',
#              'OK', '', 'NC', 'SO', 'PB', '', ''],
#             ['273268', 'D86_4.xlsx', 'BS7', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NC',
#              'Non', 'NON',
#              'P-TF303G- 96F-80 vers 273267/P-TF303G- 96F-80 vers 273269/Liaison vers 273267/Liaison vers 273269',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['273269', 'D86_4.xlsx', 'BS8', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NC',
#              'Non', 'NON', 'P-TF303G- 96F-80 vers 273268/Liaison vers 273268', 'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['FT0167', 'D86_4.xlsx', 'POT MIN', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NC',
#              'Non', 'NON', 'A-N9923A-12F-70 vers 273267/Liaison vers 273267', '', '', 'NC', 'SO', 'PB', '', ''],
#             ['FT0520', 'D86_5.xlsx', 'POT MIN', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NC',
#              'Non', 'NON', 'A-N8227A-24F-70 vers 421202/Liaison vers 421202', 'OK', '', 'NC', 'SO', '', 'OK', ''],
#             ['421202', 'D86_5.xlsx', 'MH8 S45', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NC',
#              'Non', 'NC',
#              'A-N9923A-12F-70 vers 421203/A-N8227A-24F-70 vers FT0520/Liaison vers FT0520/Liaison vers 421203',
#              'OK', '', 'NC', 'SO', 'PB', '', ''],
#             ['421203', 'D86_5.xlsx', 'BS6', 'OUI', 'OUI', 'NON', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NON', 'NC',
#              'Non', 'NON',
#              'A-N9923A-12F-70 vers 421202/A-N9923A-12F-70 vers FA001/Liaison vers 421202/Liaison vers FA001', 'OK',
#              'BS6', 'NC', 'MI7 ', 'PB', 'OK', ''],
#             ['FA001', 'D86_5.xlsx', 'POT MIN', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NC',
#              'Non', 'NON', 'A-N9923A-12F-70 vers 421203/Liaison vers 421203', '', '', 'NC', 'SO', '', '', ''],
#             ['BT0484', 'D93_1.xlsx', 'EDF', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NC',
#              'Non', 'NON', 'P-TF303G- 72F-80 vers 273258/Liaison vers 273258', 'OK', '', 'NC', 'SO', '', 'OK', ''],
#             ['273258', 'D93_1.xlsx', 'BS8', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NC',
#              'Non', 'NC',
#              'P-TF303G- 72F-80 vers BT0484/P-TF303G- 72F-80 vers 273257/Liaison vers BT0484/98-8-6 vers 273257',
#              'INSUFFISANT', 'BS8', 'NC', 'FR8', 'Non', 'OK', ''],
#             ['273257', 'D93_1.xlsx', 'BS7', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NC',
#              'Non', 'NON',
#              'P-TF303G- 72F-80 vers 273258/P-TF303G- 72F-80 vers 273256/98-8-6 vers 273258/98-8-6 vers 273256',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['273256', 'D93_1.xlsx', 'BS8', 'NC', 'NON', 'NON', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NON', 'NC',
#              'Non', 'NON',
#              'P-TF303G- 72F-80 vers 273257/P-TF303G- 72F-80 vers 273255/98-8-6 vers 273257/98-8-6 vers 273255',
#              'INSUFFISANT', 'BS8', 'NC', 'MI8 ', 'Non', 'OK', 'AUT : Autre'],
#             ['273255', 'D93_1.xlsx', 'BS7', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NC',
#              'Non', 'NON',
#              'P-TF303G- 72F-80 vers 273256/P-TF303G- 72F-80 vers 273254/98-8-6 vers 273256/98-8-6 vers 273254',
#              'INSUFFISANT', 'BS7', 'NC', 'MI7 ', 'Non', 'OK', ''],
#             ['273254', 'D93_1.xlsx', 'MI7 ', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NC',
#              'Non', 'NON',
#              'P-TF303G- 72F-80 vers 273255/P-TF303G- 72F-80 vers 273253/98-8-6 vers 273255/98-8-6 vers 273253',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['273253', 'D93_1.xlsx', 'MI7 ', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NC',
#              'Non', 'NON',
#              'P-TF303G- 72F-80 vers 273254/P-TF303G- 72F-80 vers 273252/98-8-6 vers 273254/98-8-6 vers 273252',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['273252', 'D93_1.xlsx', 'MI7 ', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NC',
#              'Non', 'NON',
#              'P-TF303G- 72F-80 vers 273253/P-TF303G- 72F-80 vers 184309/98-8-6 vers 273253/98-8-6 vers 184309',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['184309', 'D93_1.xlsx', 'BS7', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NC',
#              'Non', 'NON',
#              'P-TF303G- 72F-80 vers 273252/P-TF303G- 72F-80 vers 273251/98-8-6 vers 273252/98-8-6 vers 273251',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['273251', 'D93_1.xlsx', 'MS7 ', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NC',
#              'Non', 'NON',
#              'P-TF303G- 72F-80 vers 184309/P-TF303G- 72F-80 vers 273250/98-8-6 vers 184309/98-8-6 vers 273250',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['273250', 'D93_1.xlsx', 'MI7 ', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NC',
#              'Non', 'NON',
#              'P-TF303G- 72F-80 vers 273251/P-TF303G- 72F-80 vers 273249/98-8-6 vers 273251/98-8-6 vers 273249',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['273249', 'D93_1.xlsx', 'MI7 ', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NC',
#              'Non', 'NON',
#              'P-TF303G- 72F-80 vers 273250/P-TF303G- 72F-80 vers 273248/98-8-6 vers 273250/98-8-6 vers 273248',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['273248', 'D93_1.xlsx', 'MS7 ', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NC',
#              'Non', 'NON',
#              'P-TF303G- 72F-80 vers 273249/P-TF303G- 72F-80 vers 273247/98-8-6 vers 273249/98-8-6 vers 273247',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['273247', 'D93_1.xlsx', 'MS7 ', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NC',
#              'Non', 'NON',
#              'P-TF303G- 72F-80 vers 273248/P-TF303G- 72F-80 vers 273246/98-8-6 vers 273248/98-8-6 vers 273246',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['273246', 'D93_1.xlsx', 'MS8 ', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NC',
#              'Non', 'NON',
#              'P-TF303G- 72F-80 vers 273247/P-TF303G- 72F-80 vers 273245/98-8-6 vers 273247/98-8-6 vers 273245',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['273245', 'D93_1.xlsx', 'MS8 ', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NC',
#              'Non', 'NON',
#              'P-TF303G- 72F-80 vers 273246/P-TF303G- 72F-80 vers 273244/98-8-6 vers 273246/98-8-6 vers 273244',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['273244', 'D93_1.xlsx', 'MS7 ', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NC',
#              'Non', 'NON',
#              'P-TF303G- 72F-80 vers 273245/P-TF303G- 72F-80 vers 273243/98-8-6 vers 273245/98-8-6 vers 273243',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['273243', 'D93_1.xlsx', 'MS7 ', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NC',
#              'Non', 'NON',
#              'P-TF303G- 72F-80 vers 273244/P-TF303G- 72F-80 vers 273242/98-8-6 vers 273244/98-8-6 vers 273242',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['273242', 'D93_1.xlsx', 'MS7 ', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NC',
#              'Non', 'NON',
#              'P-TF303G- 72F-80 vers 273243/P-TF303G- 72F-80 vers 273241/98-8-6 vers 273243/98-8-6 vers 273241',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['273241', 'D93_1.xlsx', 'MS7 ', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NC',
#              'Non', 'NON',
#              'P-TF303G- 72F-80 vers 273242/P-TF303G- 72F-80 vers 273240/98-8-6 vers 273242/98-8-6 vers 273240',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['273240', 'D93_1.xlsx', 'MS7 ', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NC',
#              'Non', 'NON',
#              'P-TF303G- 72F-80 vers 273241/P-TF303G- 72F-80 vers 195494/98-8-6 vers 273241/98-8-6 vers 195494',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['195494', 'D93_1.xlsx', 'BH8 S45', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NC',
#              'Non', 'NC',
#              'P-TF303G- 72F-80 vers 273240/A-N8228A-36F-70 vers 195493/A-N9923A-12F-70 vers 273236/98-8-6 vers 273240/98-8-6 vers 273236/98-8-6 vers 195493',
#              'OK', '', 'NC', 'SO', 'PB', '', ''],
#             ['195493', 'D93_1.xlsx', 'BH8 S30', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NC',
#              'Non', 'NON', 'A-N9923A-12F-70 vers 195494/98-8-6 vers 195494', 'OK', '', 'NC', 'SO', '', '', ''],
#             ['273236', 'D93_1.xlsx', 'MS7', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NC',
#              'Non', 'NON', 'A-N9923A-12F-70 vers 195494/98-8-6 vers 195494', 'INSUFFISANT', '', 'NC', 'SO', '', '',
#              ''],
#             ['195494', 'D93_2.xlsx', 'BH8 S30', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NC',
#              'Non', 'NC', 'A-N8228A-36F-70 vers 195493/98-8-6 vers 195493', 'OKOK', '', 'NC', 'SO', 'PB', 'OK', ''],
#             ['195493', 'D93_2.xlsx', 'BH8 S45', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NC',
#              'Non', 'NON',
#              'A-N8228A-36F-70 vers 195494/A-N8228A-36F-70 vers 273235/98-8-6     vers 195494/98-8-6     vers 273235',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['273235', 'D93_2.xlsx', 'MH6 S30', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NC',
#              'Non', 'NON',
#              'A-N8228A-36F-70 vers 195493/A-N8228A-36F-70 vers 273234/98-8-6     vers 195493/98-8-6     vers 273234',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['273234', 'D93_2.xlsx', 'MH8 S45', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NC',
#              'Non', 'NON',
#              'A-N8228A-36F-70 vers 273235/A-N8228A-36F-70 vers 273233/98-8-6 vers 273235/98-8-6 vers 273233', 'OK',
#              '', 'NC', 'SO', 'Non', '', ''],
#             ['273233', 'D93_2.xlsx', 'BH7 S30', 'NC', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NON', 'NC',
#              'Non', 'NON',
#              'A-N8228A-36F-70 vers 273234/A-N8228A-36F-70 vers 273232/98-8-6 vers 273234/98-8-6 vers 273232', 'OK',
#              'BH7 S30', 'NC', 'MI7', 'Non', 'OK', 'Haubanné Cassé\r\nCAS : Cassé\r\nDEL : Délité'],
#             ['273232', 'D93_2.xlsx', 'BS7', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NC',
#              'Non', 'NON',
#              'A-N8228A-36F-70 vers 273233/A-N8228A-36F-70 vers 273231/98-8-6     vers 273233/98-8-6 vers 273231',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['273231', 'D93_2.xlsx', 'BC7 ', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NC',
#              'Non', 'NC',
#              'A-N8228A-36F-70 vers 273232/A-N9923A-12F-70 vers FA0001/98-8-6     vers 273232/Liaison vers FA0001',
#              'OK', '', 'NC', 'SO', 'PB', '', ''],
#             ['FA0001', 'D93_2.xlsx', 'POT MIN', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NC',
#              'Non', 'NON', 'A-N9923A-12F-70 vers 273231/Liaison vers 273231', '', '', 'NC', 'SO', '', '', ''],
#             ['195494', 'D93_3.xlsx', 'BH8 S30', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NC',
#              'Non', 'NC', 'A-N9923A-12F-70 vers 273236/98-8-6 vers 273236', 'OKINSUFFISANT', '', 'NC', 'SO', 'PB',
#              'OK', ''],
#             ['273236', 'D93_3.xlsx', 'MS7 ', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NC',
#              'Non', 'NON',
#              'A-N9923A-12F-70 vers 195494/A-N9923A-12F-70 vers 273237/98-8-6 vers 195494/98-8-6 vers 273237', 'OK',
#              '', 'NC', 'SO', 'Non', '', ''],
#             ['273237', 'D93_3.xlsx', 'MS7 ', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NC',
#              'Non', 'NON',
#              'A-N9923A-12F-70 vers 273236/A-N9923A-12F-70 vers 273238/98-8-6 vers 273236/98-8-6 vers 273238', 'OK',
#              '', 'NC', 'SO', 'Non', '', ''],
#             ['273238', 'D93_3.xlsx', 'MS7 ', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NC',
#              'Non', 'NON',
#              'A-N9923A-12F-70 vers 273237/A-N9923A-12F-70 vers 273239/98-8-6     vers 273237/98-8-6 vers 273239',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['273239', 'D93_3.xlsx', 'MC7 MIN', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NC',
#              'Non', 'NON',
#              'A-N9923A-12F-70 vers 273238/A-N9923A-12F-70 vers BT0399/98-8-6     vers 273238/98-8-6 vers BT0399',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['BT0399', 'D93_3.xlsx', 'EDF', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NC',
#              'Non', 'NON',
#              'A-N9923A-12F-70 vers 273239/A-N9923A-12F-70 vers BT0210/98-8-6 vers 273239/98-8-6 vers BT0210', '',
#              '', 'NC', 'SO', 'PB', '', ''],
#             ['BT0210', 'D93_3.xlsx', 'EDF', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NC',
#              'Non', 'NON',
#              'A-N9923A-12F-70 vers BT0399/A-N9923A-12F-70 vers 185326/98-8-6 vers BT0399/98-8-6 vers 185326', '',
#              '', 'NC', 'SO', '', '', ''],
#             ['185326', 'D93_3.xlsx', 'BS6', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NC',
#              'Non', 'NON',
#              'A-N9923A-12F-70 vers BT0210/A-N9923A-12F-70 vers 185325/98-8-6     vers BT0210/98-8-6 vers 185325',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['185325', 'D93_3.xlsx', 'BS7', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NC',
#              'Non', 'NON',
#              'A-N9923A-12F-70 vers 185326/A-N9923A-12F-70 vers 185324/98-8-6     vers 185326/98-8-6 vers 185324',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['185324', 'D93_3.xlsx', 'MS8 ', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NC',
#              'Non', 'NON',
#              'A-N9923A-12F-70 vers 185325/A-N9923A-12F-70 vers 185323/98-8-6     vers 185325/98-8-6 vers 185323',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['185323', 'D93_3.xlsx', 'BS6', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NC',
#              'Non', 'NON', 'A-N9923A-12F-70 vers 185324/98-8-6     vers 185324/98-8-6 vers 185322', 'OK', '', 'NC',
#              'SO', 'PB', '', ''],
#             ['BT0177', 'IMPASSE GEORGES BRASSENS.xlsx', 'EDF', 'NON', 'NON', 'NON', 'NON', 'OUI', 'NON', 'OUI',
#              'NON', 'NON', 'NC', 'Non', 'NON',
#              'P-TF303G- 48F-80 vers 000279/98-14-4 vers 000279/98-14-4 vers 000279/98-28-6 vers 000279/98-4-8 vers BT0374/98-112-6 vers BT0525/98-56-4 vers 021797/98-14-4 vers 021797',
#              'OK', '', 'NC', 'SO', '', 'OK', ''],
#             ['000279', 'IMPASSE GEORGES BRASSENS.xlsx', '197.0', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G- 48F-80 vers BT0177/P-TF303G- 48F-80 vers BT0051/98-14-4 vers BT0177/98-14-4 vers BT0177/98-28-6 vers BT0177/98-14-4 vers BT0051/98-14-4 vers BT0051/98-28-6 vers BT0051',
#              'OK', '', 'NC', 'SO', '', '', ''],
#             ['BT0051', 'IMPASSE GEORGES BRASSENS.xlsx', 'EDF', 'NON', 'NON', 'NON', 'NON', 'OUI', 'NON', 'OUI',
#              'NON', 'NON', 'NC', 'Non', 'NON',
#              'P-TF303G- 48F-80 vers 000279/98-14-4 vers 000279/98-14-4 vers 000279/98-28-6 vers 000279/98-14-6 vers BT0052/5/10 vers BT0052',
#              '', '', 'NC', 'SO', '', '', ''],
#             ['288941', 'La Gare.xlsx', 'BC8 ', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NC',
#              'Non', 'NON', '98-14-6     vers FT0359/98-8-6 vers FT0359', 'OKOK', '', 'NC', 'SO', 'PB', 'OK', ''],
#             ['288896', 'La Roberte.xlsx', 'BS7', 'NC', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NON', 'NC',
#              'Non', 'NC',
#              'A-N8227A-24F-70 vers 288895/98-8-4 vers 288898/98-8-4 vers 288897/98-8-4 vers 288895/98-8-4 vers 288895',
#              'OKOK', '', 'NC', 'SO', 'PB', 'OK', 'Elagage'],
#             ['288895', 'La Roberte.xlsx', 'BS6', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'NC', 'Non', 'NON',
#              'A-N8227A-24F-70 vers 288896/A-N8227A-24F-70 vers 288894/98-8-4 vers 288896/98-8-4 vers 288896/98-8-4 vers 288894/98-8-4 vers 288894',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['288894', 'La Roberte.xlsx', 'MC6 MIN', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'NC', 'Non', 'NON',
#              'A-N8227A-24F-70 vers 288895/A-N8227A-24F-70 vers 288893/98-8-4 vers 288895/98-8-4 vers 288895/98-14-6 vers 288893',
#              'OK', '', 'NC', 'SO', 'PB', '', ''],
#             ['288893', 'La Roberte.xlsx', 'BM7', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'NC', 'Non', 'NC',
#              'A-N8227A-24F-70 vers 288894/A-N8227A-24F-70 vers 288892/98-14-6 vers 288894/98-14-6 vers 288892',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['288892', 'La Roberte.xlsx', 'BH6 S30', 'NC', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NON',
#              'NC', 'Non', 'NC',
#              'A-N8227A-24F-70 vers 288893/A-N8227A-24F-70 vers 288891/98-14-6 vers 288893/98-14-6 vers 288891',
#              'OK', 'BH6 S30', 'NC', 'MH7 S30', 'Non', 'OK', 'CHO : Choc'],
#             ['288891', 'La Roberte.xlsx', 'MH6 S30', 'OUI', 'NON', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NON',
#              'NC', 'Non', 'NC',
#              'A-N8227A-24F-70 vers 288892/A-N8227A-24F-70 vers 288890/98-14-6 vers 288892/98-14-6 vers 288890',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['288890', 'La Roberte.xlsx', 'BS7', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'NC', 'Non', 'NON',
#              'A-N8227A-24F-70 vers 288891/A-N8227A-24F-70 vers 288889/98-14-6 vers 288891/98-14-6 vers 288889',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['288889', 'La Roberte.xlsx', '198.0', 'OUI', 'OUI', 'OUI', 'OUI', 'NON', 'OUI', 'OUI', 'NON', 'NON',
#              'NC', 'Non', 'NON',
#              'A-N8227A-24F-70 vers 288890/A-N8227A-24F-70 vers 288888/98-14-6 vers 288890/98-14-6 vers 288888',
#              'OK', '198.0', 'NC', 'BS8', 'Non', 'OK', ''],
#             ['288888', 'La Roberte.xlsx', 'BC6 ', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'NC', 'Non', 'NON',
#              'A-N8227A-24F-70 vers 288889/A-N8227A-24F-70 vers 288887/98-14-6 vers 288889/98-14-6 vers 288887',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['288887', 'La Roberte.xlsx', 'BS6', 'NC', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NON', 'NC',
#              'Non', 'NON',
#              'A-N8227A-24F-70 vers 288888/A-N8227A-24F-70 vers 288886/98-14-6 vers 288888/98-14-6 vers 288886',
#              'OK', 'BS6', 'NC', 'MI7 ', 'Non', 'OK', 'DEL : Délité'],
#             ['288886', 'La Roberte.xlsx', 'BS6', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'NC', 'Non', 'NON',
#              'A-N8227A-24F-70 vers 288887/A-N8227A-24F-70 vers 288884/98-14-6 vers 288887/98-14-6 vers 288884',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['BT0361', 'LAFARGE_2.xlsx', 'EDF', 'NC', 'NON', 'NON', 'NON', 'NON', 'NON', 'NON', 'OUI', 'NON', 'NC',
#              'Non', 'NON', 'A-N9923A-12F-70 vers FT0201/98-8-6 vers FT0201/98-8-6 vers BT0040', 'OK', '', 'NC',
#              'SO', '', 'OK', ''],
#             ['FT0201', 'LAFARGE_2.xlsx', 'POT MIN', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'NC', 'BTP', 'NON', 'A-N9923A-12F-70 vers BT0361/98-8-6 vers BT0361/98-8-6 vers FT0376', '', '', 'NC',
#              'SO', '', '', ''],
#             ['FT0376', 'LAFARGE_2.xlsx', 'POT MIN', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'NC', 'Non', 'NON', '98-8-6 vers FT0201/98-8-6 vers FT0202', '', '', 'NC', 'SO', '', '', ''],
#             ['288946', 'Le Cros_1.xlsx', 'MS8', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NC',
#              'Non', 'NON', 'A-N9923A-12F-70 vers 288953/98-8-6 vers 288953', 'OK', '', 'NC', 'SO', 'PB', 'OK', ''],
#             ['288953', 'Le Cros_1.xlsx', 'MI8 ', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'NC', 'Non', 'NC',
#              'A-N9923A-12F-70 vers 288946/A-N9923A-12F-70 vers 288954/98-8-6 vers 288946/98-8-6 vers 288954', 'OK',
#              '', 'NC', 'SO', 'Non', '', ''],
#             ['288954', 'Le Cros_1.xlsx', 'MI7 ', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'NC', 'Non', 'NON',
#              'A-N9923A-12F-70 vers 288953/A-N9923A-12F-70 vers 288955/98-8-6 vers 288953/98-8-6 vers 288955', 'OK',
#              '', 'NC', 'SO', 'Non', '', ''],
#             ['288955', 'Le Cros_1.xlsx', 'BS6', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NC',
#              'Non', 'NON',
#              'A-N9923A-12F-70 vers 288954/A-N9923A-12F-70 vers 288956/98-8-6 vers 288954/98-8-6 vers 288956', 'OK',
#              '', 'NC', 'SO', 'Non', '', ''],
#             ['288956', 'Le Cros_1.xlsx', 'BS6', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NC',
#              'Non', 'NC',
#              'A-N9923A-12F-70 vers 288955/A-N9923A-12F-70 vers 288957/98-8-6 vers 288955/98-8-6 vers 288957', 'OK',
#              '', 'NC', 'SO', 'Non', '', 'Elagage necessaire'],
#             ['288957', 'Le Cros_1.xlsx', 'BS6', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NC',
#              'Non', 'NC',
#              'A-N9923A-12F-70 vers 288956/A-N9923A-12F-70 vers 288958/98-8-6     vers 288956/98-8-6 vers 288958',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['288958', 'Le Cros_1.xlsx', 'BS6', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NC',
#              'Non', 'NC',
#              'A-N9923A-12F-70 vers 288957/A-N9923A-12F-70 vers 288959/98-8-6 vers 288957/98-8-6 vers 288959', 'OK',
#              '', 'NC', 'SO', 'Non', '', ''],
#             ['288959', 'Le Cros_1.xlsx', 'BC7 ', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'NC', 'Non', 'NON',
#              'A-N9923A-12F-70 vers 288958/A-N9923A-12F-70 vers 288960/98-8-6 vers 288958/Liaison vers 288960', 'OK',
#              '', 'NC', 'SO', 'Non', '', ''],
#             ['288960', 'Le Cros_1.xlsx', 'BS8', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NC',
#              'Non', 'NC',
#              'A-N9923A-12F-70 vers 288959/A-N9923A-12F-70 vers 288961/Liaison vers 288959/Liaison vers 288961',
#              'OK', '', 'NC', 'SO', 'PB', '', ''],
#             ['288961', 'Le Cros_1.xlsx', 'BS8', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NC',
#              'Non', 'NC',
#              'A-N9923A-12F-70 vers 288960/A-N9923A-12F-70 vers 288962/Liaison vers 288960/Liaison vers 288962',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['288962', 'Le Cros_1.xlsx', 'BS8', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NC',
#              'Non', 'NON',
#              'A-N9923A-12F-70 vers 288961/A-N9923A-12F-70 vers 288963/Liaison vers 288961/Liaison vers 288963',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['288963', 'Le Cros_1.xlsx', 'MI7 ', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'NC', 'Non', 'NON',
#              'A-N9923A-12F-70 vers 288962/A-N9923A-12F-70 vers BT0420/Liaison vers 288962/Liaison vers BT0420',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['BT0420', 'Le Cros_1.xlsx', 'EDF', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NC',
#              'Non', 'NON',
#              'A-N9923A-12F-70 vers 288963/A-N9923A-12F-70 vers 288964/Liaison vers 288963/Liaison vers 288964', '',
#              '', 'NC', 'SO', '', '', ''],
#             ['288964', 'Le Cros_1.xlsx', 'BS8', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NC',
#              'Non', 'NON', 'A-N9923A-12F-70 vers BT0420/Liaison vers BT0420/Liaison vers 288965', 'OK', '', 'NC',
#              'SO', 'PB', '', ''],
#             ['BT0094', 'Le Cros_2.xlsx', 'EDF', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NC',
#              'Non', 'NON',
#              'A-N9923A-12F-70 vers 288942/A-N9923A-12F-70 vers 288942/98-14-6 vers 288942/98-8-6 vers 288942', 'OK',
#              '', 'NC', 'SO', '', 'OK', ''],
#             ['288942', 'Le Cros_2.xlsx', 'MS8 ', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'NC', 'Non', 'NC',
#              'A-N9923A-12F-70 vers BT0094/A-N9923A-12F-70 vers BT0094/P-TF303G- 72F-80 vers 288943/98-14-6 vers BT0094/98-8-6 vers BT0094/98-8-6 vers 288943/98-8-6 vers 288943/SASZYPH-12F-100 vers 288943',
#              'OK', '', 'NC', 'SO', 'PB', '', ''],
#             ['288943', 'Le Cros_2.xlsx', 'MS8 ', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'NC', 'Non', 'NON',
#              'P-TF303G- 72F-80 vers 288942/P-TF303G- 72F-80 vers 288944/98-8-6 vers 288942/98-8-6 vers 288942/SASZYPH-12F-100 vers 288942/98-8-6 vers 288944/98-8-6 vers 288944/SASZYPH-12F-100 vers 288944',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['288944', 'Le Cros_2.xlsx', 'MS7 ', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'NC', 'Non', 'NC',
#              'P-TF303G- 72F-80 vers 288943/P-TF303G- 72F-80 vers 288945/98-8-6 vers 288943/98-8-6 vers 288943/SASZYPH-12F-100 vers 288943/98-8-6 vers 288945/SASZYPH-12F-100 vers 288945/98-8-6 vers 288945',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['288945', 'Le Cros_2.xlsx', 'MS7 ', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'NC', 'Non', 'NON',
#              'P-TF303G- 72F-80 vers 288944/P-TF303G- 72F-80 vers BT0223/98-8-6     vers 288944/SASZYPH-12F-100 vers 288944/98-8-6     vers 288944/98-8-6     vers 288946/98-8-6     vers 288946/SASZYPH-12F-100 vers 288946/Liaison vers BT0223',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['BT0223', 'Le Cros_2.xlsx', 'EDF', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NC',
#              'Non', 'NON',
#              'P-TF303G- 72F-80 vers 288945/P-TF303G- 72F-80 vers 288946/Liaison vers 288945/Liaison vers 288946',
#              '', '', 'NC', 'SO', '', '', ''],
#             ['288946', 'Le Cros_2.xlsx', 'MS8 ', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'NC', 'Non', 'NON',
#              'A-N9923A-12F-70 vers 288953/P-TF303G- 72F-80 vers BT0223/A-N9923A-12F-70 vers 288947/Liaison vers BT0223/98-8-6     vers 288945/98-8-6     vers 288945/SASZYPH-12F-100 vers 288945/98-8-6     vers 288953/Liaison vers 288947',
#              'INSUFFISANT', 'MS8 ', 'NC', 'FR8', 'PB', 'OK', ''],
#             ['288947', 'Le Cros_2.xlsx', 'MS6 ', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'NC', 'Non', 'NC',
#              'A-N9923A-12F-70 vers 288946/A-N9923A-12F-70 vers 288948/Liaison vers 288946/Liaison vers 288948',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['288948', 'Le Cros_2.xlsx', 'MS7 ', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'NC', 'Non', 'NON',
#              'A-N9923A-12F-70 vers 288947/A-N9923A-12F-70 vers 288949/Liaison vers 288947/Liaison vers 288949',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['288949', 'Le Cros_2.xlsx', 'MS7 ', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'NC', 'Non', 'NON',
#              'A-N9923A-12F-70 vers 288948/A-N9923A-12F-70 vers 288950/Liaison vers 288948/Liaison vers 288950',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['288950', 'Le Cros_2.xlsx', 'MS7 ', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'NC', 'Non', 'NC',
#              'A-N9923A-12F-70 vers 288949/A-N9923A-12F-70 vers 288951/Liaison vers 288949/Liaison vers 288951',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['288951', 'Le Cros_2.xlsx', 'BH7 S30', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'NC', 'Non', 'NON', 'A-N9923A-12F-70 vers 288950/Liaison vers 288950', 'OK', '', 'NC', 'SO', 'PB', '',
#              ''],
#             ['288953', 'Le Cros_2.xlsx', 'MI8', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NC',
#              'Non', 'NC', 'A-N9923A-12F-70 vers 288946/Liaison vers 288946', 'OK', '', 'NC', 'SO', '', '', ''],
#             ['288878', 'Le Mas_1.xlsx', 'BS7', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NC',
#              'Non', 'NON',
#              'P-TF303G- 72F-80 vers 288879/P-TF303G- 72F-80 vers 288877/98-14-6 vers 288879/98-14-6 vers 288879/98-14-6 vers 288877/98-14-6 vers 288877',
#              'OKOK', '', 'NC', 'SO', 'Non', 'OK', ''],
#             ['288877', 'Le Mas_1.xlsx', 'BC7 ', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NC',
#              'Non', 'NON',
#              'P-TF303G- 72F-80 vers 288878/P-TF303G- 72F-80 vers 288876/98-14-6 vers 288878/98-14-6 vers 288878/98-14-6 vers 288876/98-14-6 vers 288876',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['288876', 'Le Mas_1.xlsx', 'MH7 S30', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'NC', 'Non', 'NC',
#              'P-TF303G- 72F-80 vers 288877/P-TF303G- 72F-80 vers 288875/98-14-6 vers 288877/98-14-6 vers 288877/98-14-6 vers 288875/98-14-6 vers 288875',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['288875', 'Le Mas_1.xlsx', 'BH7 S30', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'NC', 'Non', 'NON',
#              'P-TF303G- 72F-80 vers 288876/P-TF303G- 72F-80 vers 288874/98-14-6 vers 288876/98-14-6 vers 288876/98-14-6 vers 288874/98-14-6 vers 288874',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['288874', 'Le Mas_1.xlsx', 'BC7 ', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NC',
#              'Non', 'NON',
#              'P-TF303G- 72F-80 vers 288875/P-TF303G- 72F-80 vers 288873/98-14-6 vers 288875/98-14-6 vers 288875/98-14-6 vers 288873/98-14-6 vers 288873',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['288873', 'Le Mas_1.xlsx', 'BS6', 'NC', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NON', 'NON', 'NC',
#              'Non', 'NON',
#              'P-TF303G- 72F-80 vers 288874/P-TF303G- 72F-80 vers 288872/98-14-6 vers 288874/98-14-6 vers 288874/98-14-6 vers 288872/98-14-6 vers 288872',
#              'OK', 'BS6', 'NC', 'BS7', 'Non', 'OK', 'AUT : Autre'],
#             ['288872', 'Le Mas_1.xlsx', 'BS6', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NC',
#              'Non', 'NON',
#              'P-TF303G- 72F-80 vers 288873/P-TF303G- 72F-80 vers 288871/98-14-6 vers 288873/98-14-6 vers 288873/98-14-6 vers 288871/98-14-6 vers 288871',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['288871', 'Le Mas_1.xlsx', 'BS7', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NC',
#              'Non', 'NON',
#              'P-TF303G- 72F-80 vers 288872/P-TF303G- 72F-80 vers 288870/98-14-6 vers 288872/98-14-6 vers 288872/98-14-6 vers 288870/98-14-6 vers 288870',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['288870', 'Le Mas_1.xlsx', 'BS6', 'NC', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NON', 'NON', 'NC',
#              'Non', 'NON',
#              'P-TF303G- 72F-80 vers 288871/P-TF303G- 72F-80 vers 288869/98-14-6 vers 288871/98-14-6 vers 288871/98-14-6 vers 288869/98-14-6 vers 288869',
#              'OK', 'BS6', 'NC', 'BS7', 'Non', 'OK', 'AUT : Autre'],
#             ['288928', 'Le Mas_2.xlsx', 'BS7', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NC',
#              'Non', 'NC',
#              'A-N9923A-12F-70 vers 288868/A-N9923A-12F-70 vers 288929/98-8-4     vers 288868/98-8-4     vers 288929',
#              'OKINSUFFISANT', 'BS7', 'NC', 'BH7 S30', 'Non', 'OKOK', ''],
#             ['288929', 'Le Mas_2.xlsx', 'BS7', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NC',
#              'Non', 'NON',
#              'A-N9923A-12F-70 vers 288928/A-N9923A-12F-70 vers 288930/98-8-4 vers 288928/98-8-4 vers 288930', 'OK',
#              '', 'NC', 'SO', 'Non', '', ''],
#             ['288930', 'Le Mas_2.xlsx', 'BS7', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NC',
#              'Non', 'NON',
#              'A-N9923A-12F-70 vers 288929/A-N9923A-12F-70 vers 288931/98-8-4 vers 288929/98-8-4 vers 288931', 'OK',
#              '', 'NC', 'SO', 'Non', '', ''],
#             ['288931', 'Le Mas_2.xlsx', 'BS7', 'NC', 'NON', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NON', 'NON', 'NC',
#              'Non', 'NON',
#              'A-N9923A-12F-70 vers 288930/A-N9923A-12F-70 vers 288932/98-8-4 vers 288930/98-8-4 vers 288932', 'OK',
#              'BS7', 'NC', 'MI7 ', 'Non', 'OK', 'AUT : Autre'],
#             ['288932', 'Le Mas_2.xlsx', 'BS7', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NC',
#              'Non', 'NON', 'A-N9923A-12F-70 vers 288931/98-8-4 vers 288931/98-8-4 vers BT725', 'OK', '', 'NC', 'SO',
#              'PB', '', ''],
#             ['288869', 'Le Mas_3.xlsx', 'BC6 ', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NC',
#              'Non', 'NC',
#              'P-TF303G- 72F-80 vers 288870/P-TF303G- 72F-80 vers 288868/98-14-6     vers 288870/98-14-6     vers 288870/98-14-6     vers 288868/98-14-6     vers 288868',
#              'OKOK', '', 'NC', 'SO', 'Non', 'OK', ''],
#             ['288868', 'Le Mas_3.xlsx', 'BC6 ', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NC',
#              'Non', 'NON',
#              'P-TF303G- 72F-80 vers 288869/P-TF303G- 72F-80 vers 288867/A-N9923A-12F-70 vers 288928/98-14-6 vers 288869/98-14-6 vers 288869/98-14-6 vers 288867/98-14-6 vers 288867',
#              'OK', '', 'NC', 'SO', 'PB', '', ''],
#             ['288867', 'Le Mas_3.xlsx', 'BS6', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NC',
#              'Non', 'NON',
#              'P-TF303G- 72F-80 vers 288868/P-TF303G- 72F-80 vers 288866/98-14-6 vers 288868/98-14-6 vers 288868/98-14-6 vers 288866/98-14-6 vers 288866',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['288866', 'Le Mas_3.xlsx', 'BS6', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NC',
#              'Non', 'NON',
#              'P-TF303G- 72F-80 vers 288867/P-TF303G- 72F-80 vers 288865/98-14-6 vers 288867/98-14-6 vers 288867/98-14-6 vers 288865/98-14-6 vers 288865',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['288865', 'Le Mas_3.xlsx', 'BS6', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NC',
#              'Non', 'NC',
#              'P-TF303G- 72F-80 vers 288866/P-TF303G- 72F-80 vers 288864/98-14-6 vers 288866/98-14-6 vers 288866/98-14-6 vers 288864/98-14-6 vers 288864',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['288864', 'Le Mas_3.xlsx', 'BS6', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NC',
#              'Non', 'NON',
#              'P-TF303G- 72F-80 vers 288865/P-TF303G- 72F-80 vers 288863/98-14-6 vers 288865/98-14-6 vers 288865/98-14-6 vers 288863/98-14-6 vers 288863',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['288863', 'Le Mas_3.xlsx', 'BS8', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NC',
#              'Non', 'NON',
#              'P-TF303G- 72F-80 vers 288864/P-TF303G- 72F-80 vers 288862/98-14-6 vers 288864/98-14-6 vers 288864/98-14-6 vers 288862/98-14-6 vers 288862',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['288862', 'Le Mas_3.xlsx', 'BH8 S30', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'NC', 'Non', 'NC',
#              'P-TF303G- 72F-80 vers 288863/P-TF303G- 72F-80 vers 288861/98-14-6 vers 288863/98-14-6 vers 288863/98-14-6 vers 288861/98-14-6 vers 288861',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['288861', 'Le Mas_3.xlsx', 'BS8', 'NC', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NON', 'NON', 'NC',
#              'Non', 'NON',
#              'P-TF303G- 72F-80 vers 288862/P-TF303G- 72F-80 vers 288860/98-14-6 vers 288862/98-14-6 vers 288862/98-14-6 vers 288860/98-14-6 vers 288860',
#              'OK', 'BS8', 'NC', 'BH8 S30', 'Non', 'OK', 'AUT : Autre'],
#             ['288860', 'Le Mas_3.xlsx', 'BS8', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NC',
#              'Non', 'NON',
#              'P-TF303G- 72F-80 vers 288861/P-TF303G- 72F-80 vers 288859/98-14-6 vers 288861/98-14-6 vers 288861/98-14-6 vers 288859/98-14-6 vers 288859',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['288859', 'Le Mas_3.xlsx', 'BS7', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NC',
#              'Non', 'NON',
#              'P-TF303G- 72F-80 vers 288860/P-TF303G- 72F-80 vers 288858/98-14-6 vers 288860/98-14-6 vers 288860/98-14-6 vers 288858/98-14-6 vers 288858',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['288858', 'Le Mas_3.xlsx', 'BS6', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NC',
#              'Non', 'NON',
#              'P-TF303G- 72F-80 vers 288859/P-TF303G- 72F-80 vers 288857/98-14-6 vers 288859/98-14-6 vers 288859/98-14-6 vers 288857/98-14-6 vers 288857',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['288857', 'Le Mas_3.xlsx', 'BS7', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NC',
#              'Non', 'NON',
#              'P-TF303G- 72F-80 vers 288858/P-TF303G- 72F-80 vers 288856/98-14-6 vers 288858/98-14-6 vers 288858/98-14-6 vers 288856/98-14-6 vers 288856',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['288856', 'Le Mas_3.xlsx', 'BS6', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NC',
#              'Non', 'NON',
#              'P-TF303G- 72F-80 vers 288857/P-TF303G- 72F-80 vers 288855/98-14-6 vers 288857/98-14-6 vers 288857/98-14-6 vers 288855/98-14-6 vers 288855',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['288855', 'Le Mas_3.xlsx', 'BC6 ', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NC',
#              'Non', 'NON',
#              'P-TF303G- 72F-80 vers 288856/P-TF303G- 72F-80 vers 288854/98-14-6 vers 288856/98-14-6 vers 288856/98-14-6 vers 288854/98-14-6 vers 288854',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['288854', 'Le Mas_3.xlsx', 'BC7 ', 'NC', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NON', 'NON', 'NC',
#              'Non', 'NON',
#              'P-TF303G- 72F-80 vers 288855/P-TF303G- 72F-80 vers 288853/98-14-6 vers 288855/98-14-6 vers 288855/98-14-6 vers 288853/98-14-6 vers 288853',
#              'OK', 'BC7 ', 'NC', 'BC7 ', 'Non', 'OK', 'AUT : Autre'],
#             ['288853', 'Le Mas_3.xlsx', 'BC6 ', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NC',
#              'Non', 'NON',
#              'P-TF303G- 72F-80 vers 288854/P-TF303G- 72F-80 vers 288852/98-14-6 vers 288854/98-14-6 vers 288854/98-14-6 vers 288852/98-14-6 vers 288852',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['288852', 'Le Mas_3.xlsx', 'BH6 S30', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'NC', 'Non', 'NON',
#              'P-TF303G- 72F-80 vers 288853/P-TF303G- 72F-80 vers 288851/98-14-6 vers 288853/98-14-6 vers 288853/98-14-6 vers 288851/98-14-6 vers 288851',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['288851', 'Le Mas_3.xlsx', 'BS6', 'NC', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NON', 'NON', 'NC',
#              'Non', 'NON',
#              'P-TF303G- 72F-80 vers 288852/P-TF303G- 72F-80 vers 288850/98-14-6 vers 288852/98-14-6 vers 288852/98-14-6 vers 288850/98-14-6 vers 288850',
#              'OK', 'BS6', 'NC', 'MI7 ', 'Non', 'OK', 'AUT : Autre'],
#             ['288850', 'Le Mas_3.xlsx', 'BS8', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NC',
#              'Non', 'NC',
#              'P-TF303G- 72F-80 vers 288851/P-TF303G- 72F-80 vers 288849/98-14-6 vers 288851/98-14-6 vers 288851/98-14-6 vers 288849/98-14-6 vers 288849',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['BT0576', 'Les Hellys.xlsx', 'EDF', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'NC', 'Non', 'NON', 'A-N8227A-24F-70 vers FT0743/Liaison vers FT0743', 'OK', '', 'NC', 'SO', 'PB',
#              'OK', ''],
#             ['FT0743', 'Les Hellys.xlsx', 'POT MIN', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'NC', 'Non', 'NON',
#              'A-N8227A-24F-70 vers BT0576/A-N8227A-24F-70 vers FT0744/Liaison vers BT0576/98-8-6     vers FT0754/98-4-8     vers FT0744',
#              '', '', 'NC', 'SO', 'Non', '', ''],
#             ['FT0744', 'Les Hellys.xlsx', 'POT MIN', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'NC', 'Non', 'NON', 'A-N8227A-24F-70 vers FT0743/98-4-8 vers FT0743', '', '', 'NC', 'SO', 'Non', '',
#              ''],
#             ['BT0010', 'Les Perriers.xlsx', 'EDF', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'NC', 'Non', 'NON', 'P-TF303G-288F-80 vers 289059/Liaison vers 289059', 'OK', '', 'NC', 'SO', '', 'OK',
#              ''],
#             ['289059', 'Les Perriers.xlsx', 'MS7 ', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'NC', 'Non', 'NON',
#              'P-TF303G-288F-80 vers BT0010/P-TF303G-288F-80 vers 289058/A-N9923A-12F-70 vers 289058/Liaison vers BT0010/98-8-4 vers 289058',
#              'INSUFFISANT', 'MS7 ', 'NC', 'FR7', 'PB', 'OK', ''],
#             ['289058', 'Les Perriers.xlsx', 'MS7 ', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'NC', 'Non', 'NON',
#              'P-TF303G-288F-80 vers 289059/P-TF303G-288F-80 vers 289057/A-N9923A-12F-70 vers 289059/98-8-4 vers 289059/98-8-4 vers 289057',
#              'OK', '', 'NC', 'SO', 'PB', '', ''],
#             ['289057', 'Les Perriers.xlsx', 'MS7 ', 'NC', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NON',
#              'NC', 'Non', 'NON',
#              'P-TF303G-288F-80 vers 289058/P-TF303G-288F-80 vers 289056/98-8-4 vers 289058/98-8-4 vers 289056',
#              'OK', 'MS7 ', 'NC', 'MI7 ', 'Non', 'OK', 'CHO : Choc'],
#             ['289056', 'Les Perriers.xlsx', 'MS7 ', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NON', 'NON',
#              'NC', 'Non', 'NON',
#              'P-TF303G-288F-80 vers 289057/P-TF303G-288F-80 vers 289055/98-8-4 vers 289057/98-8-4 vers 289055',
#              'OK', 'MS7 ', 'NC', 'MI7 ', 'Non', 'OK', ''],
#             ['289055', 'Les Perriers.xlsx', 'MI7 ', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'NC', 'Non', 'NON',
#              'P-TF303G-288F-80 vers 289056/P-TF303G-288F-80 vers 289054/98-8-4 vers 289056/98-8-4 vers 289054',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['289054', 'Les Perriers.xlsx', 'MS7 ', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'NC', 'Non', 'NON',
#              'P-TF303G-288F-80 vers 289055/P-TF303G-288F-80 vers 289053/98-8-4 vers 289055/98-8-4 vers 289053',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['289053', 'Les Perriers.xlsx', 'BS8', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'NC', 'Non', 'NC',
#              'P-TF303G-288F-80 vers 289054/P-TF303G-288F-80 vers 289052/98-8-4 vers 289054/98-8-4 vers 289052',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['289052', 'Les Perriers.xlsx', 'MS8 ', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'NC', 'Non', 'NC',
#              'P-TF303G-288F-80 vers 289053/P-TF303G-288F-80 vers 289051/98-8-4 vers 289053/98-8-4 vers 289051',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['289051', 'Les Perriers.xlsx', 'BS7', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'NC', 'Non', 'NON',
#              'P-TF303G-288F-80 vers 289052/P-TF303G-288F-80 vers 289050/98-8-4 vers 289052/98-8-4 vers 289050',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['289050', 'Les Perriers.xlsx', 'BS6', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'NC', 'Non', 'NON',
#              'P-TF303G-288F-80 vers 289051/P-TF303G-288F-80 vers 289049/98-8-4 vers 289051/98-8-4 vers 289049',
#              'OK', '', 'NC', 'SO', 'Non', '', 'Haubanné détaché'],
#             ['289049', 'Les Perriers.xlsx', 'BS6', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'NC', 'Non', 'NON',
#              'P-TF303G-288F-80 vers 289050/P-TF303G-288F-80 vers 289048/98-8-4 vers 289050/98-8-4 vers 289048',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['289048', 'Les Perriers.xlsx', 'BS6', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'NC', 'Non', 'NON',
#              'P-TF303G-288F-80 vers 289049/P-TF303G-288F-80 vers 289047/98-8-4 vers 289049/98-8-4 vers 289047',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['289047', 'Les Perriers.xlsx', 'MI6 ', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'NC', 'Non', 'NON',
#              'P-TF303G-288F-80 vers 289048/P-TF303G-288F-80 vers 289046/98-8-4 vers 289048/98-8-4 vers 289046',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['289046', 'Les Perriers.xlsx', 'BS6', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'NC', 'Non', 'NON',
#              'P-TF303G-288F-80 vers 289047/P-TF303G-288F-80 vers 289045/98-8-4 vers 289047/98-8-4 vers 289045',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['289045', 'Les Perriers.xlsx', 'BS6', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'NC', 'Non', 'NON',
#              'P-TF303G-288F-80 vers 289046/P-TF303G-288F-80 vers 289044/98-8-4 vers 289046/98-8-4 vers 289044',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['289044', 'Les Perriers.xlsx', 'BS6', 'NC', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NON',
#              'NC', 'Non', 'NON',
#              'P-TF303G-288F-80 vers 289045/P-TF303G-288F-80 vers 289043/98-8-4 vers 289045/98-8-4 vers 289043',
#              'OK', 'BS6', 'NC', 'MI7 ', 'Non', 'OK', 'CHO : Choc'],
#             ['289043', 'Les Perriers.xlsx', 'BS7', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'NC', 'Non', 'NON',
#              'P-TF303G-288F-80 vers 289044/P-TF303G-288F-80 vers 289041/98-8-4 vers 289044/98-8-4 vers 289041',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['289041', 'Les Perriers.xlsx', 'MS8 ', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'NC', 'Non', 'NON',
#              'P-TF303G-288F-80 vers 289043/P-TF303G-288F-80 vers 289040/98-8-4 vers 289043/98-8-4 vers 289040',
#              'OK', '', 'NC', 'SO', 'Non', '', 'Elagage necessaire'],
#             ['289040', 'Les Perriers.xlsx', 'MS7 ', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'NC', 'Non', 'NON',
#              'P-TF303G-288F-80 vers 289041/P-TF303G-288F-80 vers BT0008/98-8-4 vers 289041/98-8-4 vers BT0008',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['BT0008', 'Les Perriers.xlsx', 'EDF', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'NC', 'Non', 'NON', 'P-TF303G-288F-80 vers 289040/98-8-4 vers 289040', '', '', 'NC', 'SO', 'PB', '',
#              ''],
#             ['BT0605', 'Longeavoux N.xlsx', 'EDF', 'OUI', 'OUI', 'OUI', 'NON', 'OUI', 'OUI', 'OUI', 'OUI', 'NON',
#              'NC', 'Non', 'NON', 'A-N8227A-24F-70 vers 288806/Liaison vers 288806', 'OK', '', 'NC', 'SO', '', 'OK',
#              ''], ['288806', 'Longeavoux N.xlsx', 'BC8 ANC', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#                    'OUI', 'NC', 'Non', 'NON',
#                    'A-N8227A-24F-70 vers BT0605/P-TF303G-288F-80 vers 288805/Liaison vers BT0605/98-14-4 vers 288805/98-28-4 vers 288805/98-56-4 vers 288805/SACMY-36F-80 vers 288805',
#                    'OK', '', 'NC', 'SO', 'PB', '', ''],
#             ['288805', 'Longeavoux N.xlsx', 'BS8', 'OUI', 'OUI', 'OUI', 'NON', 'OUI', 'OUI', 'OUI', 'OUI', 'NON',
#              'NC', 'Non', 'NC',
#              'P-TF303G-288F-80 vers 288806/P-TF303G-288F-80 vers BT0609/98-14-4 vers 288806/98-28-4 vers 288806/98-56-4 vers 288806/SACMY-36F-80 vers 288806/SACMY-36F-80 vers BT0609/98-14-4 vers BT0609/98-28-4 vers BT0609/98-56-4 vers BT0609',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['BT0609', 'Longeavoux N.xlsx', 'EDF', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'NC', 'Non', 'NON',
#              'P-TF303G-288F-80 vers 288805/P-TF303G-288F-80 vers 288804/SACMY-36F-80 vers 288805/98-14-4 vers 288805/98-28-4 vers 288805/98-56-4 vers 288805/98-14-4 vers 288804/98-28-4 vers 288804/98-56-4 vers 288804/SACMY-36F-80 vers 288804',
#              '', '', 'NC', 'SO', '', '', ''],
#             ['288804', 'Longeavoux N.xlsx', 'BC7 ', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'NC', 'Non', 'NON',
#              'P-TF303G-288F-80 vers BT0609/P-TF303G-288F-80 vers 288787/P-TF303G-144F-80 vers 288787/P-TF303G-144F-80 vers BT0611/98-14-4 vers BT0609/98-28-4 vers BT0609/98-56-4 vers BT0609/SACMY-36F-80 vers BT0609/Liaison vers BT0611/98-14-4 vers 288787/98-28-4 vers 288787/98-14-4 vers 288787/98-14-4 vers 288787/98-28-4 vers 288787/SACMY-36F-80 vers 288787',
#              'INSUFFISANT', 'BC7 ', 'NC', 'BC7 ANC', 'Non', 'OK', ''],
#             ['288787', 'Longeavoux N.xlsx', 'BH8 S30', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NC',
#              'P-TF303G-288F-80 vers 288804/P-TF303G-288F-80 vers 288786/P-TF303G-144F-80 vers 288804/P-TF303G-144F-80 vers 288786/98-14-4 vers 288804/98-28-4 vers 288804/98-14-4 vers 288804/98-14-4 vers 288804/98-28-4 vers 288804/SACMY-36F-80 vers 288804/98-14-4 vers BT0611/98-28-4 vers 288786/98-14-4 vers 288786/98-14-4 vers 288786/98-28-4 vers 288786/SACMY-36F-80 vers 288786',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['288786', 'Longeavoux N.xlsx', 'BH8 S30', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NC',
#              'P-TF303G-288F-80 vers 288787/P-TF303G-288F-80 vers 288785/P-TF303G-144F-80 vers 288787/P-TF303G-144F-80 vers 288785/98-28-4 vers 288787/98-14-4 vers 288787/98-14-4 vers 288787/98-28-4 vers 288787/SACMY-36F-80 vers 288787/98-28-4 vers 288785/98-14-4 vers 288785/98-14-4 vers 288785/98-28-4 vers 288785/SACMY-36F-80 vers 288785',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['288785', 'Longeavoux N.xlsx', 'BH8 S45', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G-288F-80 vers 288786/P-TF303G-288F-80 vers 288784/P-TF303G-144F-80 vers 288786/P-TF303G-144F-80 vers 288784/98-28-4 vers 288786/98-14-4 vers 288786/98-14-4 vers 288786/98-28-4 vers 288786/SACMY-36F-80 vers 288786/98-28-4 vers 288784/98-14-4 vers 288784/98-14-4 vers 288784/98-28-4 vers 288784/SACMY-36F-80 vers 288784',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['288784', 'Longeavoux N.xlsx', 'BS7', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'NC', 'Non', 'NC',
#              'P-TF303G-288F-80 vers 288785/P-TF303G-288F-80 vers 288783/P-TF303G-144F-80 vers 288785/P-TF303G-144F-80 vers 288783/98-28-4 vers 288785/98-14-4 vers 288785/98-14-4 vers 288785/98-28-4 vers 288785/SACMY-36F-80 vers 288785/98-28-4 vers 288783/98-14-4 vers 288783/98-14-4 vers 288783/98-28-4 vers 288783/SACMY-36F-80 vers 288783',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['288783', 'Longeavoux N.xlsx', 'BS7', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'NC', 'Non', 'NON',
#              'P-TF303G-288F-80 vers 288784/P-TF303G-288F-80 vers 288782/P-TF303G-144F-80 vers 288784/P-TF303G-144F-80 vers 288782/98-28-4 vers 288784/98-14-4 vers 288784/98-14-4 vers 288784/98-28-4 vers 288784/SACMY-36F-80 vers 288784/98-14-4 vers 288782/98-14-4 vers 288782/98-28-4 vers 288782/98-28-4 vers 288782/SACMY-36F-80 vers 288782',
#              'INSUFFISANT', 'BS7', 'NC', 'M47', 'Non', 'OK', ''],
#             ['288782', 'Longeavoux N.xlsx', 'MI7 ', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'NC', 'Non', 'NC',
#              'P-TF303G-288F-80 vers 288783/P-TF303G-288F-80 vers 288781/P-TF303G-144F-80 vers 288783/P-TF303G-144F-80 vers 288781/98-14-4 vers 288783/98-14-4 vers 288783/98-28-4 vers 288783/98-28-4 vers 288783/SACMY-36F-80 vers 288783/98-14-4 vers 288781/98-14-4 vers 288781/98-28-4 vers 288781/98-28-4 vers 288781/SACMY-144F-300 vers 288781',
#              'INSUFFISANT', 'MI7 ', 'NC', 'M47', 'Non', 'OK', ''],
#             ['288781', 'Longeavoux N.xlsx', 'MI8 ', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'NC', 'Non', 'NC',
#              'P-TF303G-288F-80 vers 288782/P-TF303G-288F-80 vers 288780/P-TF303G-144F-80 vers 288782/P-TF303G-144F-80 vers 288780/98-14-4 vers 288782/98-14-4 vers 288782/98-28-4 vers 288782/98-28-4 vers 288782/SACMY-144F-300 vers 288782/98-14-4 vers 288780/98-14-4 vers 288780/98-28-4 vers 288780/98-28-4 vers 288780/SACMY-36F-80 vers 288780',
#              'INSUFFISANT', 'MI8 ', 'NC', 'M48', 'Non', 'OK', ''],
#             ['288780', 'Longeavoux N.xlsx', 'MH7 S45', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NC',
#              'P-TF303G-288F-80 vers 288781/P-TF303G-288F-80 vers 288779/P-TF303G-144F-80 vers 288781/P-TF303G-144F-80 vers 288779/98-14-4 vers 288781/98-14-4 vers 288781/98-28-4 vers 288781/98-28-4 vers 288781/SACMY-36F-80 vers 288781/98-14-4 vers 288779/98-14-4 vers 288779/98-28-4 vers 288779/98-28-4 vers 288779/SACMY-36F-80 vers 288779',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['288779', 'Longeavoux N.xlsx', 'MH7 S45', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G-288F-80 vers 288780/P-TF303G-288F-80 vers 288778/P-TF303G-144F-80 vers 288780/P-TF303G-144F-80 vers 288778/98-14-4 vers 288780/98-14-4 vers 288780/98-28-4 vers 288780/98-28-4 vers 288780/SACMY-36F-80 vers 288780/98-28-4 vers 288778/98-14-4 vers 288778/98-14-4 vers 288778/98-28-4 vers 288778/SACMY-36F-80 vers 288778',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['288778', 'Longeavoux N.xlsx', 'MH7 S45', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G-288F-80 vers 288779/P-TF303G-288F-80 vers 288777/P-TF303G-144F-80 vers 288779/P-TF303G-144F-80 vers 288777/98-28-4 vers 288779/98-14-4 vers 288779/98-14-4 vers 288779/98-28-4 vers 288779/SACMY-36F-80 vers 288779/98-28-4 vers 288777/98-14-4 vers 288777/98-14-4 vers 288777/98-28-4 vers 288777/SACMY-36F-80 vers 288777',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['288777', 'Longeavoux N.xlsx', 'MH7 S45', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G-288F-80 vers 288778/P-TF303G-288F-80 vers 190217/P-TF303G-144F-80 vers 288778/P-TF303G-144F-80 vers 190217/98-28-4 vers 288778/98-14-4 vers 288778/98-14-4 vers 288778/98-28-4 vers 288778/SACMY-36F-80 vers 288778/98-28-4 vers 190217/98-56-4 vers 190217/SACMY-36F-80 vers 190217',
#              'INSUFFISANT', 'MH7 S45', 'NC', 'M47', 'Non', 'OK', ''],
#             ['190217', 'Longeavoux N.xlsx', 'BH7 S45', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G-288F-80 vers 288777/P-TF303G-288F-80 vers 288776/P-TF303G-144F-80 vers 288777/P-TF303G-144F-80 vers 288776/98-28-4 vers 288777/98-56-4 vers 288777/SACMY-36F-80 vers 288777/98-56-4 vers 288776/98-28-4 vers 288776/SACMY-36F-80 vers 288776',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['288776', 'Longeavoux N.xlsx', 'MH7 S45', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G-288F-80 vers 190217/P-TF303G-288F-80 vers 288775/P-TF303G-144F-80 vers 190217/P-TF303G-144F-80 vers 288775/98-56-4 vers 190217/98-28-4 vers 190217/SACMY-36F-80 vers 190217/98-56-4 vers 288775/98-28-4 vers 288775/SACMY-36F-80 vers 288775',
#              'INSUFFISANT', 'MH7 S45', 'NC', 'M47', 'Non', 'OK', ''],
#             ['288775', 'Longeavoux N.xlsx', 'MI8 ', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'NC', 'Non', 'NON',
#              'P-TF303G-288F-80 vers 288776/P-TF303G-288F-80 vers 421066/P-TF303G-144F-80 vers 288776/P-TF303G-144F-80 vers 421066/98-56-4 vers 288776/98-28-4 vers 288776/SACMY-36F-80 vers 288776/98-56-4 vers 421066/98-28-4 vers 421066/SACMY-36F-80 vers 421066',
#              'INSUFFISANT', 'MI8 ', 'NC', 'M48', 'Non', 'OK', ''],
#             ['421066', 'Longeavoux N.xlsx', 'MC7 MIN', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G-288F-80 vers 288775/P-TF303G-288F-80 vers 288774/P-TF303G-144F-80 vers 288775/P-TF303G-144F-80 vers 288774/98-56-4 vers 288775/98-28-4 vers 288775/SACMY-36F-80 vers 288775/98-56-4 vers 288774/98-28-4 vers 288774/SACMY-36F-80 vers 288774',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['288774', 'Longeavoux N.xlsx', 'BC8 ANC', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G-288F-80 vers 421066/P-TF303G-288F-80 vers 288773/P-TF303G-144F-80 vers 421066/P-TF303G-144F-80 vers 288773/98-56-4 vers 421066/98-28-4 vers 421066/SACMY-36F-80 vers 421066/98-56-4 vers 288773/98-28-4 vers 288773/SACMY-36F-80 vers 288773',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['BT0611', 'Longeavoux N.xlsx', 'EDF', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'NC', 'Non', 'NON', 'P-TF303G-144F-80 vers 288804/98-8-6 vers 288787/Liaison vers 288804', '', '',
#              'NC', 'SO', 'PB', '', ''],
#             ['288967', 'Migelage.xlsx', 'BS7', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NC',
#              'Non', 'NC', 'A-N9923A-12F-70 vers BT0499/Liaison vers BT0499', 'OKOK', '', 'NC', 'SO', 'PB', 'OK',
#              ''],
#             ['BT0499', 'Migelage.xlsx', 'EDF', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NC',
#              'Non', 'NON', 'A-N9923A-12F-70 vers 288967/Liaison vers 288967', '', '', 'NC', 'SO', '', '', ''],
#             ['288901', 'Paurière_1.xlsx', 'BS8', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'NC', 'Non', 'NC',
#              'P-TF303G- 72F-80 vers 288879/P-TF303G- 72F-80 vers BT0586/98-14-6 vers 288879/98-14-6 vers 288879/98-14-6 vers BT0586/98-14-6 vers BT0586',
#              'OKOK', '', 'NC', 'SO', 'Non', 'OK', ''],
#             ['BT0586', 'Paurière_1.xlsx', 'EDF', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'NC', 'Non', 'NON',
#              'P-TF303G- 72F-80 vers 288901/P-TF303G- 72F-80 vers BT0585/98-14-6 vers 288901/98-14-6 vers 288901/98-14-6 vers BT0585/98-14-6 vers BT0585',
#              '', '', 'NC', 'SO', 'Non', '', ''],
#             ['BT0585', 'Paurière_1.xlsx', 'EDF', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'NC', 'Non', 'NON',
#              'P-TF303G- 72F-80 vers BT0586/P-TF303G- 72F-80 vers 288902/98-14-6 vers BT0586/98-14-6 vers BT0586/98-14-6 vers 288902/98-14-6 vers 288902',
#              '', '', 'NC', 'SO', '', '', ''],
#             ['288902', 'Paurière_1.xlsx', '198.0', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'NC', 'Non', 'NC',
#              'P-TF303G- 72F-80 vers BT0585/P-TF303G- 72F-80 vers 288903/98-14-6 vers BT0585/98-14-6 vers BT0585/98-14-6 vers 288903/98-14-6 vers 288903',
#              'OK', '', 'NC', 'SO', 'PB', '', ''],
#             ['288903', 'Paurière_1.xlsx', 'BC6 ', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'NC', 'Non', 'NON',
#              'P-TF303G- 72F-80 vers 288902/P-TF303G- 72F-80 vers 288904/98-14-6 vers 288902/98-14-6 vers 288902/98-14-6 vers 288904/98-14-6 vers 288904',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['288904', 'Paurière_1.xlsx', 'BS6', 'NC', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NON', 'NON', 'NC',
#              'Non', 'NON',
#              'P-TF303G- 72F-80 vers 288903/P-TF303G- 72F-80 vers 288905/98-14-6 vers 288903/98-14-6 vers 288903/98-14-6 vers 288905/98-14-6 vers 288905',
#              'OK', 'BS6', 'NC', 'BH7 S30', 'Non', 'OK', 'AUT : Autre'],
#             ['288905', 'Paurière_1.xlsx', 'BS6', 'NC', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NON', 'NON', 'NC',
#              'Non', 'NON',
#              'P-TF303G- 72F-80 vers 288904/P-TF303G- 72F-80 vers 288906/98-14-6 vers 288904/98-14-6 vers 288904/98-14-6 vers 288906/98-14-6 vers 288906',
#              'OK', 'BS6', 'NC', 'BH7 S30', 'Non', 'OK', 'AUT : Autre'],
#             ['288906', 'Paurière_1.xlsx', 'BH6 S30', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'NC', 'Non', 'NON',
#              'P-TF303G- 72F-80 vers 288905/P-TF303G- 72F-80 vers 288907/98-14-6 vers 288905/98-14-6 vers 288905/98-14-6 vers 288907/98-14-6 vers 288907',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['288907', 'Paurière_1.xlsx', 'BM6', 'NC', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NON', 'NON', 'NC',
#              'Non', 'NC',
#              'P-TF303G- 72F-80 vers 288906/P-TF303G- 72F-80 vers 288908/98-14-6 vers 288906/98-14-6 vers 288906/98-14-6 vers 288908/98-14-6 vers 288908',
#              'INSUFFISANT', 'BM6', 'NC', 'M47', 'Non', 'OK', 'AUT : Autre'],
#             ['288908', 'Paurière_1.xlsx', 'BS6', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'NC', 'Non', 'NON',
#              'P-TF303G- 72F-80 vers 288907/P-TF303G- 72F-80 vers 288909/98-14-6 vers 288907/98-14-6 vers 288907/98-14-6 vers 288909/98-14-6 vers 288909',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['288909', 'Paurière_1.xlsx', 'BS6', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'NC', 'Non', 'NON',
#              'P-TF303G- 72F-80 vers 288908/P-TF303G- 72F-80 vers 288910/98-14-6 vers 288908/98-14-6 vers 288908/98-14-6 vers 288910/98-14-6 vers 288910',
#              'INSUFFISANT', 'BS6', 'NC', 'BH6 S30', 'Non', 'OK', ''],
#             ['288910', 'Paurière_1.xlsx', 'BM6', 'OUI', 'NON', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NON',
#              'NC', 'Non', 'NON',
#              'P-TF303G- 72F-80 vers 288909/P-TF303G- 72F-80 vers 288911/98-14-6 vers 288909/98-14-6 vers 288909/98-14-6 vers 288911/98-14-6 vers 288911',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['288911', 'Paurière_1.xlsx', 'MI7 ', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'NC', 'Non', 'NON',
#              'P-TF303G- 72F-80 vers 288910/P-TF303G- 72F-80 vers 288912/98-14-6 vers 288910/98-14-6 vers 288910/98-14-6 vers 288912/98-14-6 vers 288912',
#              'INSUFFISANT', 'MI7 ', 'NC', 'MH7 S30', 'Non', 'OK', ''],
#             ['288912', 'Paurière_1.xlsx', 'BS6', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'NC', 'Non', 'NON',
#              'P-TF303G- 72F-80 vers 288911/P-TF303G- 72F-80 vers 288913/98-14-6 vers 288911/98-14-6 vers 288911/98-14-6 vers 288913/98-14-6 vers 288913',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['288913', 'Paurière_1.xlsx', 'BS6', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'NC', 'Non', 'NON',
#              'P-TF303G- 72F-80 vers 288912/P-TF303G- 72F-80 vers 288914/98-14-6 vers 288912/98-14-6 vers 288912/98-14-6 vers 288914/98-14-6 vers 288914',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['288914', 'Paurière_1.xlsx', 'BS7', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'NC', 'Non', 'NON',
#              'P-TF303G- 72F-80 vers 288913/P-TF303G- 72F-80 vers 288915/98-14-6 vers 288913/98-14-6 vers 288913/98-14-6 vers 288915/98-14-6 vers 288915',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['288915', 'Paurière_1.xlsx', 'BH6 S45', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'NC', 'Non', 'NC',
#              'P-TF303G- 72F-80 vers 288914/P-TF303G- 72F-80 vers 288916/98-14-6 vers 288914/98-14-6 vers 288914/98-14-6 vers 288916/98-14-6 vers 288916',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['288916', 'Paurière_2.xlsx', 'BH8 S30', 'OUI', 'OUI', 'OUI', 'NON', 'OUI', 'OUI', 'OUI', 'OUI', 'NON',
#              'NC', 'HTP', 'NON',
#              'P-TF303G- 72F-80 vers 288915/P-TF303G- 72F-80 vers 288917/98-14-6 vers 288915/98-14-6 vers 288915/98-14-6 vers 288917/98-14-6 vers 288917',
#              'OKOK', '', 'NC', 'SO', 'Non', 'OK', ''],
#             ['288917', 'Paurière_2.xlsx', 'BS6', 'NC', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NON', 'NC',
#              'Non', 'NON',
#              'P-TF303G- 72F-80 vers 288916/P-TF303G- 72F-80 vers 288918/98-14-6 vers 288916/98-14-6 vers 288916/98-14-6 vers 288918/98-14-6 vers 288918',
#              'OK', 'BS6', 'NC', 'BM7', 'PB', 'OK', 'AUT : Autre'],
#             ['288918', 'Paurière_2.xlsx', 'BS6', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'NC', 'Non', 'NON',
#              'P-TF303G- 72F-80 vers 288917/P-TF303G- 72F-80 vers 288919/98-14-6 vers 288917/98-14-6 vers 288917/98-14-6 vers 288919/98-14-6 vers 288919',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['288919', 'Paurière_2.xlsx', 'BM7', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'NC', 'Non', 'NON',
#              'P-TF303G- 72F-80 vers 288918/P-TF303G- 72F-80 vers 288920/98-14-6 vers 288918/98-14-6 vers 288918/98-14-6 vers 288920',
#              'OK', '', 'NC', 'SO', 'PB', '', ''],
#             ['288920', 'Paurière_2.xlsx', 'BS7', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'NC', 'Non', 'NON',
#              'P-TF303G- 72F-80 vers 288919/P-TF303G- 72F-80 vers 288921/98-14-6 vers 288919/98-14-6 vers 288921',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['288921', 'Paurière_2.xlsx', 'BM7', 'NC', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NON', 'NC',
#              'Non', 'NON',
#              'P-TF303G- 72F-80 vers 288920/P-TF303G- 72F-80 vers FT0030/98-14-6 vers 288920/98-14-6 vers FT0030',
#              'INSUFFISANT', 'BM7', 'NC', 'M47', 'PB', 'OK', 'AUT : Autre'],
#             ['FT0030', 'Paurière_2.xlsx', 'POT MIN', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'NC', 'Non', 'NON',
#              'P-TF303G- 72F-80 vers 288921/P-TF303G- 72F-80 vers FT0029/98-14-6 vers 288921/98-14-6 vers FT0029',
#              '', '', 'NC', 'SO', 'Non', '', ''],
#             ['FT0029', 'Paurière_2.xlsx', 'POT MIN', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'NC', 'Non', 'NON',
#              'P-TF303G- 72F-80 vers FT0030/P-TF303G- 72F-80 vers 288922/98-14-6 vers FT0030/98-14-6 vers 288922',
#              '', '', 'NC', 'SO', 'Non', '', ''],
#             ['288922', 'Paurière_2.xlsx', 'BM7', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'NC', 'Non', 'NON',
#              'P-TF303G- 72F-80 vers FT0029/P-TF303G- 72F-80 vers BT0889/98-14-6 vers FT0029/98-14-6 vers BT0889',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['BT0889', 'Paurière_2.xlsx', 'EDF', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'NC', 'Non', 'NON', 'P-TF303G- 72F-80 vers 288922/98-14-6 vers 288922', '', '', 'NC', 'SO', 'PB', '',
#              ''],
#             ['BT0871', 'Paurière_3.xlsx', 'EDF', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'NC', 'Non', 'NON', 'A-N8227A-24F-70 vers 288927/98-8-4 vers 288927', 'OK', '', 'NC', 'SO', '', 'OK',
#              ''],
#             ['288927', 'Paurière_3.xlsx', 'BS6', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'NC', 'Non', 'NON',
#              'A-N8227A-24F-70 vers BT0871/A-N8227A-24F-70 vers BT0875/98-8-4 vers BT0871/98-8-4 vers BT0875', 'OK',
#              '', 'NC', 'SO', 'Non', '', ''],
#             ['BT0875', 'Paurière_3.xlsx', 'EDF', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'NC', 'Non', 'NON', 'A-N8227A-24F-70 vers 288927/98-8-4 vers 288927', '', '', 'NC', 'SO', '', '', ''],
#             ['289062', 'Perriers_1.xlsx', 'BC6 ANC', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'NC', 'Non', 'NON', 'A-N9923A-12F-70 vers 236432/P-TF303G-288F-80 vers 236432/98-8-6 vers 236432',
#              'OKOK', '', 'NC', 'SO', 'Non', 'OK', ''],
#             ['236432', 'Perriers_1.xlsx', 'MI8 ', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'NC', 'Non', 'NC',
#              'A-N9923A-12F-70 vers 289062/A-N9923A-12F-70 vers 236431/P-TF303G-288F-80 vers 289062/P-TF303G-288F-80 vers 236431/98-8-6 vers 289062/98-8-6 vers 236431',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['236431', 'Perriers_1.xlsx', 'MI8 ', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'NC', 'Non', 'NC',
#              'A-N9923A-12F-70 vers 236432/A-N9923A-12F-70 vers 289063/P-TF303G-288F-80 vers 236432/P-TF303G-288F-80 vers 289063/98-8-6     vers 236432/98-8-6     vers 289063',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['289063', 'Perriers_1.xlsx', 'MS8 ', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'NC', 'Non', 'NON',
#              'A-N9923A-12F-70 vers 236431/A-N9923A-12F-70 vers 421201/P-TF303G-288F-80 vers 236431/P-TF303G-288F-80 vers 421201/98-8-6     vers 236431/Liaison vers 421201',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['421201', 'Perriers_1.xlsx', 'MS8 ', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'NC', 'Non', 'NC',
#              'A-N9923A-12F-70 vers 289063/A-N9923A-12F-70 vers BT0504/P-TF303G-288F-80 vers 289063/P-TF303G-288F-80 vers BT0504/Liaison vers 289063/Liaison vers BT0504',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['BT0504', 'Perriers_1.xlsx', 'EDF', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'NC', 'Non', 'NON', 'A-N9923A-12F-70 vers 421201/P-TF303G-288F-80 vers 421201/Liaison vers 421201', '',
#              '', 'NC', 'SO', 'PB', '', ''],
#             ['BT0422', 'Perriers_2.xlsx', 'EDF', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'NC', 'Non', 'NON', 'P-TF303G-288F-80 vers 289065/Liaison vers 289065', 'OK', '', 'NC', 'SO', '', 'OK',
#              ''],
#             ['289065', 'Perriers_2.xlsx', 'MS8 ', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'NC', 'Non', 'NC',
#              'P-TF303G-288F-80 vers BT0422/P-TF303G-288F-80 vers 289066/Liaison vers BT0422/Liaison vers 289066',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['289066', 'Perriers_2.xlsx', 'MS8 ', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'NC', 'Non', 'NON',
#              'P-TF303G-288F-80 vers 289065/P-TF303G-288F-80 vers AC6001/Liaison vers 289065/Liaison vers AC6001',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['AC6001', 'Perriers_2.xlsx', 'BS8', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'NC', 'Non', 'NON', 'P-TF303G-288F-80 vers 289066/Liaison vers 289066', '', '', 'NC', 'SO', '', '',
#              ''],
#             ['288884', 'Plaine des Pins.xlsx', 'BH8 S30', 'NC', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'NON', 'NC', 'Non', 'NC',
#              'A-N8227A-24F-70 vers 288886/A-N8227A-24F-70 vers 288883/A-N9923A-12F-70 vers 288885/98-14-6 vers 288886/Liaison vers 288885/98-14-6 vers 288883',
#              'OKOK', 'BH8 S30', 'NC', 'MH8 S30', 'PB', 'OKOK', 'FEN : Fendu'],
#             ['288883', 'Plaine des Pins.xlsx', 'BS8', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'NC', 'Non', 'NC',
#              'A-N8227A-24F-70 vers 288884/A-N8227A-24F-70 vers 288882/98-14-6 vers 288884/98-14-6 vers 288882',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['288882', 'Plaine des Pins.xlsx', 'BS8', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NON',
#              'NC', 'Non', 'NC',
#              'A-N8227A-24F-70 vers 288883/A-N8227A-24F-70 vers BT0565/98-14-6 vers 288883/98-14-6 vers BT0565',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['BT0565', 'Plaine des Pins.xlsx', 'EDF', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'NC', 'Non', 'NON',
#              'A-N8227A-24F-70 vers 288882/A-N8227A-24F-70 vers 288881/98-14-6 vers 288882/98-14-6 vers 288881', '',
#              '', 'NC', 'SO', '', '', ''],
#             ['288881', 'Plaine des Pins.xlsx', '197.0', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NC',
#              'A-N8227A-24F-70 vers BT0565/A-N8227A-24F-70 vers BT0566/98-14-6 vers BT0565/98-14-6 vers BT0566',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['BT0566', 'Plaine des Pins.xlsx', 'EDF', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'NC', 'Non', 'NON',
#              'A-N8227A-24F-70 vers 288881/A-N8227A-24F-70 vers 288880/98-14-6 vers 288881/98-14-6 vers 288880', '',
#              '', 'NC', 'SO', '', '', ''],
#             ['288880', 'Plaine des Pins.xlsx', 'BS8', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'NC', 'Non', 'NC',
#              'A-N8227A-24F-70 vers BT0566/A-N8227A-24F-70 vers 288879/98-14-6 vers BT0566/98-14-6 vers 288879',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['288879', 'Plaine des Pins.xlsx', 'BC8 ', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NC',
#              'A-N8227A-24F-70 vers 288880/P-TF303G- 72F-80 vers 288878/P-TF303G- 72F-80 vers 288901/98-14-6 vers 288880/98-14-6 vers 288901/98-14-6 vers 288901/98-14-6 vers 288878/98-14-6 vers 288878',
#              'OK', '', 'NC', 'SO', 'PB', '', ''],
#             ['288885', 'Plaine des Pins.xlsx', 'BS8', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'NC', 'Non', 'NON', 'A-N9923A-12F-70 vers 288884/Liaison vers 288884', 'OK', '', 'NC', 'SO', 'PB', '',
#              ''],
#             ['BT0744', 'Pomeyras.xlsx', 'EDF', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NC',
#              'Non', 'NON', 'A-N8228A-36F-70 vers 288673/98-8-6 vers 288673', 'OK', '', 'NC', 'SO', 'PB', 'OK', ''],
#             ['288673', 'Pomeyras.xlsx', 'BS8', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NC',
#              'Non', 'NC',
#              'A-N8228A-36F-70 vers BT0744/A-N8228A-36F-70 vers BT0743/98-8-6 vers BT0744/98-8-6 vers FT0949/Liaison vers BT0743',
#              'INSUFFISANT', 'BS8', 'NC', 'MI8 ', 'PB', 'OK', ''],
#             ['BT0743', 'Pomeyras.xlsx', 'EDF', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NC',
#              'Non', 'NON', 'A-N8228A-36F-70 vers 288673/Liaison vers 288673', '', '', 'NC', 'SO', '', '', ''],
#             ['021718', 'QUARTIER BAYNES.xlsx', 'BS8', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'NC', 'Non', 'NON',
#              'P-TF303G- 24F-80 vers 021719/P-TF303G- 24F-80 vers 0021717/98-8-6 vers 021719/98-8-6 vers 0021717',
#              'OKOK', '', 'NC', 'SO', '', 'OK', ''],
#             ['021719', 'QUARTIER BAYNES.xlsx', 'BS7', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'NC', 'Non', 'NON',
#              'P-TF303G- 24F-80 vers 021718/P-TF303G- 24F-80 vers 021720/98-8-6 vers 021718/98-8-6 vers 021720',
#              'OK', '', 'NC', 'SO', '', '', ''],
#             ['021720', 'QUARTIER BAYNES.xlsx', 'BH8 S30', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G- 24F-80 vers 021719/P-TF303G- 24F-80 vers 021721/98-8-6 vers 021719/98-8-6 vers 021721',
#              'OK', '', 'NC', 'SO', '', '', ''],
#             ['021721', 'QUARTIER BAYNES.xlsx', 'MI8', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'NC', 'Non', 'NON',
#              'P-TF303G- 24F-80 vers 021720/P-TF303G- 24F-80 vers 021722/98-8-6 vers 021720/98-8-6 vers 021722',
#              'OK', '', 'NC', 'SO', '', '', ''],
#             ['021722', 'QUARTIER BAYNES.xlsx', 'BS8', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'NC', 'Non', 'NON',
#              'P-TF303G- 24F-80 vers 021721/P-TF303G- 24F-80 vers 021723/98-8-6 vers 021721/98-8-6 vers 021723',
#              'OK', '', 'NC', 'SO', '', '', ''],
#             ['021723', 'QUARTIER BAYNES.xlsx', 'MH7 S30', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G- 24F-80 vers 021722/P-TF303G- 24F-80 vers 021724/98-8-6 vers 021722/98-8-6 vers 021724',
#              'OK', '', 'NC', 'SO', '', '', ''],
#             ['021724', 'QUARTIER BAYNES.xlsx', 'BS7', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'NC', 'Non', 'NON',
#              'P-TF303G- 24F-80 vers 021723/P-TF303G- 24F-80 vers 021725/98-8-6 vers 021723/98-8-6 vers 021725',
#              'OK', '', 'NC', 'SO', '', '', ''],
#             ['021725', 'QUARTIER BAYNES.xlsx', 'BS7', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'NC', 'Non', 'NON',
#              'P-TF303G- 24F-80 vers 021724/P-TF303G- 24F-80 vers 021726/98-8-6 vers 021724/98-8-6 vers 021726',
#              'OK', '', 'NC', 'SO', '', '', ''],
#             ['021726', 'QUARTIER BAYNES.xlsx', 'BS8', 'NON', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NON', 'NON',
#              'NC', 'Non', 'NON',
#              'P-TF303G- 24F-80 vers 021725/P-TF303G- 24F-80 vers 021727/98-8-6 vers 021725/98-8-6 vers 021727',
#              'OK', 'BS8', 'NC', 'FR8', '', 'OK', ''],
#             ['021727', 'QUARTIER BAYNES.xlsx', 'BS8', 'NC', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NON',
#              'NC', 'Non', 'NON',
#              'P-TF303G- 24F-80 vers 021726/P-TF303G- 24F-80 vers 021728/98-8-6 vers 021726/98-8-6 vers 021728',
#              'OK', 'BS8', 'NC', 'MI8 ', 'Non', 'OK', ''],
#             ['021728', 'QUARTIER BAYNES.xlsx', '198.0', 'NC', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NON', 'NON',
#              'NON', 'NC', 'Non', 'NON',
#              'P-TF303G- 24F-80 vers 021727/P-TF303G- 24F-80 vers 021729/98-8-6 vers 021727/98-8-6 vers 021729',
#              'OK', '198.0', 'NC', 'MI8 ', 'Non', 'OK', ''],
#             ['021729', 'QUARTIER BAYNES.xlsx', 'BS8', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'NC', 'Non', 'NON',
#              'P-TF303G- 24F-80 vers 021728/P-TF303G- 24F-80 vers 021730/98-8-6 vers 021728/98-8-6 vers 021730',
#              'OK', '', 'NC', 'SO', '', '', ''],
#             ['021730', 'QUARTIER BAYNES.xlsx', 'BS8', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'NC', 'Non', 'NON',
#              'P-TF303G- 24F-80 vers 021729/P-TF303G- 24F-80 vers 021731/98-8-6 vers 021729/98-8-6 vers 021731',
#              'OK', '', 'NC', 'SO', '', '', ''],
#             ['021731', 'QUARTIER BAYNES.xlsx', 'BS8', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NON',
#              'NC', 'Non', 'NON',
#              'P-TF303G- 24F-80 vers 021730/P-TF303G- 24F-80 vers 021732/98-8-6 vers 021730/98-8-6 vers 021732',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['021732', 'QUARTIER BAYNES.xlsx', 'BS8', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'NC', 'Non', 'NON',
#              'P-TF303G- 24F-80 vers 021731/P-TF303G- 24F-80 vers 021733/98-8-6 vers 021731/98-8-6 vers 021733',
#              'OK', '', 'NC', 'SO', '', '', ''],
#             ['021733', 'QUARTIER BAYNES.xlsx', 'BH8 S30', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G- 24F-80 vers 021732/P-TF303G- 24F-80 vers 021734/98-8-6 vers 021732/98-8-6 vers 021734',
#              'OK', '', 'NC', 'SO', '', '', ''],
#             ['021734', 'QUARTIER BAYNES.xlsx', 'BH8 S30', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G- 24F-80 vers 021733/P-TF303G- 24F-80 vers 021735/98-8-6 vers 021733/98-8-6 vers 021735',
#              'OK', '', 'NC', 'SO', '', '', ''],
#             ['021735', 'QUARTIER BAYNES.xlsx', 'BS8', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'NC', 'Non', 'NON',
#              'P-TF303G- 24F-80 vers 021734/P-TF303G- 24F-80 vers 021736/98-8-6 vers 021734/98-8-6 vers 021736',
#              'OK', '', 'NC', 'SO', '', '', ''],
#             ['021736', 'QUARTIER BAYNES.xlsx', 'BH8 S30', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G- 24F-80 vers 021735/P-TF303G- 24F-80 vers 021737/98-8-6 vers 021735/98-8-6 vers 021737',
#              'OK', '', 'NC', 'SO', '', '', ''],
#             ['021737', 'QUARTIER BAYNES.xlsx', 'BS8', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'NC', 'Non', 'NON',
#              'P-TF303G- 24F-80 vers 021736/P-TF303G- 24F-80 vers 021738/98-8-6 vers 021736/98-8-6 vers 021738',
#              'OK', '', 'NC', 'SO', '', '', ''],
#             ['021738', 'QUARTIER BAYNES.xlsx', 'BH8 S30', 'NON', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'NON', 'NC', 'Non', 'NON',
#              'P-TF303G- 24F-80 vers 021737/P-TF303G- 24F-80 vers 021739/98-8-6 vers 021737/98-8-6 vers 021739',
#              'OK', '', 'NC', 'SO', '', '', ''],
#             ['021739', 'QUARTIER BAYNES.xlsx', 'BS8', 'NC', 'NON', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NON', 'NON',
#              'NC', 'Non', 'NON',
#              'P-TF303G- 24F-80 vers 021738/P-TF303G- 24F-80 vers 0421085/98-8-6 vers 021738/98-8-6 vers 0421085',
#              'OK', 'BS8', 'NC', 'MI8 ', 'Non', 'OK', ''],
#             ['0421085', 'QUARTIER BAYNES.xlsx', 'BS8', 'NON', 'OUI', 'NON', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'NON', 'NC', 'Non', 'NON',
#              'P-TF303G- 24F-80 vers 021739/P-TF303G- 24F-80 vers 021741/98-8-6 vers 021739/98-8-6 vers 021741',
#              'OK', 'BS8', 'NC', 'MI8 ', '', 'OK', ''],
#             ['021741', 'QUARTIER BAYNES.xlsx', 'BS8', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'NC', 'Non', 'NON',
#              'P-TF303G- 24F-80 vers 0421085/P-TF303G- 24F-80 vers 021742/98-8-6 vers 0421085/98-8-6 vers 021742',
#              'OK', '', 'NC', 'SO', '', '', ''],
#             ['021742', 'QUARTIER BAYNES.xlsx', 'MH8 S30', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G- 24F-80 vers 021741/P-TF303G- 24F-80 vers 021743/98-8-6 vers 021741/98-8-6 vers 021743',
#              'OK', '', 'NC', 'SO', '', '', ''],
#             ['021743', 'QUARTIER BAYNES.xlsx', 'BS8', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'NC', 'Non', 'NON',
#              'P-TF303G- 24F-80 vers 021742/P-TF303G- 24F-80 vers 021744/98-8-6 vers 021742/98-8-6 vers 021744',
#              'OK', '', 'NC', 'SO', '', '', ''],
#             ['021744', 'QUARTIER BAYNES.xlsx', 'BS7', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'NC', 'Non', 'NON',
#              'P-TF303G- 24F-80 vers 021743/P-TF303G- 24F-80 vers 021745/98-8-6 vers 021743/98-8-6 vers 021745',
#              'OK', '', 'NC', 'SO', '', '', ''],
#             ['021745', 'QUARTIER BAYNES.xlsx', 'BH7 S30', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'NON', 'NC', 'Non', 'NON',
#              'P-TF303G- 24F-80 vers 021744/P-TF303G- 24F-80 vers 021746/98-8-6 vers 021744/98-8-6 vers 021746',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['021746', 'QUARTIER BAYNES.xlsx', 'BH8 S30', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G- 24F-80 vers 021745/P-TF303G- 24F-80 vers 021747/98-8-6 vers 021745/98-8-6 vers 021747',
#              'OK', '', 'NC', 'SO', '', '', ''],
#             ['021747', 'QUARTIER BAYNES.xlsx', 'BH8 S30', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G- 24F-80 vers 021746/P-TF303G- 24F-80 vers 021748/98-8-6 vers 021746/98-8-6 vers 021748',
#              'OK', '', 'NC', 'SO', '', '', ''],
#             ['021748', 'QUARTIER BAYNES.xlsx', 'BH8 S45', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G- 24F-80 vers 021747/P-TF303G- 24F-80 vers 0421082/98-8-6 vers 021747/98-8-6 vers 0421082',
#              'OK', '', 'NC', 'SO', '', '', ''],
#             ['0421082', 'QUARTIER BAYNES.xlsx', 'BS6', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G- 24F-80 vers 021748/P-TF303G- 24F-80 vers 421083/98-8-6 vers 021748/98-8-6 vers 421083',
#              'OK', '', 'NC', 'SO', '', '', ''],
#             ['421083', 'QUARTIER BAYNES.xlsx', 'BS8', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'NC', 'Non', 'NON',
#              'P-TF303G- 24F-80 vers 0421082/P-TF303G- 24F-80 vers 0421084/98-8-6 vers 0421082/98-8-6 vers 0421084',
#              'OK', '', 'NC', 'SO', '', '', ''],
#             ['0421084', 'QUARTIER BAYNES.xlsx', 'BS8', 'NC', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NON', 'NON',
#              'NC', 'Non', 'NON',
#              'P-TF303G- 24F-80 vers 421083/P-TF303G- 24F-80 vers 021752/98-8-6     vers 421083/98-8-6     vers 021752',
#              'OK', 'BS8', 'NC', 'FR8', 'Non', 'OK', ''],
#             ['021752', 'QUARTIER BAYNES.xlsx', 'BC7 ', 'NC', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NON', 'NON',
#              'NC', 'Non', 'NON',
#              'P-TF303G- 24F-80 vers 0421084/P-TF303G- 24F-80 vers 021753/98-8-6     vers 0421084/Liaison vers 021753/Liaison vers FT0469/Liaison vers BT0251',
#              'OK', '', 'NC', 'SO', 'PB', '', ''],
#             ['021753', 'QUARTIER BAYNES.xlsx', 'BS8', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'NC', 'Non', 'NON', 'P-TF303G- 24F-80 vers 021752/Liaison vers 021752/Liaison vers 021754', 'OK', '',
#              'NC', 'SO', 'PB', '', ''],
#             ['BT0827', 'Quartier Beauregard.xlsx', 'EDF', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON', 'A-N8228A-36F-70 vers 288731/98-8-4 vers 288731', 'OK', '', 'NC', 'SO', '',
#              'OK', ''],
#             ['288731', 'Quartier Beauregard.xlsx', 'BM6', 'NC', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NON',
#              'NON', 'NC', 'Non', 'NON',
#              'A-N8228A-36F-70 vers BT0827/A-N8228A-36F-70 vers 288730/98-8-4 vers BT0827/98-8-4 vers 288730', 'OK',
#              'BM6', 'NC', 'BM7', 'Non', 'OK', 'AUT : Autre'],
#             ['288730', 'Quartier Beauregard.xlsx', '197.0', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'A-N8228A-36F-70 vers 288731/A-N8228A-36F-70 vers 288729/98-8-4 vers 288731/98-8-4 vers 288729', 'OK',
#              '', 'NC', 'SO', 'Non', '', ''],
#             ['288729', 'Quartier Beauregard.xlsx', 'BR8 ', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'A-N8228A-36F-70 vers 288730/A-N8228A-36F-70 vers 288728/98-8-4 vers 288730/98-8-4 vers 288728', 'OK',
#              '', 'NC', 'SO', 'PB', '', ''],
#             ['288728', 'Quartier Beauregard.xlsx', 'BH6 S45', 'OUI', 'NON', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NON', 'NC', 'Non', 'NC',
#              'A-N8228A-36F-70 vers 288729/A-N8228A-36F-70 vers 288727/98-8-4 vers 288729/98-8-4 vers 288727', 'OK',
#              '', 'NC', 'SO', 'PB', '', 'Recalage'],
#             ['288727', 'Quartier Beauregard.xlsx', 'BC7 ANC', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'OUI', 'NC', 'Non', 'NON',
#              'A-N8228A-36F-70 vers 288728/A-N8228A-36F-70 vers BT0822/98-8-4 vers 288728/98-14-6 vers BT0822', 'OK',
#              '', 'NC', 'SO', 'PB', '', ''],
#             ['BT0822', 'Quartier Beauregard.xlsx', 'EDF', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'A-N8228A-36F-70 vers 288727/A-N8228A-36F-70 vers 288726/98-14-6 vers 288727/98-14-6 vers 288726', '',
#              '', 'NC', 'SO', '', '', ''],
#             ['288726', 'Quartier Beauregard.xlsx', 'BM7', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'A-N8228A-36F-70 vers BT0822/A-N8228A-36F-70 vers 288725/98-14-6 vers BT0822/98-14-6 vers 288725',
#              'OK', '', 'NC', 'SO', 'PB', '', ''],
#             ['288725', 'Quartier Beauregard.xlsx', 'MI6 ', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NC',
#              'A-N8228A-36F-70 vers 288726/A-N8228A-36F-70 vers 195332/98-14-6 vers 288726/98-14-6 vers 195332',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['195332', 'Quartier Beauregard.xlsx', 'BH7 S45', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'OUI', 'NC', 'Non', 'NC',
#              'A-N8228A-36F-70 vers 288725/A-N8228A-36F-70 vers 288724/98-14-6 vers 288725/98-14-6 vers 288724',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['288724', 'Quartier Beauregard.xlsx', 'BR8 ', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'A-N8228A-36F-70 vers 195332/A-N8228A-36F-70 vers 288723/98-14-6 vers 195332/98-14-6 vers 288723',
#              'OK', 'BR8 ', 'NC', 'BM8', 'PB', 'OK', 'Rehausse existante '],
#             ['288723', 'Quartier Beauregard.xlsx', 'BC8 ', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'A-N8228A-36F-70 vers 288724/A-N8228A-36F-70 vers 288732/98-14-6 vers 288724/98-28-4 vers AC0002/98-28-4 vers 288732',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['288732', 'Quartier Beauregard.xlsx', 'BS8', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NC',
#              'A-N8228A-36F-70 vers 288723/A-N8228A-36F-70 vers 288733/98-28-4 vers 288723/98-28-4 vers 288733',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['288733', 'Quartier Beauregard.xlsx', 'BS8', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NC',
#              'A-N8228A-36F-70 vers 288732/A-N8228A-36F-70 vers 288734/98-28-4 vers 288732/98-28-4 vers 288734',
#              'INSUFFISANT', 'BS8', 'NC', 'M48', 'Non', 'OK', ''],
#             ['288734', 'Quartier Beauregard.xlsx', 'BS8', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'A-N8228A-36F-70 vers 288733/A-N8228A-36F-70 vers 288735/98-28-4 vers 288733/98-28-4 vers 288735',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['288735', 'Quartier Beauregard.xlsx', 'BS8', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NC',
#              'A-N8228A-36F-70 vers 288734/A-N8228A-36F-70 vers 288736/98-28-4 vers 288734/98-28-4 vers 288736',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['288736', 'Quartier Beauregard.xlsx', 'BS8', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NC',
#              'A-N8228A-36F-70 vers 288735/A-N8228A-36F-70 vers 288737/98-28-4 vers 288735/98-28-4 vers 288737',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['288737', 'Quartier Beauregard.xlsx', 'BC8 ', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'A-N8228A-36F-70 vers 288736/P-TF303G- 96F-80 vers 680907/P-TF303G- 96F-80 vers 288738/98-28-4 vers 288736/98-28-4 vers 288738/Liaison vers 680907',
#              'OK', '', 'NC', 'SO', 'PB', '', ''],
#             ['680907', 'Quartier Beauregard.xlsx', 'MI8 ', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G- 96F-80 vers 288737/P-TF303G- 96F-80 vers 680906/Liaison vers 288737/Liaison vers 680906',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['680906', 'Quartier Beauregard.xlsx', 'MI8 ', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G- 96F-80 vers 680907/P-TF303G- 96F-80 vers 680905/Liaison vers 680907/Liaison vers 680905',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['680905', 'Quartier Beauregard.xlsx', 'MI8 ', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G- 96F-80 vers 680906/P-TF303G- 96F-80 vers AC0001/Liaison vers 680906/Liaison vers AC0001',
#              'OK', '', 'NC', 'SO', 'PB', '', ''],
#             ['0421077', 'QUARTIER BERINGEAS.xlsx', 'BS7', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G- 24F-80 vers BT0257/P-TF303G- 24F-80 vers BT0390/98-8-6     vers BT0257/98-8-6     vers BT0390',
#              'OKINSUFFISANT', 'BS7', 'NC', 'FR7', 'Non', 'OKOK', ''],
#             ['BT0847', 'Quartier Couijanet.xlsx', 'EDF', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON', 'A-N8227A-24F-70 vers 234302/98-8-6 vers 234302', 'OK', '', 'NC', 'SO',
#              'PB', 'OK', ''],
#             ['234302', 'Quartier Couijanet.xlsx', 'BM8', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NC',
#              'A-N8227A-24F-70 vers BT0847/A-N8227A-24F-70 vers 234301/98-8-6 vers BT0847/98-8-6 vers 234301', 'OK',
#              '', 'NC', 'SO', 'Non', '', ''],
#             ['234301', 'Quartier Couijanet.xlsx', 'BH8 S30', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'A-N8227A-24F-70 vers 234302/A-N8227A-24F-70 vers 421073/98-8-6 vers 234302/98-8-6 vers 421073', 'OK',
#              '', 'NC', 'SO', 'PB', '', ''],
#             ['421073', 'Quartier Couijanet.xlsx', 'BS7', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'A-N8227A-24F-70 vers 234301/A-N8227A-24F-70 vers BT0840/98-8-6 vers 234301/98-8-6 vers BT0840',
#              'INSUFFISANT', 'BS7', 'NC', 'BH7 S30', 'Non', 'OK', ''],
#             ['BT0840', 'Quartier Couijanet.xlsx', 'EDF', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON', 'A-N8227A-24F-70 vers 421073/98-8-6 vers 421073', '', '', 'NC', 'SO', '',
#              '', ''],
#             ['BT0843', 'Quartier Couijanet_2.xlsx', 'EDF', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G- 96F-80 vers 680908/A-N8227A-24F-70 vers 680908/98-28-6 vers 680908', 'OK', '', 'NC', 'SO',
#              'Non', 'OK', ''],
#             ['680908', 'Quartier Couijanet_2.xlsx', 'MI8 ', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G- 96F-80 vers BT0843/P-TF303G- 96F-80 vers 288748/A-N8227A-24F-70 vers BT0843/A-N8227A-24F-70 vers BT0842/98-28-6 vers BT0843/98-28-6 vers 248749/Liaison vers BT0842/Liaison vers 288748',
#              'INSUFFISANT', 'MI8 ', 'NC', 'M48', 'PB', 'OK', ''],
#             ['288748', 'Quartier Couijanet_2.xlsx', 'MI7 ', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G- 96F-80 vers 680908/P-TF303G- 96F-80 vers 288747/Liaison vers 680908/98-28-6 vers 248749/98-14-6 vers 288747/98-8-6 vers 288747',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['288747', 'Quartier Couijanet_2.xlsx', 'BS6', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G- 96F-80 vers 288748/P-TF303G- 96F-80 vers 288746/98-14-6 vers 288748/98-8-6 vers 288748/98-14-6 vers 288746/98-8-6 vers 288746',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['288746', 'Quartier Couijanet_2.xlsx', 'BS7', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G- 96F-80 vers 288747/P-TF303G- 96F-80 vers 288745/98-14-6 vers 288747/98-8-6 vers 288747/98-14-6 vers 288745/98-8-6 vers 288745',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['288745', 'Quartier Couijanet_2.xlsx', 'BS8', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G- 96F-80 vers 288746/P-TF303G- 96F-80 vers 288744/98-14-6 vers 288746/98-8-6 vers 288746/98-28-4 vers 288744',
#              'OK', '', 'NC', 'SO', 'PB', '', ''],
#             ['288744', 'Quartier Couijanet_2.xlsx', 'BM7', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G- 96F-80 vers 288745/P-TF303G- 96F-80 vers 21317/98-28-4 vers 288745/98-28-4 vers 21317',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['21317', 'Quartier Couijanet_2.xlsx', 'BM7', 'OUI', 'NON', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'NON', 'NC', 'Non', 'NON',
#              'P-TF303G- 96F-80 vers 288744/P-TF303G- 96F-80 vers 21318/98-28-4 vers 288744/98-28-4 vers 21318',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['21318', 'Quartier Couijanet_2.xlsx', 'BC7 ', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NC',
#              'P-TF303G- 96F-80 vers 21317/P-TF303G- 96F-80 vers 288743/98-28-4 vers 21317/98-28-4 vers 288743',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['288743', 'Quartier Couijanet_2.xlsx', 'BC6 ', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G- 96F-80 vers 21318/P-TF303G- 96F-80 vers 288742/98-28-4 vers 21318/98-28-4 vers 288742',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['288742', 'Quartier Couijanet_2.xlsx', 'BC6 ', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G- 96F-80 vers 288743/P-TF303G- 96F-80 vers 288741/98-28-4 vers 288743/98-28-4 vers 288741',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['288741', 'Quartier Couijanet_2.xlsx', 'BH7 S30', 'NC', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NON', 'NC', 'Non', 'NC',
#              'P-TF303G- 96F-80 vers 288742/P-TF303G- 96F-80 vers 288740/98-28-4 vers 288742/98-28-4 vers 288740',
#              'OK', 'BH7 S30', 'NC', 'MH7 S30', 'Non', 'OK', 'AUT : Autre\r\nCAS : Cassé'],
#             ['288740', 'Quartier Couijanet_2.xlsx', 'BM8', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G- 96F-80 vers 288741/P-TF303G- 96F-80 vers 288739/98-28-4 vers 288741/98-28-4 vers 288739',
#              'OK', '', 'NC', 'SO', 'PB', '', ''],
#             ['288739', 'Quartier Couijanet_2.xlsx', 'BH8 S30', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G- 96F-80 vers 288740/P-TF303G- 96F-80 vers 288738/98-28-4 vers 288740/98-28-4 vers 288738',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['288738', 'Quartier Couijanet_2.xlsx', 'BS7', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G- 96F-80 vers 288739/P-TF303G- 96F-80 vers 288737/98-28-4 vers 288739/98-28-4 vers 288737',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['BT0780', 'Quartier Eymieux.xlsx', 'EDF', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON', 'A-N8228A-36F-70 vers 288677/Liaison vers 288677', 'OK', '', 'NC', 'SO', '',
#              'OK', ''],
#             ['288677', 'Quartier Eymieux.xlsx', 'MH7 S30', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'A-N8228A-36F-70 vers BT0780/A-N8228A-36F-70 vers 288639/Liaison vers BT0780/98-14-4 vers FT0961/98-8-4 vers FT0961/98-8-4 vers 288639/98-14-4 vers 288639',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['288639', 'Quartier Eymieux.xlsx', 'MC7 MIN', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NC',
#              'P-TF303G-288F-80 vers 288640/P-TF303G-288F-80 vers 288638/A-N8228A-36F-70 vers 288677/98-8-4 vers 288677/98-14-4 vers 288677/98-56-4 vers 288640/98-8-4 vers 288640/98-56-4 vers 288638/98-28-4 vers 288638/98-8-4 vers 288638',
#              'OK', '', 'NC', 'SO', 'PB', '', ''],
#             ['288638', 'Quartier Eymieux.xlsx', 'BS7', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G-288F-80 vers 288639/P-TF303G-288F-80 vers 288636/98-56-4 vers 288639/98-28-4 vers 288639/98-8-4 vers 288639/98-56-4 vers 288636/98-28-4 vers 288636/98-8-4 vers 288636',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['288636', 'Quartier Eymieux.xlsx', 'BM7', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NC',
#              'P-TF303G-288F-80 vers 288638/P-TF303G-288F-80 vers 288635/98-56-4 vers 288638/98-28-4 vers 288638/98-8-4 vers 288638/98-56-4 vers 288635/98-28-4 vers 288635/98-8-4 vers 288635',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['288635', 'Quartier Eymieux.xlsx', 'BM6', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NC',
#              'P-TF303G-288F-80 vers 288636/P-TF303G-288F-80 vers 288634/A-N9923A-12F-70 vers 288634/A-N8228A-36F-70 vers 288637/98-56-4 vers 288636/98-28-4 vers 288636/98-8-4 vers 288636/98-28-4 vers 288637/98-56-4 vers 288634/98-56-4 vers 288634',
#              'OK', '', 'NC', 'SO', 'PB', '', ''],
#             ['288634', 'Quartier Eymieux.xlsx', 'BS8', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G-288F-80 vers 288635/P-TF303G-288F-80 vers 288633/A-N9923A-12F-70 vers 288635/98-56-4 vers 288635/98-56-4 vers 288635/98-56-4 vers 288633/98-56-4 vers 288633',
#              'OK', '', 'NC', 'SO', 'PB', '', ''],
#             ['288633', 'Quartier Eymieux.xlsx', 'BM7', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NC',
#              'P-TF303G-288F-80 vers 288634/P-TF303G-288F-80 vers 288632/98-56-4 vers 288634/98-56-4 vers 288634/98-56-4 vers 288632/98-56-4 vers 288632',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['288632', 'Quartier Eymieux.xlsx', 'BS7', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G-288F-80 vers 288633/P-TF303G-288F-80 vers 288631/98-56-4 vers 288633/98-56-4 vers 288633/98-56-4 vers 288631/98-56-4 vers 288631',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['288631', 'Quartier Eymieux.xlsx', 'BS7', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G-288F-80 vers 288632/P-TF303G-288F-80 vers 288630/98-56-4 vers 288632/98-56-4 vers 288632/98-56-4 vers 288630/98-56-4 vers 288630',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['288630', 'Quartier Eymieux.xlsx', 'MI8 ', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G-288F-80 vers 288631/P-TF303G-288F-80 vers 288629/98-56-4 vers 288631/98-56-4 vers 288631/98-56-4 vers 288629/98-56-4 vers 288629/98-8-6 vers 288629',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['288629', 'Quartier Eymieux.xlsx', 'MI8 ', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G-288F-80 vers 288630/P-TF303G-288F-80 vers 288628/A-N8227A-24F-70 vers 288628/98-56-4 vers 288630/98-56-4 vers 288630/98-8-6 vers 288630/98-56-4 vers 288628/98-56-4 vers 288628/98-8-6 vers 288628',
#              'INSUFFISANT', 'MI8 ', 'NC', 'M48', 'PB', 'OK', ''],
#             ['288628', 'Quartier Eymieux.xlsx', '198.0', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NC',
#              'P-TF303G-288F-80 vers 288629/P-TF303G-288F-80 vers 288681/A-N8227A-24F-70 vers 288629/A-N8227A-24F-70 vers 288681/98-56-4 vers 288629/98-56-4 vers 288629/98-8-6 vers 288629/98-56-4 vers 288627/98-56-4 vers 288627/98-8-6 vers 288681',
#              'OK', '', 'NC', 'SO', 'PB', '', ''],
#             ['288681', 'Quartier Eymieux.xlsx', 'BS8', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NC',
#              'P-TF303G-288F-80 vers 288628/P-TF303G-288F-80 vers 288680/A-N8227A-24F-70 vers 288628/A-N8227A-24F-70 vers 288680/98-8-6 vers 288628/98-8-6 vers 288680',
#              'OK', '', 'NC', 'SO', 'Non', '', 'Elagage necessaire'],
#             ['288680', 'Quartier Eymieux.xlsx', 'BC8 ANC', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NC',
#              'P-TF303G-288F-80 vers 288681/P-TF303G-288F-80 vers BT0788/A-N9923A-12F-70 vers FT0967/A-N8227A-24F-70 vers 288681/98-8-6 vers 288681/Liaison vers FT0967/Liaison vers FT0966/98-14-6 vers BT0788',
#              'OK', '', 'NC', 'SO', 'PB', '', ''],
#             ['BT0788', 'Quartier Eymieux.xlsx', 'EDF', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON', 'P-TF303G-288F-80 vers 288680/98-14-6 vers 288680', '', '', 'NC', 'SO',
#              'PB', '', ''],
#             ['FT0967', 'Quartier Eymieux.xlsx', 'POT MIN', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'A-N9923A-12F-70 vers 288680/A-N9923A-12F-70 vers FT0966/Liaison vers 288680/Liaison vers FT0966', '',
#              '', 'NC', 'SO', 'Non', '', ''],
#             ['FT0966', 'Quartier Eymieux.xlsx', 'POT MIN', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON', 'A-N9923A-12F-70 vers FT0967/Liaison vers FT0966/Liaison vers 288680', '',
#              '', 'NC', 'SO', 'Non', '', ''],
#             ['288637', 'Quartier Eymieux.xlsx', 'BM7', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON', 'A-N8228A-36F-70 vers 288635/98-28-4 vers 288635', 'OK', '', 'NC', 'SO',
#              'Non', '', ''],
#             ['BT0644', 'Quartier Granges de Beauregard.xlsx', 'EDF', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'OUI', 'OUI', 'NC', 'Non', 'NON', 'A-N9923A-12F-70 vers 288832/98-8-4 vers 288832', 'OK', '',
#              'NC', 'SO', 'PB', 'OK', ''],
#             ['288832', 'Quartier Granges de Beauregard.xlsx', 'BH7 S30', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'OUI', 'OUI', 'NC', 'Non', 'NC',
#              'A-N9923A-12F-70 vers BT0644/A-N9923A-12F-70 vers 288831/98-8-4 vers BT0644/98-8-4 vers 288831', 'OK',
#              '', 'NC', 'SO', 'Non', '', ''],
#             ['288831', 'Quartier Granges de Beauregard.xlsx', 'BS6', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'OUI', 'OUI', 'NC', 'Non', 'NC',
#              'A-N9923A-12F-70 vers 288832/A-N9923A-12F-70 vers 288830/98-8-4 vers 288832/98-8-4 vers 288830', 'OK',
#              '', 'NC', 'SO', 'Non', '', ''],
#             ['288830', 'Quartier Granges de Beauregard.xlsx', 'BS7', 'NC', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NON', 'NC', 'Non', 'NC',
#              'A-N9923A-12F-70 vers 288831/A-N9923A-12F-70 vers 288829/98-8-4 vers 288831/98-8-4 vers 288829', 'OK',
#              'BS7', 'NC', 'MI7 ', 'Non', 'OK', 'CHO : Choc'],
#             ['288829', 'Quartier Granges de Beauregard.xlsx', 'MI8 ', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'OUI', 'OUI', 'NC', 'Non', 'NC',
#              'A-N9923A-12F-70 vers 288830/A-N9923A-12F-70 vers 288828/98-8-4 vers 288830/98-8-4 vers 288828', 'OK',
#              '', 'NC', 'SO', 'Non', '', ''],
#             ['288828', 'Quartier Granges de Beauregard.xlsx', '198.0', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'OUI', 'OUI', 'NC', 'Non', 'NC',
#              'A-N9923A-12F-70 vers 288829/A-N9923A-12F-70 vers 288827/98-8-4 vers 288829/98-8-4 vers 288827', 'OK',
#              '', 'NC', 'SO', 'Non', '', ''],
#             ['288827', 'Quartier Granges de Beauregard.xlsx', 'BS6', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'OUI', 'OUI', 'NC', 'Non', 'NON',
#              'A-N9923A-12F-70 vers 288828/A-N9923A-12F-70 vers 288826/98-8-4 vers 288828/98-8-4 vers 288826', 'OK',
#              '', 'NC', 'SO', 'Non', '', ''],
#             ['288826', 'Quartier Granges de Beauregard.xlsx', 'BS6', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'OUI', 'OUI', 'NC', 'Non', 'NON',
#              'A-N9923A-12F-70 vers 288827/A-N9923A-12F-70 vers 288825/98-8-4 vers 288827/98-8-4 vers 288825', 'OK',
#              '', 'NC', 'SO', 'Non', '', ''],
#             ['288825', 'Quartier Granges de Beauregard.xlsx', '197.0', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'OUI', 'OUI', 'NC', 'Non', 'NC',
#              'A-N9923A-12F-70 vers 288826/A-N9923A-12F-70 vers 288824/98-8-4 vers 288826/98-8-4 vers 288824', 'OK',
#              '', 'NC', 'SO', 'Non', '', ''],
#             ['288824', 'Quartier Granges de Beauregard.xlsx', 'BH7 S30', 'NC', 'NON', 'NON', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NON', 'NON', 'NC', 'Non', 'NC',
#              'A-N9923A-12F-70 vers 288825/A-N9923A-12F-70 vers 288823/98-8-4 vers 288825/98-8-4 vers 288823', 'OK',
#              'BH7 S30', 'NC', 'MH7 S30', 'Non', 'OK', 'AUT : Autre'],
#             ['288823', 'Quartier Granges de Beauregard.xlsx', 'BC8 ', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'OUI', 'OUI', 'NC', 'Non', 'NC',
#              'A-N9923A-12F-70 vers 288824/A-N9923A-12F-70 vers 288818/98-8-4 vers 288824/98-8-4 vers 288818', 'OK',
#              '', 'NC', 'SO', 'Non', '', ''],
#             ['288818', 'Quartier Granges de Beauregard.xlsx', '197.0', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'OUI', 'OUI', 'NC', 'Non', 'NC',
#              'A-N9923A-12F-70 vers 288823/A-N9923A-12F-70 vers 288819/98-8-4 vers 288823/98-8-4 vers 288819', 'OK',
#              '', 'NC', 'SO', 'PB', '', 'AUT : Autre'],
#             ['288819', 'Quartier Granges de Beauregard.xlsx', 'BS7', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'OUI', 'OUI', 'NC', 'Non', 'NON',
#              'A-N9923A-12F-70 vers 288818/A-N9923A-12F-70 vers 288820/98-8-4 vers 288818/98-8-4 vers 288820', 'OK',
#              '', 'NC', 'SO', 'Non', '', ''],
#             ['288820', 'Quartier Granges de Beauregard.xlsx', 'BH6 S30', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'OUI', 'OUI', 'NC', 'Non', 'NON',
#              'A-N9923A-12F-70 vers 288819/A-N9923A-12F-70 vers 288821/98-8-4 vers 288819/98-8-4 vers 288821', 'OK',
#              '', 'NC', 'SO', 'Non', '', ''],
#             ['288821', 'Quartier Granges de Beauregard.xlsx', 'BC7 ', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'OUI', 'OUI', 'NC', 'Non', 'NON', 'A-N9923A-12F-70 vers 288820/98-8-4 vers 288820', 'OK', '',
#              'NC', 'SO', 'PB', '', ''],
#             ['FT0069', 'QUARTIER HAUTERIVES 4.xlsx', 'BS8', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G- 12F-80 vers 195796/P-TF303G- 12F-80 vers 195797/98-8-6     vers 195796/98-8-6     vers 195797',
#              'OKOK', '', 'NC', 'SO', 'Non', 'OK', ''],
#             ['195797', 'QUARTIER HAUTERIVES 4.xlsx', 'BS7', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G- 12F-80 vers 195798/P-TF303G- 12F-80 vers FT0069/98-8-6     vers 195798/98-8-6     vers FT0069',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['195798', 'QUARTIER HAUTERIVES 4.xlsx', 'BS7', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G- 12F-80 vers 195797/P-TF303G- 12F-80 vers 021636/98-8-6     vers 195797/5/10 vers FA0210/98-8-6     vers 021636',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['021636', 'QUARTIER HAUTERIVES 4.xlsx', 'BS7', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G- 12F-80 vers 195798/98-8-6     vers 195798/98-8-6     vers FT0496', 'OK', '', 'NC', 'SO',
#              'PB', '', ''],
#             ['FT0323', 'QUARTIER HAUTERIVES 5.xlsx', 'POT MIN', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'OUI', 'NC', 'Non', 'NON', '98-8-6 vers BT0138', 'OK', '', 'NC', 'SO', 'Non', 'OK', ''],
#             ['FT0408', 'QUARTIER HAUTERIVES 6.xlsx', 'BS7', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'NON', 'NC', 'Non', 'NON',
#              'P-TF303G- 48F-80 vers BT0138/5/10 vers 021679/5/10 vers 021679/98-8-6     vers BT0138/5/10 vers BT0138',
#              'OKINSUFFISANT', 'BS7', 'NC', 'FR7', 'PB', 'OKOK', ''],
#             ['2002003', 'QUARTIER HAUTERIVES 7.xlsx', 'BS8', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON', 'P-TF303G- 12F-80 vers BT00389/Liaison vers BT0129/Liaison vers BT0071',
#              'OKOK', '', 'NC', 'SO', 'PB', 'OK', ''],
#             ['021637', 'QUARTIER HAUTERIVES22.xlsx', 'BS8', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G- 96F-80 vers FT0149/P-TF303G- 96F-80 vers FT0149/P-TF303G- 96F-80 vers 195796/P-TF303G- 96F-80 vers 195796/P-TF303G- 12F-80 vers 021638/98-14-6     vers FT0149/98-28-6     vers FT0149/98-8-6     vers 021638/98-28-6     vers 195796/98-14-6 vers 195796/98-8-6 vers 195796',
#              'OKINSUFFISANT', 'BS8', 'NC', 'FR8', 'PB', 'OKOK', ''],
#             ['FT0149', 'QUARTIER HAUTERIVES22.xlsx', 'BS8', 'NC', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'NON', 'NC', 'Non', 'NON',
#              'P-TF303G- 96F-80 vers 021637/P-TF303G- 96F-80 vers 021637/P-TF303G- 96F-80 vers BT0202/P-TF303G- 96F-80 vers BT0202/98-14-6     vers 021637/98-28-6 vers 021637/98-14-6 vers 021644/98-28-6 vers 021644',
#              'INSUFFISANT', '', 'NC', 'SO', 'Non', '', 'REMPLACEMENT PAR AEOP'],
#             ['021644', 'QUARTIER HAUTERIVES22.xlsx', 'BS8', 'NON', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'NON', 'NC', 'Non', 'NON',
#              '98-14-6 vers FT0149/98-28-6 vers FT0149/98-14-6 vers 021645/98-28-6 vers 021645', 'OK', '', 'NC',
#              'SO', '', '', ''],
#             ['021645', 'QUARTIER HAUTERIVES22.xlsx', 'BS8', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G- 96F-80 vers BT0202/P-TF303G- 96F-80 vers BT0202/P-TF303G- 96F-80 vers 021641/P-TF303G- 96F-80 vers FT0489/98-14-6     vers 021644/98-28-6     vers 021644/98-8-6     vers 021641/98-28-6     vers FT0489/98-8-6 vers FT0489',
#              'INSUFFISANT', 'BS8', 'NC', 'FR8', 'Non', 'OK', ''],
#             ['FT0489', 'QUARTIER HAUTERIVES22.xlsx', 'BM8', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G- 96F-80 vers 021645/P-TF303G- 96F-80 vers 021647/98-28-6     vers 021645/98-8-6     vers 021645/98-28-6     vers 021647/98-8-6     vers 021647',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['021647', 'QUARTIER HAUTERIVES22.xlsx', 'MC8 ANC MIN', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G- 96F-80 vers FT0489/P-TF303G- 96F-80 vers 021648/98-28-6     vers FT0489/98-8-6     vers FT0489/98-28-6     vers 021648/98-8-6 vers 021648',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['021648', 'QUARTIER HAUTERIVES22.xlsx', 'MC8 ANC MIN', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G- 96F-80 vers 021647/P-TF303G- 96F-80 vers 021649/98-28-6     vers 021647/98-8-6     vers 021647/5/10 vers BT0203/98-28-6     vers 021649/98-8-6 vers 021649/5/10 vers 021649',
#              'OK', '', 'NC', 'SO', 'PB', '', ''],
#             ['021649', 'QUARTIER HAUTERIVES22.xlsx', 'BM8', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G- 96F-80 vers 021648/P-TF303G- 96F-80 vers 021650/98-28-6     vers 021648/98-8-6     vers 021648/5/10 vers 021648/5/10 vers FA0080/98-28-6     vers 021650/98-8-6 vers 021650/5/10 vers 021650',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['021650', 'QUARTIER HAUTERIVES22.xlsx', '198.0', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G- 96F-80 vers 021649/P-TF303G- 96F-80 vers 021651/98-28-6     vers 021649/98-8-6     vers 021649/5/10 vers 021649/98-28-6     vers 021651/98-8-6 vers 021651/5/10 vers 021651',
#              'INSUFFISANT', '198.0', 'NC', 'FR8', 'Non', 'OK', ''],
#             ['021651', 'QUARTIER HAUTERIVES22.xlsx', 'MH8 S30', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G- 96F-80 vers 021650/P-TF303G- 96F-80 vers 021652/98-28-6     vers 021650/98-8-6     vers 021650/5/10 vers 021650/98-28-6     vers 021652/98-8-6     vers 021652/5/10 vers 021652',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['021652', 'QUARTIER HAUTERIVES22.xlsx', 'BC8 ANC', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G- 96F-80 vers 021651/P-TF303G- 96F-80 vers BT0076/98-28-6     vers 021651/98-8-6     vers 021651/5/10 vers 021651/98-28-6     vers BT0076/98-8-6 vers BT0076/5/10 vers BT0076',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['021638', 'QUARTIER HAUTERIVES22.xlsx', 'BS7', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G- 12F-80 vers 021637/98-8-6     vers 021637/98-14-6     vers 021639', 'OK', '', 'NC', 'SO',
#              'PB', '', ''],
#             ['021641', 'QUARTIER HAUTERIVES22.xlsx', 'BS7', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G- 96F-80 vers 021645/P-TF303G- 96F-80 vers 021642/98-8-6     vers 021645/98-8-6     vers 021642',
#              'INSUFFISANT', 'BS7', 'NC', 'FR7', 'Non', 'OK', ''],
#             ['021642', 'QUARTIER HAUTERIVES22.xlsx', 'BS7', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G- 96F-80 vers 021641/P-TF303G- 96F-80 vers BT0397/98-8-6     vers 021641/5/10 vers BT0397/5/10 vers BT0397/5/10 vers BT0397',
#              'INSUFFISANT', 'BS7', 'NC', 'FR7', 'Non', 'OK', ''],
#             ['BT0479', 'QUARTIER HAUTERIVES_3.xlsx', 'EDF', 'NON', 'NON', 'NON', 'NON', 'OUI', 'NON', 'OUI', 'NON',
#              'NON', 'NC', 'Non', 'NON', 'P-TF303G- 48F-80 vers 021677/98-14-6 vers BT0206/98-14-6 vers 021677',
#              'OK', '', 'NC', 'SO', '', 'OK', ''],
#             ['021677', 'QUARTIER HAUTERIVES_3.xlsx', 'BS7', 'NON', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'NON', 'NC', 'Non', 'NON',
#              'P-TF303G- 48F-80 vers BT0479/P-TF303G- 48F-80 vers FT0156/98-14-6 vers BT0479/98-14-6 vers FT0156',
#              'OK', '', 'NC', 'SO', '', '', ''],
#             ['FT0156', 'QUARTIER HAUTERIVES_3.xlsx', 'POT MIN', 'NC', 'NON', 'NON', 'NON', 'NON', 'NON', 'NON',
#              'NON', 'OUI', 'NC', 'Non', 'NON', 'P-TF303G- 48F-80 vers 021677/98-14-6 vers 021677', '', '', 'NC',
#              'SO', 'Non', '', ''],
#             ['354649', 'Quartier la Lauze.xlsx', 'MC8 MIN', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'A-N8227A-24F-70 vers 354650/A-N8227A-24F-70 vers 186940/Liaison vers 354650/98-8-6 vers BT0708/98-56-6 vers 354648/SACMY-36F-80 vers 354648/98-56-6 vers 186940/SACMY-36F-80 vers 186940',
#              'OKOK', '', 'NC', 'SO', 'Non', 'OK', ''],
#             ['186940', 'Quartier la Lauze.xlsx', 'BS8', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'A-N8227A-24F-70 vers 354649/A-N8227A-24F-70 vers 234681/98-56-6 vers 354649/SACMY-36F-80 vers 354649/98-56-6 vers 234681/SACMY-36F-80 vers 234681',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['234681', 'Quartier la Lauze.xlsx', 'BH8 S30', 'OUI', 'OUI', 'OUI', 'NON', 'OUI', 'OUI', 'OUI', 'OUI',
#              'NON', 'NC', 'HTC', 'NC',
#              'A-N8227A-24F-70 vers 186940/A-N8227A-24F-70 vers 234682/98-56-6 vers 186940/SACMY-36F-80 vers 186940/98-56-6 vers 234682/SACMY-36F-80 vers 234682',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['234682', 'Quartier la Lauze.xlsx', 'MC8 MIN', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NC',
#              'A-N8227A-24F-70 vers 234681/A-N8227A-24F-70 vers 234683/98-56-6 vers 234681/SACMY-36F-80 vers 234681/98-56-6 vers 234683/SACMY-36F-80 vers 234683',
#              'INSUFFISANT', 'MC8 MIN', 'NC', 'M48', 'Non', 'OK', ''],
#             ['234683', 'Quartier la Lauze.xlsx', 'MI7 ', 'OUI', 'OUI', 'OUI', 'NON', 'OUI', 'OUI', 'OUI', 'OUI',
#              'NON', 'NC', 'Non', 'NON',
#              'A-N8227A-24F-70 vers 234682/A-N8227A-24F-70 vers BT0724/98-56-6 vers 234682/SACMY-36F-80 vers 234682/98-56-6 vers BT0724/SACMY-36F-80 vers BT0724',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['BT0724', 'Quartier la Lauze.xlsx', 'EDF', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'A-N8227A-24F-70 vers 234683/P-TF303G- 72F-80 vers 234684/98-56-6 vers 234683/SACMY-36F-80 vers 234683/98-56-6 vers 234684/SACMY-36F-80 vers 234684/98-8-4 vers 234684',
#              '', '', 'NC', 'SO', 'PB', '', ''],
#             ['234684', 'Quartier la Lauze.xlsx', 'MI7 ', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G- 72F-80 vers BT0724/P-TF303G- 72F-80 vers 234685/98-56-6 vers BT0724/SACMY-36F-80 vers BT0724/98-8-4 vers BT0724/98-56-6 vers 234685/SACMY-36F-80 vers 234685/98-8-4 vers 234685',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['234685', 'Quartier la Lauze.xlsx', 'BS6', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G- 72F-80 vers 234684/P-TF303G- 72F-80 vers 234686/98-56-6 vers 234684/SACMY-36F-80 vers 234684/98-8-4 vers 234684/98-56-6 vers 234686/SACMY-36F-80 vers 234686/98-8-4 vers 234686',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['234686', 'Quartier la Lauze.xlsx', 'BS6', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G- 72F-80 vers 234685/P-TF303G- 72F-80 vers 234687/98-56-6 vers 234685/SACMY-36F-80 vers 234685/98-8-4 vers 234685/98-56-6 vers 234687/SACMY-36F-80 vers 234687/98-8-4 vers 234687',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['234687', 'Quartier la Lauze.xlsx', 'MI8 ', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G- 72F-80 vers 234686/P-TF303G- 72F-80 vers BT0690/98-56-6 vers 234686/SACMY-36F-80 vers 234686/98-8-4 vers 234686/98-56-6 vers BT0690/SACMY-36F-80 vers BT0690/98-8-4 vers BT0690',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['BT0690', 'Quartier la Lauze.xlsx', 'EDF', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G- 72F-80 vers 234687/P-TF303G- 72F-80 vers 234689/98-56-6 vers 234687/SACMY-36F-80 vers 234687/98-8-4 vers 234687/98-56-6 vers 234689/SACMY-36F-80 vers 234689/98-8-4 vers 234689',
#              '', '', 'NC', 'SO', '', '', ''],
#             ['234689', 'Quartier la Lauze.xlsx', 'BC6 ', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NC',
#              'P-TF303G- 72F-80 vers BT0690/P-TF303G- 72F-80 vers 234690/98-56-6 vers BT0690/SACMY-36F-80 vers BT0690/98-8-4 vers BT0690/98-56-6 vers 234690/SACMY-36F-80 vers 234690/98-8-4 vers 234690',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['234690', 'Quartier la Lauze.xlsx', 'MC7 MIN', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NC',
#              'P-TF303G- 72F-80 vers 234689/P-TF303G- 72F-80 vers 234691/98-56-6 vers 234689/SACMY-36F-80 vers 234689/98-8-4 vers 234689/98-56-6 vers 234691/SACMY-36F-80 vers 234691/98-8-4 vers 234691',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['234691', 'Quartier la Lauze.xlsx', 'BH8 S30', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G- 72F-80 vers 234690/P-TF303G- 72F-80 vers 669592/98-56-6 vers 234690/SACMY-36F-80 vers 234690/98-8-4 vers 234690/98-56-6 vers BT0689/SACMY-36F-80 vers BT0689/98-8-4 vers BT0689/Liaison vers 669592',
#              'INSUFFISANT', 'BH8 S30', 'NC', 'M48', 'PB', 'OK', ''],
#             ['669592', 'Quartier la Lauze.xlsx', 'MI6 ', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G- 72F-80 vers 234691/P-TF303G- 72F-80 vers 234693/Liaison vers 234691/Liaison vers 234693',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['234693', 'Quartier la Lauze.xlsx', 'MI8 ', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NC',
#              'P-TF303G- 72F-80 vers 669592/P-TF303G- 72F-80 vers 234694/Liaison vers 669592/98-56-6 vers BT0689/SACMY-36F-80 vers BT0689/98-8-4 vers BT0689/98-56-6 vers 234694/SACMY-36F-80 vers 234694/98-8-4 vers 234694',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['234694', 'Quartier la Lauze.xlsx', '197.0', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G- 72F-80 vers 234693/P-TF303G- 72F-80 vers 234695/98-56-6 vers 234693/SACMY-36F-80 vers 234693/98-8-4 vers 234693/98-56-6 vers 234695/SACMY-36F-80 vers 234695/98-8-4 vers 234695',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['234695', 'Quartier la Lauze.xlsx', '197.0', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G- 72F-80 vers 234694/P-TF303G- 72F-80 vers 234696/98-56-6 vers 234694/SACMY-36F-80 vers 234694/98-8-4 vers 234694/98-56-6 vers 234696/SACMY-36F-80 vers 234696/98-8-4 vers 234696',
#              'INSUFFISANT', '197.0', 'NC', 'BH7 S30', 'Non', 'OK', ''],
#             ['234696', 'Quartier la Lauze.xlsx', 'EDF', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G- 72F-80 vers 234695/98-56-6 vers 234695/SACMY-36F-80 vers 234695/98-8-4 vers 234695',
#              'INSUFFISANT', '', 'NC', 'SO', '', '', ''],
#             ['BT0722', 'Quartier le Pommier.xlsx', 'EDF', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON', 'A-N8227A-24F-70 vers 354658/98-8-6 vers 354658', 'OK', '', 'NC', 'SO', '',
#              'OK', ''],
#             ['354658', 'Quartier le Pommier.xlsx', 'BS7', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'A-N8227A-24F-70 vers BT0722/A-N8227A-24F-70 vers 354657/98-8-6 vers BT0722/98-8-6 vers 354657', 'OK',
#              '', 'NC', 'SO', 'Non', '', ''],
#             ['354657', 'Quartier le Pommier.xlsx', 'BS8', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'A-N8227A-24F-70 vers 354658/A-N8227A-24F-70 vers 354656/98-8-6 vers 354658/98-8-6 vers 354656',
#              'INSUFFISANT', 'BS8', 'NC', 'MI8 ', 'Non', 'OK', ''],
#             ['354656', 'Quartier le Pommier.xlsx', 'BS7', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NC',
#              'A-N8227A-24F-70 vers 354657/A-N8227A-24F-70 vers 354655/98-8-6 vers 354657/98-8-6 vers 354655', 'OK',
#              '', 'NC', 'SO', 'Non', '', ''],
#             ['354655', 'Quartier le Pommier.xlsx', 'BS7', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NC',
#              'A-N8227A-24F-70 vers 354656/A-N8227A-24F-70 vers 195311/98-8-6 vers 354656/98-8-6 vers 195311', 'OK',
#              '', 'NC', 'SO', 'PB', '', ''],
#             ['195311', 'Quartier le Pommier.xlsx', 'BS7', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'A-N8227A-24F-70 vers 354655/A-N8227A-24F-70 vers 195310/98-8-6 vers 354655/98-8-6 vers 195310', 'OK',
#              '', 'NC', 'SO', 'Non', '', ''],
#             ['195310', 'Quartier le Pommier.xlsx', 'BS8', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'A-N8227A-24F-70 vers 195311/A-N8227A-24F-70 vers 354653/98-8-6 vers 195311/98-8-6 vers 354653', 'OK',
#              '', 'NC', 'SO', 'Non', '', ''],
#             ['354653', 'Quartier le Pommier.xlsx', 'BH7 S30', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'OUI', 'NC', 'Non', 'NON',
#              'A-N8227A-24F-70 vers 195310/A-N8227A-24F-70 vers 354652/98-8-6 vers 195310/98-8-6 vers 354652', 'OK',
#              '', 'NC', 'SO', 'Non', '', ''],
#             ['354652', 'Quartier le Pommier.xlsx', 'BS7', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'A-N8227A-24F-70 vers 354653/A-N8227A-24F-70 vers 354651/98-8-6 vers 354653/98-8-6 vers 354651', 'OK',
#              '', 'NC', 'SO', 'Non', '', ''],
#             ['354651', 'Quartier le Pommier.xlsx', 'BS7', 'NC', 'NON', 'OUI', 'OUI', 'NON', 'NON', 'NON', 'NON',
#              'NON', 'NC', 'Non', 'NON',
#              'A-N8227A-24F-70 vers 354652/A-N8227A-24F-70 vers 354650/98-8-6 vers 354652/98-8-6 vers 354650', 'OK',
#              'BS7', 'NC', 'FR7', 'Non', 'OK', 'AUT : Autre'],
#             ['354650', 'Quartier le Pommier.xlsx', 'BM7', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'A-N8227A-24F-70 vers 354651/A-N8227A-24F-70 vers 354649/98-8-6 vers 354651/98-8-6 vers BT0708/Liaison vers 354649',
#              'OK', '', 'NC', 'SO', 'PB', '', ''],
#             ['BT0694', "Quartier les Hauts dEymieux.xlsx", 'EDF', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'OUI', 'NC', 'Non', 'NON', 'A-N8227A-24F-70 vers 288664/Liaison vers 288664', 'OK', '', 'NC',
#              'SO', 'PB', 'OK', ''],
#             ['288664', "Quartier les Hauts dEymieux.xlsx", 'BS8', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'OUI', 'NC', 'Non', 'NC',
#              'A-N8227A-24F-70 vers BT0694/A-N8227A-24F-70 vers 288663/Liaison vers BT0694/98-14-6 vers 288663',
#              'INSUFFISANT', 'BS8', 'NC', 'M48', 'Non', 'OK', ''],
#             ['288663', "Quartier les Hauts dEymieux.xlsx", 'BS7', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'OUI', 'NC', 'Non', 'NC',
#              'A-N8227A-24F-70 vers 288664/A-N8227A-24F-70 vers 288662/98-14-6 vers 288664/98-14-6 vers 288662',
#              'OK', '', 'NC', 'SO', 'PB', '', ''],
#             ['288662', "Quartier les Hauts dEymieux.xlsx", 'BS6', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'OUI', 'NC', 'Non', 'NON',
#              'A-N8227A-24F-70 vers 288663/A-N8227A-24F-70 vers 288661/98-14-6 vers 288663/98-14-6 vers 288661',
#              'OK', '', 'NC', 'SO', 'PB', '', ''],
#             ['288661', "Quartier les Hauts dEymieux.xlsx", 'BC8 ', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'OUI', 'OUI', 'NC', 'Non', 'NON',
#              'A-N8227A-24F-70 vers 288662/A-N8227A-24F-70 vers 288660/98-14-6 vers 288662/98-14-6 vers 288660',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['288660', "Quartier les Hauts dEymieux.xlsx", 'BH8 S45', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'OUI', 'OUI', 'NC', 'Non', 'NC',
#              'A-N8227A-24F-70 vers 288661/A-N8227A-24F-70 vers 288659/98-14-6 vers 288661/98-14-6 vers 288659',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['288659', "Quartier les Hauts dEymieux.xlsx", 'BS7', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'OUI', 'NC', 'Non', 'NC',
#              'A-N8227A-24F-70 vers 288660/A-N8227A-24F-70 vers 288658/98-14-6 vers 288660/98-14-6 vers 288658',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['288658', "Quartier les Hauts dEymieux.xlsx", 'BH8 S45', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'OUI', 'OUI', 'NC', 'Non', 'NON',
#              'A-N8227A-24F-70 vers 288659/A-N8227A-24F-70 vers 288657/98-14-6 vers 288659/98-14-6 vers 288657',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['288657', "Quartier les Hauts dEymieux.xlsx", 'BS8', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'OUI', 'NC', 'Non', 'NC',
#              'A-N8227A-24F-70 vers 288658/A-N8227A-24F-70 vers 288656/98-14-6 vers 288658/98-14-6 vers 288656',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['288656', "Quartier les Hauts dEymieux.xlsx", 'BC8 ', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'OUI', 'OUI', 'NC', 'Non', 'NC',
#              'A-N8227A-24F-70 vers 288657/A-N8227A-24F-70 vers 288655/98-14-6 vers 288657/98-14-6 vers 288655',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['288655', "Quartier les Hauts dEymieux.xlsx", 'MC7 MIN', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'OUI', 'OUI', 'NC', 'Non', 'NON',
#              'A-N8227A-24F-70 vers 288656/A-N8227A-24F-70 vers 288654/98-14-6 vers 288656/98-14-6 vers 288654',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['288654', "Quartier les Hauts dEymieux.xlsx", 'BH7 S45', 'NC', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NON', 'NON', 'NC', 'Non', 'NON',
#              'A-N8227A-24F-70 vers 288655/A-N8227A-24F-70 vers 288653/98-14-6 vers 288655/98-14-6 vers 288653',
#              'OK', 'BH7 S45', 'NC', 'BH7 S30', 'Non', 'OK', 'AUT : Autre'],
#             ['288653', "Quartier les Hauts dEymieux.xlsx", 'BS7', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'OUI', 'NC', 'Non', 'NON',
#              'A-N8227A-24F-70 vers 288654/A-N8227A-24F-70 vers BT0734/98-14-6 vers 288654/98-14-6 vers BT0734',
#              'OK', '', 'NC', 'SO', 'PB', '', ''],
#             ['BT0734', "Quartier les Hauts dEymieux.xlsx", 'EDF', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'OUI', 'NC', 'Non', 'NON', 'A-N8227A-24F-70 vers 288653/98-14-6 vers 288653', '', '', 'NC',
#              'SO', 'PB', '', ''],
#             ['288788', 'Quartier Longeavoux_1.xlsx', 'BS8', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'A-N9923A-12F-70 vers 288763/A-N9923A-12F-70 vers 288789/98-4-8 vers 288763/98-4-8 vers 288789',
#              'OKOK', '', 'NC', 'SO', 'Non', 'OK', ''],
#             ['288789', 'Quartier Longeavoux_1.xlsx', 'BS7', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'A-N9923A-12F-70 vers 288788/A-N9923A-12F-70 vers FT0795/98-4-8 vers 288788/98-4-8 vers FT0795', 'OK',
#              '', 'NC', 'SO', 'Non', '', ''],
#             ['FT0795', 'Quartier Longeavoux_1.xlsx', 'POT MIN', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'OUI', 'NC', 'Non', 'NON',
#              'A-N9923A-12F-70 vers 288789/A-N9923A-12F-70 vers BT0612/98-4-8 vers 288789/98-4-8 vers BT0612', '',
#              '', 'NC', 'SO', 'Non', '', ''],
#             ['BT0612', 'Quartier Longeavoux_1.xlsx', 'EDF', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON', 'A-N9923A-12F-70 vers FT0795/98-4-8 vers FT0795', '', '', 'NC', 'SO', 'PB',
#              '', ''],
#             ['288773', 'Quartier Longeavoux_2.xlsx', 'BC8 ANC', 'OUI', 'OUI', 'NON', 'NON', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NON', 'NC', 'Non', 'NON',
#              'P-TF303G-288F-80 vers 288774/P-TF303G-288F-80 vers 288772/P-TF303G-144F-80 vers 288774/P-TF303G-144F-80 vers 288772/98-28-4 vers 288774/98-56-4 vers 288774/SACMY-36F-80 vers 288774/98-28-4 vers 288772/98-56-4 vers 288772/SACMY-36F-80 vers 288772',
#              'OKOK', 'BC8 ANC', 'NC', 'BH8 S30', 'Non', 'OKOK', ''],
#             ['288772', 'Quartier Longeavoux_2.xlsx', 'MI8 ', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G-288F-80 vers 288773/P-TF303G-288F-80 vers 288771/P-TF303G-144F-80 vers 288773/P-TF303G-144F-80 vers 288771/98-28-4 vers 288773/98-56-4 vers 288773/SACMY-36F-80 vers 288773/98-28-4 vers 288771/98-56-4 vers 288771/SACMY-36F-80 vers 288771',
#              'INSUFFISANT', 'MI8 ', 'NC', 'M48', 'Non', 'OK', ''],
#             ['288771', 'Quartier Longeavoux_2.xlsx', 'BS8', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G-288F-80 vers 288772/P-TF303G-288F-80 vers 288770/P-TF303G-144F-80 vers 288772/P-TF303G-144F-80 vers 288770/98-28-4 vers 288772/98-56-4 vers 288772/SACMY-36F-80 vers 288772/98-28-4 vers 288770/98-56-4 vers 288770/SACMY-36F-80 vers 288770',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['288770', 'Quartier Longeavoux_2.xlsx', 'BS8', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G-288F-80 vers 288771/P-TF303G-288F-80 vers 288769/P-TF303G-144F-80 vers 288771/P-TF303G-144F-80 vers 288769/98-28-4 vers 288771/98-56-4 vers 288771/SACMY-36F-80 vers 288771/98-28-4 vers 288769/98-56-4 vers 288769/SACMY-36F-80 vers 288769',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['288769', 'Quartier Longeavoux_2.xlsx', 'BS8', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G-288F-80 vers 288770/P-TF303G-288F-80 vers 288768/P-TF303G-144F-80 vers 288770/P-TF303G-144F-80 vers 288768/98-28-4 vers 288770/98-56-4 vers 288770/SACMY-36F-80 vers 288770/98-28-4 vers 288768/98-56-4 vers 288768/SACMY-36F-80 vers 288768',
#              'INSUFFISANT', 'BS8', 'NC', 'M48', 'PB', 'OK', ''],
#             ['288768', 'Quartier Longeavoux_2.xlsx', 'BS8', 'OUI', 'OUI', 'OUI', 'NON', 'OUI', 'OUI', 'OUI', 'OUI',
#              'NON', 'NC', 'Non', 'NON',
#              'P-TF303G-288F-80 vers 288769/P-TF303G-288F-80 vers 288767/P-TF303G-144F-80 vers 288769/P-TF303G-144F-80 vers 288767/98-28-4 vers 288769/98-56-4 vers 288769/SACMY-36F-80 vers 288769/98-28-4 vers 288767/98-56-4 vers 288767/SACMY-36F-80 vers 288767',
#              'INSUFFISANT', 'BS8', 'NC', 'FR8', 'Non', 'OK', ''],
#             ['288767', 'Quartier Longeavoux_2.xlsx', 'BS8', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G-288F-80 vers 288768/P-TF303G-288F-80 vers 288765/P-TF303G-144F-80 vers 288768/P-TF303G-144F-80 vers 288765/A-N9923A-12F-70 vers 421065/98-28-4 vers 288768/98-56-4 vers 288768/SACMY-36F-80 vers 288768/Liaison vers 421065/98-28-4 vers 288765/98-56-4 vers 288765/SACMY-36F-80 vers 288765',
#              'INSUFFISANT', 'BS8', 'NC', 'M48', 'PB', 'OK', ''],
#             ['288765', 'Quartier Longeavoux_2.xlsx', 'MI8 ', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G-288F-80 vers 288767/P-TF303G-288F-80 vers 288766/P-TF303G-144F-80 vers 288767/P-TF303G-144F-80 vers 288766/98-28-4 vers 288767/98-56-4 vers 288767/SACMY-36F-80 vers 288767/98-28-4 vers 288766/98-56-4 vers 288766/SACMY-36F-80 vers 288766',
#              'INSUFFISANT', 'MI8 ', 'NC', 'M48', 'Non', 'OK', ''],
#             ['288766', 'Quartier Longeavoux_2.xlsx', 'MI8 ', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NC',
#              'P-TF303G-288F-80 vers 288765/P-TF303G-288F-80 vers 189569/P-TF303G-144F-80 vers 288765/P-TF303G-144F-80 vers 189569/98-28-4 vers 288765/98-56-4 vers 288765/SACMY-36F-80 vers 288765/98-28-4 vers 189569/98-56-4 vers 189569/SACMY-36F-80 vers 189569',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['189569', 'Quartier Longeavoux_2.xlsx', 'MI8 ', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NC',
#              'P-TF303G-288F-80 vers 288766/P-TF303G-288F-80 vers 288764/P-TF303G-144F-80 vers 288766/P-TF303G-144F-80 vers 288764/98-28-4 vers 288766/98-56-4 vers 288766/SACMY-36F-80 vers 288766/98-28-4 vers 288764/98-56-4 vers 288764/SACMY-36F-80 vers 288764',
#              'INSUFFISANT', 'MI8 ', 'NC', 'M48', 'Non', 'OK', ''],
#             ['288764', 'Quartier Longeavoux_2.xlsx', 'MI8 ', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NC',
#              'P-TF303G-288F-80 vers 189569/P-TF303G-288F-80 vers 288763/P-TF303G-144F-80 vers 189569/P-TF303G-144F-80 vers 288763/98-28-4 vers 189569/98-56-4 vers 189569/SACMY-36F-80 vers 189569/98-28-4 vers 288763/98-56-4 vers 288763/SACMY-36F-80 vers 288763',
#              'INSUFFISANT', 'MI8 ', 'NC', 'MH8 S30', 'Non', 'OK', ''],
#             ['288763', 'Quartier Longeavoux_2.xlsx', 'MC8 MIN', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'OUI', 'NC', 'Non', 'NC',
#              'P-TF303G-288F-80 vers 288764/P-TF303G-288F-80 vers 288762/P-TF303G-144F-80 vers 288764/P-TF303G-144F-80 vers 288762/A-N9923A-12F-70 vers 288788/98-28-4 vers 288764/98-56-4 vers 288764/SACMY-36F-80 vers 288764/98-4-8 vers 288788/98-28-4 vers 288762/98-56-4 vers 288762/SACMY-36F-80 vers 288762',
#              'INSUFFISANT', 'MC8 MIN', 'NC', 'M48', 'PB', 'OK', ''],
#             ['288762', 'Quartier Longeavoux_2.xlsx', 'BS7', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G-288F-80 vers 288763/P-TF303G-288F-80 vers 288761/P-TF303G-144F-80 vers 288763/P-TF303G-144F-80 vers 288761/98-28-4 vers 288763/98-56-4 vers 288763/SACMY-36F-80 vers 288763/98-28-4 vers 288761/98-56-4 vers 288761/SACMY-36F-80 vers 288761',
#              'INSUFFISANT', 'BS7', 'NC', 'M47', 'PB', 'OK', ''],
#             ['288761', 'Quartier Longeavoux_2.xlsx', 'BR7 ', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G-288F-80 vers 288762/P-TF303G-288F-80 vers 288760/P-TF303G-144F-80 vers 288762/P-TF303G-144F-80 vers 288760/98-28-4 vers 288762/98-56-4 vers 288762/SACMY-36F-80 vers 288762/98-28-4 vers 288760/98-56-4 vers 288760/SACMY-36F-80 vers 288760',
#              'INSUFFISANT', 'BR7 ', 'NC', 'M47', 'Non', 'OK', ''],
#             ['288760', 'Quartier Longeavoux_2.xlsx', 'BS8', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G-288F-80 vers 288761/P-TF303G-288F-80 vers FT0830/P-TF303G-144F-80 vers 288761/P-TF303G-144F-80 vers FT0830/A-N8227A-24F-70 vers BT0657/98-28-4 vers 288761/98-56-4 vers 288761/SACMY-36F-80 vers 288761/Liaison vers BT0657/98-28-4 vers FT0830/98-56-4 vers FT0830/SACMY-36F-80 vers FT0830',
#              'OK', '', 'NC', 'SO', 'PB', '', ''],
#             ['FT0830', 'Quartier Longeavoux_2.xlsx', 'POT MIN', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G-288F-80 vers 288760/P-TF303G-288F-80 vers 288758/P-TF303G-144F-80 vers 288760/P-TF303G-144F-80 vers 288758/A-N8228A-36F-70 vers 288758/98-28-4 vers 288760/98-56-4 vers 288760/SACMY-36F-80 vers 288760/98-28-4 vers 288758/98-56-4 vers 288758/SACMY-36F-80 vers 288758',
#              '', '', 'NC', 'SO', 'PB', '', ''],
#             ['288758', 'Quartier Longeavoux_2.xlsx', 'BM8', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NC',
#              'P-TF303G-288F-80 vers FT0830/P-TF303G-288F-80 vers 288757/P-TF303G-288F-80 vers 288757/P-TF303G-144F-80 vers FT0830/A-N8228A-36F-70 vers FT0830/A-N8228A-36F-70 vers BT0654/A-N9923A-12F-70 vers 288757/98-28-4 vers FT0830/98-56-4 vers FT0830/SACMY-36F-80 vers FT0830/98-8-4 vers BT0654/98-28-4 vers 288757/98-56-4 vers 288757/SACMY-36F-80 vers 288757',
#              'OK', '', 'NC', 'SO', 'PB', '', ''],
#             ['421065', 'Quartier Longeavoux_2.xlsx', 'BS8', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON', 'A-N9923A-12F-70 vers 288767/Liaison vers 288767', 'OK', '', 'NC', 'SO',
#              'PB', '', ''],
#             ['BT0657', 'Quartier Longeavoux_2.xlsx', 'EDF', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON', 'A-N8227A-24F-70 vers 288760/Liaison vers 288760', '', '', 'NC', 'SO', '',
#              '', ''],
#             ['BT0654', 'Quartier Longeavoux_2.xlsx', 'EDF', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON', 'A-N8228A-36F-70 vers 288758/98-8-4 vers 288758', '', '', 'NC', 'SO', '',
#              '', ''],
#             ['BT0672', 'Quartier Longeavoux_3.xlsx', 'EDF', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON', 'A-N8228A-36F-70 vers 288797/Liaison vers 288797', 'OK', '', 'NC', 'SO',
#              'PB', 'OK', ''],
#             ['288797', 'Quartier Longeavoux_3.xlsx', 'BS6', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'A-N8228A-36F-70 vers BT0672/A-N8228A-36F-70 vers 288796/Liaison vers BT0672/Liaison vers 288796',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['288796', 'Quartier Longeavoux_3.xlsx', 'BS6', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'A-N8228A-36F-70 vers 288797/A-N8228A-36F-70 vers 288795/Liaison vers 288797/Liaison vers 288795',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['288795', 'Quartier Longeavoux_3.xlsx', 'BH6 S30', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'OUI', 'NC', 'Non', 'NON',
#              'A-N8228A-36F-70 vers 288796/A-N8228A-36F-70 vers 288794/Liaison vers 288796/Liaison vers 288794',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['288794', 'Quartier Longeavoux_3.xlsx', 'BS7', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'A-N8228A-36F-70 vers 288795/A-N8228A-36F-70 vers BT0662/Liaison vers 288795/Liaison vers BT0662',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['BT0662', 'Quartier Longeavoux_3.xlsx', 'EDF', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'A-N8228A-36F-70 vers 288794/A-N8228A-36F-70 vers 288793/Liaison vers 288794/98-8-4 vers 288793', '',
#              '', 'NC', 'SO', '', '', ''],
#             ['288793', 'Quartier Longeavoux_3.xlsx', 'BS7', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'A-N8228A-36F-70 vers BT0662/A-N8228A-36F-70 vers BT0661/98-8-4 vers BT0662/98-8-4 vers BT0661', 'OK',
#              '', 'NC', 'SO', 'PB', '', ''],
#             ['BT0661', 'Quartier Longeavoux_3.xlsx', 'EDF', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'A-N8228A-36F-70 vers 288793/A-N8228A-36F-70 vers 288792/98-8-4 vers 288793/98-8-4 vers 288792', '',
#              '', 'NC', 'SO', '', '', ''],
#             ['288792', 'Quartier Longeavoux_3.xlsx', 'MI8 ', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'A-N8228A-36F-70 vers BT0661/A-N8228A-36F-70 vers BT0660/98-8-4 vers BT0661/98-8-4 vers BT0660', 'OK',
#              '', 'NC', 'SO', 'PB', '', ''],
#             ['BT0660', 'Quartier Longeavoux_3.xlsx', 'EDF', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'A-N8228A-36F-70 vers 288792/A-N8228A-36F-70 vers 288791/98-8-4 vers 288792/98-8-4 vers 288791', '',
#              '', 'NC', 'SO', '', '', ''],
#             ['288791', 'Quartier Longeavoux_3.xlsx', 'BS8', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NC',
#              'A-N8228A-36F-70 vers BT0660/A-N8228A-36F-70 vers BT0655/98-8-4 vers BT0660/98-8-4 vers BT0655', 'OK',
#              '', 'NC', 'SO', 'PB', '', ''],
#             ['BT0655', 'Quartier Longeavoux_3.xlsx', 'EDF', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON', 'A-N8228A-36F-70 vers 288791/98-8-4 vers 288791', '', '', 'NC', 'SO', '',
#              '', ''],
#             ['288757', 'Quartier Longeavoux_4.xlsx', 'BC8 ANC', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G-288F-80 vers 288758/P-TF303G-288F-80 vers 288756/P-TF303G-288F-80 vers 288758/P-TF303G-288F-80 vers 288756/A-N9923A-12F-70 vers 288758/98-28-4 vers 288758/98-56-4 vers 288758/SACMY-36F-80 vers 288758/98-28-4 vers 288756/98-56-4 vers 288756/98-14-4 vers 288756/98-14-4 vers 288756/SACMY-36F-80 vers 288756',
#              'OKOK', '', 'NC', 'SO', 'PB', 'OK', ''],
#             ['288756', 'Quartier Longeavoux_4.xlsx', 'BC8 ', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NC',
#              'P-TF303G-288F-80 vers 288757/P-TF303G-288F-80 vers 288755/P-TF303G-288F-80 vers 288757/P-TF303G-288F-80 vers 288755/98-28-4 vers 288757/98-56-4 vers 288757/98-14-4 vers 288757/98-14-4 vers 288757/SACMY-36F-80 vers 288757/98-28-4 vers 288755/98-56-4 vers 288755/98-14-4 vers 288755/98-14-4 vers 288755/SACMY-36F-80 vers 288755',
#              'OK', '', 'NC', 'SO', 'Non', '', 'AUT : Autre'],
#             ['288755', 'Quartier Longeavoux_4.xlsx', 'BS7', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G-288F-80 vers 288756/P-TF303G-288F-80 vers 288754/P-TF303G-288F-80 vers 288756/P-TF303G-288F-80 vers 288754/98-28-4 vers 288756/98-56-4 vers 288756/98-14-4 vers 288756/98-14-4 vers 288756/SACMY-36F-80 vers 288756/98-28-4 vers 288754/98-56-4 vers 288754/98-14-4 vers 288754/98-14-4 vers 288754/SACMY-36F-80 vers 288754',
#              'INSUFFISANT', 'BS7', 'NC', 'BH7 S30', 'Non', 'OK', ''],
#             ['288754', 'Quartier Longeavoux_4.xlsx', 'MI7 ', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G-288F-80 vers 288755/P-TF303G-288F-80 vers 288753/P-TF303G-288F-80 vers 288755/P-TF303G-288F-80 vers 288753/98-28-4 vers 288755/98-56-4 vers 288755/98-14-4 vers 288755/98-14-4 vers 288755/SACMY-36F-80 vers 288755/98-28-4 vers 288753/98-56-4 vers 288753/98-14-4 vers 288753/98-14-4 vers 288753/SACMY-36F-80 vers 288753',
#              'INSUFFISANT', 'MI7 ', 'NC', 'M47', 'Non', 'OK', ''],
#             ['288753', 'Quartier Longeavoux_4.xlsx', 'BS7', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G-288F-80 vers 288754/P-TF303G-288F-80 vers 288752/P-TF303G-288F-80 vers 288754/P-TF303G-288F-80 vers 288752/A-N9923A-12F-70 vers 288752/98-28-4 vers 288754/98-56-4 vers 288754/98-14-4 vers 288754/98-14-4 vers 288754/SACMY-36F-80 vers 288754/98-28-4 vers 288752/98-56-4 vers 288752/98-14-4 vers 288752/98-14-4 vers 288752/SACMY-36F-80 vers 288752',
#              'INSUFFISANT', 'BS7', 'NC', 'BH7 S30', 'PB', 'OK', ''],
#             ['288752', 'Quartier Longeavoux_4.xlsx', 'MI8 ', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G-288F-80 vers 288753/P-TF303G-288F-80 vers 288751/P-TF303G-288F-80 vers 288753/P-TF303G-288F-80 vers 288751/A-N9923A-12F-70 vers 288753/98-28-4 vers 288753/98-56-4 vers 288753/98-14-4 vers 288753/98-14-4 vers 288753/SACMY-36F-80 vers 288753/98-28-4 vers 288751/98-56-4 vers 288751/98-14-4 vers 288751/98-14-4 vers 288751/SACMY-36F-80 vers 288751',
#              'INSUFFISANT', 'MI8 ', 'NC', 'M48', 'PB', 'OK', ''],
#             ['288751', 'Quartier Longeavoux_4.xlsx', 'MC7 ANC MIN', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G-288F-80 vers 288752/P-TF303G-288F-80 vers 288752/98-28-4 vers 288752/98-56-4 vers 288752/98-14-4 vers 288752/98-14-4 vers 288752/SACMY-36F-80 vers 288752',
#              'INSUFFISANT', 'MC7 ANC MIN', 'NC', 'B37 ', 'Non', 'INSUFFISANT', ''],
#             ['BT0788', 'Quartier Rochecondrie_1.xlsx', 'EDF', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G-288F-80 vers 288679/P-TF303G-288F-80 vers 288679/98-14-6 vers 288679/98-28-6 vers 288679',
#              'OK', '', 'NC', 'SO', 'PB', 'OK', ''],
#             ['288679', 'Quartier Rochecondrie_1.xlsx', 'BS8', 'OUI', 'NON', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NON', 'NC', 'Non', 'NC',
#              'P-TF303G-288F-80 vers BT0788/P-TF303G-288F-80 vers 288678/P-TF303G-288F-80 vers BT0788/P-TF303G-288F-80 vers 288678/98-14-6     vers BT0788/98-28-6 vers BT0788/98-14-6 vers 288678/98-28-6 vers 288678',
#              'INSUFFISANT', 'BS8', 'NC', 'M48', 'Non', 'OK', ''],
#             ['288678', 'Quartier Rochecondrie_1.xlsx', 'BC8 ', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'OUI', 'NC', 'Non', 'NC',
#              'P-TF303G-288F-80 vers 288679/P-TF303G-288F-80 vers 288679/A-N8227A-24F-70 vers BT0791/98-14-6     vers 288679/98-28-6 vers 288679/Liaison vers BT0791',
#              'INSUFFISANT', 'BC8 ', 'NC', 'BC8 ANC', 'PB', 'OK', ''],
#             ['BT0791', 'Quartier Rochecondrie_1.xlsx', 'EDF', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'OUI', 'NC', 'Non', 'NON', 'A-N8227A-24F-70 vers 288678/Liaison vers 288678', '', '', 'NC',
#              'SO', '', '', ''],
#             ['421071', 'Quartier Rochecondrie_2.xlsx', 'BS7', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'OUI', 'NC', 'Non', 'NON', 'A-N9923A-12F-70 vers 421070/Liaison vers 421070', 'OKOK', '', 'NC',
#              'SO', 'PB', 'OK', ''],
#             ['421070', 'Quartier Rochecondrie_2.xlsx', 'BS8', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'OUI', 'NC', 'Non', 'NON',
#              'A-N9923A-12F-70 vers 421071/A-N9923A-12F-70 vers 421069/Liaison vers 421071/Liaison vers 421069',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['421069', 'Quartier Rochecondrie_2.xlsx', 'BC8 ', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'OUI', 'NC', 'Non', 'NON',
#              'A-N9923A-12F-70 vers 421070/A-N9923A-12F-70 vers 421068/Liaison vers 421070/98-8-4 vers 421068', 'OK',
#              '', 'NC', 'SO', 'Non', '', ''],
#             ['421068', 'Quartier Rochecondrie_2.xlsx', 'BS7', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'OUI', 'NC', 'Non', 'NC',
#              'A-N9923A-12F-70 vers 421069/A-N9923A-12F-70 vers 421067/98-8-4 vers 421069/98-8-4 vers 421067', 'OK',
#              '', 'NC', 'SO', 'Non', '', ''],
#             ['421067', 'Quartier Rochecondrie_2.xlsx', 'BS7', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'OUI', 'NC', 'Non', 'NC',
#              'A-N9923A-12F-70 vers 421068/A-N9923A-12F-70 vers 288711/98-8-4 vers 421068/98-8-4 vers 288711', 'OK',
#              '', 'NC', 'SO', 'Non', '', ''],
#             ['288711', 'Quartier Rochecondrie_2.xlsx', 'BH8 S45', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'OUI', 'NC', 'Non', 'NON',
#              'A-N9923A-12F-70 vers 421067/A-N9923A-12F-70 vers 288710/A-N9923A-12F-70 vers 288712/98-8-4 vers 421067/98-28-6 vers 288712/98-8-4 vers 288712/98-28-6 vers 288710',
#              'OK', '', 'NC', 'SO', 'PB', '', ''],
#             ['288710', 'Quartier Rochecondrie_2.xlsx', 'BS8', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'OUI', 'NC', 'Non', 'NC',
#              'A-N9923A-12F-70 vers 288711/A-N9923A-12F-70 vers 288709/98-28-6 vers 288711/98-28-6 vers 288709',
#              'INSUFFISANT', 'BS8', 'NC', 'BH8 S30', 'Non', 'OK', ''],
#             ['288709', 'Quartier Rochecondrie_2.xlsx', 'BS6', 'NC', 'NON', 'NON', 'OUI', 'OUI', 'OUI', 'OUI', 'NON',
#              'NON', 'NC', 'Non', 'NC',
#              'A-N9923A-12F-70 vers 288710/A-N9923A-12F-70 vers 288708/98-28-6 vers 288710/98-28-6 vers 288708',
#              'INSUFFISANT', 'BS6', 'NC', 'MH7 S30', 'Non', 'OK', 'AUT : Autre'],
#             ['288708', 'Quartier Rochecondrie_2.xlsx', 'BH7 S30', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'OUI', 'NC', 'Non', 'NC',
#              'A-N9923A-12F-70 vers 288709/A-N8227A-24F-70 vers 288707/A-N8227A-24F-70 vers BT0678/98-28-6 vers 288709/98-4-8 vers BT0678/98-28-6 vers 288707',
#              'OK', '', 'NC', 'SO', 'PB', '', ''],
#             ['288707', 'Quartier Rochecondrie_2.xlsx', 'BS8', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'OUI', 'NC', 'Non', 'NC',
#              'A-N8227A-24F-70 vers 288708/A-N8227A-24F-70 vers 288706/98-28-6 vers 288708/98-28-6 vers 288706',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['288706', 'Quartier Rochecondrie_2.xlsx', 'BS7', 'OUI', 'NON', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NON', 'NC', 'Non', 'NC',
#              'A-N8227A-24F-70 vers 288707/A-N8227A-24F-70 vers 288705/98-28-6 vers 288707/98-28-6 vers 288705',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['288705', 'Quartier Rochecondrie_2.xlsx', 'BC8 ', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'OUI', 'NC', 'Non', 'NC', 'A-N8227A-24F-70 vers 288706/98-28-6 vers 288706', 'OK', '', 'NC',
#              'SO', 'Non', '', ''],
#             ['BT0678', 'Quartier Rochecondrie_2.xlsx', 'EDF', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'OUI', 'NC', 'Non', 'NON', 'A-N8227A-24F-70 vers 288708/98-4-8 vers 288708', '', '', 'NC', 'SO',
#              'PB', '', ''],
#             ['288719', 'Quartier Roumanas.xlsx', 'MI8 ', 'OUI', 'NON', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'NON', 'NC', 'Non', 'NON', 'A-N9923A-12F-70 vers 288718/98-8-4 vers 288718/98-8-4 vers BT0681', 'OKOK',
#              '', 'NC', 'SO', 'PB', 'OK', ''],
#             ['288718', 'Quartier Roumanas.xlsx', 'BM7', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'A-N9923A-12F-70 vers 288719/A-N9923A-12F-70 vers 288717/98-8-4 vers 288719/98-28-6 vers 288720/98-28-6 vers 288717',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['288717', 'Quartier Roumanas.xlsx', 'BM8', 'NC', 'NON', 'NON', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'NON', 'NC', 'Non', 'NON',
#              'A-N9923A-12F-70 vers 288718/A-N9923A-12F-70 vers 288716/98-28-6 vers 288718/98-8-4 vers 288718/98-8-4 vers 288716/98-28-6 vers 288716',
#              'OK', 'BM8', 'NC', 'BM8', 'Non', 'OK', 'AUT : Autre'],
#             ['288716', 'Quartier Roumanas.xlsx', 'BM7', 'NC', 'NON', 'NON', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'NON', 'NC', 'Non', 'NON',
#              'A-N9923A-12F-70 vers 288717/A-N9923A-12F-70 vers 288715/98-28-6 vers 288717/98-8-4 vers 288717/98-28-6 vers 288715/98-8-4 vers 288715',
#              'OK', 'BM7', 'NC', 'M47', 'Non', 'OK', 'AUT : Autre'],
#             ['288715', 'Quartier Roumanas.xlsx', 'BM8', 'NC', 'NON', 'NON', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'NON', 'NC', 'Non', 'NON',
#              'A-N9923A-12F-70 vers 288716/A-N9923A-12F-70 vers 288714/98-28-6 vers 288716/98-8-4 vers 288716/98-28-6 vers 288714/98-8-4 vers 288714',
#              'INSUFFISANT', 'BM8', 'NC', 'M48', 'Non', 'OK', 'AUT : Autre'],
#             ['288714', 'Quartier Roumanas.xlsx', 'BM8', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NC',
#              'A-N9923A-12F-70 vers 288715/A-N9923A-12F-70 vers 288713/98-28-6 vers 288715/98-8-4 vers 288715/98-28-6 vers 288713/98-8-4 vers 288713',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['288713', 'Quartier Roumanas.xlsx', 'BS7', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'A-N9923A-12F-70 vers 288714/A-N9923A-12F-70 vers 288712/98-28-6 vers 288714/98-8-4 vers 288714/98-28-6 vers 288712/98-8-4 vers 288712',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['288712', 'Quartier Roumanas.xlsx', 'BS7', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NC',
#              'A-N9923A-12F-70 vers 288713/A-N9923A-12F-70 vers 288711/98-28-6 vers 288713/98-8-4 vers 288713/98-8-4 vers 288711/98-28-6 vers 288711',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['288849', 'Quartier Saint Alban_1.xlsx', 'BS8', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NC',
#              'P-TF303G-144F-80 vers 288850/P-TF303G-144F-80 vers 288848/98-14-4 vers 288850/98-14-4 vers 288850/98-14-4 vers 288848/98-14-4 vers 288848',
#              'OKOK', '', 'NC', 'SO', 'PB', 'OK', ''],
#             ['288848', 'Quartier Saint Alban_1.xlsx', 'BS6', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G-144F-80 vers 288849/P-TF303G-144F-80 vers 288846/98-14-4 vers 288849/98-14-4 vers 288849/98-14-4 vers 288846/98-14-4 vers 288846',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['288846', 'Quartier Saint Alban_1.xlsx', 'BC7 ', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G-144F-80 vers 288848/P-TF303G-144F-80 vers 288845/A-N8227A-24F-70 vers 288847/A-N8227A-24F-70 vers 288845/98-14-4 vers 288848/98-14-4 vers 288848/98-8-4 vers 288847/98-14-4 vers 288845/98-14-4 vers 288845/98-14-4 vers 288845',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['288845', 'Quartier Saint Alban_1.xlsx', 'BS8', 'OUI', 'OUI', 'NON', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'NON', 'NC', 'Non', 'NON',
#              'P-TF303G-144F-80 vers 288846/P-TF303G-144F-80 vers 288844/A-N8227A-24F-70 vers 288846/98-14-4 vers 288846/98-14-4 vers 288846/98-14-4 vers 288846/98-56-4 vers 288844',
#              'OK', 'BS8', 'NC', 'FR8', 'PB', 'OK', ''],
#             ['288844', 'Quartier Saint Alban_1.xlsx', 'BS7', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NC',
#              'P-TF303G-144F-80 vers 288845/P-TF303G-144F-80 vers 288843/98-56-4 vers 288845/98-56-4 vers 288843',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['288843', 'Quartier Saint Alban_1.xlsx', 'MC7 MIN', 'NC', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NON', 'NC', 'Non', 'NC',
#              'P-TF303G-144F-80 vers 288844/P-TF303G-144F-80 vers 288842/98-56-4 vers 288844/98-56-4 vers 288842',
#              'INSUFFISANT', 'MC7 MIN', 'NC', 'FR7', 'Non', 'OK', 'AUT : Autre'],
#             ['288842', 'Quartier Saint Alban_1.xlsx', 'BS8', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NC',
#              'P-TF303G-144F-80 vers 288843/P-TF303G-144F-80 vers 288841/98-56-4 vers 288843/98-56-4 vers 288841',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['288841', 'Quartier Saint Alban_1.xlsx', 'MI6 ', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'OUI', 'NC', 'Non', 'NC',
#              'P-TF303G-144F-80 vers 288842/P-TF303G-144F-80 vers 288837/98-56-4 vers 288842/98-56-4 vers 288837',
#              'INSUFFISANT', 'MI6 ', 'NC', 'FR7', 'Non', 'OK', ''],
#             ['288837', 'Quartier Saint Alban_1.xlsx', 'BH7 S30', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G-144F-80 vers 288841/P-TF303G-144F-80 vers 288836/A-N9923A-12F-70 vers 288840/A-N9923A-12F-70 vers 288838/98-56-4 vers 288841/98-8-4 vers 288838/98-8-4 vers 288840/98-8-4 vers 288836/98-56-4 vers 288836',
#              'OK', '', 'NC', 'SO', 'PB', '', ''],
#             ['288836', 'Quartier Saint Alban_1.xlsx', 'BM7', 'NC', 'NON', 'NON', 'OUI', 'OUI', 'OUI', 'OUI', 'NON',
#              'NON', 'NC', 'Non', 'NC',
#              'P-TF303G-144F-80 vers 288837/P-TF303G-144F-80 vers BT0595/98-8-4 vers 288837/98-56-4 vers 288837/98-8-4 vers BT0595/98-56-4 vers BT0595',
#              'OK', 'BM7', 'NC', 'FR8', 'Non', 'OK', 'AUT : Autre'],
#             ['BT0595', 'Quartier Saint Alban_1.xlsx', 'EDF', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON', 'P-TF303G-144F-80 vers 288836/98-8-4 vers 288836/98-56-4 vers 288836', '',
#              '', 'NC', 'SO', 'Non', '', ''],
#             ['288838', 'Quartier Saint Alban_1.xlsx', 'BS8', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NC',
#              'A-N9923A-12F-70 vers 288837/A-N9923A-12F-70 vers 288839/98-8-4 vers 288837/98-8-4 vers 288839', 'OK',
#              '', 'NC', 'SO', 'Non', '', ''],
#             ['288839', 'Quartier Saint Alban_1.xlsx', 'BM8', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON', 'A-N9923A-12F-70 vers 288838/98-8-4 vers 288838', 'OK', '', 'NC', 'SO',
#              'PB', '', ''],
#             ['288840', 'Quartier Saint Alban_1.xlsx', 'MI8 ', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'OUI', 'NC', 'Non', 'NON', 'A-N9923A-12F-70 vers 288837/98-8-4 vers 288837', 'INSUFFISANT',
#              'MI8 ', 'NC', 'FR8', 'PB', 'OK', ''],
#             ['288847', 'Quartier Saint Alban_1.xlsx', 'BS7', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NC',
#              'A-N8227A-24F-70 vers 288846/A-N8227A-24F-70 vers BT0576/98-8-4 vers 288846/98-8-4 vers FT0754/Liaison vers BT0576',
#              'OK', '', 'NC', 'SO', 'PB', '', ''],
#             ['BT0576', 'Quartier Saint Alban_1.xlsx', 'EDF', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON', 'A-N8227A-24F-70 vers 288847/Liaison vers 288847', '', '', 'NC', 'SO', 'PB',
#              '', ''],
#             ['234696', 'Quartier Saint Alban_2.xlsx', '197.0', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G- 72F-80 vers 234695/P-TF303G- 72F-80 vers 234697/98-56-6 vers 234695/SACMY-36F-80 vers 234695/98-8-4 vers 234695/98-56-6 vers 234697/SACMY-36F-80 vers 234697/98-8-4 vers 234697',
#              'OKOK', '', 'NC', 'SO', 'Non', 'OK', ''],
#             ['234697', 'Quartier Saint Alban_2.xlsx', '197.0', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G- 72F-80 vers 234696/P-TF303G- 72F-80 vers 234698/98-56-6 vers 234696/SACMY-36F-80 vers 234696/98-8-4 vers 234696/98-56-6 vers 234698/SACMY-36F-80 vers 234698/98-8-4 vers 234698',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['234698', 'Quartier Saint Alban_2.xlsx', 'BS7', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G- 72F-80 vers 234697/P-TF303G- 72F-80 vers 234699/98-56-6 vers 234697/SACMY-36F-80 vers 234697/98-8-4 vers 234697/98-56-6 vers 234699/SACMY-36F-80 vers 234699/98-8-4 vers 234699',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['234699', 'Quartier Saint Alban_2.xlsx', 'BS7', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G- 72F-80 vers 234698/P-TF303G- 72F-80 vers 234700/98-56-6 vers 234698/SACMY-36F-80 vers 234698/98-8-4 vers 234698/98-56-6 vers 234700/SACMY-36F-80 vers 234700/98-8-4 vers 234700',
#              'INSUFFISANT', 'BS7', 'NC', 'M47', 'Non', 'OK', ''],
#             ['234700', 'Quartier Saint Alban_2.xlsx', 'MI7 ', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G- 72F-80 vers 234699/P-TF303G- 72F-80 vers 236228/98-56-6 vers 234699/SACMY-36F-80 vers 234699/98-8-4 vers 234699/98-56-6 vers 236228/SACMY-36F-80 vers 236228/98-8-4 vers 236228',
#              'INSUFFISANT', 'MI7 ', 'NC', 'M47', 'Non', 'OK', ''],
#             ['236228', 'Quartier Saint Alban_2.xlsx', 'MH8 S30', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G- 72F-80 vers 234700/P-TF303G- 72F-80 vers 236229/98-56-6 vers 234700/SACMY-36F-80 vers 234700/98-8-4 vers 234700/98-56-6 vers 236229/SACMY-36F-80 vers 236229/98-8-4 vers 236229',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['236229', 'Quartier Saint Alban_2.xlsx', 'BS7', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G- 72F-80 vers 236228/P-TF303G- 72F-80 vers 236230/98-56-6 vers 236228/SACMY-36F-80 vers 236228/98-8-4 vers 236228/98-56-6 vers 236230/SACMY-36F-80 vers 236230/98-8-4 vers 236230',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['236230', 'Quartier Saint Alban_2.xlsx', 'BM7', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G- 72F-80 vers 236229/P-TF303G- 72F-80 vers 236231/98-56-6 vers 236229/SACMY-36F-80 vers 236229/98-8-4 vers 236229/98-56-6 vers 236231/SACMY-36F-80 vers 236231/98-8-4 vers 236231',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['236231', 'Quartier Saint Alban_2.xlsx', 'BM7', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G- 72F-80 vers 236230/P-TF303G- 72F-80 vers 236232/98-56-6 vers 236230/SACMY-36F-80 vers 236230/98-8-4 vers 236230/98-56-6 vers 236232/SACMY-36F-80 vers 236232/98-8-4 vers 236232',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['236232', 'Quartier Saint Alban_2.xlsx', 'MC7 MIN', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G- 72F-80 vers 236231/P-TF303G- 72F-80 vers 236233/98-56-6 vers 236231/SACMY-36F-80 vers 236231/98-8-4 vers 236231/98-56-6 vers 236233/SACMY-36F-80 vers 236233/98-8-4 vers 236233',
#              'INSUFFISANT', 'MC7 MIN', 'NC', 'MC7 MAX', 'PB', 'OK', ''],
#             ['236233', 'Quartier Saint Alban_2.xlsx', 'BS7', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G- 72F-80 vers 236232/P-TF303G- 72F-80 vers 236234/98-56-6 vers 236232/SACMY-36F-80 vers 236232/98-8-4 vers 236232/98-56-6 vers 236234/SACMY-36F-80 vers 236234/98-8-4 vers 236234',
#              'INSUFFISANT', 'BS7', 'NC', 'BC7 ', 'Non', 'OK', ''],
#             ['236234', 'Quartier Saint Alban_2.xlsx', 'BS7', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G- 72F-80 vers 236233/P-TF303G- 72F-80 vers 236235/98-56-6 vers 236233/SACMY-36F-80 vers 236233/98-8-4 vers 236233/98-56-6 vers 236235/SACMY-36F-80 vers 236235/98-8-4 vers 236235',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['236235', 'Quartier Saint Alban_2.xlsx', 'BS7', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G- 72F-80 vers 236234/P-TF303G- 72F-80 vers 236236/98-56-6 vers 236234/SACMY-36F-80 vers 236234/98-8-4 vers 236234/98-56-6 vers 236236/SACMY-36F-80 vers 236236/98-8-4 vers 236236',
#              'INSUFFISANT', 'BS7', 'NC', 'BC7 ', 'Non', 'OK', ''],
#             ['236236', 'Quartier Saint Alban_2.xlsx', 'BC7 ', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G- 72F-80 vers 236235/P-TF303G- 72F-80 vers 288815/98-56-6 vers 236235/SACMY-36F-80 vers 236235/98-8-4 vers 236235/98-56-6 vers 288815/SACMY-36F-80 vers 288815/98-8-4 vers 288815',
#              'OK', '', 'NC', 'SO', 'Non', '', '\r\n'],
#             ['288815', 'Quartier Saint Alban_2.xlsx', 'BC8 ', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G- 72F-80 vers 236236/P-TF303G- 72F-80 vers 288814/98-56-6 vers 236236/SACMY-36F-80 vers 236236/98-8-4 vers 236236/98-56-6 vers 288814/SACMY-36F-80 vers 288814/98-8-4 vers 288814',
#              'OK', '', 'NC', 'SO', 'PB', '', ''],
#             ['288814', 'Quartier Saint Alban_2.xlsx', 'MC8 MIN', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G- 72F-80 vers 288815/P-TF303G- 72F-80 vers 288813/98-56-6 vers 288815/SACMY-36F-80 vers 288815/98-8-4 vers 288815/98-56-6 vers 288813/SACMY-36F-80 vers 288813/98-8-4 vers 288813',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['288813', 'Quartier Saint Alban_2.xlsx', 'MC8 MIN', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G- 72F-80 vers 288814/P-TF303G- 72F-80 vers 288812/98-56-6 vers 288814/SACMY-36F-80 vers 288814/98-8-4 vers 288814/98-56-6 vers 288812/SACMY-36F-80 vers 288812/98-8-4 vers 288812',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['288812', 'Quartier Saint Alban_2.xlsx', 'BH7 S30', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G- 72F-80 vers 288813/P-TF303G- 72F-80 vers 288811/98-56-6 vers 288813/SACMY-36F-80 vers 288813/98-8-4 vers 288813/98-56-6 vers 288811/SACMY-36F-80 vers 288811/98-8-4 vers 288811',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['288811', 'Quartier Saint Alban_2.xlsx', 'MI8 ', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'OUI', 'NC', 'Non', 'NC',
#              'P-TF303G- 72F-80 vers 288812/P-TF303G- 72F-80 vers 288810/98-56-6 vers 288812/SACMY-36F-80 vers 288812/98-8-4 vers 288812/98-56-6 vers 288810/SACMY-36F-80 vers 288810/98-8-4 vers 288810',
#              'INSUFFISANT', 'MI8 ', 'NC', 'MH8 S45', 'PB', 'OK', ''],
#             ['288810', 'Quartier Saint Alban_2.xlsx', 'MH8 S30', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'OUI', 'NC', 'Non', 'NC',
#              'P-TF303G- 72F-80 vers 288811/P-TF303G- 72F-80 vers 288809/98-56-6 vers 288811/SACMY-36F-80 vers 288811/98-8-4 vers 288811/98-56-6 vers 288809/SACMY-36F-80 vers 288809/98-8-4 vers 288809',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['288809', 'Quartier Saint Alban_2.xlsx', 'MC8 MIN', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G- 72F-80 vers 288810/P-TF303G- 72F-80 vers 288808/P-TF303G-144F-80 vers BT0595/P-TF303G-144F-80 vers 288808/98-56-6 vers 288810/SACMY-36F-80 vers 288810/98-8-4 vers 288810/98-8-4 vers BT0595/98-56-4 vers BT0595/98-56-6 vers 288808/98-28-6 vers 288808/SACMY-36F-80 vers 288808',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['288808', 'Quartier Saint Alban_2.xlsx', 'MI8 ', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G- 72F-80 vers 288809/P-TF303G- 72F-80 vers 288807/P-TF303G-144F-80 vers 288809/P-TF303G-144F-80 vers 288807/98-56-6 vers 288809/98-28-6 vers 288809/SACMY-36F-80 vers 288809/98-56-6 vers 288807/98-28-6 vers 288807/SACMY-36F-80 vers 288807',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['288807', 'Quartier Saint Alban_2.xlsx', 'BC6 ANC', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G- 72F-80 vers 288808/P-TF303G-144F-80 vers 288808/98-56-6 vers 288808/98-28-6 vers 288808/SACMY-36F-80 vers 288808',
#              'OK', '', 'NC', 'SO', 'PB', '', ''],
#             ['BT0595', 'Quartier Saint Alban_2.xlsx', 'EDF', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON', 'P-TF303G-144F-80 vers 288809/98-8-4 vers 288809/98-56-4 vers 288809', '',
#              '', 'NC', 'SO', '', '', ''],
#             ['BT0817', 'Quartier Saint Julien.xlsx', 'EDF', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON', 'P-TF303G- 96F-80 vers 288690/Liaison vers 288690', 'OK', '', 'NC', 'SO',
#              '', 'OK', ''],
#             ['288690', 'Quartier Saint Julien.xlsx', 'BH7 S30', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G- 96F-80 vers BT0817/P-TF303G- 96F-80 vers 288689/Liaison vers BT0817/Liaison vers 288689',
#              'OK', '', 'NC', 'SO', 'PB', '', ''],
#             ['288689', 'Quartier Saint Julien.xlsx', 'BS6', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G- 96F-80 vers 288690/P-TF303G- 96F-80 vers 288688/Liaison vers 288690/Liaison vers 288688',
#              'OK', '', 'NC', 'SO', 'PB', '', ''],
#             ['288688', 'Quartier Saint Julien.xlsx', 'BH7 S30', 'OUI', 'NON', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NON', 'NC', 'Non', 'NC',
#              'A-N9923A-12F-70 vers BT0811/A-N9923A-12F-70 vers 288687/P-TF303G- 96F-80 vers 288689/P-TF303G- 96F-80 vers 288687/Liaison vers 288689/98-8-6 vers BT0811/98-8-6 vers 288687',
#              'OK', '', 'NC', 'SO', 'PB', '', ''],
#             ['288687', 'Quartier Saint Julien.xlsx', 'BH8 S30', 'NC', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NON', 'NC', 'Non', 'NC',
#              'A-N9923A-12F-70 vers 288688/P-TF303G-288F-80 vers 288686/P-TF303G- 96F-80 vers 288688/98-8-6 vers 288688/98-8-6 vers 288686',
#              'OK', 'BH8 S30', 'NC', 'MH8 S30', 'PB', 'OK', 'Haubanné Cassé\r\nCHO : Choc'],
#             ['288686', 'Quartier Saint Julien.xlsx', 'MI8 ', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G-288F-80 vers 288687/P-TF303G-288F-80 vers 288685/A-N9923A-12F-70 vers BT0814/98-8-6 vers 288687/Liaison vers BT0814/98-14-6 vers 288685',
#              'OK', '', 'NC', 'SO', 'PB', '', ''],
#             ['288685', 'Quartier Saint Julien.xlsx', 'BC8 ', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NC',
#              'P-TF303G-288F-80 vers 288686/P-TF303G-288F-80 vers BT0813/98-14-6 vers 288686/98-14-6 vers BT0813',
#              'OK', '', 'NC', 'SO', 'Non', '', 'Elagage necessaire'],
#             ['BT0813', 'Quartier Saint Julien.xlsx', 'EDF', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON', 'P-TF303G-288F-80 vers 288685/98-14-6 vers 288685', '', '', 'NC', 'SO', '',
#              '', ''],
#             ['BT0811', 'Quartier Saint Julien.xlsx', 'EDF', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON', 'A-N9923A-12F-70 vers 288688/98-8-6 vers 288688', '', '', 'NC', 'SO', '',
#              '', ''],
#             ['BT0814', 'Quartier Saint Julien.xlsx', 'EDF', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON', 'A-N9923A-12F-70 vers 288686/Liaison vers 288686', '', '', 'NC', 'SO', 'PB',
#              '', ''],
#             ['BT0058', 'QUARTIER SAINT OSTIAN.xlsx', 'EDF', 'NON', 'NON', 'NON', 'NON', 'OUI', 'NON', 'OUI', 'NON',
#              'NON', 'NC', 'Non', 'NON', 'P-TF303G- 48F-80 vers 021769/98-14-6 vers BT0059/98-14-6 vers 021769',
#              'OK', '', 'NC', 'SO', '', 'OK', ''],
#             ['021769', 'QUARTIER SAINT OSTIAN.xlsx', 'MH8 S30', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G- 48F-80 vers BT0058/P-TF303G- 48F-80 vers 021768/98-14-6 vers BT0059/98-14-6 vers 021768',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['021768', 'QUARTIER SAINT OSTIAN.xlsx', 'BM8', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G- 48F-80 vers 021769/P-TF303G- 48F-80 vers 021767/98-14-6 vers 021767/98-14-6 vers 021769',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['021767', 'QUARTIER SAINT OSTIAN.xlsx', 'MH8 S30', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G- 48F-80 vers 021768/P-TF303G- 48F-80 vers 021766/98-14-6 vers 021768/98-14-6 vers 021766',
#              'INSUFFISANT', 'MH8 S30', 'NC', 'M48', 'Non', 'OK', ''],
#             ['021766', 'QUARTIER SAINT OSTIAN.xlsx', 'BS8', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G- 48F-80 vers 021767/P-TF303G- 48F-80 vers 021765/98-14-6 vers 021767/98-14-6 vers 021765',
#              'OK', '', 'NC', 'SO', 'PB', '', ''],
#             ['021765', 'QUARTIER SAINT OSTIAN.xlsx', 'BH8 S30', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G- 48F-80 vers 021766/P-TF303G- 48F-80 vers 021764/98-14-6 vers 021766/98-14-6 vers 021764',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['021764', 'QUARTIER SAINT OSTIAN.xlsx', 'BM8', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G- 48F-80 vers 021765/P-TF303G- 48F-80 vers BT0378/98-14-6 vers 021765/98-14-6 vers BT0378/5/10 vers BT0378/5/10 vers BT0453',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['BT0378', 'QUARTIER SAINT OSTIAN.xlsx', 'EDF', 'NON', 'NON', 'NON', 'NON', 'NON', 'NON', 'OUI', 'NON',
#              'NON', 'NC', 'Non', 'NON',
#              'P-TF303G- 48F-80 vers 021764/P-TF303G- 48F-80 vers 024763/98-14-6 vers 021764/5/10 vers 021764/98-14-6 vers 024763/98-8-6 vers 024763',
#              '', '', 'NC', 'SO', '', '', ''],
#             ['024763', 'QUARTIER SAINT OSTIAN.xlsx', 'BC8 ', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G- 48F-80 vers BT0378/P-TF303G-288F-80 vers 021761/98-14-6     vers BT0378/98-8-6     vers BT0378/98-14-6     vers 021761/98-8-6     vers 021761',
#              'INSUFFISANT', 'BC8 ', 'NC', 'BC8 ANC', 'Non', 'OK', ''],
#             ['021761', 'QUARTIER SAINT OSTIAN.xlsx', 'BS7', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G-288F-80 vers 024763/P-TF303G-288F-80 vers 021760/98-14-6     vers 024763/98-8-6     vers 024763/98-14-6     vers 021760/98-8-6     vers 021760',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['021760', 'QUARTIER SAINT OSTIAN.xlsx', 'BS8', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G-288F-80 vers 021761/P-TF303G-288F-80 vers 021759/98-14-6     vers 021761/98-8-6     vers 021761/98-14-6 vers 021759/98-8-6 vers 021759',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['021759', 'QUARTIER SAINT OSTIAN.xlsx', 'BS7', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G-288F-80 vers FT0298/P-TF303G-288F-80 vers 021757/P-TF303G- 12F-80 vers 021757/98-14-6 vers FT0298/98-8-6 vers FT0298/98-14-6 vers 021757/98-8-6 vers 021757',
#              'OK', '', 'NC', 'SO', 'PB', '', ''],
#             ['021757', 'QUARTIER SAINT OSTIAN.xlsx', 'BS6', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G-288F-80 vers 021759/P-TF303G-288F-80 vers 021756/P-TF303G- 12F-80 vers 021759/98-14-6 vers 021759/98-8-6 vers 021759/5/10 vers 021756/98-14-6 vers 021756/98-8-6 vers 021756/5/10 vers 021758',
#              'INSUFFISANT', 'BS6', 'NC', 'BH6 S30', 'PB', 'OK', ''],
#             ['021756', 'QUARTIER SAINT OSTIAN.xlsx', 'BS6', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G-288F-80 vers 021757/P-TF303G-288F-80 vers 0421087/5/10 vers 021757/98-14-6 vers 021757/98-8-6 vers 021757/5/10 vers 0421087/98-14-6 vers 0421087/98-8-6 vers 0421087',
#              'INSUFFISANT', 'BS6', 'NC', 'M47', 'Non', 'OK', ''],
#             ['0421087', 'QUARTIER SAINT OSTIAN.xlsx', 'BS8', 'OUI', 'OUI', 'OUI', 'NON', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G-288F-80 vers 021756/P-TF303G-288F-80 vers 021755/5/10 vers 021756/98-14-6 vers 021756/98-8-6 vers 021756/98-14-6 vers 021755/98-8-6 vers 021755',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['021755', 'QUARTIER SAINT OSTIAN.xlsx', 'BS8', 'NON', 'NON', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NON',
#              'NON', 'NC', 'Non', 'NON',
#              'P-TF303G-288F-80 vers 0421087/P-TF303G-288F-80 vers 021694/98-14-6     vers 0421087/98-8-6     vers 0421087/98-14-6     vers 021694/98-8-6     vers 021694',
#              'OK', 'BS8', 'NC', 'M48', '', 'OK', ''],
#             ['021694', 'QUARTIER SAINT OSTIAN_2.xlsx', 'BC8 ', 'NC', 'NON', 'NON', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NON', 'NC', 'Non', 'NON',
#              'P-TF303G- 72F-80 vers 195789/98-14-6 vers 195789/98-14-6 vers 195789/98-14-6 vers 021755/98-8-6 vers 021755/98-28-6 vers 021693/98-28-6 vers 021693',
#              'OKOK', 'BC8 ', 'NC', 'M48', 'PEO', 'OKOK', ''],
#             ['195789', 'QUARTIER SAINT OSTIAN_2.xlsx', 'BS7', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G- 72F-80 vers 021694/P-TF303G- 72F-80 vers 195790/98-14-6 vers 021694/98-14-6 vers 021694/98-14-6 vers 195790/98-14-6 vers 195790',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['195790', 'QUARTIER SAINT OSTIAN_2.xlsx', 'BH8 S30', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G- 72F-80 vers 195789/P-TF303G- 72F-80 vers 021697/98-14-6 vers 195789/98-14-6 vers 195789/98-14-6 vers 021697/98-14-6 vers 021697',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['021697', 'QUARTIER SAINT OSTIAN_2.xlsx', 'BS8', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G- 72F-80 vers 195790/P-TF303G- 72F-80 vers 021698/98-14-6 vers 195790/98-14-6 vers 195790/98-14-6 vers 021698/98-14-6 vers 021698',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['021698', 'QUARTIER SAINT OSTIAN_2.xlsx', 'BH8 S30', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G- 72F-80 vers 021697/P-TF303G- 72F-80 vers POT_07346_DA_6041/98-14-6     vers 021697/98-14-6     vers 021697/98-14-6     vers 021699/98-14-6     vers 021699',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['POT_07346_DA_6041', 'QUARTIER SAINT OSTIAN_2.xlsx', 'FR8', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'OUI', 'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G- 72F-80 vers 021698/P-TF303G- 72F-80 vers 021699/98-14-6 vers 021698/98-14-6 vers 021698/98-14-6 vers 021699/98-8-6 vers 021699',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['021699', 'QUARTIER SAINT OSTIAN_2.xlsx', 'BC7 ', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G- 72F-80 vers POT_07346_DA_6041/P-TF303G- 72F-80 vers 021701/98-14-6     vers 021698/98-8-6     vers 021698/98-14-6     vers 021701/98-8-6     vers 021701/98-14-6     vers 021701/98-14-6     vers 021701/Liaison vers FT0301',
#              'OK', '', 'NC', 'SO', 'PB', '', ''],
#             ['021701', 'QUARTIER SAINT OSTIAN_2.xlsx', 'BS8', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G- 72F-80 vers 021699/P-TF303G- 72F-80 vers 021702/98-14-6 vers 021699/98-8-6 vers 021699/98-14-6 vers 021699/98-14-6 vers 021699/98-14-6 vers 021702/98-14-6 vers 021702',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['021702', 'QUARTIER SAINT OSTIAN_2.xlsx', 'BH8 S30', 'NC', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'NON', 'NON', 'NC', 'Non', 'NON',
#              'P-TF303G- 72F-80 vers 021701/P-TF303G- 72F-80 vers 021703/P-TF303G- 48F-80 vers 021703/98-14-6 vers 021701/98-14-6 vers 021701/98-14-6 vers 021703/98-8-6 vers 021703',
#              'OK', 'BH8 S30', 'NC', 'M48', 'PEO', 'OK', ''],
#             ['021703', 'QUARTIER SAINT OSTIAN_2.xlsx', 'BS8', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G- 72F-80 vers 021707/P-TF303G- 24F-80 vers 195791/P-TF303G- 48F-80 vers 021702/98-14-6     vers 021702/98-8-6     vers 021702/98-14-6     vers 021707/98-14-6     vers 021707',
#              'INSUFFISANT', 'BS8', 'NC', 'M48', 'PEO', 'OK', ''],
#             ['195791', 'QUARTIER SAINT OSTIAN_2.xlsx', 'BS8', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G- 24F-80 vers 021703/P-TF303G- 24F-80 vers 021705/Liaison vers 021705/98-14-6 vers 021705/Liaison vers 021707/98-14-6 vers 021707',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['021705', 'QUARTIER SAINT OSTIAN_2.xlsx', 'BS8', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G- 24F-80 vers 195791/P-TF303G- 24F-80 vers 021706/Liaison vers 195791/98-14-6 vers 195791/Liaison vers 021706/98-14-6 vers 021706',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['021706', 'QUARTIER SAINT OSTIAN_2.xlsx', 'BS7', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G- 24F-80 vers 021705/P-TF303G- 24F-80 vers BT0536/Liaison vers 021705/98-14-6 vers 021705/98-8-6 vers BT0536',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['BT0536', 'QUARTIER SAINT OSTIAN_2.xlsx', 'EDF', 'NON', 'NON', 'NON', 'NON', 'OUI', 'NON', 'OUI',
#              'NON', 'NON', 'NC', 'Non', 'NON', 'P-TF303G- 24F-80 vers 021706/98-8-6 vers 021706/98-8-6 vers FT0640',
#              '', '', 'NC', 'SO', '', '', ''],
#             ['021707', 'QUARTIER SARRAZIN.xlsx', 'BC8 ', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G- 12F-80 vers BT0380/P-TF303G- 48F-80 vers 021708/98-14-6 vers 021708/98-14-6 vers 021703/98-14-6 vers 021703/Liaison vers 195791/98-14-6 vers 195791/Liaison vers BT0060/Liaison vers BT0380',
#              'OKOK', '', 'NC', 'SO', 'Non', 'OK', ''],
#             ['BT0380', 'QUARTIER SARRAZIN.xlsx', 'EDF', 'NON', 'NON', 'NON', 'NON', 'OUI', 'NON', 'OUI', 'NON',
#              'NON', 'NC', 'Non', 'NON', 'P-TF303G- 12F-80 vers 021707/Liaison vers 021707', '', '', 'NC', 'SO', '',
#              '', ''],
#             ['021708', 'QUARTIER SARRAZIN.xlsx', 'BS8', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G- 48F-80 vers 021707/P-TF303G- 48F-80 vers 021709/98-14-6 vers 021707/98-14-6 vers 021709',
#              'OK', '', 'NC', 'SO', '', '', ''],
#             ['021709', 'QUARTIER SARRAZIN.xlsx', '197.0', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NON',
#              'NON', 'NC', 'Non', 'NON',
#              'P-TF303G- 48F-80 vers 021708/P-TF303G- 48F-80 vers 021710/98-14-6 vers 021708/98-14-6 vers 021710',
#              'OK', '197.0', 'NC', 'MI7 ', '', 'OK', ''],
#             ['021710', 'QUARTIER SARRAZIN.xlsx', '198.0', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NON',
#              'NON', 'NC', 'Non', 'NON',
#              'P-TF303G- 48F-80 vers 021709/P-TF303G- 48F-80 vers 021711/98-14-6 vers 021709/98-14-6 vers 021711',
#              'OK', '198.0', 'NC', 'FR8', 'Non', 'OK', ''],
#             ['021711', 'QUARTIER SARRAZIN.xlsx', 'BS7', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G- 48F-80 vers 021710/P-TF303G- 48F-80 vers 002171/98-14-6 vers 021710/98-14-6 vers 002171/Liaison vers BT0126',
#              'OK', '', 'NC', 'SO', 'PB', '', ''],
#             ['002171', 'QUARTIER SARRAZIN.xlsx', 'BC8', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G- 48F-80 vers 021711/P-TF303G- 48F-80 vers 195792/98-14-6 vers 021711/98-8-6 vers 195792/Liaison vers 195792/98-8-6 vers 195792',
#              'OK', '', 'NC', 'SO', '', '', ''],
#             ['195792', 'QUARTIER SARRAZIN.xlsx', 'BH8 S30', 'OUI', 'OUI', 'OUI', 'NON', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G- 48F-80 vers 002171/P-TF303G- 48F-80 vers 195793/98-8-6 vers 002171/Liaison vers 002171/98-8-6 vers 002171/Liaison vers 195793/98-8-6 vers 195793/98-8-6 vers 195793',
#              'OK', '', 'NC', 'SO', '', '', ''],
#             ['195793', 'QUARTIER SARRAZIN.xlsx', 'BS7', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G- 48F-80 vers 195792/P-TF303G- 48F-80 vers 021715/Liaison vers 195792/98-8-6 vers 195792/98-8-6 vers 195792/Liaison vers 021715/98-8-6 vers 021715/98-8-6 vers 021715',
#              'OK', '', 'NC', 'SO', '', '', ''],
#             ['021715', 'QUARTIER SARRAZIN.xlsx', 'BS8', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G- 48F-80 vers 195793/P-TF303G- 48F-80 vers 021716/Liaison vers 195793/98-8-6     vers 195793/98-8-6     vers 195793/Liaison vers 021716/98-8-6 vers 021716/98-8-6 vers 021716',
#              'OK', '', 'NC', 'SO', '', '', ''],
#             ['021716', 'QUARTIER SARRAZIN.xlsx', 'BS8', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G- 48F-80 vers 021715/P-TF303G- 48F-80 vers 0021717/Liaison vers 021715/98-8-6 vers 021715/98-8-6 vers 021715/Liaison vers 0021717/98-8-6 vers 0021717/98-8-6 vers 0021717',
#              'OK', '', 'NC', 'SO', '', '', ''],
#             ['0021717', 'QUARTIER SARRAZIN.xlsx', 'BS7', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G- 48F-80 vers 021716/P-TF303G- 24F-80 vers 021718/Liaison vers 021716/98-8-6 vers 021716/98-8-6 vers 021716/Liaison vers BT0541/98-8-6 vers 021718',
#              'INSUFFISANT', 'BS7', 'NC', 'M47', 'PB', 'OK', ''],
#             ['021581', 'QUARTIER VALFLEURY 2.xlsx', 'BM8', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G-288F-80 vers 195794/P-TF303G- 24F-80 vers BT0390/P-TF303G- 24F-80 vers 0421076/P-TF303G-288F-80 vers 0421076/98-28-6     vers 0421076/98-28-6     vers 0421076/98-56-6     vers 0421076/Liaison vers BT0130/98-8-6     vers BT0390/98-28-6     vers 195794/98-28-6     vers 195794/98-56-6     vers 195794',
#              'OKINSUFFISANT', '', 'NC', 'SO', 'Non', 'OK', 'REMPLACEMENT PAR AEOP'],
#             ['195794', 'QUARTIER VALFLEURY 2.xlsx', 'BC8 ', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G-288F-80 vers 021581/P-TF303G-288F-80 vers 021583/98-28-6     vers 021581/98-28-6     vers 021581/98-56-6     vers 021581/98-28-6     vers 021581/98-56-6     vers 021583/98-28-6 vers 021583/5/10 vers FA0169',
#              'INSUFFISANT', 'BC8 ', 'NC', 'BC8 ANC', 'Non', 'OK', ''],
#             ['021583', 'QUARTIER VALFLEURY 2.xlsx', 'BM8', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G-288F-80 vers 195794/P-TF303G-288F-80 vers 021584/98-56-6     vers 195794/98-28-6     vers 195794/98-14-6     vers 195794/98-28-6     vers 021584/98-28-6 vers 021584/98-56-6 vers 021584',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['021584', 'QUARTIER VALFLEURY 2.xlsx', 'BM8', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G-288F-80 vers 021585/P-TF303G-288F-80 vers 021583/98-28-6     vers 021583/98-28-6     vers 021583/98-56-6     vers 021583/98-56-6     vers 021585/98-28-6     vers 021585/98-28-6     vers 021585',
#              'INSUFFISANT', '', 'NC', 'SO', 'Non', '', 'REMPLACEMENT AEOP'],
#             ['021585', 'QUARTIER VALFLEURY 2.xlsx', 'BS8', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G-288F-80 vers 021584/P-TF303G-288F-80 vers 021586/98-56-6     vers 021584/98-28-6     vers 021584/98-28-6     vers 021584/98-56-6     vers 021586/98-28-6 vers 021586/98-28-6 vers 021586',
#              'INSUFFISANT', 'BS8', 'NC', 'BC8 ', 'Non', 'OK', ''],
#             ['021586', 'QUARTIER VALFLEURY 2.xlsx', 'BH7 S30', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G-288F-80 vers 021585/P-TF303G-288F-80 vers 021587/98-56-6     vers 021585/98-28-6     vers 021585/98-28-6     vers 021585/98-56-6     vers 021587/98-28-6 vers 021587/98-28-6 vers 021587',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['021587', 'QUARTIER VALFLEURY 2.xlsx', 'BC8', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G-288F-80 vers 021586/P-TF303G-288F-80 vers 021592/98-56-6     vers 021586/98-28-6     vers 021586/98-28-6     vers 021586/5/10 vers 021588/98-56-6     vers 021592/98-28-6 vers 021592/98-28-6 vers 021592',
#              'OK', '', 'NC', 'SO', '', '', ''],
#             ['021592', 'QUARTIER VALFLEURY 2.xlsx', 'BC8 ANC', 'NC', 'NON', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'NON', 'NON', 'NC', 'Non', 'NON',
#              'P-TF303G-288F-80 vers 021587/P-TF303G-288F-80 vers 021593/98-56-6     vers 021587/98-28-6     vers 021587/98-28-6     vers 021587/98-56-6     vers 021593/98-28-6 vers 021593/98-28-6 vers 021593',
#              'OK', '', 'NC', 'SO', 'Non', '', 'REMPLACEMENT AEOP'],
#             ['021593', 'QUARTIER VALFLEURY 2.xlsx', 'BH8 S30', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G-288F-80 vers 021592/P-TF303G-288F-80 vers 021594/P-TF303G- 12F-80 vers 021594/98-56-6     vers 021592/98-28-6     vers 021592/98-28-6     vers 021592/98-56-6     vers 021594/98-28-6 vers 021594/98-28-6 vers 021594',
#              'OK', '', 'NC', 'SO', 'PB', '', ''],
#             ['021594', 'QUARTIER VALFLEURY 2.xlsx', 'BH8 S30', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G-288F-80 vers 021593/P-TF303G-288F-80 vers 021595/P-TF303G- 12F-80 vers 021593/P-TF303G- 12F-80 vers 021595/98-56-6     vers 021593/98-28-6     vers 021593/98-28-6     vers 021593/98-28-6     vers 021595/98-28-6 vers 021595/98-56-6 vers 021595',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['021595', 'QUARTIER VALFLEURY 2.xlsx', 'BS8', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G-288F-80 vers 021594/P-TF303G-288F-80 vers 021596/P-TF303G- 12F-80 vers 021594/P-TF303G- 12F-80 vers 021596/98-28-6     vers 021594/98-28-6     vers 021594/98-56-6     vers 021594/98-28-6     vers 021596/98-28-6 vers 021596/98-56-6 vers 021596',
#              'INSUFFISANT', 'BS8', 'NC', 'FR8', 'Non', 'OK', ''],
#             ['021596', 'QUARTIER VALFLEURY 2.xlsx', 'BH8 S30', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G-288F-80 vers 021595/P-TF303G-288F-80 vers 021597/P-TF303G- 12F-80 vers 021595/P-TF303G- 12F-80 vers 021597/98-28-6     vers 021595/98-28-6     vers 021595/98-56-6     vers 021595/98-56-6     vers 021597/98-28-6 vers 021597',
#              'INSUFFISANT', '', 'NC', 'SO', 'Non', '', 'REMPLACEMENT AEOP'],
#             ['021597', 'QUARTIER VALFLEURY 2.xlsx', 'BS7', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G- 12F-80 vers 021596/P-TF303G-288F-80 vers 021596/P-TF303G- 96F-80 vers 021598/P-TF303G- 96F-80 vers 021598/98-56-6     vers 021596/98-28-6     vers 021596/98-56-6     vers 021598/98-28-6 vers 021598',
#              'INSUFFISANT', 'BS7', 'NC', 'FR7', 'Non', 'OK', ''],
#             ['021598', 'QUARTIER VALFLEURY 2.xlsx', 'MC7 MIN', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G- 96F-80 vers 021597/P-TF303G- 96F-80 vers 021597/P-TF303G- 96F-80 vers 021599/P-TF303G- 96F-80 vers 021599/98-56-6     vers 021597/98-28-6     vers 021597/98-56-6     vers 021599/98-28-6 vers 021599',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['021599', 'QUARTIER VALFLEURY 2.xlsx', 'MH7 S30', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G- 96F-80 vers 021598/P-TF303G- 96F-80 vers 021598/P-TF303G- 96F-80 vers 021600/P-TF303G- 96F-80 vers 021600/98-56-6     vers 021598/98-28-6     vers 021598/98-56-6     vers 021600/98-28-6 vers 021600',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['021600', 'QUARTIER VALFLEURY 2.xlsx', 'BS8', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G- 96F-80 vers 021599/P-TF303G- 96F-80 vers 021599/P-TF303G- 96F-80 vers 021608/P-TF303G- 96F-80 vers 021608/98-56-6     vers 021599/98-28-6     vers 021599/5/10 vers 021601/5/10 vers 021601/5/10 vers BT0258/98-56-6     vers 021608/98-14-6 vers 021608/5/10 vers 021608',
#              'INSUFFISANT', 'BS8', 'NC', 'FR8', 'PB', 'OK', ''],
#             ['021608', 'QUARTIER VALFLEURY 3.xlsx', 'BS7', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G- 96F-80 vers 021600/P-TF303G- 96F-80 vers 021600/P-TF303G- 96F-80 vers 021609/P-TF303G- 96F-80 vers 021609/98-56-6 vers 021600/98-14-6 vers 021600/5/10 vers 021600/98-56-6 vers 021609/98-14-6 vers 021609/5/10 vers 021609',
#              'OKOK', '', 'NC', 'SO', 'Non', 'OK', ''],
#             ['021609', 'QUARTIER VALFLEURY 3.xlsx', 'BH8 S30', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G- 96F-80 vers 021608/P-TF303G- 96F-80 vers 021608/P-TF303G- 96F-80 vers 195795/P-TF303G- 96F-80 vers 195795/98-56-6 vers 021608/98-14-6 vers 021608/5/10 vers 021608/98-56-6 vers 195795/98-14-6 vers 195795/5/10 vers 195795',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['195795', 'QUARTIER VALFLEURY 3.xlsx', 'BH8 S30', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G- 96F-80 vers 021609/P-TF303G- 96F-80 vers 021609/P-TF303G- 96F-80 vers 021611/P-TF303G- 96F-80 vers 021611/98-56-6 vers 021609/98-14-6 vers 021609/5/10 vers 021609/98-56-6 vers 021611/98-14-6 vers 021611/5/10 vers 021611',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['021611', 'QUARTIER VALFLEURY 3.xlsx', 'BS8', 'NC', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'NON', 'NC', 'Non', 'NON',
#              'P-TF303G- 96F-80 vers 195795/P-TF303G- 96F-80 vers 195795/P-TF303G- 96F-80 vers 021612/P-TF303G- 96F-80 vers 021612/98-56-6 vers 195795/98-14-6 vers 195795/5/10 vers 195795/98-56-6 vers 021612/98-14-6 vers 021612',
#              'INSUFFISANT', 'BS8', 'NC', 'FR8', 'Non', 'OK', ''],
#             ['021612', 'QUARTIER VALFLEURY 3.xlsx', 'BM8', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G- 96F-80 vers 021611/P-TF303G- 96F-80 vers 021611/P-TF303G- 96F-80 vers 021613/P-TF303G- 96F-80 vers 021613/98-56-6 vers 021611/98-14-6 vers 021611/98-14-6 vers 021613/98-56-6 vers 021613',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['021613', 'QUARTIER VALFLEURY 3.xlsx', 'BS7', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G- 96F-80 vers 021612/P-TF303G- 96F-80 vers 021612/P-TF303G- 96F-80 vers 021614/P-TF303G- 96F-80 vers 021614/98-14-6 vers 021612/98-56-6 vers 021612/98-14-6 vers 021614/98-56-6 vers 021614',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['021614', 'QUARTIER VALFLEURY 3.xlsx', 'BS8', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G- 96F-80 vers 021613/P-TF303G- 96F-80 vers 021613/P-TF303G- 96F-80 vers 021615/P-TF303G- 96F-80 vers 021615/98-14-6     vers 021613/98-56-6     vers 021613/98-14-6     vers 021615/98-56-6 vers 021615',
#              'INSUFFISANT', 'BS8', 'NC', 'FR8', 'Non', 'OK', ''],
#             ['021615', 'QUARTIER VALFLEURY 3.xlsx', 'BH8 S30', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G- 96F-80 vers 021614/P-TF303G- 96F-80 vers 021614/P-TF303G- 96F-80 vers 021619/P-TF303G- 96F-80 vers 021619/P-TF303G- 48F-80 vers BT0265/98-14-6     vers 021614/98-56-6     vers 021614/5/10 vers 0421078/5/10 vers 0421078/98-14-6     vers 0421078/Liaison vers BT0393/98-56-6     vers 021619',
#              'OK', '', 'NC', 'SO', 'PB', '', ''],
#             ['021619', 'QUARTIER VALFLEURY 3.xlsx', 'BS7', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G- 96F-80 vers 021615/P-TF303G- 96F-80 vers 021615/P-TF303G- 96F-80 vers 021620/P-TF303G- 96F-80 vers 021620/98-56-6     vers 021615/98-56-6     vers 021620',
#              'INSUFFISANT', 'BS7', 'NC', 'MI7 ', 'Non', 'OK', ''],
#             ['021620', 'QUARTIER VALFLEURY 3.xlsx', 'MI7 ', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G- 96F-80 vers 021619/P-TF303G- 96F-80 vers 021619/P-TF303G- 96F-80 vers 021621/P-TF303G- 96F-80 vers 021621/98-56-6     vers 021619/98-56-6     vers 021621',
#              'INSUFFISANT', 'MI7 ', 'NC', 'FR7', 'Non', 'OK', ''],
#             ['021621', 'QUARTIER VALFLEURY 3.xlsx', 'BH8 S30', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G- 96F-80 vers 021620/P-TF303G- 96F-80 vers 021620/P-TF303G- 96F-80 vers 021622/P-TF303G- 96F-80 vers 021622/98-56-6     vers 021620/98-56-6     vers 021622',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['021622', 'QUARTIER VALFLEURY 3.xlsx', 'MI7 ', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G- 96F-80 vers 021621/P-TF303G- 96F-80 vers 021621/P-TF303G- 96F-80 vers 021623/P-TF303G- 96F-80 vers 021623/98-56-6     vers 021621/98-56-6     vers 021623',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['021623', 'QUARTIER VALFLEURY 3.xlsx', 'BM7', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G- 96F-80 vers 021622/P-TF303G- 96F-80 vers 021622/P-TF303G- 96F-80 vers 021624/P-TF303G- 96F-80 vers 021624/98-56-6     vers 021622/98-56-6     vers 021624',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['021624', 'QUARTIER VALFLEURY 3.xlsx', 'BM7', 'OUI', 'OUI', 'OUI', 'NON', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G- 96F-80 vers 021623/P-TF303G- 96F-80 vers 021623/P-TF303G- 96F-80 vers 021625/P-TF303G- 96F-80 vers 021625/98-56-6     vers 021623/98-56-6     vers 021625',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['021625', 'QUARTIER VALFLEURY 3.xlsx', 'BH7 S30', 'NC', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'NON', 'NON', 'NC', 'Non', 'NON',
#              'P-TF303G- 96F-80 vers 021624/P-TF303G- 96F-80 vers 021624/P-TF303G- 96F-80 vers 021626/P-TF303G- 96F-80 vers 021626/98-56-6     vers 021624/Liaison vers BT0075/98-56-6     vers 021626',
#              'OK', 'BH7 S30', 'NC', 'FR7', 'PB', 'OK', ''],
#             ['021626', 'QUARTIER VALFLEURY 3.xlsx', 'BC8 ANC', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G- 96F-80 vers 021625/P-TF303G- 96F-80 vers 021625/P-TF303G- 96F-80 vers 021627/P-TF303G- 96F-80 vers 021627/98-56-6     vers 021625/Liaison vers BT0075/98-28-6     vers 021627/98-28-6 vers 021627',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['021627', 'QUARTIER VALFLEURY 3.xlsx', 'BC8 ANC', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G- 96F-80 vers 021626/P-TF303G- 96F-80 vers 021626/P-TF303G- 96F-80 vers 021628/P-TF303G- 96F-80 vers 021628/98-28-6     vers 021626/98-28-6     vers 021626/98-28-6     vers 021628/98-28-6 vers 021628',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['021628', 'QUARTIER VALFLEURY 3.xlsx', 'BS8', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G- 96F-80 vers 021627/P-TF303G- 96F-80 vers 021627/P-TF303G- 96F-80 vers 021629/P-TF303G- 96F-80 vers 021629/98-28-6     vers 021627/98-28-6     vers 021627/98-28-6     vers 021629/98-28-6 vers 021629',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['021629', 'QUARTIER VALFLEURY 3.xlsx', 'BM7', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G- 96F-80 vers 021628/P-TF303G- 96F-80 vers 021628/P-TF303G- 96F-80 vers 021630/P-TF303G- 96F-80 vers 021630/98-28-6     vers 021628/98-28-6     vers 021628/98-28-6     vers 021630/98-28-6 vers 021630',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['021630', 'QUARTIER VALFLEURY 3.xlsx', 'BM7', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G- 96F-80 vers 021629/P-TF303G- 96F-80 vers 021629/P-TF303G- 96F-80 vers 021631/P-TF303G- 96F-80 vers 021631/98-28-6     vers 021629/98-28-6     vers 021629/98-28-6     vers 021631/98-28-6     vers 021631',
#              'INSUFFISANT', 'BM7', 'NC', 'FR7', 'Non', 'OK', ''],
#             ['021631', 'QUARTIER VALFLEURY 3.xlsx', 'BS8', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G- 96F-80 vers 021630/P-TF303G- 96F-80 vers 021630/P-TF303G- 96F-80 vers 195796/P-TF303G- 96F-80 vers 195796/98-28-6     vers 021630/98-28-6     vers 021630/98-28-6     vers 195796/98-28-6 vers 195796',
#              'INSUFFISANT', 'BS8', 'NC', 'FR8', 'Non', 'OK', ''],
#             ['195796', 'QUARTIER VALFLEURY 3.xlsx', 'BC8 ', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G- 12F-80 vers FT0069/P-TF303G- 96F-80 vers 021631/P-TF303G- 96F-80 vers 021631/P-TF303G- 96F-80 vers 021637/P-TF303G- 96F-80 vers 021637/98-28-6     vers 021631/98-28-6     vers 021631/98-8-6     vers FT0069/98-28-6     vers 021637/98-14-6 vers 021637/98-8-6 vers 021637',
#              'OK', '', 'NC', 'SO', 'PB', '', ''],
#             ['FT0569', 'QUARTIER VALFLEURY.xlsx', 'BS7', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON', '5/10 vers FT0486', 'OK', '', 'NC', 'SO', 'Non', 'OK', ''],
#             ['FT0486', 'QUARTIER VALFLEURY.xlsx', 'BS8', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G- 48F-80 vers BT0263/P-TF303G- 48F-80 vers 236498/5/10 vers BT0263/5/10 vers 236498/5/10 vers 236498/5/10 vers 236498/5/10 vers FT0569',
#              'OKOK', '', 'NC', 'SO', 'Non', '', ''],
#             ['236498', 'QUARTIER VALFLEURY.xlsx', 'MC7 MIN', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G- 12F-80 vers BT0261/P-TF303G- 48F-80 vers FT0141/P-TF303G- 48F-80 vers FT0486/5/10 vers BT0261/5/10 vers FT0486/5/10 vers FT0486/5/10 vers FT0486/5/10 vers FT0141/5/10 vers FT0141/98-14-6     vers FT0141',
#              'INSUFFISANT', 'MC7 MIN', 'NC', 'FR7', 'Non', 'OK', ''],
#             ['FT0141', 'QUARTIER VALFLEURY.xlsx', 'BM8', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G- 48F-80 vers 236498/P-TF303G- 48F-80 vers FT0236/5/10 vers FT0236/5/10 vers FT0236/98-14-6     vers FT0236/Liaison vers BT0476/5/10 vers 236498/5/10 vers 236498/98-14-6     vers 236498',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['FT0236', 'QUARTIER VALFLEURY.xlsx', 'BS8', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G- 48F-80 vers FT0141/P-TF303G- 48F-80 vers 236497/5/10 vers FT0141/5/10 vers FT0141/98-14-6     vers FT0141/5/10 vers 236497/5/10 vers 236497/98-14-6     vers 236497',
#              'INSUFFISANT', 'BS8', 'NC', 'BC8 ', 'Non', 'OK', ''],
#             ['236497', 'QUARTIER VALFLEURY.xlsx', 'BH6 S30', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G- 48F-80 vers BT0135/P-TF303G- 48F-80 vers FT0236/98-14-6     vers 0421080/98-14-6     vers 0421080/98-14-6     vers 0421080/5/10 vers FT0236/5/10 vers FT0236/98-14-6     vers FT0236',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['BT0206', 'QUARTIER_HAUTERIVES_2.xlsx', 'EDF', 'NON', 'NON', 'NON', 'NON', 'OUI', 'NON', 'OUI', 'NON',
#              'NON', 'NC', 'Non', 'NON', 'P-TF303G- 96F-80 vers 021676/98-28-6 vers 021676', 'OK', '', 'NC', 'SO',
#              '', 'OK', ''],
#             ['021676', 'QUARTIER_HAUTERIVES_2.xlsx', 'BS7', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G- 96F-80 vers BT0206/P-TF303G- 96F-80 vers 021675/98-28-6 vers BT0206/98-28-6 vers 021675',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['021675', 'QUARTIER_HAUTERIVES_2.xlsx', 'BS7', 'NC', 'OUI', 'NON', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'NON', 'NC', 'Non', 'NON',
#              'P-TF303G- 96F-80 vers 021676/P-TF303G- 96F-80 vers 021674/98-28-6 vers 021676/98-28-6 vers 021674',
#              'INSUFFISANT', 'BS7', 'NC', 'FR7', 'Non', 'OK', ''],
#             ['021674', 'QUARTIER_HAUTERIVES_2.xlsx', 'BM8', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G- 96F-80 vers 021675/P-TF303G- 96F-80 vers 021673/98-28-6 vers 021675/98-28-6 vers 021673',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['021673', 'QUARTIER_HAUTERIVES_2.xlsx', 'BS8', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G- 96F-80 vers 021674/P-TF303G- 96F-80 vers 021672/98-28-6 vers 021674/98-28-6 vers 021672',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['021672', 'QUARTIER_HAUTERIVES_2.xlsx', 'BM8', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G- 96F-80 vers 021673/P-TF303G- 96F-80 vers 021671/98-28-6     vers 021673/98-28-6 vers 021671',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['021671', 'QUARTIER_HAUTERIVES_2.xlsx', 'BS8', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G- 96F-80 vers 021672/P-TF303G- 96F-80 vers 021654/98-28-6 vers 021672/98-28-6 vers 021654',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['021654', 'QUARTIER_HAUTERIVES_2.xlsx', 'BS8', 'OUI', 'OUI', 'OUI', 'NON', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G- 24F-80 vers 021655/P-TF303G- 96F-80 vers 021671/98-28-6 vers 021671/98-8-6 vers 021655/98-8-6 vers BT0204/98-28-6 vers BT0204',
#              'INSUFFISANT', 'BS8', 'NC', 'FR8', 'PB', 'OK', ''],
#             ['021655', 'QUARTIER_HAUTERIVES_2.xlsx', 'BM7', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G- 24F-80 vers 021654/P-TF303G- 24F-80 vers 021656/98-8-6 vers 021654/98-8-6 vers 021656',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['021656', 'QUARTIER_HAUTERIVES_2.xlsx', 'BS7', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G- 24F-80 vers 021655/P-TF303G- 24F-80 vers 021657/98-8-6 vers 021655/98-8-6 vers 021657',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['021657', 'QUARTIER_HAUTERIVES_2.xlsx', 'BS7', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G- 24F-80 vers 021656/P-TF303G- 24F-80 vers 021658/98-8-6 vers 021656/98-8-6 vers 021658',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['021658', 'QUARTIER_HAUTERIVES_2.xlsx', 'BS7', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G- 24F-80 vers 021657/P-TF303G- 24F-80 vers 021659/98-8-6 vers 021657/98-8-6 vers 021659',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['021659', 'QUARTIER_HAUTERIVES_2.xlsx', 'BS7', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G- 24F-80 vers 021658/P-TF303G- 24F-80 vers 021660/98-8-6 vers 021658/98-8-6 vers 021660',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['021660', 'QUARTIER_HAUTERIVES_2.xlsx', 'BS7', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NON', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G- 24F-80 vers 021659/P-TF303G- 24F-80 vers 021661/98-8-6 vers 021659/98-8-6 vers 021661',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['021661', 'QUARTIER_HAUTERIVES_2.xlsx', 'BS7', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G- 24F-80 vers 021660/P-TF303G- 24F-80 vers 021662/98-8-6 vers 021660/98-8-6 vers 021662',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['021662', 'QUARTIER_HAUTERIVES_2.xlsx', 'BM7', 'OUI', 'OUI', 'NON', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G- 24F-80 vers 021661/98-8-6 vers 021661/98-8-6 vers BT0335/98-8-6 vers POT_07346_DA_6005',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['021552', 'ROUTE DE BAYNES.xlsx', 'BH7 S30', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NC',
#              'A-N9271A-96F-70 vers 021553/98-112-4     vers 021553/Liaison vers 021553/98-56-4     vers 021553',
#              'OKOK', '', 'NC', 'SO', 'Non', 'OK', ''],
#             ['021553', 'ROUTE DE BAYNES.xlsx', 'BS7', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'NC', 'Non', 'NON',
#              'A-N9271A-96F-70 vers 021554/A-N9271A-96F-70 vers 021552/98-112-4 vers 021552/Liaison vers 021552/98-56-4 vers 021552/98-112-4 vers 021554/Liaison vers 021554/98-56-4 vers 021554',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['021554', 'ROUTE DE BAYNES.xlsx', 'BM8', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'NC', 'Non', 'NC',
#              'A-N9271A-96F-70 vers 021553/A-N9271A-96F-70 vers 021555/98-112-4 vers 021553/Liaison vers 021553/98-56-4 vers 021553/98-112-4 vers 021555/Liaison vers 021555/98-56-4 vers 021555',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['021555', 'ROUTE DE BAYNES.xlsx', 'BS8', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'NC', 'Non', 'NC',
#              'A-N9271A-96F-70 vers 021554/A-N9271A-96F-70 vers 021556/98-112-4 vers 021554/Liaison vers 021554/98-56-4 vers 021554/98-112-4 vers 021556/Liaison vers 021556/98-56-4 vers 021556',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['021556', 'ROUTE DE BAYNES.xlsx', 'BH8 S30', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NC',
#              'A-N9271A-96F-70 vers 021555/A-N9271A-96F-70 vers 021557/98-112-4 vers 021555/Liaison vers 021555/98-56-4 vers 021555/98-112-4 vers 021557/Liaison vers 021557/98-56-4 vers 021557',
#              'INSUFFISANT', 'BH8 S30', 'NC', 'FR8', 'Non', 'OK', ''],
#             ['021557', 'ROUTE DE BAYNES.xlsx', 'BM8', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'NC', 'Non', 'NC',
#              'A-N9271A-96F-70 vers 021556/A-N9271A-96F-70 vers 021558/98-112-4 vers 021556/Liaison vers 021556/98-56-4 vers 021556/98-112-4 vers 021558/Liaison vers 021558/98-56-4 vers 021558',
#              'INSUFFISANT', 'BM8', 'NC', 'FR8', 'Non', 'OK', ''],
#             ['021558', 'ROUTE DE BAYNES.xlsx', 'BC8 ', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NC',
#              'A-N9271A-96F-70 vers 021557/A-N9271A-96F-70 vers 021559/A-N8227A-24F-70 vers BT0319/98-112-4 vers 021557/Liaison vers 021557/98-14-4 vers 021557/98-8-4 vers BT0319/Liaison vers FT0562/98-112-4 vers 021559/98-8-4 vers 021559/Liaison vers 021559/98-56-6 vers 021559',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['021559', 'ROUTE DE BAYNES.xlsx', 'BS8', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'NC', 'Non', 'NC',
#              'A-N9271A-96F-70 vers 021558/A-N9271A-96F-70 vers 021560/98-112-4 vers 021558/98-8-4 vers 021558/Liaison vers 021558/98-56-4 vers 021558/98-112-4 vers 021560/98-8-4 vers 021560/Liaison vers 021560/98-56-4 vers 021560',
#              'INSUFFISANT', 'BS8', 'NC', 'FR8', 'PEO', 'OK', ''],
#             ['021560', 'ROUTE DE BAYNES.xlsx', 'BS8', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'NC', 'Non', 'NC',
#              'A-N9271A-96F-70 vers 021561/A-N9271A-96F-70 vers 021559/98-112-4 vers 021559/98-8-4 vers 021559/Liaison vers 021559/98-56-4 vers 021559/98-112-4 vers 021561/98-8-4 vers 021561/Liaison vers 021561/98-56-4 vers 021561',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['021561', 'ROUTE DE BAYNES.xlsx', 'BS8', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'NC', 'Non', 'NON',
#              'A-N9271A-96F-70 vers 021560/A-N9271A-96F-70 vers BT0254/98-112-4 vers 021560/98-8-4 vers 021560/Liaison vers 021560/98-56-4 vers 021560/Liaison vers BT0254/98-112-4 vers AX0080/98-8-4 vers AX0080/98-14-4 vers AX0080/Liaison vers 021562',
#              'INSUFFISANT', 'BS8', 'NC', 'FR8', 'PB', 'OK', ''],
#             ['021562', 'ROUTE DE BAYNES.xlsx', 'MI8', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NON', 'OUI',
#              'NC', 'Non', 'NON', 'Liaison vers FA0043/Liaison vers 021561', 'OK', '', 'NC', 'SO', '', '', ''],
#             ['021782', 'ROUTE DE BEILLEURE 2.xlsx', 'BS8', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              '5/9 vers BT0306/5/9 vers BT0522/98-8-4     vers BT0522/98-8-4     vers BT0522/5/9 vers BT0306',
#              'OKOK', '', 'NC', 'SO', 'PB', 'OK', ''],
#             ['021783', 'ROUTE DE BEILLEURE.xlsx', 'BC7 ', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G-288F-80 vers BT0176/P-TF303G- 96F-80 vers BT0176/98-56-6     vers BT0176/98-28-6 vers BT0176',
#              'OKOK', '', 'NC', 'SO', 'Non', 'OK', ''],
#             ['289068', 'Rue de la breche.xlsx', 'BC8 ANC', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON', 'A-N9923A-12F-70 vers 289069/98-8-6 vers 289069/98-8-6 vers 289069', 'OKOK',
#              '', 'NC', 'SO', 'Non', 'OK', ''],
#             ['289069', 'Rue de la breche.xlsx', 'BS7', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NC',
#              'A-N9923A-12F-70 vers 289068/A-N9923A-12F-70 vers 289070/98-8-6 vers 289068/98-8-6 vers 289068/98-8-6 vers FT0521/98-8-6 vers 289070',
#              'INSUFFISANT', 'BS7', 'NC', 'FR7', 'Non', 'OK', ''],
#             ['289070', 'Rue de la breche.xlsx', 'BS7', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NC', 'A-N9923A-12F-70 vers 289069/98-8-6 vers 289069/98-8-6 vers BT0096',
#              'INSUFFISANT', 'BS7', 'NC', 'FR7', 'PB', 'OK', ''],
#             ['021787', 'RUE DES MURIERS.xlsx', 'BM8', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'NC', 'Non', 'NON', 'P-TF303G-288F-80 vers 185007/98-14-6 vers 185007/98-14-6 vers 185007', 'OKOK', '',
#              'NC', 'SO', '', 'OK', ''],
#             ['185007', 'RUE DES MURIERS.xlsx', 'BM8', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'NC', 'Non', 'NON',
#              'P-TF303G-288F-80 vers 021787/P-TF303G-288F-80 vers 185008/98-14-6 vers 021787/98-14-6 vers 021787/98-14-6 vers 185008/98-14-6 vers 185008',
#              'OK', '', 'NC', 'SO', '', '', ''],
#             ['185008', 'RUE DES MURIERS.xlsx', 'BM8', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'NC', 'Non', 'NON',
#              'P-TF303G-288F-80 vers 185007/P-TF303G-288F-80 vers 185009/98-14-6 vers 185007/98-14-6 vers 185007/98-14-6 vers 185009/98-14-6 vers 185009',
#              'OK', '', 'NC', 'SO', '', '', ''],
#             ['185009', 'RUE DES MURIERS.xlsx', 'BM8', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'NC', 'Non', 'NON',
#              'P-TF303G-288F-80 vers 185008/P-TF303G-288F-80 vers BT0053/98-14-6 vers 185008/98-14-6 vers 185008/98-14-6 vers BT0053/98-14-6 vers BT0053',
#              'OK', '', 'NC', 'SO', '', '', ''],
#             ['BT0053', 'RUE DES MURIERS.xlsx', 'EDF', 'NON', 'NON', 'NON', 'NON', 'OUI', 'NON', 'OUI', 'NON', 'NON',
#              'NC', 'Non', 'NON',
#              'P-TF303G-288F-80 vers 185009/98-14-6 vers 185009/98-14-6 vers 185009/98-14-6 vers BT0375/98-14-6 vers BT0375',
#              '', '', 'NC', 'SO', '', '', ''],
#             ['BT0444', 'RUE DES MURIERS_2.xlsx', 'EDF', 'NON', 'NON', 'NON', 'NON', 'OUI', 'NON', 'OUI', 'NON',
#              'NON', 'NC', 'Non', 'NON',
#              'P-TF303G-288F-80 vers 021784/P-TF303G- 96F-80 vers 021784/98-56-4 vers 021784/98-14-4 vers 021784/98-56-4 vers BT0118/98-14-4 vers BT0118',
#              'OK', '', 'NC', 'SO', '', 'OK', ''],
#             ['021784', 'RUE DES MURIERS_2.xlsx', 'BM8', 'OUI', 'NON', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'NON', 'NC', 'Non', 'NON',
#              'P-TF303G-288F-80 vers BT0444/P-TF303G-288F-80 vers 021785/P-TF303G- 96F-80 vers BT0444/P-TF303G- 96F-80 vers 021785/98-56-4 vers BT0444/98-14-4 vers BT0444/98-56-4 vers 021785/98-14-4 vers 021785',
#              'OK', '', 'NC', 'SO', '', '', ''],
#             ['021785', 'RUE DES MURIERS_2.xlsx', 'BS8', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G-288F-80 vers 021784/P-TF303G- 96F-80 vers 021784/98-56-4     vers 021784/98-14-4 vers 021784',
#              'INSUFFISANT', '', 'NC', 'SO', 'Non', '', "Utilisation d'un AEOP"],
#             ['021798', 'RUE JACQUES BREL 2.xlsx', 'BS7', 'OUI', 'OUI', 'OUI', 'NON', 'OUI', 'OUI', 'OUI', 'OUI',
#              'NON', 'NC', 'Non', 'NON',
#              'P-TF303G- 12F-80 vers BT0373/98-8-6     vers 021795/98-8-6     vers BT0373', 'OKOK', '', 'NC', 'SO',
#              'PB', 'OK', ''],
#             ['BT0446', 'RUE JACQUES BREL.xlsx', 'EDF', 'NON', 'NON', 'NON', 'NON', 'OUI', 'NON', 'OUI', 'NON',
#              'NON', 'NC', 'Non', 'NON',
#              'P-TF303G- 12F-80 vers 021797/P-TF303G- 24F-80 vers 021797/98-28-6 vers 021797', 'OK', '', 'NC', 'SO',
#              '', 'OK', ''],
#             ['021797', 'RUE JACQUES BREL.xlsx', 'BC8', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G- 12F-80 vers BT0446/P-TF303G- 24F-80 vers BT0446/P-TF303G-144F-80 vers BT0177/P-TF303G- 48F-80 vers 021795/98-28-6 vers BT0446/98-56-4 vers BT0177/98-14-4 vers BT0177/98-56-4 vers 021795',
#              'OK', '', 'NC', 'SO', '', '', ''],
#             ['BT0177', 'RUE JACQUES BREL.xlsx', 'EDF', 'NON', 'NON', 'NON', 'NON', 'OUI', 'NON', 'OUI', 'NON',
#              'NON', 'NC', 'Non', 'NON',
#              'P-TF303G-144F-80 vers 021797/98-14-4 vers 000279/98-14-4 vers 000279/98-28-6 vers 000279/98-56-4 vers 021797/98-14-4 vers 021797/98-4-8 vers BT0374/98-112-6 vers BT0525',
#              '', '', 'NC', 'SO', '', '', ''],
#             ['021795', 'RUE JACQUES BREL.xlsx', 'BM7', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G- 48F-80 vers 021797/P-TF303G- 48F-80 vers FT0461/98-56-4 vers 021797/98-56-4 vers FT0461/98-8-6 vers 021798',
#              'OK', '', 'NC', 'SO', '', '', ''],
#             ['FT0461', 'RUE JACQUES BREL.xlsx', 'MI7', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G- 48F-80 vers 021795/P-TF303G- 48F-80 vers BT0448/98-56-4 vers 021795/98-56-4 vers BT0448',
#              'OK', '', 'NC', 'SO', '', '', ''],
#             ['021794', 'RUE MAURICE CHEVALIER.xlsx', 'MI7 ', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'OUI', 'NC', 'Non', 'NON',
#              'P-TF303G- 12F-80 vers BT0179/98-8-4     vers BT0179/98-8-4     vers BT0447', 'OKOK', '', 'NC', 'SO',
#              'PB', 'OK', ''],
#             ['FT0768', 'Saint-Alban.xlsx', 'POT MIN', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'NC', 'Non', 'NON', 'Liaison vers FT0767', 'OK', '', 'NC', 'SO', 'PB', 'OK', ''],
#             ['273219', 'Saint-Robert.xlsx', 'BC7 ', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'NC', 'Non', 'NC', 'A-N8228A-36F-70 vers 273221/Liaison vers 273221', 'OKOK', '', 'NC', 'SO', 'PB',
#              'OK', ''],
#             ['273221', 'Saint-Robert.xlsx', 'BM7', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'NC', 'Non', 'NON',
#              'A-N8228A-36F-70 vers 273219/A-N8228A-36F-70 vers 664474/Liaison vers 273219/Liaison vers 664474',
#              'OK', '', 'NC', 'SO', 'Non', '', 'Elagage necessaire'],
#             ['664474', 'Saint-Robert.xlsx', 'BM7', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'NC', 'Non', 'NON',
#              'A-N8228A-36F-70 vers 273221/A-N8228A-36F-70 vers 273222/Liaison vers 273221/Liaison vers 273222',
#              'OK', '', 'NC', 'SO', 'Non', '', 'Elagage necessaire'],
#             ['273222', 'Saint-Robert.xlsx', 'BS8', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'NC', 'Non', 'NON',
#              'A-N8228A-36F-70 vers 664474/A-N8228A-36F-70 vers 273223/Liaison vers 664474/Liaison vers 273223',
#              'OK', '', 'NC', 'SO', 'Non', '', 'Elagage necessaire'],
#             ['273223', 'Saint-Robert.xlsx', 'BS6', 'NC', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NON',
#              'NC', 'Non', 'NON',
#              'A-N8228A-36F-70 vers 273222/A-N8228A-36F-70 vers 273224/Liaison vers 273222/Liaison vers 273224',
#              'OK', 'BS6', 'NC', 'MI7 ', 'Non', 'OK', 'Elagage necessaire\r\nCAS : Cassé'],
#             ['273224', 'Saint-Robert.xlsx', 'BS6', 'NC', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NON',
#              'NC', 'Non', 'NON',
#              'A-N8228A-36F-70 vers 273223/A-N8228A-36F-70 vers 273225/Liaison vers 273223/Liaison vers 273225',
#              'OK', 'BS6', 'NC', 'MI7 ', 'Non', 'OK', 'CAS : Cassé'],
#             ['273225', 'Saint-Robert.xlsx', 'BS6', 'NC', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NON',
#              'NC', 'Non', 'NON',
#              'A-N8228A-36F-70 vers 273224/A-N8228A-36F-70 vers 273226/Liaison vers 273224/Liaison vers 273226',
#              'OK', 'BS6', 'NC', 'MI7 ', 'Non', 'OK', 'POU : Pourri base'],
#             ['273226', 'Saint-Robert.xlsx', 'BS6', 'NC', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NON',
#              'NC', 'Non', 'NON',
#              'A-N8228A-36F-70 vers 273225/A-N8228A-36F-70 vers 273227/Liaison vers 273225/Liaison vers 273227',
#              'OK', 'BS6', 'NC', 'MI7 ', 'Non', 'OK', 'CAS : Cassé'],
#             ['273227', 'Saint-Robert.xlsx', 'BS8', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'NC', 'Non', 'NON',
#              'A-N8228A-36F-70 vers 273226/A-N8228A-36F-70 vers 273228/Liaison vers 273226/Liaison vers 273228',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['273228', 'Saint-Robert.xlsx', 'BS8', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'NC', 'Non', 'NON',
#              'A-N8228A-36F-70 vers 273227/A-N8228A-36F-70 vers 273229/Liaison vers 273227/Liaison vers 273229',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['273229', 'Saint-Robert.xlsx', 'BS8', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'NC', 'Non', 'NON', 'A-N8228A-36F-70 vers 273228/Liaison vers 273228', 'OK', '', 'NC', 'SO', 'PB', '',
#              ''],
#             ['BT0281', 'Valmont_1.xlsx', 'EDF', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NC',
#              'Non', 'NON', 'P-TF303G- 96F-80 vers 289028/98-8-6 vers 289028/98-8-6 vers 289028', 'OK', '', 'NC',
#              'SO', 'PB', 'OK', ''],
#             ['289028', 'Valmont_1.xlsx', 'MH7 S45', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'NC', 'Non', 'NON',
#              'P-TF303G- 96F-80 vers BT0281/P-TF303G- 96F-80 vers 289029/98-8-6 vers BT0281/98-8-6 vers BT0281/98-8-6 vers 289029/98-8-6 vers 289029',
#              'INSUFFISANT', 'MH7 S45', 'NC', 'FR7', 'Non', 'OK', ''],
#             ['289029', 'Valmont_1.xlsx', 'MH7 S30', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'NC', 'Non', 'NC',
#              'P-TF303G- 96F-80 vers 289028/P-TF303G- 96F-80 vers BT0349/98-8-6 vers 289028/98-8-6 vers 289028/98-8-6 vers BT0349/98-8-6 vers BT0349',
#              'INSUFFISANT', 'MH7 S30', 'NC', 'FR7', 'Non', 'OK', 'Elagage necessaire'],
#             ['BT0349', 'Valmont_1.xlsx', 'EDF', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NC',
#              'Non', 'NON', 'P-TF303G- 96F-80 vers 289029/98-8-6 vers 289029/98-8-6 vers 289029', '', '', 'NC', 'SO',
#              '', '', ''],
#             ['289021', 'Valmont_2.xlsx', 'MI8 ', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'NC', 'Non', 'NC', 'P-TF303G- 96F-80 vers 289022/98-14-6     vers 289022/98-8-6 vers 289022',
#              'OKINSUFFISANT', 'MI8 ', 'NC', 'FR8', 'Non', 'OKOK', ''],
#             ['289022', 'Valmont_2.xlsx', 'BC8 ', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'NC', 'Non', 'NON',
#              'P-TF303G- 96F-80 vers 289021/P-TF303G- 96F-80 vers 289025/A-N9923A-12F-70 vers BT0091/98-14-6 vers 289021/98-8-6 vers 289021/Liaison vers BT0091/98-14-6 vers 289025/98-8-6 vers 289025',
#              'OK', '', 'NC', 'SO', 'PB', '', ''],
#             ['289025', 'Valmont_2.xlsx', 'MH7 S30', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'NC', 'Non', 'NON',
#              'P-TF303G- 96F-80 vers 289022/P-TF303G- 96F-80 vers 289026/98-14-6 vers 289022/98-8-6 vers 289022/98-14-6 vers 289026/98-8-6 vers 289026',
#              'OK', '', 'NC', 'SO', 'Non', '', ''],
#             ['289026', 'Valmont_2.xlsx', 'MI8 ', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'NC', 'Non', 'NC',
#              'P-TF303G- 96F-80 vers 289025/P-TF303G- 96F-80 vers BT0151/98-14-6 vers 289025/98-8-6 vers 289025/98-14-6 vers BT0151/98-8-6 vers BT0151',
#              'OK', '', 'NC', 'SO', 'PB', '', ''],
#             ['BT0151', 'Valmont_2.xlsx', 'EDF', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NC',
#              'Non', 'NON', 'P-TF303G- 96F-80 vers 289026/98-14-6 vers 289026/98-8-6 vers 289026', '', '', 'NC',
#              'SO', '', '', ''],
#             ['BT0091', 'Valmont_2.xlsx', 'EDF', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NC',
#              'Non', 'NON', 'A-N9923A-12F-70 vers 289022/Liaison vers 289022', '', '', 'NC', 'SO', 'Non', '', ''],
#             ['FT0422', 'Viviers.xlsx', 'POT MIN', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI',
#              'NC', 'Non', 'NON', 'A-N8228A-36F-70 vers 289032/98-8-6 vers 289032', 'OK', '', 'NC', 'SO', '', 'OK',
#              ''],
#             ['289032', 'Viviers.xlsx', 'MS7 ', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NC',
#              'Non', 'NON',
#              'A-N8228A-36F-70 vers FT0422/A-N8228A-36F-70 vers 289033/98-8-6 vers FT0422/98-8-6 vers 289033', 'OK',
#              '', 'NC', 'SO', 'PB', '', 'Elagage necessaire'],
#             ['289033', 'Viviers.xlsx', 'MS7 ', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NC',
#              'Non', 'NON',
#              'A-N8228A-36F-70 vers 289032/A-N8228A-36F-70 vers 289034/98-8-6 vers 289032/98-8-6 vers 289034', 'OK',
#              '', 'NC', 'SO', 'Non', '', ''],
#             ['289034', 'Viviers.xlsx', 'MS7 ', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NC',
#              'Non', 'NON',
#              'A-N8228A-36F-70 vers 289033/A-N8228A-36F-70 vers 289035/98-8-6 vers 289033/98-8-6 vers 289035', 'OK',
#              '', 'NC', 'SO', 'Non', '', ''],
#             ['289035', 'Viviers.xlsx', 'MS7 ', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NC',
#              'Non', 'NON',
#              'A-N8228A-36F-70 vers 289034/A-N8228A-36F-70 vers 289036/98-8-6 vers 289034/98-8-6 vers 289036', 'OK',
#              '', 'NC', 'SO', 'Non', '', ''],
#             ['289036', 'Viviers.xlsx', 'MS7 ', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NC',
#              'Non', 'NON',
#              'A-N8228A-36F-70 vers 289035/A-N8228A-36F-70 vers 289037/98-8-6 vers 289035/98-8-6 vers 289037', 'OK',
#              '', 'NC', 'SO', 'Non', '', ''],
#             ['289037', 'Viviers.xlsx', 'MS7 ', 'OUI', 'NON', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NON', 'NON', 'NC',
#              'Non', 'NON',
#              'A-N8228A-36F-70 vers 289036/A-N8228A-36F-70 vers 289038/98-8-6 vers 289036/98-8-6 vers 289038', 'OK',
#              'MS7 ', 'NC', 'MI7 ', 'Non', 'OK', ''],
#             ['289038', 'Viviers.xlsx', 'MI7 ', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NC',
#              'Non', 'NON',
#              'A-N8228A-36F-70 vers 289037/A-N8228A-36F-70 vers 289039/98-8-6 vers 289037/98-8-6 vers 289039', 'OK',
#              '', 'NC', 'SO', 'Non', '', ''],
#             ['289039', 'Viviers.xlsx', 'MS7 ', 'OUI', 'NON', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NON', 'NON', 'NC',
#              'Non', 'NON',
#              'A-N8228A-36F-70 vers 289038/A-N8228A-36F-70 vers 680761/98-8-6 vers 289038/98-8-6 vers 680761', 'OK',
#              'MS7 ', 'NC', 'MI7 ', 'Non', 'OK', ''],
#             ['680761', 'Viviers.xlsx', 'MI7 ', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NC',
#              'Non', 'NON',
#              'A-N8228A-36F-70 vers 289039/A-N8228A-36F-70 vers BT0215/98-8-6 vers 289039/98-8-6 vers BT0215', 'OK',
#              '', 'NC', 'SO', 'Non', '', ''],
#             ['BT0215', 'Viviers.xlsx', 'EDF', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'OUI', 'NC',
#              'Non', 'NON', 'A-N8228A-36F-70 vers 680761/98-8-6 vers 680761', '', '', 'NC', 'SO', 'PB', '', '']]


# 'N° APPUI', 'TYPE DAPPUI (FORMAT GESPOT)', 'ADRESSE DE LAPPUI (N°, RUE OU LIEU DIT)',
# 'LATITUDE\n(WGS84)', 'LONGITUDE\n(WGS84)', 'CONTRÔLE VISUEL OK',
# 'CONTRÔLE VERTICALITÉ OK ET ABSENCE ÉTIQUETTE ORANGE', 'CONTRÔLE FLAMBLEMENT OK',
# 'RESPECT VOISINAGE RÉSEAU ÉLECTRIQUE', 'CONTRÔLE POINTE CARRÉE OK',
# 'CONTRÔLE SECOUSSES OK', 'CONTRÔLE PERCUSSION OK', 'ABSENCE ÉTIQUETTE JAUNE',
# 'APPUI UTILISABLE EN LÉTAT', 'MILIEU ENVIRONNANT DE LAPPUI',
# 'VOISINAGE ÉLECTRIQUE APPUI', 'APPUI STRATÉGIQUE', 'APPUI INACCESSIBLE VÉHICULE',
# 'NOM DU CÂBLE', 'LONGUEUR PORTÉE', 'ANGLE EN GRADE', 'HAUTEUR NAPPE',
# 'HAUTEUR DE FLÈCHE PORTÉE', 'TEMPÉRATURE DU RELEVÉ FLÈCHE', 'N° APPUI DESTINATION',
# 'FORFAIT CUIVRE ', 'FORFAIT OPTIQUE ', 'EFFORT DISPONIBLE AVANT AJOUT CÂBLE',
# 'EFFORT DISPONIBLE APRÈS AJOUT CÂBLE', 'EFFORT DISPONIBLE NOUVEAU SUPPORT',
# 'TYPE DAPPUI AVANT TRAVAUX', 'NATURE DES TRAVAUX', 'TYPE DAPPUI APRÉS TRAVAUX',
# 'NOMBRE DE POTEAU COMMANDÉ', 'INSTALLATION RÉHAUSSE', 'POSE DUN BOITIER OPTIQUE',
# 'NOMBRE DE BOITIERS SUR LAPPUI', 'TRANSITION SOUTERRAINE',
# 'DISTANCE AVEC TRANSITION EXISTANTE', 'INSTALLATION DISPOSITIF DE LOVAGE',
# 'COMMENTAIRES'


# function pour recuperer les info de la fiche comac
# def function_recperation_info_fiches_appuis_ft(self, Fichier_appuis):
# 	# global xlwings
# 	if Fichier_appuis:
# 		name_file = str(os.path.splitext(os.path.basename(Fichier_appuis))[0]).replace("'", '')
# 		workbook = xlrd.open_workbook(Fichier_appuis, on_demand=True)
# 		# Recuperation de la derniere sheet du fichier
# 		worksheet = workbook.sheet_by_name(workbook.sheets()[-1].name)  # workbook.sheet_by_index(0)
# 		var_entet_ref = ['N° APPUI', 'TYPE DAPPUI (FORMAT GESPOT)', 'ADRESSE DE LAPPUI (N°, RUE OU LIEU DIT)', 'LATITUDE\n(WGS84)', 'LONGITUDE\n(WGS84)', 'CONTRÔLE VISUEL OK', 'CONTRÔLE VERTICALITÉ OK', 'CONTRÔLE FLAMBLEMENT OK', 'RESPECT VOISINAGE RÉSEAU ÉLECTRIQUE', 'CONTRÔLE POINTE CARRÉE OK', 'CONTRÔLE SECOUSSES OK', 'CONTRÔLE PERCUSSION OK', 'ABSENCE ÉTIQUETTE JAUNE OU ORANGE', 'APPUI UTILISABLE EN LÉTAT', 'MILIEU ENVIRONNANT DE LAPPUI', 'VOISINAGE ÉLECTRIQUE APPUI', 'APPUI STRATÉGIQUE', 'APPUI INACCESSIBLE VÉHICULE', 'NOM DU CÂBLE', 'LONGUEUR PORTÉE', 'ANGLE EN GRADE', 'HAUTEUR NAPPE', 'HAUTEUR DE FLÈCHE PORTÉE', 'TEMPÉRATURE DU RELEVÉ FLÈCHE', 'N° APPUI DESTINATION', 'FORFAIT CUIVRE ', 'FORFAIT OPTIQUE ', 'EFFORT DISPONIBLE AVANT AJOUT CÂBLE', 'EFFORT DISPONIBLE APRÈS AJOUT CÂBLE', 'EFFORT DISPONIBLE NOUVEAU SUPPORT', 'TYPE DAPPUI AVANT TRAVAUX', 'NATURE DES TRAVAUX', 'TYPE DAPPUI APRÉS TRAVAUX', 'NOMBRE DE POTEAU COMMANDÉ', 'INSTALLATION RÉHAUSSE', 'POSE DUN BOITIER OPTIQUE', 'NOMBRE DE BOITIERS SUR LAPPUI', 'TRANSITION SOUTERRAINE', 'DISTANCE AVEC TRANSITION EXISTANTE', 'INSTALLATION DISPOSITIF DE LOVAGE', 'COMMENTAIRES']
# 		first_row = []
# 		data_dict = []
# 		var_list_col_fiche_ft = []
# 		var_list_erreur_model = []
# 		# Recuperation Header
# 		for col in range(worksheet.ncols):
# 			first_row.append(str(worksheet.cell_value(7, col)).replace('.0', '').upper().replace("'", ''))
#
# 		# Verfication des colonnes absentes par rapport au modele
# 		var_entite_file_not_in_ref = []
# 		for index_file in range(0, len(first_row)):
# 			var_entite_file = first_row[index_file]
# 			if var_entite_file not in var_entet_ref:
# 				var_entite_file_not_in_ref.append(var_entite_file)
#
# 		# Ne prendre que les entites presentes dans le modele
# 		var_compare_entete_by_ref = len(var_entet_ref) == len(first_row)
# 		#     0 == Nom Fichier; 1 == reference du modele de dev; 2 == valeur fichier etude
# 		var_list_erreur_model.append([name_file, var_entet_ref, var_entite_file_not_in_ref])
# 		if var_compare_entete_by_ref: #   and not var_entite_file_not_in_ref
# 			app = xlwings.App(visible=False)
# 			wb = app.books.open(Fichier_appuis)  # xlwings.Book(Fichier_appuis)
# 			sheet_xlwings = wb.sheets['Export 1']
# 			# Recuperation values colonnes
# 			list_dict_color_af_eta_cap = []
# 			list_dict_color_af_dan_apr = []
# 			for row in range(8, worksheet.nrows):
# 				elm = {}
# 				dict_color_af_eta_cap = {}
# 				dict_color_af_dan_apr = {}
# 				for col in range(worksheet.ncols):
# 					value_cell_num_appui = str(worksheet.cell_value(row, 0)).replace("'", '').replace('"', '').\
# 						replace(' ', '').replace('.0', '')
# 					if col in (0, 1, 17, 5, 6, 7, 8, 9, 10, 11, 12, 13, 35, 37, 18, 24, 29, 31, 14, 15, 32, 30, 40):
# 				#             (0, 1, 16, 5, 6, 7, 8, 9, 10, 11, 12, 13, 35, 37, 18, 24, 28, 31, 14, 15, 32, 29, 40)
# 						value_cell = str(worksheet.cell_value(row, col)).replace("'", '').replace('"', '').replace(
# 							'', '').replace('.0', '')
# 						elm[first_row[col]] = value_cell
# 						# nump_appui = sheet_xlwings.range((row, col)).value
# 						# # color_af_eta_cap = xlwings.Range((row, 29)).value
# 						# print(nump_appui)
# 						if col == 29:
# 							color_af_eta_cap = sheet_xlwings.range((row, col)).value
# 							print(value_cell_num_appui, ';', color_af_eta_cap)
# 					if col == 29:
# 						color_af_eta_cap = xlwings.Range((row, 29)).value
# 						# print(str(value_cell_num_appui), ';', color_af_eta_cap)
# 						# str(xlwings.Range((row, col)).value) + ':' + str(first_row[col])  # 'Color'
# 						# dict_color_af_eta_cap[str(value_cell_num_appui)] = ''.join(str(color_af_eta_cap))
# 					elif col == 30:
# 						color_af_dan_apr = xlwings.Range((row, col)).value
# 						# str(xlwings.Range((row, col)).value) + ':' + str(first_row[col])  # 'Color'
# 						# dict_color_af_dan_apr[str(value_cell_num_appui)] = ''.join(str(color_af_dan_apr))
# 				# Nombre de colonne a recuperer doit etre egal a 23
# 				if len(elm) == 23:
# 					data_dict.append(elm)
# 					list_dict_color_af_eta_cap.append(dict_color_af_eta_cap)
# 					list_dict_color_af_dan_apr.append(dict_color_af_dan_apr)
#
# 			# print(list_dict_color_af_eta_cap)
# 			# print('---------------------')
# 			# print(self.generalfunctions.function_getdict_list(list_dict_color_af_eta_cap))
#
# 			# print(list_dict_color_af_dan_apr)
# 			# print(self.generalfunctions.function_getdict_list(list_dict_color_af_dan_apr))
# 			# print('---------------------')
# 			cmp = '0'
# 			dict_name_vable = {}
# 			for index_dict in range(0, len(data_dict)):
# 				# Duplication code fiche pour cables multiples pour concatener
# 				var_current_number = list(data_dict[index_dict].values())[0]
# 				var_af_cable = list(data_dict[index_dict].values())[14]
# 				if var_current_number != '':
# 					cmp = var_current_number
# 					dict_name_vable[str(var_current_number)] = [
# 						var_af_cable + ' vers ' + list(data_dict[index_dict].values())[15]]
# 				else:
# 					var_current_number = cmp
# 					dict_name_vable[str(var_current_number)].append(
# 						var_af_cable + ' vers ' + list(data_dict[index_dict].values())[15])
# 			for index_dict in range(0, len(data_dict)):
# 				# Duplication code fiche pour cablesmultiples
# 				var_current_number = list(data_dict[index_dict].values())[0]
# 				# Recuperation values par cellule et prendre les lignes dont la premiere colonne est != de nulle
# 				if var_current_number != '':
# 					var_list_val = list(data_dict[index_dict].values())
# 					af_codeext = var_list_val[0]
# 					af_etude = name_file
# 					af_struct = var_list_val[1]
# 					af_inv = self.generalfunctions.function_cond_value_ft(var_list_val[13], 'cond_oui_non_nc')
# 					af_visuel = self.generalfunctions.function_cond_value_ft(var_list_val[2], 'cond_oui_non_nc')
# 					af_vertica = self.generalfunctions.function_cond_value_ft(var_list_val[3], 'cond_oui_non_nc')
# 					af_flambe = self.generalfunctions.function_cond_value_ft(var_list_val[4], 'cond_oui_non_nc')
# 					af_voisin = self.generalfunctions.function_cond_value_ft(var_list_val[5], 'cond_oui_non_nc')
# 					af_pointe = self.generalfunctions.function_cond_value_ft(var_list_val[6], 'cond_oui_non_nc')
# 					af_secouss = self.generalfunctions.function_cond_value_ft(var_list_val[7], 'cond_oui_non_nc')
# 					af_percu = self.generalfunctions.function_cond_value_ft(var_list_val[8], 'cond_oui_non_nc')
# 					af_jaune = self.generalfunctions.function_cond_value_ft(var_list_val[9], 'cond_oui_non_nc')
# 					af_mobilis = self.generalfunctions.function_cond_value_ft(var_list_val[10], 'cond_oui_non_nc')
# 					af_ebp = self.generalfunctions.function_cond_value_ft(var_list_val[20], 'cond_null_so')
# 					af_ras = self.generalfunctions.function_cond_value_ft(var_list_val[21], 'cond_oui_non_nc')
# 					af_cable = '/'.join(dict_name_vable[var_current_number])
# 					af_eta_cap = ''  # ''.join(self.generalfunctions.function_getdict_list(list_dict_color_af_eta_cap) [var_current_number])
# 					af_nat_tvx = var_list_val[18]
# 					af_environ = self.generalfunctions.function_cond_value_ft(var_list_val[11], 'BMP_TER')
# 					af_vois_el = self.generalfunctions.function_cond_value_ft(var_list_val[12], 'cond_null_so')
# 					af_str_tvx = var_list_val[19]
# 					af_dan_apr = ''  # ''.join(self.generalfunctions.function_getdict_list(list_dict_color_af_dan_apr) [var_current_number])
# 					af_com_etl = var_list_val[22]
# 					af_nature_owf = ''
# 					if str(af_nat_tvx).upper() == 'REMPLACEMENT' and str(af_vois_el).upper() != 'SO':
# 						af_nature_owf = "PCOM"
# 					elif str(af_nat_tvx).upper() == 'REMPLACEMENT' and str(af_environ).upper() == 'BMP':
# 						af_nature_owf = 'PMET'
# 					else:
# 						af_nature_owf = "PBOI"
# 					var_list_col_fiche_ft.append(
# 						[af_codeext, af_etude, af_struct, af_inv, af_visuel, af_vertica,
# 						 af_flambe, af_voisin, af_pointe, af_secouss, af_percu, af_jaune,
# 						 af_mobilis, af_ebp, af_ras, af_cable, af_eta_cap, af_nat_tvx,
# 						 af_environ, af_vois_el, af_str_tvx, af_dan_apr, af_com_etl, af_nature_owf])
# 			if len(wb.app.books) == 1:
# 				wb.app.quit()
# 			else:
# 				wb.close()
# 			app.quit()
#
# 		else:
# 			#     0 == Nom Fichier; 1 == reference du modele de dev; 2 == valeur fichier etude
# 			var_list_erreur_model.append([name_file, var_entet_ref, var_entite_file_not_in_ref])
# 			# 0 == var_list_col_fiche_ft; 1 == var_list_erreur_model
# 		# print('-------------------------------------------------')
# 		# print(var_list_col_fiche_ft)
# 		return var_list_col_fiche_ft, var_list_erreur_model
